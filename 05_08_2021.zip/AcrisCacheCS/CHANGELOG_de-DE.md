# 2.0.0
- Kompatibilität mit Shopware 6.4* hergestellt.

# 1.0.2
- Behebt ein Problem beim Löschen des Cache bei neueren Shopware Versionen.

# 1.0.1
- Die benötigte Shopware Version wurde geändert.

# 1.0.0
- Veröffentlichung.
