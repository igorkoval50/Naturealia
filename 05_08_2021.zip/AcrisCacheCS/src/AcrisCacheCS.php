<?php declare(strict_types=1);

namespace Acris\Cache;

use Shopware\Core\Framework\Plugin;

class AcrisCacheCS extends Plugin
{

}
