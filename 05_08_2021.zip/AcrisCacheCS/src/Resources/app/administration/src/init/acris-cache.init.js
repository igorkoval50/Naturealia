import AcrisCacheApiService
    from '../core/service/api/acris-cache.service';

const { Application } = Shopware;

Application.addServiceProvider('AcrisCacheApiService', (container) => {
    const initContainer = Application.getContainer('init');

    return new AcrisCacheApiService(initContainer.httpClient, container.loginService);
});

