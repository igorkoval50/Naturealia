const ApiService = Shopware.Classes.ApiService;

class AcrisCacheApiService extends ApiService {
    constructor(httpClient, loginService, apiEndpoint = 'acris/cache-clear') {
        super(httpClient, loginService, apiEndpoint);
    }

    clearCache() {
        const headers = this.getBasicHeaders();
        return this.httpClient
            .post(this.getApiBasePath(),
                {
                    headers
                }
            )
            .then((response) => {
                return [ ApiService.handleResponse(response), response ];
            });
    }
}
export default AcrisCacheApiService;
