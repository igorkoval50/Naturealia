import './component/structure/sw-page';
import './init/acris-cache.init';
import './component/meteor/sw-meteor-page';

import deDeSnippets from './snippet/de-DE.json';
import enGBSnippets from './snippet/en-GB.json';

Shopware.Locale.extend('de-DE', deDeSnippets);
Shopware.Locale.extend('en-GB', enGBSnippets);

