import template from './sw-page.html.twig';
import './sw-page.scss';

const { Component } = Shopware;
const { Mixin } = Shopware;

Component.override('sw-page', {
    template,

    inject: ['AcrisCacheApiService'],

    mixins: [
        Mixin.getByName('listing'),
        Mixin.getByName('notification'),
        Mixin.getByName('placeholder')
    ],

    methods: {
        onClickClearCache() {
            const titleSaveError = this.$tc('acrisCacheButton.messageErrorTitle');
            const messageSaveError = this.$tc('acrisCacheButton.messageError');
            const titleSaveSuccess = this.$tc('acrisCacheButton.messageSuccessTitle');
            const messageSaveSuccess = this.$tc('acrisCacheButton.messageSuccess');

            this.AcrisCacheApiService.clearCache().then((response) => {
                if (response[1].status === 200) {
                    this.createNotificationSuccess({
                        title: titleSaveSuccess,
                        message: messageSaveSuccess
                    });
                } else {
                    this.createNotificationError({
                        title: titleSaveError,
                        message: messageSaveError
                    });
                }
            });
        }
    }
});
