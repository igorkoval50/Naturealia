<?php

namespace Acris\Cache\Controller;

use Shopware\Core\Framework\Adapter\Cache\CacheClearer;
use Shopware\Core\Framework\Routing\Annotation\RouteScope;
use Shopware\Core\Framework\Context;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @RouteScope(scopes={"api"})
 */
class AcrisCacheClear extends AbstractController
{
    /**
     * @var CacheClearer
     */
    private $cache;

    public function __construct(CacheClearer $cache)
    {
        $this->cache = $cache;
    }

    /**
     * @Route("/api/acris/cache-clear", name="api.action.acris-cache", methods={"POST"})
     */
    public function cacheClear(Request $request, Context $context): JsonResponse
    {
        $this->cache->clear();
        return new JsonResponse(['Cache is successfully cleared!']);
    }
}
