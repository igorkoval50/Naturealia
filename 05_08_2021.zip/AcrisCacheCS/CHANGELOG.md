# 2.0.0
- Improved compatibility with Shopware 6.4*.

# 1.0.2
- Fixes a problem with clearing the cache on newer Shopware versions.

# 1.0.1
- Changed Shopware required version.

# 1.0.0
- Release.
