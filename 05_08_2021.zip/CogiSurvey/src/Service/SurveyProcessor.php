<?php
namespace Cogi\CogiSurvey\Service;

use Cogi\CogiSurvey\CogiSurvey;
use Shopware\Core\Checkout\Customer\CustomerEntity;
use Shopware\Core\Checkout\Order\OrderEntity;
use Shopware\Core\Content\MailTemplate\MailTemplateEntity;
use Shopware\Core\Content\Mail\Service\MailService;
use Shopware\Core\Framework\Api\Context\SystemSource;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Validation\DataBag\DataBag;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;
use Shopware\Core\System\Salutation\SalutationEntity;

class SurveyProcessor {

    /**
     * @var MailService $mailService
     */
    private $mailService;

    /**
     * @var EntityRepositoryInterface $mailTemplateRepository
     */
    private $mailTemplateRepository;

    /**
     * @var EntityRepositoryInterface $salutationRepository
     */
    private $salutationRepository;

    /**
     * @var EntityRepositoryInterface $salesChannelRepository
     */
    private $salesChannelRepository;


    public function __construct
    (
        MailService $mailService,
        EntityRepositoryInterface $mailTemplateRepository,
        EntityRepositoryInterface $salutationRepository
    )
    {
        $this->mailService = $mailService;
        $this->mailTemplateRepository = $mailTemplateRepository;
        $this->salutationRepository = $salutationRepository;
    }

    public function sendMailToCustomer(OrderEntity $order, Context $context)
    {

        try {
            $mailTemplate = $this->getMailTemplate(CogiSurvey::TEMPLATE_TYPE_TECHNICAL_NAME, $context);
        } catch (InconsistentCriteriaIdsException $e) {
            return;
        }

        if ($order === null) {
            return;
        }

        $customer = $order->getOrderCustomer();

        if ($customer === null) {
            return;
        }
        $customer->setSalutation($this->getSalutation($customer->getSalutationId(), $context));
        
        $recipients = [
            $customer->getEmail() => $customer->getFirstName() . ' ' . $customer->getLastName()
        ];

        $this->sendEmail($customer->getCustomer(), $order, $mailTemplate, $order->getSalesChannel(), $recipients);
    }

    private function sendEmail(
        CustomerEntity $customer,
        OrderEntity $order,
        MailTemplateEntity $mailTemplate,
        SalesChannelEntity $salesChannel,
        array $recipients
    ) {
        $context = new Context(new SystemSource());

        $data = new DataBag();

        $data->set('recipients', $recipients);
        $data->set('senderName', $mailTemplate->getTranslation('senderName'));
        $data->set('salesChannelId', $order->getSalesChannelId());

        $data->set('contentHtml', $mailTemplate->getTranslation('contentHtml'));
        $data->set('contentPlain', $mailTemplate->getTranslation('contentPlain'));
        $data->set('subject', $mailTemplate->getTranslation('subject'));

        $this->mailService->send(
            $data->all(),
            $context,
            [
                'customer' => $customer,
                'order' => $order,
                'salesChannel' => $salesChannel
            ]
        );
    }

    private function getMailTemplate(string $technicalName, Context $context): ?MailTemplateEntity {
        // $context = new Context(new SystemSource());

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('mailTemplateType.technicalName', $technicalName));
        $criteria->setLimit(1);

        /** @var MailTemplateEntity|null $mailTemplate */
        $mailTemplate = $this->mailTemplateRepository->search($criteria, $context)->first();

        return $mailTemplate;
    }

    private function getSalutation($salutationId, Context $context): ?SalutationEntity {

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('id', $salutationId));
        $criteria->setLimit(1);

        /** @var SalutationEntity|null $salutation */
        $salutation = $this->salutationRepository->search($criteria, $context)->first();

        return $salutation;
    }

}