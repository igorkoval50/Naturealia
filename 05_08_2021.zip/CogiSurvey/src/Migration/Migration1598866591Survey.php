<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

class Migration1598866591Survey extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return 1598866591;
    }

    public function update(Connection $connection): void
    {
        $connection->executeUpdate('
        CREATE TABLE IF NOT EXISTS `cogi_survey` (
            `id` BINARY(16) NOT NULL,
            `active` TINYINT(1) NOT NULL DEFAULT \'0\',
            `is_required` TINYINT(1) NOT NULL DEFAULT \'0\',
            `answer_type` VARCHAR(255) NOT NULL,
            `position` INT(11) NOT NULL,
            `created_at` DATETIME(3) NOT NULL,
            `updated_at` DATETIME(3) NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ');

        $connection->executeUpdate('
        CREATE TABLE IF NOT EXISTS `cogi_survey_translation` (
            `question` VARCHAR(255) NULL,
            `created_at` DATETIME(3) NOT NULL,
            `updated_at` DATETIME(3) NULL,
            `cogi_survey_id` BINARY(16) NOT NULL,
            `language_id` BINARY(16) NOT NULL,
            PRIMARY KEY (`cogi_survey_id`,`language_id`),
            KEY `fk.cogi_survey_translation.cogi_survey_id` (`cogi_survey_id`),
            KEY `fk.cogi_survey_translation.language_id` (`language_id`),
            CONSTRAINT `fk.cogi_survey_translation.cogi_survey_id` FOREIGN KEY (`cogi_survey_id`) REFERENCES `cogi_survey` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT `fk.cogi_survey_translation.language_id` FOREIGN KEY (`language_id`) REFERENCES `language` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ');

        $connection->executeUpdate('
        CREATE TABLE IF NOT EXISTS `cogi_survey_answer` (
            `id` BINARY(16) NOT NULL,
            `position` INT(11) NOT NULL,
            `active` TINYINT(1) NOT NULL DEFAULT \'0\',
            `answer_count` INT NOT NULL DEFAULT \'0\',
            `survey_id` BINARY(16) NULL,
            `created_at` DATETIME(3) NOT NULL,
            `updated_at` DATETIME(3) NULL,
            PRIMARY KEY (`id`),
            KEY `fk.cogi_survey_answer.survey_id` (`survey_id`),
            CONSTRAINT `fk.cogi_survey_answer.survey_id` FOREIGN KEY (`survey_id`) REFERENCES `cogi_survey` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ');

        $connection->executeUpdate('
        CREATE TABLE IF NOT EXISTS `cogi_survey_answer_translation` (
            `answer` VARCHAR(255) NULL,
            `created_at` DATETIME(3) NOT NULL,
            `updated_at` DATETIME(3) NULL,
            `cogi_survey_answer_id` BINARY(16) NOT NULL,
            `language_id` BINARY(16) NOT NULL,
            PRIMARY KEY (`cogi_survey_answer_id`,`language_id`),
            KEY `fk.cogi_survey_answer_translation.cogi_survey_answer_id` (`cogi_survey_answer_id`),
            KEY `fk.cogi_survey_answer_translation.language_id` (`language_id`),
            CONSTRAINT `fk.cogi_survey_answer_translation.cogi_survey_answer_id` FOREIGN KEY (`cogi_survey_answer_id`) REFERENCES `cogi_survey_answer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT `fk.cogi_survey_answer_translation.language_id` FOREIGN KEY (`language_id`) REFERENCES `language` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ');
    }

    public function updateDestructive(Connection $connection): void
    {
        // implement update destructive
    }
}
