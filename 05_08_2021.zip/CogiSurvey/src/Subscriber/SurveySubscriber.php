<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Subscriber;

use Cogi\CogiSurvey\Core\Content\Survey\SurveyEntity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Sorting\FieldSorting;
use Shopware\Core\Framework\Struct\ArrayEntity;
use Shopware\Storefront\Page\Checkout\Finish\CheckoutFinishPageLoadedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;


class SurveySubscriber implements EventSubscriberInterface
{
    /**
     * @var EntityRepositoryInterface
     */
    private $surveyRepository;
    

    public function __construct(
        EntityRepositoryInterface $surveyRepository)
    {
        $this->surveyRepository = $surveyRepository;
    }

    public static function getSubscribedEvents(): array
    {
        return[
            CheckoutFinishPageLoadedEvent::class => 'onConfirmPageLoaded',
        ];
    }

    public function onConfirmPageLoaded (CheckoutFinishPageLoadedEvent $event): void
    {

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('active', 1));
        $criteria->addSorting(new FieldSorting('cogi_survey.position', FieldSorting::ASCENDING));
        $criteria->getAssociation("answer")->addSorting(new FieldSorting('position'));;

        /** @var SurveyEntity $survey */
        $survey = $this->surveyRepository->search($criteria, $event->getContext())->getElements();

        $array = new ArrayEntity([
            'survey' => $survey
        ]);

        $event->getPage()->addExtension('CogiSurvey', $array);
    }
}
