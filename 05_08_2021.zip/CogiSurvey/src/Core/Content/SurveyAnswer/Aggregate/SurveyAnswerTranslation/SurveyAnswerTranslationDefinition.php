<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\SurveyAnswer\Aggregate\SurveyAnswerTranslation;

use Shopware\Core\Framework\DataAbstractionLayer\EntityTranslationDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\StringField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Cogi\CogiSurvey\Core\Content\SurveyAnswer\SurveyAnswerDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\Required;

class SurveyAnswerTranslationDefinition extends EntityTranslationDefinition
{
    public function getEntityName(): string
    {
        return 'cogi_survey_answer_translation';
    }

    public function getCollectionClass(): string
    {
        return SurveyAnswerTranslationCollection::class;
    }

    public function getEntityClass(): string
    {
        return SurveyAnswerTranslationEntity::class;
    }

    public function getParentDefinitionClass(): string
    {
        return SurveyAnswerDefinition::class;
    }

    protected function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new StringField('answer', 'answer'))->addFlags(new Required())
        ]);
    }
}