<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\SurveyAnswer\Aggregate\SurveyAnswerTranslation;

use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;
use Cogi\CogiSurvey\Core\Content\SurveyAnswer\SurveyAnswerEntity;
use Shopware\Core\System\Language\LanguageEntity;

class SurveyAnswerTranslationEntity extends Entity
{
    use EntityIdTrait;

    /**
     * @var string|null
     */
    protected $answer;

    /**
     * @var \DateTimeInterface
     */
    protected $createdAt;

    /**
     * @var \DateTimeInterface|null
     */
    protected $updatedAt;

    /**
     * @var string
     */
    protected $cogiSurveyAnswerId;

    /**
     * @var string
     */
    protected $languageId;

    /**
     * @var SurveyAnswerEntity|null
     */
    protected $cogiSurveyAnswer;

    /**
     * @var LanguageEntity|null
     */
    protected $language;

    public function getAnswer(): ?string
    {
        return $this->answer;
    }

    public function setAnswer(?string $answer): void
    {
        $this->answer = $answer;
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTimeInterface $updatedAt): void
    {
        $this->updatedAt = $updatedAt;
    }

    public function getCogiSurveyAnswerId(): string
    {
        return $this->cogiSurveyAnswerId;
    }

    public function setCogiSurveyAnswerId(string $cogiSurveyAnswerId): void
    {
        $this->cogiSurveyAnswerId = $cogiSurveyAnswerId;
    }

    public function getLanguageId(): string
    {
        return $this->languageId;
    }

    public function setLanguageId(string $languageId): void
    {
        $this->languageId = $languageId;
    }

    public function getCogiSurveyAnswer(): ?SurveyAnswerEntity
    {
        return $this->cogiSurveyAnswer;
    }

    public function setCogiSurveyAnswer(?SurveyAnswerEntity $cogiSurveyAnswer): void
    {
        $this->cogiSurveyAnswer = $cogiSurveyAnswer;
    }

    public function getLanguage(): ?LanguageEntity
    {
        return $this->language;
    }

    public function setLanguage(?LanguageEntity $language): void
    {
        $this->language = $language;
    }
}