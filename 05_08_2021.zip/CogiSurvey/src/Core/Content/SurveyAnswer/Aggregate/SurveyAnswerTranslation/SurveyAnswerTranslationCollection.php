<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\SurveyAnswer\Aggregate\SurveyAnswerTranslation;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @method void                add(SurveyAnswerTranslationEntity $entity)
 * @method void                set(string $key, SurveyAnswerTranslationEntity $entity)
 * @method SurveyAnswerTranslationEntity[]    getIterator()
 * @method SurveyAnswerTranslationEntity[]    getElements()
 * @method SurveyAnswerTranslationEntity|null get(string $key)
 * @method SurveyAnswerTranslationEntity|null first()
 * @method SurveyAnswerTranslationEntity|null last()
 */
class SurveyAnswerTranslationCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return SurveyAnswerTranslationEntity::class;
    }
}