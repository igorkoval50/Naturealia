<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\SurveyAnswer;

use Cogi\CogiSurvey\Core\Content\Survey\SurveyDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\BoolField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\PrimaryKey;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\Required;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IdField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\TranslationsAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Cogi\CogiSurvey\Core\Content\SurveyAnswer\Aggregate\SurveyAnswerTranslation\SurveyAnswerTranslationDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\FkField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IntField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\ManyToOneAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\TranslatedField;

class SurveyAnswerDefinition extends EntityDefinition
{
    public const ENTITY_NAME = 'cogi_survey_answer';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }

    public function getCollectionClass(): string
    {
        return SurveyAnswerCollection::class;
    }

    public function getEntityClass(): string
    {
        return SurveyAnswerEntity::class;
    }

    protected function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new IdField('id', 'id'))->addFlags(new PrimaryKey(), new Required()),
            (new IntField('position', 'position'))->addFlags(new Required()),
            (new BoolField('active', 'active'))->addFlags(new Required()),
            (new IntField('answer_count', 'answerCount'))->addFlags(new Required()),
            new FkField('survey_id', 'survey_id', SurveyDefinition::class),
            


            new TranslatedField('answer'),

            new ManyToOneAssociationField('survey', 'survey_id', SurveyDefinition::class, 'id', false),
            
            (new TranslationsAssociationField(SurveyAnswerTranslationDefinition::class, 'cogi_survey_answer_id'))
            ->addFlags(new Required()),
        ]);
    }
}