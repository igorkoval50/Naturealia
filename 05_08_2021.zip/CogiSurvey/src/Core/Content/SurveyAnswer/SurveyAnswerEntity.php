<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\SurveyAnswer;

use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;
use Cogi\CogiSurvey\Core\Content\Survey\SurveyEntity;
use Cogi\CogiSurvey\Core\Content\SurveyAnswer\Aggregate\SurveyAnswerTranslation\SurveyAnswerTranslationCollection;

class SurveyAnswerEntity extends Entity
{
    use EntityIdTrait;

    /**
     * @var string
     */
    protected $id;

    /**
     * @var int
     */
    protected $position;

    /**
     * @var bool
     */
    protected $active;

    /**
     * @var int
     */
    protected $answerCount;

    /**
     * @var string|null
     */
    protected $answer;

    /**
     * @var SurveyEntity|null
     */
    protected $survey;

    /**
     * @var SurveyAnswerTranslationCollection
     */
    protected $translations;

    /**
     * @var \DateTimeInterface
     */
    protected $createdAt;

    /**
     * @var \DateTimeInterface|null
     */
    protected $updatedAt;

    /**
     * @var array|null
     */
    protected $translated;

    public function getId(): string
    {
        return $this->id;
    }

    public function setId(string $id): void
    {
        $this->id = $id;
    }

    public function getPosition(): int
    {
        return $this->position;
    }

    public function setPosition(int $position): void
    {
        $this->position = $position;
    }

    public function getActive(): bool
    {
        return $this->active;
    }

    public function setActive(bool $active): void
    {
        $this->active = $active;
    }

    public function getAnswerCount(): int
    {
        return $this->answerCount;
    }

    public function setAnswerCount(int $answerCount): void
    {
        $this->answerCount = $answerCount;
    }

    public function getAnswer(): ?string
    {
        return $this->answer;
    }

    public function setAnswer(?string $answer): void
    {
        $this->answer = $answer;
    }

    public function getSurvey(): ?SurveyEntity
    {
        return $this->survey;
    }

    public function setSurvey(?SurveyEntity $survey): void
    {
        $this->survey = $survey;
    }

    public function getTranslations(): SurveyAnswerTranslationCollection
    {
        return $this->translations;
    }

    public function setTranslations(SurveyAnswerTranslationCollection $translations): void
    {
        $this->translations = $translations;
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTimeInterface $updatedAt): void
    {
        $this->updatedAt = $updatedAt;
    }

    public function getTranslated(): array
    {
        return $this->translated;
    }

    public function setTranslated(array $translated): void
    {
        $this->translated = $translated;
    }
}