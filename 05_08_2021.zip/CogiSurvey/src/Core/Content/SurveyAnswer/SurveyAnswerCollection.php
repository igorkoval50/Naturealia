<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\SurveyAnswer;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @method void              add(SurveyAnswerEntity $entity)
 * @method void              set(string $key, SurveyAnswerEntity $entity)
 * @method SurveyAnswerEntity[]    getIterator()
 * @method SurveyAnswerEntity[]    getElements()
 * @method SurveyAnswerEntity|null get(string $key)
 * @method SurveyAnswerEntity|null first()
 * @method SurveyAnswerEntity|null last()
 */
class SurveyAnswerCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return SurveyAnswerEntity::class;
    }
}