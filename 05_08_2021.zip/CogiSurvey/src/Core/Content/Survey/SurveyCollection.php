<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\Survey;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @method void              add(SurveyEntity $entity)
 * @method void              set(string $key, SurveyEntity $entity)
 * @method SurveyEntity[]    getIterator()
 * @method SurveyEntity[]    getElements()
 * @method SurveyEntity|null get(string $key)
 * @method SurveyEntity|null first()
 * @method SurveyEntity|null last()
 */
class SurveyCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return SurveyEntity::class;
    }
}