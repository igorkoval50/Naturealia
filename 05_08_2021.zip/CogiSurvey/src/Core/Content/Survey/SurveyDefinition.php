<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\Survey;

use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\BoolField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\PrimaryKey;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\Required;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IdField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\TranslationsAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Cogi\CogiSurvey\Core\Content\Survey\Aggregate\SurveyTranslation\SurveyTranslationDefinition;
use Cogi\CogiSurvey\Core\Content\SurveyAnswer\SurveyAnswerDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IntField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToManyAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\StringField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\TranslatedField;

class SurveyDefinition extends EntityDefinition
{
    public const ENTITY_NAME = 'cogi_survey';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }

    public function getCollectionClass(): string
    {
        return SurveyCollection::class;
    }

    public function getEntityClass(): string
    {
        return SurveyEntity::class;
    }

    protected function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new IdField('id', 'id'))->addFlags(new PrimaryKey(), new Required()),
            (new BoolField('active', 'active'))->addFlags(new Required()),
            (new StringField('answer_type', 'answerType'))->addFlags(new Required()),
            (new BoolField('is_required', 'isRequired'))->addFlags(new Required()),
            (new IntField('position', 'position'))->addFlags(new Required()),

            new TranslatedField('question'),

            (new OneToManyAssociationField('answer', SurveyAnswerDefinition::class, 'survey_id', 'id'))->addFlags(),
            
            (new TranslationsAssociationField(SurveyTranslationDefinition::class, 'cogi_survey_id'))
            ->addFlags(new Required()),
        ]);
    }
}