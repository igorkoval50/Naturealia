<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\Survey\Aggregate\SurveyTranslation;

use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;
use Cogi\CogiSurvey\Core\Content\Survey\SurveyEntity;
use Shopware\Core\System\Language\LanguageEntity;

class SurveyTranslationEntity extends Entity
{
    use EntityIdTrait;

    /**
     * @var string|null
     */
    protected $question;

    /**
     * @var \DateTimeInterface
     */
    protected $createdAt;

    /**
     * @var \DateTimeInterface|null
     */
    protected $updatedAt;

    /**
     * @var string
     */
    protected $cogiSurveyId;

    /**
     * @var string
     */
    protected $languageId;

    /**
     * @var SurveyEntity|null
     */
    protected $cogiSurvey;

    /**
     * @var LanguageEntity|null
     */
    protected $language;

    public function getQuestion(): ?string
    {
        return $this->question;
    }

    public function setQuestion(?string $question): void
    {
        $this->question = $question;
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTimeInterface $updatedAt): void
    {
        $this->updatedAt = $updatedAt;
    }

    public function getCogiSurveyId(): string
    {
        return $this->cogiSurveyId;
    }

    public function setCogiSurveyId(string $cogiSurveyId): void
    {
        $this->cogiSurveyId = $cogiSurveyId;
    }

    public function getLanguageId(): string
    {
        return $this->languageId;
    }

    public function setLanguageId(string $languageId): void
    {
        $this->languageId = $languageId;
    }

    public function getCogiSurvey(): ?SurveyEntity
    {
        return $this->cogiSurvey;
    }

    public function setCogiSurvey(?SurveyEntity $cogiSurvey): void
    {
        $this->cogiSurvey = $cogiSurvey;
    }

    public function getLanguage(): ?LanguageEntity
    {
        return $this->language;
    }

    public function setLanguage(?LanguageEntity $language): void
    {
        $this->language = $language;
    }
}