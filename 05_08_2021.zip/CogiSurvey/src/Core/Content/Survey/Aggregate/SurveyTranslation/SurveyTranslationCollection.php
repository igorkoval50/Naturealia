<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\Survey\Aggregate\SurveyTranslation;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @method void                add(SurveyTranslationEntity $entity)
 * @method void                set(string $key, SurveyTranslationEntity $entity)
 * @method SurveyTranslationEntity[]    getIterator()
 * @method SurveyTranslationEntity[]    getElements()
 * @method SurveyTranslationEntity|null get(string $key)
 * @method SurveyTranslationEntity|null first()
 * @method SurveyTranslationEntity|null last()
 */
class SurveyTranslationCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return SurveyTranslationEntity::class;
    }
}