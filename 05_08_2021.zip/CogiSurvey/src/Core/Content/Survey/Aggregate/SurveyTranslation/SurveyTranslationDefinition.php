<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Core\Content\Survey\Aggregate\SurveyTranslation;

use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\Required;
use Cogi\CogiSurvey\Core\Content\Survey\SurveyDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityTranslationDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\StringField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;

class SurveyTranslationDefinition extends EntityTranslationDefinition
{
    public function getEntityName(): string
    {
        return 'cogi_survey_translation';
    }

    public function getCollectionClass(): string
    {
        return SurveyTranslationCollection::class;
    }

    public function getEntityClass(): string
    {
        return SurveyTranslationEntity::class;
    }

    public function getParentDefinitionClass(): string
    {
        return SurveyDefinition::class;
    }

    protected function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new StringField('question', 'question'))->addFlags(new Required())
        ]);
    }
}