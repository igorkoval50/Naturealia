<?php declare(strict_types=1);

namespace Cogi\CogiSurvey\Storefront\Controller;

use Cogi\CogiSurvey\Service\SurveyProcessor;
use Shopware\Core\Checkout\Order\OrderEntity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Routing\Annotation\RouteScope;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Controller\StorefrontController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Sorting\FieldSorting;

/**
 * @RouteScope(scopes={"storefront"})
 */
class SurveyController extends StorefrontController
{

    /**
     * @var EntityRepositoryInterface
     */
    private $surveyRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $orderCustomerRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $surveyAnswerRepository;

    /**
     * @var SurveyProcessor
     */
    private $surveyProcessor;

    /**
     * SurveyController constructor.
     * @param EntityRepositoryInterface $surveyRepository
     * @param EntityRepositoryInterface $orderCustomerRepository
     * @param EntityRepositoryInterface $orderRepository
     * @param EntityRepositoryInterface $surveyAnswerRpository
     * @param SurveyProcessor $surveyProcessor
     */
    public function __construct(
        EntityRepositoryInterface $surveyRepository,
        EntityRepositoryInterface $orderCustomerRepository,
        EntityRepositoryInterface $orderRepository,
        EntityRepositoryInterface $surveyAnswerRpository,
        SurveyProcessor $surveyProcessor
    ) {
        $this->surveyRepository = $surveyRepository;
        $this->orderCustomerRepository = $orderCustomerRepository;
        $this->orderRepository = $orderRepository;
        $this->surveyAnswerRepository = $surveyAnswerRpository;
        $this->surveyProcessor = $surveyProcessor;
    }

    /**
     * @Route("/checkout/finish", name="frontend.survey.send", methods={"POST"}, defaults={"csrf_protected"=true})
     */
    public function sendSurvey(Request $request, SalesChannelContext $salesChannelContext, Context $context)
    {
        $activeCustomerId = $salesChannelContext->getCustomer()->getId();

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('active', 1));
        $criteria->addSorting(new FieldSorting('position', FieldSorting::ASCENDING));
        $survey = $this->surveyRepository->search($criteria, $context);
        $surveyElements= $survey->getElements();

        $answerCriteria = new Criteria();
        $answerCriteria->addAssociation('survey');
        $answerCriteria->addFilter(new EqualsFilter('active', 1));
        $surveyAnswer = $this->surveyAnswerRepository->search($answerCriteria, $context);

        $orderCustomerCriteria = new Criteria();
        $orderCustomerCriteria->addFilter(new EqualsFilter('customerId', $activeCustomerId));
        $orderCustomerCriteria->addSorting(new FieldSorting('createdAt', FieldSorting::DESCENDING));
        $orderCustomer = $this->orderCustomerRepository->search($orderCustomerCriteria, $context)->getEntities();

        $orderCriteria = new Criteria();
        $orderCriteria->getAssociation('orderCustomer')->addFilter(new EqualsFilter('customerId', $activeCustomerId))->getAssociation('customer')->getAssociation('salutation');
        $orderCriteria->getAssociation('salesChannel');
        $orderCriteria->addSorting(new FieldSorting('createdAt', FieldSorting::DESCENDING));
        $order = $this->orderRepository->search($orderCriteria, $context)->getEntities();

        $result = [];

        $array = [];
        $counter = 0;

        foreach ($surveyElements as $key => $value) {
            $counter++;
            array_push($array, [$value]);
        };

        $arrayAnswer = [];
        $counter = 0;

        foreach ($surveyAnswer->getElements() as $key => $value) {
            $counter++;
            array_push($arrayAnswer, [$value]);
        };

        $arrayOrders = [];
        $counter = 0;

        foreach ($orderCustomer as $key => $value) {
            $counter++;
            array_push($arrayOrders, [$value]);
        };

        $customersLastOrderId = $arrayOrders[0][0]->getOrderId();

        $criteria = new Criteria();
        $criteria->setLimit(1)
            ->addFilter(new EqualsFilter("id", $customersLastOrderId));

        /** @var OrderEntity $activeOrder */
        $activeOrder = $this->orderRepository->search($criteria, $context)->getEntities()->first();

        $activeOrderCustomFields = $activeOrder->getCustomFields();

        for ($i=0; $i < $survey->getTotal(); $i++) {
            $t = $i + 1;

            for ($j=0; $j < $surveyAnswer->getTotal(); $j++) {
                if($array[$i][0]->getId() == $arrayAnswer[$j][0]->getSurvey()->getId() && $request->get('answer-' . $t) == $arrayAnswer[$j][0]->getTranslated()['answer'])
                {

                    if (!isset($activeOrderCustomFields)){

                        $count = $arrayAnswer[$j][0]->getAnswerCount() + 1;

                        $this->surveyAnswerRepository->upsert([[
                            'id' => $arrayAnswer[$j][0]->getId(),
                            'answerCount' => $count 
                        ]], $context);
                    }
                };
            };
            
            array_push($result,[
                'question' => $array[$i][0]->getTranslated()["question"],
                'answer' => ($request->get('answer-' . $t) != null | $request->get('answer-' . $t) != "" ? $request->get('answer-' . $t) : $request->get('answer-' . $t) . "-"),
                'answer_type' => $array[$i][0]->getAnswerType()
            ]);
        }

        /** @var int $alert */
        $alert = 0;

        if(isset($activeOrderCustomFields['survey_result'])){
            $alert = 1;
        } else {
            $alert = 2;
        };

        // Die Umfrageergebnisse dem Orderrepository in CustomFileds hinzufügen
        $this->orderRepository->upsert([[
            'id' => $customersLastOrderId,
            'customFields' => ['survey_result' => [
                $result
            ]]
        ]], $context);

        //senden der E-Mail zum Customer, wenn noch keine E-Mail raus ist
        if (!isset($order->first()->getCustomFields()['survey_result']))
        {
            $this->surveyProcessor->sendMailToCustomer($order->first(), $context);
        } else {
            $alert = 1;
        }

        return $this->forwardToRoute(
            'frontend.checkout.finish.page',
            [
                'orderId' => $customersLastOrderId, 
                'alert' => $alert
            ]
        );
    }
}