<?php declare(strict_types=1);

namespace DreiscSeoPro\Command\BulkGenerator;

use Doctrine\DBAL\Connection;
use DreiscSeoPro\Core\BulkGenerator\CategoryGenerator;
use DreiscSeoPro\Core\BulkGenerator\TemplateGenerator\Exception\ReferenceEntityNotFoundException;
use DreiscSeoPro\Core\Foundation\Command\AbstractIteratorProgressCommand;
use DreiscSeoPro\Core\Foundation\Dal\Iterator\IteratorFactory;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Exception\UnknownAreaException;
use Shopware\Core\Content\Category\CategoryDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Dbal\Common\IterableQuery;
use Shopware\Core\Framework\DataAbstractionLayer\DefinitionInstanceRegistry;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class CategoryCommand extends AbstractIteratorProgressCommand
{
    /**
     * @var Connection
     */
    protected $connection;

    /**
     * @var DefinitionInstanceRegistry
     */
    protected $definitionInstanceRegistry;

    /**
     * @var CategoryGenerator
     */
    protected $categoryGenerator;

    /**
     * @var IteratorFactory
     */
    protected $iteratorFactory;

    /**
     * @var bool
     */
    protected $enableTimeLimit = false;

    /**
     * @param Connection $connection
     * @param DefinitionInstanceRegistry $definitionInstanceRegistry
     * @param CategoryGenerator $categoryGenerator
     * @param IteratorFactory $iteratorFactory
     */
    public function __construct(Connection $connection, DefinitionInstanceRegistry $definitionInstanceRegistry, CategoryGenerator $categoryGenerator, IteratorFactory $iteratorFactory)
    {
        $this->connection = $connection;
        $this->definitionInstanceRegistry = $definitionInstanceRegistry;
        $this->categoryGenerator = $categoryGenerator;
        $this->iteratorFactory = $iteratorFactory;

        parent::__construct();
    }

    public static function createOrderByStructs(): array
    {
        return [
            new IteratorFactory\Struct\OrderByStruct('level'),
            new IteratorFactory\Struct\OrderByStruct('auto_increment')
        ];
    }

    protected function configure() :void
    {
        $this->setName('dreisc-seo:bulk-generator:category')
            ->setDescription('Starts the generation of the category bulk templates');
    }

    protected function getIterator(): IterableQuery
    {
        return $this->iteratorFactory->createIdIterator(
            new IteratorFactory\Struct\IteratorFactoryStruct(
                CategoryDefinition::class,
                0,
                $this->interval,
                self::createOrderByStructs()
            )
        );
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @param array $ids
     * @throws ReferenceEntityNotFoundException
     * @throws InconsistentCriteriaIdsException
     * @throws UnknownAreaException
     */
    protected function runProgress(InputInterface $input, OutputInterface $output, array $ids): void
    {
        /** Generates the category bulk settings */
        $this->categoryGenerator->generate($ids);
    }
}
