<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\RobotsTag;

use DreiscSeoPro\Core\CustomSetting\Struct\CustomSettingStruct;
use DreiscSeoPro\Core\Foundation\Struct\DefaultStruct;
use RuntimeException;
use Shopware\Core\Content\Category\CategoryDefinition;
use Shopware\Core\Content\Product\ProductDefinition;

class RobotsTagFetcherStruct extends DefaultStruct
{
    const POSSIBLE_ENTITY_NAMES = [
        ProductDefinition::ENTITY_NAME,
        CategoryDefinition::ENTITY_NAME
    ];

    /**
     * @var CustomSettingStruct
     */
    protected $customSetting;

    /**
     * @var string
     */
    protected $entityName;

    /**
     * @var string
     */
    protected $entityId;

    /**
     * @var string
     */
    protected $languageId;

    /**
     * @var array|null
     */
    protected $requestParams;

    /**
     * @param CustomSettingStruct $customSetting
     * @param string $entityName
     * @param string $entityId
     * @param string $languageId
     */
    public function __construct(CustomSettingStruct $customSetting, string $entityName, string $entityId, string $languageId, ?array $requestParams)
    {
        $this->customSetting = $customSetting;
        $this->entityId = $entityId;
        $this->languageId = $languageId;
        $this->requestParams = $requestParams;

        $this->setEntityName($entityName);
    }

    /**
     * @return CustomSettingStruct
     */
    public function getCustomSetting(): CustomSettingStruct
    {
        return $this->customSetting;
    }

    /**
     * @param CustomSettingStruct $customSetting
     * @return RobotsTagFetcherStruct
     */
    public function setCustomSetting(CustomSettingStruct $customSetting): RobotsTagFetcherStruct
    {
        $this->customSetting = $customSetting;
        return $this;
    }

    /**
     * @return string
     */
    public function getEntityName(): string
    {
        return $this->entityName;
    }

    /**
     * @param string $entityName
     * @return $this
     */
    public function setEntityName(string $entityName): RobotsTagFetcherStruct
    {
        if (!in_array($entityName, self::POSSIBLE_ENTITY_NAMES, true)) {
            throw new RuntimeException('Invalid entity name: ' . $entityName);
        }

        $this->entityName = $entityName;

        return $this;
    }

    /**
     * @return string
     */
    public function getEntityId(): string
    {
        return $this->entityId;
    }

    /**
     * @param string $entityId
     * @return RobotsTagFetcherStruct
     */
    public function setEntityId(string $entityId): RobotsTagFetcherStruct
    {
        $this->entityId = $entityId;
        return $this;
    }

    /**
     * @return string
     */
    public function getLanguageId(): string
    {
        return $this->languageId;
    }

    /**
     * @param string $languageId
     * @return RobotsTagFetcherStruct
     */
    public function setLanguageId(string $languageId): RobotsTagFetcherStruct
    {
        $this->languageId = $languageId;

        return $this;
    }

    /**
     * @return array|null
     */
    public function getRequestParams(): ?array
    {
        return $this->requestParams;
    }

    /**
     * @param array|null $requestParams
     * @return RobotsTagFetcherStruct
     */
    public function setRequestParams(?array $requestParams): RobotsTagFetcherStruct
    {
        $this->requestParams = $requestParams;

        return $this;
    }
}
