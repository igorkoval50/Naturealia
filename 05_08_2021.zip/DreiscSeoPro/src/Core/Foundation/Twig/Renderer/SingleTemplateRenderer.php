<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Foundation\Twig\Renderer;

use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Error\SyntaxError;
use Twig\Loader\ArrayLoader;
use Twig\Loader\LoaderInterface;

class SingleTemplateRenderer extends Renderer
{
    const TEMPLATE_KEY = 'twigTemplate';

    /**
     * @var string
     */
    private $template;

    /**
     * @var ArrayLoader
     */
    private $arrayLoader = null;

    /**
     * @param string $template
     */
    public function __construct(string $template)
    {
        $this->template = $template;
    }

    /**
     * @return LoaderInterface
     */
    public function getLoader(): LoaderInterface
    {
        if (null === $this->arrayLoader) {
            $this->arrayLoader = new ArrayLoader([
                self::TEMPLATE_KEY => $this->template
            ]);
        }

        return $this->arrayLoader;
    }

    /**
     * @param null $name
     * @return string
     * @throws LoaderError
     * @throws RuntimeError
     * @throws SyntaxError
     */
    public function render($name = null): string
    {
        return $this->getEnvironment()->render(
            self::TEMPLATE_KEY,
            $this->getContext()
        );
    }
}
