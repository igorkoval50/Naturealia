<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Foundation\CustomSettingEntity;

use DreiscSeoPro\Core\Foundation\Dal\EntityRepository;
use DreiscSeoPro\Core\Foundation\Struct\DefaultStruct;

class CustomSettingEntityStruct extends DefaultStruct
{
    /**
     * @var EntityRepository
     */
    protected $entityRepository;

    /**
     * @var string
     */
    protected $salesChannelId;

    /**
     * @var bool
     */
    protected $mergeDefaultToSalesChannel;

    /**
     * @var string
     */
    protected $keyField;

    /**
     * @var string
     */
    protected $valueField;

    /**
     * @var string
     */
    protected $salesChannelIdField;

    /**
     * @param EntityRepository $entityRepository
     * @param string|null $salesChannelId
     * @param bool $mergeDefaultToSalesChannel
     * @param string $keyField
     * @param string $valueField
     * @param string $salesChannelIdField
     */
    public function __construct(EntityRepository $entityRepository, string $salesChannelId = null, bool $mergeDefaultToSalesChannel = false, $keyField = 'key', $valueField = 'value', $salesChannelIdField = 'salesChannelId')
    {
        $this->entityRepository = $entityRepository;
        $this->salesChannelId = $salesChannelId;
        $this->mergeDefaultToSalesChannel = $mergeDefaultToSalesChannel;
        $this->keyField = $keyField;
        $this->valueField = $valueField;
        $this->salesChannelIdField = $salesChannelIdField;
    }

    /**
     * @return EntityRepository
     */
    public function getEntityRepository(): EntityRepository
    {
        return $this->entityRepository;
    }

    /**
     * @param EntityRepository $entityRepository
     * @return CustomSettingEntityStruct
     */
    public function setEntityRepository(EntityRepository $entityRepository): CustomSettingEntityStruct
    {
        $this->entityRepository = $entityRepository;

        return $this;
    }

    /**
     * @return string
     */
    public function getSalesChannelId(): ?string
    {
        return $this->salesChannelId;
    }

    /**
     * @param string $salesChannelId
     * @return CustomSettingEntityStruct
     */
    public function setSalesChannelId(?string $salesChannelId): CustomSettingEntityStruct
    {
        $this->salesChannelId = $salesChannelId;

        return $this;
    }

    /**
     * @return bool
     */
    public function isMergeDefaultToSalesChannel(): bool
    {
        return $this->mergeDefaultToSalesChannel;
    }

    /**
     * @param bool $mergeDefaultToSalesChannel
     * @return \DreiscSeoPro\Core\Foundation\CustomSettingEntity\CustomSettingEntityStruct
     */
    public function setMergeDefaultToSalesChannel(bool $mergeDefaultToSalesChannel): CustomSettingEntityStruct
    {
        $this->mergeDefaultToSalesChannel = $mergeDefaultToSalesChannel;
        return $this;
    }

    /**
     * @return string
     */
    public function getKeyField(): string
    {
        return $this->keyField;
    }

    /**
     * @param string $keyField
     * @return CustomSettingEntityStruct
     */
    public function setKeyField(string $keyField): CustomSettingEntityStruct
    {
        $this->keyField = $keyField;

        return $this;
    }

    /**
     * @return string
     */
    public function getValueField(): string
    {
        return $this->valueField;
    }

    /**
     * @param string $valueField
     * @return CustomSettingEntityStruct
     */
    public function setValueField(string $valueField): CustomSettingEntityStruct
    {
        $this->valueField = $valueField;

        return $this;
    }

    /**
     * @return string
     */
    public function getSalesChannelIdField(): string
    {
        return $this->salesChannelIdField;
    }

    /**
     * @param string $salesChannelIdField
     * @return CustomSettingEntityStruct
     */
    public function setSalesChannelIdField(string $salesChannelIdField): CustomSettingEntityStruct
    {
        $this->salesChannelIdField = $salesChannelIdField;

        return $this;
    }
}
