<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Foundation\Dal\Iterator\IteratorFactory\Struct;

use DreiscSeoPro\Core\Foundation\Struct\DefaultStruct;
use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;

class IteratorFactoryStruct extends DefaultStruct
{
    const ORDER_BY__DISABLED = 'disabled';
    const ORDER_BY__AUTO_INCREMENT = 'auto_increment';

    /**
     * @var string
     */
    private $entityDefinitionClass;

    /**
     * @var int
     */
    private $offset;

    /**
     * @var int
     */
    private $limit;

    /**
     * @var OrderByStruct[]
     */
    private $orderByStructs;

    /**
     * @var string
     */
    private $idField;

    /**
     * @param string $entityDefinitionClass
     * @param int $offset
     * @param int $limit
     * @param OrderByStruct[] $orderByStructs
     * @param string $idField
     */
    public function __construct(string $entityDefinitionClass, int $offset = 0, int $limit = 50, array $orderByStructs = [], string $idField = 'id')
    {
        $this->entityDefinitionClass = $entityDefinitionClass;
        $this->offset = $offset;
        $this->limit = $limit;
        $this->orderByStructs = $orderByStructs;
        $this->idField = $idField;
    }

    /**
     * @return string
     */
    public function getEntityDefinitionClass(): string
    {
        return $this->entityDefinitionClass;
    }

    /**
     * @param string $entityDefinitionClass
     * @return IteratorFactoryStruct
     */
    public function setEntityDefinitionClass(string $entityDefinitionClass): IteratorFactoryStruct
    {
        $this->entityDefinitionClass = $entityDefinitionClass;
        return $this;
    }

    /**
     * @return int
     */
    public function getOffset(): int
    {
        return $this->offset;
    }

    /**
     * @param int $offset
     * @return IteratorFactoryStruct
     */
    public function setOffset(int $offset): IteratorFactoryStruct
    {
        $this->offset = $offset;
        return $this;
    }

    /**
     * @return int
     */
    public function getLimit(): int
    {
        return $this->limit;
    }

    /**
     * @param int $limit
     * @return IteratorFactoryStruct
     */
    public function setLimit(int $limit): IteratorFactoryStruct
    {
        $this->limit = $limit;
        return $this;
    }

    /**
     * @return OrderByStruct[]
     */
    public function getOrderByStructs(): array
    {
        return $this->orderByStructs;
    }

    /**
     * @param OrderByStruct[] $orderByStructs
     * @return IteratorFactoryStruct
     */
    public function setOrderByStructs(array $orderByStructs): IteratorFactoryStruct
    {
        $this->orderByStructs = $orderByStructs;
        return $this;
    }

    /**
     * @return string
     */
    public function getIdField(): string
    {
        return $this->idField;
    }

    /**
     * @param string $idField
     * @return IteratorFactoryStruct
     */
    public function setIdField(string $idField): IteratorFactoryStruct
    {
        $this->idField = $idField;
        return $this;
    }
}
