<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Foundation\Dal\Iterator\IteratorFactory\Struct;

use DreiscSeoPro\Core\Foundation\Struct\DefaultStruct;

class OrderByStruct extends DefaultStruct
{
    public const ORDER__ASC = 'ASC';
    public const ORDER__DESC = 'DESC';

    /**
     * @var string
     */
    protected $field;

    /**
     * @var string
     */
    protected $order;

    /**
     * @param string $field
     * @param string $order
     */
    public function __construct(string $field, string $order = self::ORDER__ASC)
    {
        $this->field = $field;
        $this->order = $order;
    }

    /**
     * @return string
     */
    public function getField(): string
    {
        return $this->field;
    }

    /**
     * @param string $field
     * @return OrderByStruct
     */
    public function setField(string $field): OrderByStruct
    {
        $this->field = $field;
        return $this;
    }

    /**
     * @return string
     */
    public function getOrder(): string
    {
        return $this->order;
    }

    /**
     * @param string $order
     * @return OrderByStruct
     */
    public function setOrder(string $order): OrderByStruct
    {
        $this->order = $order;
        return $this;
    }
}
