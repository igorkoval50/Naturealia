<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Foundation\Seo\Struct;

use DreiscSeoPro\Core\Foundation\Struct\DefaultStruct;
use Shopware\Core\Framework\Struct\Struct;
use Shopware\Core\System\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainEntity;

class SeoUrlParserResultStruct extends DefaultStruct
{
    /**
     * @var SalesChannelDomainEntity|null
     */
    private $salesChannelDomainEntity;

    /**
     * @var string|null
     */
    private $baseUrl;

    /**
     * @param SalesChannelDomainEntity|null $salesChannelDomainEntity
     * @param string|null $baseUrl
     */
    public function __construct(?SalesChannelDomainEntity $salesChannelDomainEntity = null, ?string $baseUrl = null)
    {
        $this->salesChannelDomainEntity = $salesChannelDomainEntity;
        $this->baseUrl = $baseUrl;
    }

    /**
     * @return SalesChannelDomainEntity|null
     */
    public function getSalesChannelDomainEntity(): ?SalesChannelDomainEntity
    {
        return $this->salesChannelDomainEntity;
    }

    /**
     * @param SalesChannelDomainEntity|null $salesChannelDomainEntity
     * @return SeoUrlParserResultStruct
     */
    public function setSalesChannelDomainEntity(?SalesChannelDomainEntity $salesChannelDomainEntity): SeoUrlParserResultStruct
    {
        $this->salesChannelDomainEntity = $salesChannelDomainEntity;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getBaseUrl(): ?string
    {
        return $this->baseUrl;
    }

    /**
     * @param string|null $baseUrl
     * @return SeoUrlParserResultStruct
     */
    public function setBaseUrl(?string $baseUrl): SeoUrlParserResultStruct
    {
        $this->baseUrl = $baseUrl;
        return $this;
    }
}
