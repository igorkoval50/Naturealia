<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Foundation\Seo;

use RuntimeException;
use Shopware\Core\Content\Category\CategoryEntity;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Content\Seo\SeoUrl\SeoUrlEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\MultiFilter;
use Shopware\Core\System\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainEntity;

class SeoUrlAssembler
{
    public const IS_SEO_URL = 'isSeoUrl';
    public const TECHNICAL_PATH_INFO = 'technicalPathInfo';
    public const PATH_INFO = 'pathInfo';
    public const ABSOLUTE_PATHS = 'absolutePaths';

    /**
     * @var EntityRepositoryInterface
     */
    private $seoUrlRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $salesChannelDomainRepository;

    /**
     * @param EntityRepositoryInterface $seoUrlRepository
     * @param EntityRepositoryInterface $salesChannelDomainRepository
     */
    public function __construct(EntityRepositoryInterface $seoUrlRepository, EntityRepositoryInterface $salesChannelDomainRepository)
    {
        $this->seoUrlRepository = $seoUrlRepository;
        $this->salesChannelDomainRepository = $salesChannelDomainRepository;
    }

    /**
     * Determined the url info of the given entity
     *
     * @param Entity $entity
     * @param string $salesChannelId
     * @param string $languageId
     * @return array
     * @throws InconsistentCriteriaIdsException
     */
    public function assemble(Entity $entity, string $salesChannelId, string $languageId): array
    {
        /** Fetch the path info */
        switch (true) {
            case $entity instanceof ProductEntity:
                $pathInfo = $this->getProductPathInfo($entity);
                break;

            case $entity instanceof CategoryEntity:
                $pathInfo = $this->getCategoryPathInfo($entity);
                break;

            default:
                throw new RuntimeException('Unknown entity: ' . get_class($entity));
        }

        /** Add the technical url to the result array */
        $urlInfo[self::TECHNICAL_PATH_INFO] = $pathInfo;

        /** Set fallback values */
        $urlInfo[self::PATH_INFO] = $urlInfo[self::TECHNICAL_PATH_INFO];
        $urlInfo[self::IS_SEO_URL] = false;

        /** Try to find the seo url */
        /** @var SeoUrlEntity $seoUrlEntity */
        $seoUrlEntity = $this->seoUrlRepository->search(
            (new Criteria())
                ->setLimit(1)
                ->addFilter(
                    new MultiFilter(
                        MultiFilter::CONNECTION_AND,
                        [
                            new EqualsFilter('salesChannelId', $salesChannelId),
                            new EqualsFilter('languageId', $languageId),
                            new EqualsFilter('pathInfo', $urlInfo['technicalPathInfo']),
                            new EqualsFilter('isDeleted', false),
                            new EqualsFilter('isCanonical', true)
                        ]
                    )
                ),
            Context::createDefaultContext()
        )->first();

        if(null === $seoUrlEntity) {
            return $this->fetchAbsolutePaths($urlInfo, $salesChannelId, $languageId);
        }

        /** Add additional values */
        $urlInfo[self::IS_SEO_URL] = true;
        $urlInfo[self::PATH_INFO] = $seoUrlEntity->getSeoPathInfo();

        return $this->fetchAbsolutePaths($urlInfo, $salesChannelId, $languageId);
    }

    /**
     * @param ProductEntity $productEntity
     * @return string
     */
    protected function getProductPathInfo(ProductEntity $productEntity): string
    {
        return sprintf(
            '/detail/%s',
            $productEntity->getId()
        );
    }

    /**
     * @param CategoryEntity $categoryEntity
     * @return string
     */
    protected function getCategoryPathInfo(CategoryEntity $categoryEntity): string
    {
        return sprintf(
            '/navigation/%s',
            $categoryEntity->getId()
        );
    }

    protected function fetchAbsolutePaths(array $urlInfo, string $salesChannelId, string $languageId)
    {
        $absolutePaths = [];

        /** Fetch all sales channel domains for the given sales channel and language */
        $searchResult = $this->salesChannelDomainRepository->search(
            (new Criteria())
                ->addFilter(
                    new MultiFilter(
                        MultiFilter::CONNECTION_AND,
                        [
                            new EqualsFilter('salesChannelId', $salesChannelId),
                            new EqualsFilter('languageId', $languageId)
                        ]
                    )
                ),
            Context::createDefaultContext()
        );

        /** @var SalesChannelDomainEntity $salesChannelDomain */
        foreach($searchResult->getEntities() as $salesChannelDomain) {
            $url = rtrim($salesChannelDomain->getUrl(), '/');
            $pathInfo = ltrim($urlInfo[self::PATH_INFO], '/');

            $absolutePaths[$salesChannelDomain->getId()] = sprintf(
                '%s/%s',
                $url,
                $pathInfo
            );
        }

        $urlInfo[self::ABSOLUTE_PATHS] = $absolutePaths;

        return $urlInfo;
    }
}
