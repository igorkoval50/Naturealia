<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Foundation\Context\ContextFactory\Struct;

use DreiscSeoPro\Core\Foundation\Struct\DefaultStruct;
use Shopware\Core\Framework\Api\Context\ContextSource;

class ContextStruct extends DefaultStruct
{
    /**
     * @var ContextSource|null
     */
    protected $contextSource = null;

    /**
     * @var array|null
     */
    protected $ruleIds = null;

    /**
     * @var string|null
     */
    protected $currencyId = null;

    /**
     * @var array|null
     */
    protected $languageIdChain = null;

    /**
     * @var string|null
     */
    protected $versionId = null;

    /**
     * @var float|null
     */
    protected $currencyFactor = null;

    /**
     * @var bool|null
     */
    protected $considerInheritance = null;

    /**
     * @var string|null
     */
    protected $taxState = null;

    /**
     * @return ContextSource|null
     */
    public function getContextSource(): ?ContextSource
    {
        return $this->contextSource;
    }

    /**
     * @param ContextSource|null $contextSource
     * @return ContextStruct
     */
    public function setContextSource(?ContextSource $contextSource): ContextStruct
    {
        $this->contextSource = $contextSource;
        return $this;
    }

    /**
     * @return array|null
     */
    public function getRuleIds(): ?array
    {
        return $this->ruleIds;
    }

    /**
     * @param array|null $ruleIds
     * @return ContextStruct
     */
    public function setRuleIds(?array $ruleIds): ContextStruct
    {
        $this->ruleIds = $ruleIds;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getCurrencyId(): ?string
    {
        return $this->currencyId;
    }

    /**
     * @param string|null $currencyId
     * @return ContextStruct
     */
    public function setCurrencyId(?string $currencyId): ContextStruct
    {
        $this->currencyId = $currencyId;
        return $this;
    }

    /**
     * @return array|null
     */
    public function getLanguageIdChain(): ?array
    {
        return $this->languageIdChain;
    }

    /**
     * @param array|null $languageIdChain
     * @return ContextStruct
     */
    public function setLanguageIdChain(?array $languageIdChain): ContextStruct
    {
        $this->languageIdChain = $languageIdChain;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getVersionId(): ?string
    {
        return $this->versionId;
    }

    /**
     * @param string|null $versionId
     * @return ContextStruct
     */
    public function setVersionId(?string $versionId): ContextStruct
    {
        $this->versionId = $versionId;
        return $this;
    }

    /**
     * @return float|null
     */
    public function getCurrencyFactor(): ?float
    {
        return $this->currencyFactor;
    }

    /**
     * @param float|null $currencyFactor
     * @return ContextStruct
     */
    public function setCurrencyFactor(?float $currencyFactor): ContextStruct
    {
        $this->currencyFactor = $currencyFactor;
        return $this;
    }

    /**
     * @return bool|null
     */
    public function getConsiderInheritance(): ?bool
    {
        return $this->considerInheritance;
    }

    /**
     * @param bool|null $considerInheritance
     * @return ContextStruct
     */
    public function setConsiderInheritance(?bool $considerInheritance): ContextStruct
    {
        $this->considerInheritance = $considerInheritance;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getTaxState(): ?string
    {
        return $this->taxState;
    }

    /**
     * @param string|null $taxState
     * @return ContextStruct
     */
    public function setTaxState(?string $taxState): ContextStruct
    {
        $this->taxState = $taxState;
        return $this;
    }
}
