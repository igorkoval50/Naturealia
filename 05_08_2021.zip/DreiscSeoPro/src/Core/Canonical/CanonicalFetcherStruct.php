<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Canonical;

use DreiscSeoPro\Core\CustomSetting\Struct\CustomSettingStruct;
use DreiscSeoPro\Core\Foundation\Struct\DefaultStruct;
use RuntimeException;
use Shopware\Core\Content\Category\CategoryDefinition;
use Shopware\Core\Content\Product\ProductDefinition;

class CanonicalFetcherStruct extends DefaultStruct
{
    const POSSIBLE_ENTITY_NAMES = [
        ProductDefinition::ENTITY_NAME,
        CategoryDefinition::ENTITY_NAME
    ];

    /**
     * @var string
     */
    protected $entityName;

    /**
     * @var string
     */
    protected $entityId;

    /**
     * @var string
     */
    protected $languageId;

    /**
     * @var string
     */
    protected $salesChannelId;

    /**
     * @var string
     */
    protected $salesChannelDomainId;

    /**
     * @param string $entityName
     * @param string $entityId
     * @param string $languageId
     * @param string $salesChannelId
     */
    public function __construct(string $entityName, string $entityId, string $languageId, string $salesChannelId, string $salesChannelDomainId)
    {
        $this->entityId = $entityId;
        $this->languageId = $languageId;
        $this->salesChannelId = $salesChannelId;
        $this->salesChannelDomainId = $salesChannelDomainId;

        $this->setEntityName($entityName);
    }

    /**
     * @return string
     */
    public function getEntityName(): string
    {
        return $this->entityName;
    }

    /**
     * @param string $entityName
     * @return CanonicalFetcherStruct
     */
    public function setEntityName(string $entityName): CanonicalFetcherStruct
    {
        if (!in_array($entityName, self::POSSIBLE_ENTITY_NAMES, true)) {
            throw new RuntimeException('Invalid entity name: ' . $entityName);
        }

        $this->entityName = $entityName;

        return $this;
    }

    /**
     * @return string
     */
    public function getEntityId(): string
    {
        return $this->entityId;
    }

    /**
     * @param string $entityId
     * @return CanonicalFetcherStruct
     */
    public function setEntityId(string $entityId): CanonicalFetcherStruct
    {
        $this->entityId = $entityId;

        return $this;
    }

    /**
     * @return string
     */
    public function getLanguageId(): string
    {
        return $this->languageId;
    }

    /**
     * @param string $languageId
     * @return CanonicalFetcherStruct
     */
    public function setLanguageId(string $languageId): CanonicalFetcherStruct
    {
        $this->languageId = $languageId;

        return $this;
    }

    /**
     * @return string
     */
    public function getSalesChannelId(): string
    {
        return $this->salesChannelId;
    }

    /**
     * @param string $salesChannelId
     * @return CanonicalFetcherStruct
     */
    public function setSalesChannelId(string $salesChannelId): CanonicalFetcherStruct
    {
        $this->salesChannelId = $salesChannelId;

        return $this;
    }

    /**
     * @return string
     */
    public function getSalesChannelDomainId(): string
    {
        return $this->salesChannelDomainId;
    }

    /**
     * @param string $salesChannelDomainId
     * @return CanonicalFetcherStruct
     */
    public function setSalesChannelDomainId(string $salesChannelDomainId): CanonicalFetcherStruct
    {
        $this->salesChannelDomainId = $salesChannelDomainId;

        return $this;
    }
}
