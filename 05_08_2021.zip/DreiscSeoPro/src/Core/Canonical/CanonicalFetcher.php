<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Canonical;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\Product\ProductEnum;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Foundation\Seo\SeoUrlAssembler;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\CategorySeoDataFetcher;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\ProductSeoDataFetcher;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\Struct\SeoDataFetchResultStruct;
use Shopware\Core\Content\Category\CategoryDefinition;
use Shopware\Core\Content\Product\ProductDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;

class CanonicalFetcher
{
    /**
     * @var ProductSeoDataFetcher
     */
    private $productSeoDataFetcher;

    /**
     * @var CategorySeoDataFetcher
     */
    private $categorySeoDataFetcher;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var SeoUrlAssembler
     */
    private $seoUrlAssembler;

    /**
     * @param ProductSeoDataFetcher $productSeoDataFetcher
     * @param CategorySeoDataFetcher $categorySeoDataFetcher
     * @param ProductRepository $productRepository
     * @param CategoryRepository $categoryRepository
     * @param SeoUrlAssembler $seoUrlAssembler
     */
    public function __construct(ProductSeoDataFetcher $productSeoDataFetcher, CategorySeoDataFetcher $categorySeoDataFetcher, ProductRepository $productRepository, CategoryRepository $categoryRepository, SeoUrlAssembler $seoUrlAssembler)
    {
        $this->productSeoDataFetcher = $productSeoDataFetcher;
        $this->categorySeoDataFetcher = $categorySeoDataFetcher;
        $this->productRepository = $productRepository;
        $this->categoryRepository = $categoryRepository;
        $this->seoUrlAssembler = $seoUrlAssembler;
    }

    /**
     * @param CanonicalFetcherStruct $canonicalFetcherStruct
     * @return string|null
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     */
    public function fetch(CanonicalFetcherStruct $canonicalFetcherStruct): ?string
    {
        /** Get the seo data fetch result */
        $seoDataFetchResultStruct = $this->getSeoDataFetchResultStruct($canonicalFetcherStruct);
        if (null === $seoDataFetchResultStruct) {
            return null;
        }

        /** Progress type */
        switch ($seoDataFetchResultStruct->getCanonicalLinkType()) {
            case ProductEnum::CANONICAL_LINK_TYPE__EXTERNAL_URL:
                return $this->progressExternalUrl($seoDataFetchResultStruct);
                break;
            case ProductEnum::CANONICAL_LINK_TYPE__PRODUCT_URL:
                return $this->progressProductUrl($seoDataFetchResultStruct, $canonicalFetcherStruct);
                break;
            case ProductEnum::CANONICAL_LINK_TYPE__CATEGORY_URL:
                return $this->progressCategoryUrl($seoDataFetchResultStruct, $canonicalFetcherStruct);
                break;
        }

        return null;
    }

    /**
     * @param CanonicalFetcherStruct $canonicalFetcherStruct
     * @return SeoDataFetchResultStruct|null
     * @throws InconsistentCriteriaIdsException
     * @throws DBALException
     * @throws InvalidUuidException
     */
    private function getSeoDataFetchResultStruct(CanonicalFetcherStruct $canonicalFetcherStruct): ?SeoDataFetchResultStruct
    {
        if (ProductDefinition::ENTITY_NAME === $canonicalFetcherStruct->getEntityName()) {
            return $this->productSeoDataFetcher->fetch(
                $canonicalFetcherStruct->getEntityId(),
                $canonicalFetcherStruct->getLanguageId(),
                $canonicalFetcherStruct->getSalesChannelId(),
                true
            );
        }

        if (CategoryDefinition::ENTITY_NAME === $canonicalFetcherStruct->getEntityName()) {
            return $this->categorySeoDataFetcher->fetch(
                $canonicalFetcherStruct->getEntityId(),
                $canonicalFetcherStruct->getLanguageId(),
                $canonicalFetcherStruct->getSalesChannelId()
            );
        }

        return null;
    }

    /**
     * @param SeoDataFetchResultStruct $seoDataFetchResultStruct
     * @return string|null
     */
    private function progressExternalUrl(SeoDataFetchResultStruct $seoDataFetchResultStruct): ?string
    {
        $externalUrl = $seoDataFetchResultStruct->getCanonicalLinkReference();
        if(empty($externalUrl)) {
            return null;
        }

        return $externalUrl;
    }

    /**
     * @param SeoDataFetchResultStruct $seoDataFetchResultStruct
     * @param CanonicalFetcherStruct $canonicalFetcherStruct
     * @return string|null
     * @throws InconsistentCriteriaIdsException
     */
    private function progressProductUrl(SeoDataFetchResultStruct $seoDataFetchResultStruct, CanonicalFetcherStruct $canonicalFetcherStruct): ?string
    {
        $productId = $seoDataFetchResultStruct->getCanonicalLinkReference();
        if(empty($productId)) {
            return null;
        }

        /** Fetch the product entity */
        $productEntity = $this->productRepository->get($productId);

        return $this->progressEntityUrl($productEntity, $canonicalFetcherStruct);
    }

    /**
     * @param SeoDataFetchResultStruct $seoDataFetchResultStruct
     * @param CanonicalFetcherStruct $canonicalFetcherStruct
     * @return string|null
     * @throws InconsistentCriteriaIdsException
     */
    private function progressCategoryUrl(SeoDataFetchResultStruct $seoDataFetchResultStruct, CanonicalFetcherStruct $canonicalFetcherStruct): ?string
    {
        $categoryId = $seoDataFetchResultStruct->getCanonicalLinkReference();
        if(empty($categoryId)) {
            return null;
        }

        /** Fetch the category entity */
        $categoryEntity = $this->categoryRepository->get($categoryId);

        return $this->progressEntityUrl($categoryEntity, $canonicalFetcherStruct);
    }

    /**
     * @param Entity $entity
     * @param CanonicalFetcherStruct $canonicalFetcherStruct
     * @return string|null
     * @throws InconsistentCriteriaIdsException
     */
    private function progressEntityUrl(?Entity $entity, CanonicalFetcherStruct $canonicalFetcherStruct): ?string
    {
        /** Abort, if category is not available */
        if (null === $entity) {
            return null;
        }

        /** Fetch the  */
        $urlInfo = $this->seoUrlAssembler->assemble(
            $entity,
            $canonicalFetcherStruct->getSalesChannelId(),
            $canonicalFetcherStruct->getLanguageId()
        );

        if (!empty($urlInfo)) {
            $salesChannelDomainId = $canonicalFetcherStruct->getSalesChannelDomainId();
            if (!empty($urlInfo['absolutePaths']) && !empty($urlInfo['absolutePaths'][$salesChannelDomainId])) {
                return $urlInfo['absolutePaths'][$salesChannelDomainId];
            }
        }

        return null;
    }
}
