<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Dbl\PlainSqlUpdate;

class Category
{
    /**
     * @var Common
     */
    private $commonPlainSqlUpdater;

    /**
     * @param Common $commonPlainSqlUpdater
     */
    public function __construct(Common $commonPlainSqlUpdater)
    {
        $this->commonPlainSqlUpdater = $commonPlainSqlUpdater;
    }

    public function update(array $updates)
    {
        $this->commonPlainSqlUpdater->updateTranslations(
            'category',
            $updates
        );
    }
}
