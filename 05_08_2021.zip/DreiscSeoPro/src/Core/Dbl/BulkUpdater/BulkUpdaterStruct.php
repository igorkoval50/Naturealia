<?php declare(strict_types=1);

namespace DreiscSeoPro\Core\Dbl\BulkUpdater;

use DreiscSeoPro\Core\Foundation\Dal\EntityRepository;
use DreiscSeoPro\Core\Foundation\Struct\DefaultStruct;

class BulkUpdaterStruct extends DefaultStruct
{
    /**
     * @var ?EntityRepository
     */
    protected $entityRepository;

    /**
     * @var array
     */
    protected $updates;

    /**
     * @param EntityRepository|null $entityRepository
     * @param array|null $updates
     */
    public function __construct(?EntityRepository $entityRepository = null, ?array $updates = [])
    {
        $this->entityRepository = $entityRepository;
        $this->updates = $updates;
    }

    /**
     * @return EntityRepository|null
     */
    public function getEntityRepository(): ?EntityRepository
    {
        return $this->entityRepository;
    }

    /**
     * @param EntityRepository $entityRepository
     * @return BulkUpdaterStruct
     */
    public function setEntityRepository(EntityRepository $entityRepository): BulkUpdaterStruct
    {
        $this->entityRepository = $entityRepository;

        return $this;
    }

    /**
     * @param EntityRepository $entityRepository
     * @return BulkUpdaterStruct
     */
    public function setEntityRepositoryIfNull(EntityRepository $entityRepository): BulkUpdaterStruct
    {
        if (null !== $this->entityRepository) {
            return $this;
        }

        $this->entityRepository = $entityRepository;

        return $this;
    }

    /**
     * @return array
     */
    public function getUpdates(): array
    {
        return $this->updates;
    }

    /**
     * @param array $updates
     * @return BulkUpdaterStruct
     */
    public function setUpdates(array $updates): BulkUpdaterStruct
    {
        $this->updates = $updates;

        return $this;
    }

    public function addUpdate(array $update): void
    {
        $this->updates[] = $update;
    }
}
