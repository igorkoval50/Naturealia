const ApiService = Shopware.Classes.ApiService;

/**
 * Gateway for the API end point "frw"
 * @class
 * @extends ApiService
 */
class BulkApiService extends ApiService {
    constructor(httpClient, loginService, apiEndpoint = '') {
        super(httpClient, loginService, apiEndpoint);
    }

    /**
     * @param categoryIds
     * @param area
     * @param seoOption
     * @param languageId
     * @param salesChannelId
     * @returns {Promise<AxiosResponse<T>>}
     */
    getResponsibleSeoBulk(categoryIds = null, area = null, seoOption = null, languageId = null, salesChannelId = null) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .post(`dreisc.seo/dreisc.seo.bulk/getResponsibleSeoBulk`, {
                categoryIds: categoryIds,
                area: area,
                seoOption: seoOption,
                languageId: languageId,
                salesChannelId: salesChannelId
            }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    /**
     * @param categoryIds
     * @param area
     * @param seoOption
     * @param languageId
     * @param salesChannelId
     * @returns {Promise<AxiosResponse<T>>}
     */
    getResponsibleProductSeoBulkRespectPriority(productId = null, seoOption = null, languageId = null, salesChannelId = null) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .post(`dreisc.seo/dreisc.seo.bulk/getResponsibleProductSeoBulkRespectPriority`, {
                productId: productId,
                seoOption: seoOption,
                languageId: languageId,
                salesChannelId: salesChannelId
            }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    /**
     * @param seoBulkTemplateId
     * @param deleteSeoBulkWhichUseTemplate
     * @returns {Promise<AxiosResponse<T>>}
     */
    deleteBulkTemplate(seoBulkTemplateId, deleteSeoBulkWhichUseTemplate = false) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .post(`dreisc.seo/dreisc.seo.bulk/deleteBulkTemplate`, {
                seoBulkTemplateId: seoBulkTemplateId,
                deleteSeoBulkWhichUseTemplate: deleteSeoBulkWhichUseTemplate
            }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    /**
     * @param area
     * @param activeItemId
     * @param seoOption
     * @param languageId
     * @param salesChannelId
     * @param template
     * @param spaceless
     * @returns {Promise<AxiosResponse<T>>}
     */
    getTemplatePreview(area, activeItemId, seoOption, languageId, salesChannelId, template, spaceless) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .post(`dreisc.seo/dreisc.seo.bulk/getTemplatePreview`, {
                area: area,
                activeItemId: activeItemId,
                seoOption: seoOption,
                languageId: languageId,
                salesChannelId: salesChannelId,
                template: template,
                spaceless: spaceless
            }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    /**
     * @param area
     * @returns {Promise<AxiosResponse<T>>}
     */
    prepareBulkGenerator(area) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .post(`dreisc.seo/dreisc.seo.bulk/prepareBulkGenerator`, {
                area: area
            }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    /**
     * @param area
     * @param offset
     * @param limit
     * @returns {Promise<AxiosResponse<T>>}
     */
    runBulkGeneratorThread(area, offset, limit) {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .post(`dreisc.seo/dreisc.seo.bulk/runBulkGeneratorThread`, {
                area: area,
                offset: offset,
                limit: limit
            }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }
}

export default BulkApiService;
