const ApiService = Shopware.Classes.ApiService;

/**
 * Gateway for the API end point "frw"
 * @class
 * @extends ApiService
 */
class RedirectService extends ApiService {
    constructor(httpClient, loginService, apiEndpoint = '') {
        super(httpClient, loginService, apiEndpoint);
    }

    /**
     * @param dreiscSeoRedirectId
     * @returns {Promise<AxiosResponse<T>>}
     */
    deleteSeoRedirect(dreiscSeoRedirectId = null) {
        const headers = this.getBasicHeaders();

        /**
         * This is a workaround because the entity is not deletable by the shopware DAL
         * @see: https://issues.shopware.com/issues/NEXT-7866
         */
        return this.httpClient
            .post(`dreisc.seo.pro/dreisc.seo.redirect/deleteSeoRedirect`, {
                dreiscSeoRedirectId: dreiscSeoRedirectId
            }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    /**
     * @param file {File} The csv file
     * @param callback {Function} Callback for progress
     * @param config {Object} Additional config for profile
     * @returns {Promise<void>}
     */
    async import(file, callback, config = {}) {
        const expireDate = new Date();
        expireDate.setDate(expireDate.getDate() + 30);

        const formData = new FormData();
        if (file) {
            formData.append('file', file);
        }
        // formData.append('profileId', profileId);
        formData.append('expireDate', expireDate.toDateString());

        Object.entries(config).forEach(([key, value]) => {
            formData.append(`config[${key}]`, JSON.stringify(value));
        });

        const createdFile = await this.httpClient.post('dreisc.seo.pro/dreisc.seo.redirect/prepareImport', formData, {
            headers: this.getBasicHeaders()
        });

        return this.trackImportProgress(createdFile, config, callback);
    }

    /**
     * @param file {String} log entity
     * @param config
     * @param callback
     * @param progress
     * @returns {Promise<void>}
     */
    async trackImportProgress(file, config, callback, progress) {
        const { data: { progress: newProgress } } = await this.httpClient.post(
            'dreisc.seo.pro/dreisc.seo.redirect/processImport',
            {
                dreiscSeoRedirectImportExportFileId: file.data.fileId,
                offset: (progress && progress.offset) ? progress.offset : 0,
                delimiter: config.delimiter
            },
            {
                headers: this.getBasicHeaders()
            }
        );

        callback.call(this, newProgress);

        if (newProgress.offset >= newProgress.total) {
            return file;
        }

        return this.trackImportProgress(file, config, callback, newProgress);
    }

    /**
     * @returns {Promise<AxiosResponse<T>>}
     */
    fetchImportResult() {
        const headers = this.getBasicHeaders();

        return this.httpClient
            .post(`dreisc.seo.pro/dreisc.seo.redirect/fetchImportResult`, {
            }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });
    }

    /**
     * Export data from the Shop with the given profile. The callback function gets called with progress information
     * and final result data.
     *
     * @param profileId {Entity} Profile entity
     * @param callback {Function} Callback for progress
     * @param config {Object} Additional config for profile
     * @returns {Promise<void>}
     */
    async export(callback) {
        const expireDate = new Date();
        expireDate.setDate(expireDate.getDate() + 30);

        const createdFile = await this.httpClient.post('dreisc.seo.pro/dreisc.seo.redirect/prepareExport', {
            expireDate: expireDate.toDateString()
        }, { headers: this.getBasicHeaders() });

        return this.trackExportProgress(createdFile, callback);
    }

    /**
     * @param file {String} log entity
     * @param config
     * @param callback
     * @param progress
     * @returns {Promise<void>}
     */
    async trackExportProgress(file, callback, progress) {
        const { data: { progress: newProgress } } = await this.httpClient.post(
            'dreisc.seo.pro/dreisc.seo.redirect/processExport',
            {
                dreiscSeoRedirectImportExportFileId: file.data.fileId,
                offset: (progress && progress.offset) ? progress.offset : 0
            },
            {
                headers: this.getBasicHeaders()
            }
        );

        callback.call(this, newProgress, file);

        if (newProgress.offset >= newProgress.total) {
            return file;
        }

        return this.trackExportProgress(file, callback, newProgress);
    }

    /**
     * Download the export file
     *
     * @param fileId {Entity} File entity
     * @param accessToken
     * @returns {Promise<void>}
     */
    getDownloadUrl(fileId, accessToken) {
        const apiPath = Shopware.Context.api.apiPath;
        const versionId = Shopware.Context.api.apiVersion;
        return `${apiPath}/dreisc.seo.pro/dreisc.seo.redirect/download?fileId=${fileId}&accessToken=${accessToken}`;
    }
}

export default RedirectService;
