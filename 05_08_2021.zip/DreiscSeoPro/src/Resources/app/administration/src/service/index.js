import BulkApiService from "./api/bulk.api.service";
import DreiscSeoCustomConfigApiService from "./api/dreisc.seo.custom.config.api.service";
import RedirectService from "./api/redirect.service";

const { Application } = Shopware;

Application.addServiceProvider('bulkApiService', (container) => {
    const initContainer = Application.getContainer('init');

    return new BulkApiService(initContainer.httpClient, container.loginService);
});

Application.addServiceProvider('dreiscSeoCustomConfigApiService', (container) => {
    const initContainer = Application.getContainer('init');

    return new DreiscSeoCustomConfigApiService(initContainer.httpClient, container.loginService);
});

Application.addServiceProvider('redirectService', (container) => {
    const initContainer = Application.getContainer('init');

    return new RedirectService(initContainer.httpClient, container.loginService);
});
