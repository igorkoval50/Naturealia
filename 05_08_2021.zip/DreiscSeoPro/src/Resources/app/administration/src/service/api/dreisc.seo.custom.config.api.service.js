const ApiService = Shopware.Classes.ApiService;

/**
 * Gateway for the API end point "frw"
 * @class
 * @extends ApiService
 */
class DreiscSeoCustomConfigApiService extends ApiService {
    constructor(httpClient, loginService, apiEndpoint = '') {
        super(httpClient, loginService, apiEndpoint);

        this.config = null;
    }

    /**
     * @returns {Promise<AxiosResponse<T>>}
     */
    getCustomConfig(breakCache) {
        const headers = this.getBasicHeaders();

        if (null !== this.config && true !== breakCache) {
            /** Return cached config */
            return this.config;
        }

        this.config = this.httpClient
            .post(`dreisc.seo/dreisc.seo.custom.config/loadCustomConfig`, { }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });

        return this.config;
    }

    /**
     * @returns {Promise<AxiosResponse<T>>}
     */
    saveCustomConfig(customSettings, salesChannelCustomSettings) {
        const headers = this.getBasicHeaders();

        this.config = this.httpClient
            .post(`dreisc.seo/dreisc.seo.custom.config/saveCustomConfig`, {
                customSettings: customSettings,
                salesChannelCustomSettings: salesChannelCustomSettings,
            }, {
                headers
            })
            .then((response) => {
                return ApiService.handleResponse(response);
            });

        return this.config;
    }
}

export default DreiscSeoCustomConfigApiService;
