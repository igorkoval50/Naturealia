export const SeoOptions = {
    URL: 'url',
    META_TITLE: 'metaTitle',
    META_DESCRIPTION: 'metaDescription',
    ROBOTS_TAG: 'robotsTag',
    SEO_OPTION__FACEBOOK_TITLE: 'facebookTitle',
    SEO_OPTION__FACEBOOK_DESCRIPTION: 'facebookDescription',
    SEO_OPTION__TWITTER_TITLE: 'twitterTitle',
    SEO_OPTION__TWITTER_DESCRIPTION: 'twitterDescription'
};

export const Areas = {
    PRODUCT: 'product',
    CATEGORY: 'category'
};

export const SeoOptionsWhichRequiredSalesChannel = [
    SeoOptions.URL
];
