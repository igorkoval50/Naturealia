const { Component, Mixin } = Shopware;
import template from './dreisc-seo-redirect-exporter.html.twig';
import './dreisc-seo-redirect-exporter.scss';

Component.register('dreisc-seo-redirect-exporter', {
    template,

    inject: [ 'redirectService' ],

    mixins: [
        Mixin.getByName('notification')
    ],

    data() {
        return {
            isLoading: false,

            progressOffset: 0,
            progressTotal: null,
            progressText: '',
            progressState: '',

            fileId: null,
            accessToken: null,
            finished: false
        }
    },

    computed: {

    },

    methods: {
        resetProgressStats() {
            // Reset progress stats
            this.progressOffset = 0;
            this.progressTotal = null;
            this.progressText = '';
            this.progressState = '';
        },

        onStartProcess() {
            this.isLoading = true;
            this.finished = false;
            this.fileId = null;
            this.accessToken = null;

            this.resetProgressStats();
            this.progressTotal = 0;

            this.redirectService.export(this.handleProgress).then((result) => {
                this.finished = true;
            }).catch((error) => {
                if (!error.response || !error.response.data || !error.response.data.errors) {
                    this.createNotificationError({
                        title: this.$tc('sw-import-export.exporter.errorNotificationTitle'),
                        message: error.message
                    });
                } else {
                    error.response.data.errors.forEach((singleError) => {
                        this.createNotificationError({
                            title: this.$tc('sw-import-export.exporter.errorNotificationTitle'),
                            message: `${singleError.code}: ${singleError.detail}`
                        });
                    });
                }

                this.resetProgressStats();
                this.isLoading = false;
            });
        },

        handleProgress(progress, file) {
            this.fileId = file.data.fileId;
            this.accessToken = file.data.accessToken;

            this.progressOffset = progress.offset;
            this.progressTotal = progress.total;
            this.progressText = progress.state;
            this.progressState = progress.state;

            if (progress.state === 'succeeded') {
                this.onProgressFinished(progress);
            }
        },

        onProgressFinished() {
            this.createNotificationSuccess({
                title: this.$tc('sw-import-export.exporter.titleExportSuccess'),
                message: this.$tc('sw-import-export.exporter.messageExportSuccess', 0)
            });
            this.isLoading = false;
            this.$emit('export-finish');
        },

        downloadUrl() {
            return this.redirectService.getDownloadUrl(this.fileId, this.accessToken);
        }
    }
});
