import './extension/sw-product-detail'
import './extension/sw-product-detail-base'
import './extension/sw-category-view'
import './extension/sw-category-detail-base'
import './component/dreisc-seo-tabs-bulk-info-box'
import './component/dreisc-seo-tabs-seo-url'
import './component/dreisc-seo-tabs-serp'
import './component/dreisc-seo-tabs-length-status-bar'
import './component/dreisc-seo-tabs-product-rich-snippet'
import './component/dreisc-seo-tabs-social-media'
import './extension/sw-product-seo-form'
import './extension/sw-category-seo-form'
import './extension/sw-product-detail-seo'
import './extension/sw-category-detail-seo'
const { Module } = Shopware;
import snippetsDE_DE from './snippets/de-DE'
import snippetsEN_GB from './snippets/en-GB'

Module.register('dreisc-seo-tabs', {
    type: 'plugin',
    name: 'DreiscSeo',
    version: '1.0.0',
    targetVersion: '1.0.0',
    color: '#9AA8B5',
    icon: 'default-basic-stack-block',

    snippets: {
        'de-DE': snippetsDE_DE,
        'en-GB': snippetsEN_GB
    },

    routes: {
        index: {
            component: 'sw-error',
            path: 'index'
        }
    },

    // navigation: [{ }]
});
