const { Component, Context } = Shopware;
const { Criteria } = Shopware.Data;
import template from './dreisc-seo-redirect-redirect-widget.html.twig';
import './dreisc-seo-redirect-redirect-widget.scss';

Component.register('dreisc-seo-redirect-redirect-widget', {
    template,

    inject: [
        'repositoryFactory'
    ],

    data() {
        return {
            dreiscSeoRedirects: null,
            salesChannelDomains: null,
            showRedirectDetails: false
        }
    },

    props: {
        redirectEntity: {
            type: String,
            required: true
        },

        entityId: {
            type: String|null,
            required: true
        },

        showCardTitle: {
            type: Boolean,
            default: true
        },

        showIfRedirectExists: {
            type: Boolean,
            default: true
        },

        showIfNoRedirectExists: {
            type: Boolean,
            default: true
        }
    },

    computed: {
        dreiscSeoRedirectRepository() {
            return this.repositoryFactory.create('dreisc_seo_redirect');
        },

        salesChannelDomainRepository() {
            return this.repositoryFactory.create('sales_channel_domain');
        },

        productRepository() {
            return this.repositoryFactory.create('product');
        },

        categoryRepository() {
            return this.repositoryFactory.create('category');
        }
    },

    watch: {
        'entityId': {
            handler() {
                this.loadData();
            }
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.fetchSalesChannelDomains();
            this.loadData();
        },

        loadData() {
            this.dreiscSeoRedirects = null;
            this.fetchRedirects();
        },

        fetchSalesChannelDomains() {
            const criteria = new Criteria();

            this.salesChannelDomainRepository.search(criteria, Context.api).then((searchResult) => {
                if (searchResult.total > 0) {
                    this.salesChannelDomains = searchResult;
                }
            });
        },

        fetchRedirects() {
            const criteria = new Criteria();

            if ('undefined' === typeof this.entityId) {
                return;
            }

            if ('product' === this.redirectEntity) {
                criteria.addFilter(Criteria.multi('AND', [
                    Criteria.equals('sourceType', this.redirectEntity),
                    Criteria.equals('sourceProductId', this.entityId),
                ]));
            } else if ('category' === this.redirectEntity) {
                criteria.addFilter(Criteria.multi('AND', [
                    Criteria.equals('sourceType', this.redirectEntity),
                    Criteria.equals('sourceCategoryId', this.entityId),
                ]));
            } else {
                console.warn('Unknown redirectEntity: ' + this.redirectEntity);
                return;
            }

            this.dreiscSeoRedirectRepository.search(criteria, Context.api).then((searchResult) => {
                if (searchResult.total > 0) {
                    this.dreiscSeoRedirects = searchResult;
                }
            });
        },

        getRedirectHeadline(dreiscSeoRedirect) {
            let redirectType = dreiscSeoRedirect.redirectType;

            switch (dreiscSeoRedirect.redirectType) {
                case "product":
                    redirectType = 'redirectToProduct';
                    break;
                case "category":
                    redirectType = 'redirectToCategory';
                    break;
                case "url":
                    redirectType = 'redirectToInternalUrl';
                    break;
                case "externalUrl":
                    redirectType = 'redirectToExternalUrl';
                    break;
            }

            return this.$tc(`dreiscSeoRedirect.componentRedirectWidget.${redirectType}`);
        }
    }
});
