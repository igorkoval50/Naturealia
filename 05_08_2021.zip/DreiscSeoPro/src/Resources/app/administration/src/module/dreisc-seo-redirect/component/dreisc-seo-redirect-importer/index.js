const { Component, Mixin } = Shopware;
import template from './dreisc-seo-redirect-importer.html.twig';
import './dreisc-seo-redirect-importer.scss';

Component.register('dreisc-seo-redirect-importer', {
    template,

    inject: [ 'redirectService' ],

    mixins: [
        Mixin.getByName('notification')
    ],

    data() {
        return {
            importFile: null,
            isLoading: false,
            importFields: {
                delimiter: ";"
            },

            config: {},

            progressOffset: 0,
            progressTotal: null,
            progressText: '',
            progressState: '',
            progressLogEntry: null
        }
    },

    computed: {
        disableImporting() {
            return this.isLoading || this.importFile === null || '' === this.importFields.delimiter;
        }
    },

    methods: {
        resetProgressStats() {
            // Reset progress stats
            this.progressOffset = 0;
            this.progressTotal = null;
            this.progressText = '';
            this.progressState = '';
            this.progressLogEntry = null;
        },

        onChangeDelimiter() {
            if (null === this.importFields.delimiter || '' === this.importFields.delimiter) {
                return;
            }

            this.importFields.delimiter = this.importFields.delimiter.substring(0, 1);
        },

        onStartProcess() {
            this.isLoading = true;

            this.resetProgressStats();
            this.progressTotal = 0;

            this.config.delimiter = this.importFields.delimiter

            this.redirectService.import(this.importFile, this.handleProgress, this.config).then((result) => {
            }).catch((error) => {
                if (!error.response || !error.response.data || !error.response.data.errors) {
                    this.createNotificationError({
                        title: this.$tc('sw-import-export.importer.errorNotificationTitle'),
                        message: error.message
                    });
                } else {
                    error.response.data.errors.forEach((singleError) => {
                        if('MISSING_HEADER' === singleError.detail) {
                            this.createNotificationError({
                                title: this.$tc('sw-import-export.importer.errorNotificationTitle'),
                                message: this.$tc('dreiscSeoRedirect.importer.notifications.missingHeader.message')
                            });
                        } else {
                            this.createNotificationError({
                                title: this.$tc('sw-import-export.importer.errorNotificationTitle'),
                                message: `${singleError.detail}`
                            });
                        }

                    });
                }

                this.resetProgressStats();
                this.isLoading = false;
            });
        },

        handleProgress(progress) {
            this.progressOffset = Math.round(progress.offset / 1024); // Convert byte to kilobyte
            this.progressTotal = Math.round(progress.total / 1024); // Convert byte to kilobyte
            this.progressState = progress.state;

            if (progress.state === 'succeeded') {
                // this.createNotificationSuccess({
                //     title: this.$tc('sw-import-export.importer.titleImportSuccess'),
                //     message: this.$tc('sw-import-export.importer.messageImportSuccess', 0)
                // });
                this.onProgressFinished();
                this.outputResult()
            } else if (progress.state === 'failed') {
                this.createNotificationError({
                    title: this.$tc('sw-import-export.importer.titleImportError'),
                    message: this.$tc('sw-import-export.importer.messageImportError', 0)
                });
                this.onProgressFinished();
            }
        },

        onProgressFinished() {
            this.importFile = null;
            this.isLoading = false;

            this.$emit('reload-list');
            this.$refs.importResult.getList(true)
        },

        outputResult() {
            this.redirectService.fetchImportResult().then((result) => {
                if (result.errors > 0 && result.errors === result.total) {
                    this.createNotificationError({
                        title: this.$tc('dreiscSeoRedirect.importer.notifications.importFailed.title'),
                        message: this.$tc('dreiscSeoRedirect.importer.notifications.importFailed.message', 0, result)
                    });
                } else if (result.errors > 0) {
                    this.createNotificationWarning({
                        title: this.$tc('dreiscSeoRedirect.importer.notifications.importIncomplete.title'),
                        message: this.$tc('dreiscSeoRedirect.importer.notifications.importIncomplete.message', 0, result)
                    });
                } else {
                    this.createNotificationSuccess({
                        title: this.$tc('dreiscSeoRedirect.importer.notifications.importSuccessful.title'),
                        message: this.$tc('dreiscSeoRedirect.importer.notifications.importSuccessful.message', 0, result)
                    });
                }
            }).catch((error) => {
            });
        }
    }
});
