const { Component, Mixin } = Shopware;
import template from './dreisc-seo-bulk-detail-base.html.twig';
import './dreisc-seo-bulk-detail-base.scss';

Component.register('dreisc-seo-bulk-detail-base', {
    template,

    mixins: [
        Mixin.getByName('dreisc-seo-bulk-detail-snippet')
    ],

    data() {
        return {}
    },

    computed: {
        inheritInfo() {
            const categoryId = this.dreiscSeoBulkEntity.categoryId;
            if (null === categoryId) {
                return null;
            }

            const category = this.findItemByCategoryId(categoryId);
            if (null === category || 'object' !== typeof category.seoBulkEntity || null === category.seoBulkEntity) {
                return null;
            }

            /** Abort, if the seo bulk is of this category */
            if (categoryId === category.seoBulkEntity.categoryId) {
                return null;
            }

            /** Load the information of the inherit category */
            const inheritCategory = this.findItemByCategoryId(category.seoBulkEntity.categoryId);
            if (null === inheritCategory) {
                return null;
            }

            return {
                inheritCategoryName: inheritCategory.translated.name || inheritCategory.name,
                templateName: this.translateSnippet(category.seoBulkEntity.dreiscSeoBulkTemplate.name, 'dreiscSeoBulk')
            };
        }
    },

    props: {
        dreiscSeoBulkEntity: {
            type: Object | null,
            required: true
        },
        bulkTemplates: {
            type: Object | null,
            required: true
        },
        settingScope: {
            type: Object | null,
            required: true
        },
        payload: {
            type: Object | null,
            required: true
        },
        area: {
            type: String | null,
            required: true
        },
        activeItemId: {
            type: Object | null,
            required: true
        },
        findItemByCategoryId: {
            type: Function,
            required: true,
            default: false
        },
        isLoading: {
            type: Boolean,
            required: false,
            default: false
        },
        isEditMode: {
            type: Boolean,
            required: false,
            default: false
        },
        isCreateMode: {
            type: Boolean,
            required: false,
            default: false
        },
        fieldErrors: {
            type: Object | null,
            required: false
        }
    },

    methods: {
        onReloadBulkTemplates() {
            this.$emit('onReloadBulkTemplates');
        }
    }
});
