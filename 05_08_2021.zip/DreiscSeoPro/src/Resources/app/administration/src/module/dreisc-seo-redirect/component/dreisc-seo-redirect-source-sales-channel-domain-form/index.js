import template from './dreisc-seo-redirect-source-sales-channel-domain-form.html.twig';
import './dreisc-seo-redirect-source-sales-channel-domain-form.scss';

const { Component, Context } = Shopware;
const { Criteria } = Shopware.Data;

Component.register('dreisc-seo-redirect-source-sales-channel-domain-form', {
    template,

    inject: [
        'repositoryFactory'
    ],

    props: {
        dreiscSeoRedirectEntity: {
            type: Object | null,
            required: true
        },
        isEditMode: {
            type: Boolean,
            required: false,
            default: false
        },
        fieldErrors: {
            type: Object | null,
            required: false
        }
    },

    data() {
        return {
            salesChannelDomainEntity: null
        }
    },

    computed: {
        salesChannelDomainRepository() {
            return this.repositoryFactory.create('sales_channel_domain');
        },

        absoluteSourceUrl() {
            let url = this.salesChannelDomainEntity.url;

            /** Add a slash, if the domain don't ends with it */
            if(!url.endsWith('/')) {
                url+= '/';
            }

            /** Add the source path */
            if(null !== this.dreiscSeoRedirectEntity) {
                url+= this.dreiscSeoRedirectEntity.sourcePath;
            }

            return url;
        }
    },

    watch: {
        /** Refresh the salesChannelDomainEntity, when the salesChannelDomain was changed */
        'dreiscSeoRedirectEntity.sourceSalesChannelDomainId': {
            handler() {
                this.loadSalesChannelDomain();
            }
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            if(null !== this.dreiscSeoRedirectEntity) {
                this.loadSalesChannelDomain();
            }
        },

        loadSalesChannelDomain() {
            if(null === this.dreiscSeoRedirectEntity || undefined === this.dreiscSeoRedirectEntity.sourceSalesChannelDomainId) {
                return;
            }

            const criteria = new Criteria();

            this.salesChannelDomainRepository.get(
                this.dreiscSeoRedirectEntity.sourceSalesChannelDomainId,
                Context.api,
                criteria
            ).then((salesChannelDomainEntity) => {
                this.salesChannelDomainEntity = salesChannelDomainEntity;
            });
        }
    }
});
