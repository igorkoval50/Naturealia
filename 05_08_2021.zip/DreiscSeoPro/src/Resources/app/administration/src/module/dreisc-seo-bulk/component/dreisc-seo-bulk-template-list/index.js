const { Component, Mixin, Context } = Shopware;
import template from './dreisc-seo-bulk-template-list.html.twig';
import './dreisc-seo-bulk-template-list.scss';

Component.register('dreisc-seo-bulk-template-list', {
    template,

    inject: [
        'bulkApiService',
        'repositoryFactory'
    ],

    mixins: [
        Mixin.getByName('dreisc-seo-bulk-detail-repository'),
        Mixin.getByName('dreisc-seo-bulk-detail-snippet'),
    ],

    props: {
        bulkTemplates: {
            type: Object | null,
            required: true
        },
        dreiscSeoBulkEntity: {
            type: Object | null,
            required: true
        },
        settingScope: {
            type: Object | null,
            required: true
        },
        payload: {
            type: Object | null,
            required: true
        },
        activeItemId: {
            type: Object | null,
            required: true
        },
        area: {
            type: String | null,
            required: true
        }
    },

    data() {
        return {
            total: 0,
            isLoading: false,
            isGridLoading: false,
            deleteButtonDisabled: true,
            currentBulkTemplate: null,
            showDeleteConfirmModal: false,
            deleteConfirmBuffer: [],
            showDeletingTemplateInUseModal: false,
            deletingTemplateInUseModalData: [],
        }
    },

    computed: {
        dreiscSeoBulkTemplateRepository() {
            return this.repositoryFactory.create('dreisc_seo_bulk_template');
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
        },

        onAddTemplate() {
            const dreiscSeoBulkTemplate = this.dreiscSeoBulkTemplateRepository.create();
            dreiscSeoBulkTemplate.area = this.dreiscSeoBulkEntity.area;
            dreiscSeoBulkTemplate.seoOption = this.dreiscSeoBulkEntity.seoOption;
            dreiscSeoBulkTemplate.spaceless = true;

            this.currentBulkTemplate = dreiscSeoBulkTemplate;
        },

        onOptionEdit(item) {
            this.currentBulkTemplate = item;
        },

        selectionChanged() {
            const selection = this.$refs.grid.getSelection();
            this.deleteButtonDisabled = Object.keys(selection).length <= 0;
        },

        onTemplateDelete(item) {
            this.deleteConfirmBuffer = [];
            this.deleteConfirmBuffer.push(item);
            this.showDeleteConfirmModal = true;
        },

        onDeleteTemplates() {
            const selection = this.$refs.grid.getSelection();
            this.deleteConfirmBuffer = [];

            Object.values(selection).forEach((option) => {
                this.deleteConfirmBuffer.push(option);
                this.$refs.grid.selectItem(false, option);
                this.showDeleteConfirmModal = true;
            });
        },

        onConfirmDeleteTemplates() {
            this.showDeleteConfirmModal = false;
            this.deleteTemplatesSuccessively();
        },

        deleteTemplatesSuccessively() {
            this.isGridLoading = true;
            if (this.deleteConfirmBuffer.length <= 0) {
                this.isGridLoading = false;
                this.$emit('onReloadBulkTemplates');
                return;
            }

            const template = this.deleteConfirmBuffer.shift();
            this.bulkApiService.deleteBulkTemplate(template.id).then((response) => {
                if (false === response.success) {
                    this.showDeletingTemplateInUseModal = true;
                    this.deletingTemplateInUseModalData.templateId = template.id;
                    this.deletingTemplateInUseModalData.templateName = this.translateSnippet(response.seoBulkTemplateEntity.name, 'dreiscSeoBulk');
                    this.deletingTemplateInUseModalData.seoBulkEntriesWithCurrentTemplate = response.seoBulkEntriesWithCurrentTemplate;
                    this.deletingTemplateInUseModalData.seoBulkEntriesWithCurrentTemplateTotal = response.seoBulkEntriesWithCurrentTemplateTotal;
                } else {
                    this.deleteTemplatesSuccessively();
                }
            });
        },

        confirmDeletingTemplateInUse() {
            this.showDeletingTemplateInUseModal = false;

            this.bulkApiService.deleteBulkTemplate(this.deletingTemplateInUseModalData.templateId, true).then((response) => {
                this.deleteTemplatesSuccessively();
            });
        },

        skipDeletingTemplateInUse() {
            this.showDeletingTemplateInUseModal = false;
            this.deleteTemplatesSuccessively();
        },

        getBreadcrumb(category) {
            let breadcrumb = [];

            if('object' !== typeof category || 0 === category.breadcrumb.length) {
                return '';
            }

            category.breadcrumb.forEach((item) => {
                breadcrumb.push(item);
            });

            return breadcrumb.join(' » ');
        },

        onSaveBulkTemplate() {
            this.isGridLoading = true;
            this.dreiscSeoBulkTemplateRepository.save(this.currentBulkTemplate , Context.api).then(() => {
                this.$emit('onReloadBulkTemplates');
            });

            this.currentBulkTemplate = null;
        },

        onCancelBulkTemplate() {
            this.currentBulkTemplate = null;
            this.$emit('onReloadBulkTemplates');
        }
    }
});
