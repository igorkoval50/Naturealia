import dreiscSeoRichSnippetsDetailState from "../page/dreisc-seo-settings-detail/state";

const { Mixin } = Shopware;
const { Criteria } = Shopware.Data;
const { mapPageErrors, mapState, mapGetters } = Shopware.Component.getComponentHelper();

Mixin.register('dreisc-seo-settings-custom-setting-rich-snippets', {
    computed: {
        ...mapState('dreiscSeoRichSnippetsDetailState', [
            'customSettings',
            'currentSalesChannelId',
            'currentSalesChannelCustomSettings'
        ]),

        ...mapGetters('dreiscSeoRichSnippetsDetailState', [
            'isLoading'
        ])
    },

    beforeCreate() {
        if (!Shopware.State.list().includes('dreiscSeoRichSnippetsDetailState')) {
            Shopware.State.registerModule('dreiscSeoRichSnippetsDetailState', dreiscSeoRichSnippetsDetailState);
        }
    },

    methods: {
        getActiveCustomSetting(path, ignoreSalesChannelCustomSettings) {
            let sourcePointer = {};

            if ('boolean' !== typeof ignoreSalesChannelCustomSettings) {
                ignoreSalesChannelCustomSettings = false;
            }

            if (0 === Object.keys(this.customSettings).length) {
                return {};
            }

            if (null === this.currentSalesChannelId || true === ignoreSalesChannelCustomSettings) {
                sourcePointer = this.customSettings;
            } else {
                sourcePointer = this.currentSalesChannelCustomSettings;
            }

            path.split('.').forEach(pathItem => {
                if ('object' === typeof sourcePointer && sourcePointer.hasOwnProperty(pathItem)) {
                    sourcePointer = sourcePointer[pathItem];
                } else {
                    return {};
                }
            })

            return sourcePointer;
        },

        getInheritCustomSetting(path) {
            let sourcePointer = {};

            if (0 === Object.keys(this.customSettings).length) {
                return {};
            }

            if (null === this.currentSalesChannelId) {
                return {};
            } else {
                sourcePointer = this.customSettings;
            }

            path.split('.').forEach(pathItem => {
                if ('object' === typeof sourcePointer && sourcePointer.hasOwnProperty(pathItem)) {
                    sourcePointer = sourcePointer[pathItem];
                } else {
                    return {};
                }
            })

            return sourcePointer;
        },

        onSalesChannelChanged(salesChannelId) {
            Shopware.State.commit(
                'dreiscSeoRichSnippetsDetailState/changeSalesChannelCustomSettings',
                salesChannelId
            );
        }
    }
});
