const { Component, Mixin } = Shopware;
const { Criteria } = Shopware.Data;
import template from './dreisc-seo-redirect-importer-result-list.html.twig';
import './dreisc-seo-redirect-importer-result-list.scss';

Component.register('dreisc-seo-redirect-importer-result-list', {
    template,

    inject: ['repositoryFactory'],

    data() {
        return {
            showDetailModal: null,
            listShowMode: 'showAll',

            dataSource: [],
            isLoading: false,

            sortBy: 'rowIndex',
            sortDirection: 'asc',
            useNaturalSorting: true,

            page: 1,
            total: 0,
            limit: 25,
            totalVisible: 7
        }
    },

    computed: {
        logRepository() {
            return this.repositoryFactory.create('dreisc_seo_redirect_import_export_log');
        },

        defaultCriteria() {
            const criteria = new Criteria(this.page, this.limit);

            if ('showOnlyBugs' === this.listShowMode) {
                criteria.addFilter(Criteria.equals('dreiscSeoRedirectId', null))
            }

            criteria.setTerm(this.term);
            criteria.addSorting(Criteria.sort(this.sortBy, this.sortDirection, this.useNaturalSorting));

            return criteria;
        }
    },

    created() {
        this.getList();
    },

    watch: {
        listShowMode() {
            this.getList(true);
        }
    },

    methods: {
        outputErrors(item) {
            let errorText = '<p><ul>';

            if (item.errors && item.errors.length > 0) {
                item.errors.forEach((errorItem) => {
                    errorItem.params.rowIndex = item.rowIndex;

                    errorText+= '<li>';
                    errorText+= this.$tc(`dreiscSeoRedirect.importer.list.${errorItem.error}`, 0, errorItem.params);

                    errorText+= '</li>';
                });
            }

            errorText+= '</ul></p>'

            return errorText;
        },

        hasSourceAlreadyExistsError(item) {
            let result = false;
            if (item.errors && item.errors.length > 0) {
                item.errors.forEach((errorItem) => {
                    if ('sourceAlreadyExists' === errorItem.error) {
                        result = true;
                    }
                });
            }

            return result;
        },

        getList(resetPage) {
            this.isLoading = true;

            if (true === resetPage) {
                this.page = 1;
            }

            this.logRepository.search(this.defaultCriteria, Shopware.Context.api).then((items) => {
                this.total = items.total;
                this.dataSource = items;
                this.isLoading = false;

                return items;
            }).catch(() => {
                this.isLoading = false;
            });
        },

        onPageChange(args) {
            this.page = args.page;
            this.getList(false);
        },

        onDetailModalClose() {
            this.showDetailModal = null;
        }
    }
});
