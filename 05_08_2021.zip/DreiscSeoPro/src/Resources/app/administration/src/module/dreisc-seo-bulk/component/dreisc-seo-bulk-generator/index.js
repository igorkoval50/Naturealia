const { Component } = Shopware;
import template from './dreisc-seo-bulk-generator.html.twig';
import './dreisc-seo-bulk-generator.scss';

Component.register('dreisc-seo-bulk-generator', {
    template,

    inject: [
        'bulkApiService'
    ],

    props: {
        showModal: {
            type: Boolean,
            required: true
        },

        area: {
            type: String,
            required: true
        }
    },

    data() {
        return {
            isLoading: true,
            inProgress: false,
            hasFinished: false,
            total: 0,
            generatedCount: 0,
            offset: 0,
            limit: 25
        }
    },

    computed: {
        progressValue() {
            if(this.total <= 0) {
                return 0;
            }

            return Math.floor(100 / this.total * this.generatedCount);
        }
    },

    watch: {
        showModal() {
            if(true === this.showModal) {
                this.createdComponent();
            }
        }
    },

    created() {
        if(true === this.showModal) {
            this.createdComponent();
        }
    },

    methods: {
        createdComponent() {
            /** Reset form */
            this.isLoading = true;
            this.inProgress = false;
            this.hasFinished = false;
            this.offset = 0;
            this.generatedCount = 0;

            /** Prepare */
            this.bulkApiService.prepareBulkGenerator(this.area).then((response) => {
                this.isLoading = false;
                this.total = response.total;
            });
        },

        onClose() {
            this.$emit('destroy-bulk-generator');
        },

        onConfirm() {
            this.inProgress = true;
            this.runBulkGeneratorThread();
        },

        runBulkGeneratorThread() {
            this.bulkApiService.runBulkGeneratorThread(this.area, this.offset, this.limit).then((response) => {
                if (true === response.success) {
                    /** Increment offset */
                    this.offset+= this.limit;

                    /** Add generated items */
                    this.generatedCount+= response.generatedCount;

                    if(this.offset < this.total) {
                        this.runBulkGeneratorThread();
                    } else {
                        this.hasFinished = true;
                    }
                }
            });
        }
    }
});
