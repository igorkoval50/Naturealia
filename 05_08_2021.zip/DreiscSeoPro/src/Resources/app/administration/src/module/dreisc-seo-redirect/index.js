import './component/dreisc-seo-redirect-redirect-widget'
import './component/dreisc-seo-redirect-entity-listing'
import './component/dreisc-seo-redirect-exporter'
import './component/dreisc-seo-redirect-import-export'
import './component/dreisc-seo-redirect-importer-result-list'
import './component/dreisc-seo-redirect-importer'
const { Module } = Shopware;
import snippetsDE_DE from './snippets/de-DE'
import snippetsEN_GB from './snippets/en-GB'
import './page/dreisc-seo-redirect-list'
import './page/dreisc-seo-redirect-detail'
import './view/dreisc-seo-redirect-detail-base'
import './page/dreisc-seo-redirect-create'
import './component/dreisc-seo-redirect-source-sales-channel-domain-form'
import './component/dreisc-seo-redirect-redirect-sales-channel-domain-form'
import './component/dreisc-seo-redirect-sales-channel-domain-select'

Module.register('dreisc-seo-redirect', {
    type: 'plugin',
    name: 'DreiscSeo',
    version: '1.0.0',
    targetVersion: '1.0.0',
    color: '#0070ba',
    icon: 'default-location-gps',

    snippets: {
        'de-DE': snippetsDE_DE,
        'en-GB': snippetsEN_GB
    },

    routes: {
	    index: {
	        component: 'sw-error',
	        path: 'index',
	        redirect: {
	            name: 'dreisc.seo.redirect.list'
	        }
	    },
	    list: {
	        component: 'dreisc-seo-redirect-list',
	        path: 'list'
	    },
	    detail: {
	        component: 'dreisc-seo-redirect-detail',
	        path: 'detail/:id',
	        meta: {
	            parentPath: 'dreisc.seo.redirect.list'
	        },
	        redirect: {
	            name: 'dreisc.seo.redirect.detail.base'
	        },
	        children: {
	            base: {
	                component: 'dreisc-seo-redirect-detail-base',
	                path: 'base',
	                meta: {
	                    parentPath: 'dreisc.seo.redirect.list'
	                }
	            }
	        }
	    },
	    create: {
	        component: 'dreisc-seo-redirect-create',
	        path: 'create/:redirectEntity?/:entityId?',
	        redirect: {
	            name: 'dreisc.seo.redirect.create.base'
	        },
	        children: {
	            base: {
	                component: 'dreisc-seo-redirect-detail-base',
	                path: 'base',
	                meta: {
	                    parentPath: 'dreisc.seo.redirect.list'
	                }
	            }
	        }
	    }
	},

    navigation: [{
        id: 'dreisc-seo-redirect',
        label: 'dreiscSeoRedirect.general.navigation.label',
        color: '#0070ba',
        path: 'dreisc.seo.redirect.index',
        icon: 'default-basic-stack-block',
        parent: 'dreisc-seo',
        position: 30
    }]
});
