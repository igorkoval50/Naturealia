const { Component } = Shopware;
import template from './dreisc-seo-data-seo-tab-sw-product-detail.html.twig';
import './dreisc-seo-data-seo-tab-sw-product-detail.scss';

Component.override('sw-product-detail', {
    template
});
