const { Component, Mixin } = Shopware;
const { Criteria } = Shopware.Data;
import template from './dreisc-seo-bulk-category-detail.html.twig';
import './dreisc-seo-bulk-category-detail.scss';
import {SeoOptions} from "../../../dreisc-seo-bulk/helper/bulk.helper";

Component.extend('dreisc-seo-bulk-category-detail', 'dreisc-seo-bulk-detail', {
    template,

    data() {
        return {
            detailRoute: 'dreisc.seo.bulk.category.detail',
            area: 'category',
            payload: {
                templateVariablesSnippetNamespace: 'dreiscSeoBulkCategory.payload.templateVariablesDescription',
                templateVariables: [
                    { key: 'categoryId', codeSnippet: 'category.id', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'categoryTranslatedName', codeSnippet: 'category.translated.name', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'categoryTranslatedDescription', codeSnippet: 'category.translated.description', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'categoryTranslatedBreadcrumb', codeSnippet: 'category.translated.breadcrumb', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'categorySeoMetaTitle', codeSnippet: 'categorySeo.metaTitle', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'categorySeoIsInheritedMetaTitle', codeSnippet: '{% if categorySeo.isInheritedMetaTitle %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'categorySeoMetaDescription', codeSnippet: 'categorySeo.metaDescription', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'categorySeoIsInheritedMetaDescription', codeSnippet: '{% if categorySeo.isInheritedMetaDescription %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'categorySeoUrl', codeSnippet: 'categorySeo.url', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'categorySeoIsInheritedUrl', codeSnippet: '{% if categorySeo.isInheritedUrl %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'categoryParent', codeSnippet: '{% if null != category.parent %}\n\t{{ category.parent.translated.name }}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'categoryParentSeoMetaTitle', codeSnippet: 'categoryParentSeo.metaTitle', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'categoryParentSeoIsInheritedMetaTitle', codeSnippet: '{% if categoryParentSeo.isInheritedMetaTitle %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'categoryParentSeoMetaDescription', codeSnippet: 'categoryParentSeo.metaDescription', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'categoryParentSeoIsInheritedMetaDescription', codeSnippet: '{% if categoryParentSeo.isInheritedMetaDescription %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'categoryParentSeoUrl', codeSnippet: 'categoryParentSeo.url', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'categoryParentSeoIsInheritedUrl', codeSnippet: '{% if categoryParentSeo.isInheritedUrl %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'parentCategories', codeSnippet: "{% for parentCategory in parentCategories %}\n\t» {{ parentCategory.translated.name }}\n{% endfor %}", showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'childCategories', codeSnippet: "{% for childCategory in childCategories %}\n\t» {{ childCategory.translated.name }}\n{% endfor %}", showCodeSnippetInName: false, addCurvedBraces: false }
                ]
            }
        }
    }
});
