const { Component, Mixin } = Shopware;
import template from './dreisc-seo-bulk-detail-tree.html.twig';
import { SeoOptions } from "../../helper/bulk.helper";
import './dreisc-seo-bulk-detail-tree.scss';

Component.register('dreisc-seo-bulk-detail-tree', {
    template,

    mixins: [
        Mixin.getByName('dreisc-seo-bulk-detail-snippet')
    ],

    data() {
        return {
            seoOptions: [
                { key: SeoOptions.META_TITLE, name: this.$tc('dreiscSeoBulk.seoOptions.labels.metaTitle') },
                { key: SeoOptions.META_DESCRIPTION, name: this.$tc('dreiscSeoBulk.seoOptions.labels.metaDescription') },
                { key: SeoOptions.URL, name: this.$tc('dreiscSeoBulk.seoOptions.labels.url') },
                { key: SeoOptions.ROBOTS_TAG, name: this.$tc('dreiscSeoBulk.seoOptions.labels.robotsTag') },
                { key: SeoOptions.SEO_OPTION__FACEBOOK_TITLE, name: this.$tc('dreiscSeoBulk.seoOptions.labels.facebookTitle') },
                { key: SeoOptions.SEO_OPTION__FACEBOOK_DESCRIPTION, name: this.$tc('dreiscSeoBulk.seoOptions.labels.facebookDescription') },
                { key: SeoOptions.SEO_OPTION__TWITTER_TITLE, name: this.$tc('dreiscSeoBulk.seoOptions.labels.twitterTitle') },
                { key: SeoOptions.SEO_OPTION__TWITTER_DESCRIPTION, name: this.$tc('dreiscSeoBulk.seoOptions.labels.twitterDescription') },
            ]
        }
    },

    props: {
        items: {
            type: Array,
            required: true
        },

        settingScope: {
            type: Object,
            required: true
        },

        isLoadingInitialData: {
            type: Boolean,
            required: true
        },

        isSalesChannelRequired: {
            type: Boolean,
            required: true
        },

        activeItem: {
            type: [Object, null],
            required: false,
            default: null
        },

        disableContextMenu: {
            type: Boolean,
            required: false,
            default: false
        },

        findItemByCategoryId: {
            type: Function,
            required: true
        }
    },

    computed: {
        activeTreeItemId: {
            get() {
                if(null === this.activeItem) {
                    return null;
                }

                return this.activeItem.id;
            }
        }
    },

    methods: {
        onChangeItem(item) {
            this.$emit('item-changed', item);
        },

        onGetTreeItems(parentId) {
            if(null !== parentId) {
                this.$emit('children-load', this.getParentIdString(parentId));
            }
        },

        getParentIdString(parentId) {
            if('object' === typeof parentId && parentId.length > 0) {
                return this.getParentIdString(parentId[0]);
            }

            return parentId;
        },

        getInheritCategoryName(categoryId) {
            const category = this.findItemByCategoryId(categoryId);

            return category.translated.name || category.name
        }
    }
});
