const { Component } = Shopware;
import template from './dreisc-seo-doku-link-form-head.html.twig';
import './dreisc-seo-doku-link-form-head.scss';

Component.register('dreisc-seo-doku-link-form-head', {
    template,

    props: {
        dokuLink: {
            type: String,
            required: true
        }
    },

    data() {
        return {}
    },

    methods: {}
});
