const { Component, Mixin, Context } = Shopware;
import template from './dreisc-seo-settings-detail.html.twig';
import './dreisc-seo-settings-detail.scss';
import dreiscSeoSettingsDetailState from './state';
const { mapPageErrors, mapState, mapGetters } = Shopware.Component.getComponentHelper();

Component.register('dreisc-seo-settings-detail', {
    template,

    inject: [
        'repositoryFactory',
        'dreiscSeoCustomConfigApiService'
    ],

    mixins: [
        Mixin.getByName('notification')
    ],

    data() {
        return {
            isSaveSuccessful: false
        };
    },

    created() {
        this.createdComponent();
    },

    computed: {
        ...mapState('dreiscSeoSettingsDetailState', [
            'customSettings', 'fieldErrors'
        ]),

        ...mapGetters('dreiscSeoSettingsDetailState', [
            'isLoading'
        ])
    },

    beforeCreate() {
        if (!Shopware.State.list().includes('dreiscSeoSettingsDetailState')) {
            Shopware.State.registerModule('dreiscSeoSettingsDetailState', dreiscSeoSettingsDetailState);
        }
    },

    beforeDestroy() {
        if (Shopware.State.list().includes('dreiscSeoSettingsDetailState')) {
            Shopware.State.unregisterModule('dreiscSeoSettingsDetailState');
        }
    },

    methods: {
        createdComponent() {
            Shopware.State.commit(
                'dreiscSeoSettingsDetailState/setDreiscSeoCustomConfigApiService',
                this.dreiscSeoCustomConfigApiService
            );

            Shopware.State.commit('dreiscSeoSettingsDetailState/loadCustomSettings');
        },

        onSave() {
            if(true !== this.isFormValid()) {
                this.createNotificationError({
                    title: this.$tc('dreiscSeoSettings.detailSeoSettings.notification.titleSaveError'),
                    message: this.$tc('dreiscSeoSettings.detailSeoSettings.notification.messageSaveError')
                });

                return;
            }

            Shopware.State.commit('dreiscSeoSettingsDetailState/saveCustomSettings', () => {
                this.isSaveSuccessful = true;
            });
        },

        saveFinish() {
            this.isSaveSuccessful = false;
        },

        isFormValid() {
            let isValid = true;

            /** Reset the errors */
            Object.keys(this.fieldErrors).forEach((errorKey) => {
                this.fieldErrors[errorKey] = null;
            });

            /** Check fields for greater then 0 */
            if (this.customSettings.metaTags.metaTitle.lengthConfig.recommendedLengthStart <= 0) {
                this.fieldErrors.metaTags_metaTitle_lengthConfig_recommendedLengthStart = this.generateErrorObject(
                    this.$tc('dreiscSeoSettings.general.fieldErrors.shouldBeGreaterThenZero')
                );

                isValid = false;
            }

            if (this.customSettings.metaTags.metaTitle.lengthConfig.recommendedLengthEnd <= 0) {
                this.fieldErrors.metaTags_metaTitle_lengthConfig_recommendedLengthEnd = this.generateErrorObject(
                    this.$tc('dreiscSeoSettings.general.fieldErrors.shouldBeGreaterThenZero')
                );

                isValid = false;
            }

            if (this.customSettings.metaTags.metaTitle.lengthConfig.maxLength <= 0) {
                this.fieldErrors.metaTags_metaTitle_lengthConfig_maxLength = this.generateErrorObject(
                    this.$tc('dreiscSeoSettings.general.fieldErrors.shouldBeGreaterThenZero')
                );

                isValid = false;
            }

            if (this.customSettings.metaTags.metaDescription.lengthConfig.recommendedLengthStart <= 0) {
                this.fieldErrors.metaTags_metaDescription_lengthConfig_recommendedLengthStart = this.generateErrorObject(
                    this.$tc('dreiscSeoSettings.general.fieldErrors.shouldBeGreaterThenZero')
                );

                isValid = false;
            }

            if (this.customSettings.metaTags.metaDescription.lengthConfig.recommendedLengthEnd <= 0) {
                this.fieldErrors.metaTags_metaDescription_lengthConfig_recommendedLengthEnd = this.generateErrorObject(
                    this.$tc('dreiscSeoSettings.general.fieldErrors.shouldBeGreaterThenZero')
                );

                isValid = false;
            }

            if (this.customSettings.metaTags.metaDescription.lengthConfig.maxLength <= 0) {
                this.fieldErrors.metaTags_metaDescription_lengthConfig_maxLength = this.generateErrorObject(
                    this.$tc('dreiscSeoSettings.general.fieldErrors.shouldBeGreaterThenZero')
                );

                isValid = false;
            }

            if (this.customSettings.metaTags.keywords.lengthConfig.recommendedLengthStart <= 0) {
                this.fieldErrors.metaTags_keywords_lengthConfig_recommendedLengthStart = this.generateErrorObject(
                    this.$tc('dreiscSeoSettings.general.fieldErrors.shouldBeGreaterThenZero')
                );

                isValid = false;
            }

            if (this.customSettings.metaTags.keywords.lengthConfig.recommendedLengthEnd <= 0) {
                this.fieldErrors.metaTags_keywords_lengthConfig_recommendedLengthEnd = this.generateErrorObject(
                    this.$tc('dreiscSeoSettings.general.fieldErrors.shouldBeGreaterThenZero')
                );

                isValid = false;
            }

            if (this.customSettings.metaTags.keywords.lengthConfig.maxLength <= 0) {
                this.fieldErrors.metaTags_keywords_lengthConfig_maxLength = this.generateErrorObject(
                    this.$tc('dreiscSeoSettings.general.fieldErrors.shouldBeGreaterThenZero')
                );

                isValid = false;
            }

            return isValid;
        },

        generateErrorObject(error) {
            return {
                code: 'ERROR',
                detail: error
            };
        }
    }
});
