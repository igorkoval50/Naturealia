const { Component } = Shopware;
import template from './dreisc-seo-redirect-import-export.html.twig';
import './dreisc-seo-redirect-import-export.scss';

Component.register('dreisc-seo-redirect-import-export', {
    template,

    data() {
        return {
            activeTab: 'import'
        }
    },

    methods: {
        onReloadList() {
            this.$emit('reload-list');
        }
    }
});
