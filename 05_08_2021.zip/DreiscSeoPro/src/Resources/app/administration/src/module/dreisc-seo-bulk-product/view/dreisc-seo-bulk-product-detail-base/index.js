const { Component } = Shopware;
import template from './dreisc-seo-bulk-product-detail-base.html.twig';
import './dreisc-seo-bulk-product-detail-base.scss';

Component.extend('dreisc-seo-bulk-product-detail-base', 'dreisc-seo-bulk-detail-base', {
    template
});
