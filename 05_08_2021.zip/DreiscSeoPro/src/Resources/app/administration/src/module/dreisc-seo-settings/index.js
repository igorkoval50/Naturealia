import './page/dreisc-seo-settings-detail'
import './view/dreisc-seo-settings-detail-seo-settings'
import './component/dreisc-seo-settings-length-config-form'
const { Module } = Shopware;
import snippetsDE_DE from './snippets/de-DE'
import snippetsEN_GB from './snippets/en-GB'

Module.register('dreisc-seo-settings', {
    type: 'plugin',
    name: 'DreiscSeoPro',
    version: '1.0.0',
    targetVersion: '1.0.0',
    color: '#9AA8B5',
    icon: 'default-basic-stack-block',

    snippets: {
        'de-DE': snippetsDE_DE,
        'en-GB': snippetsEN_GB
    },

    routes: {
	    index: {
	        component: 'sw-error',
	        path: 'index',
	        redirect: {
	            name: 'dreisc.seo.settings.detail'
	        }
	    },
	    detail: {
	        component: 'dreisc-seo-settings-detail',
	        path: 'detail',
	        redirect: {
	            name: 'dreisc.seo.settings.detail.seoSettings'
	        },
	        children: {
                seoSettings: {
	                component: 'dreisc-seo-settings-detail-seo-settings',
	                path: 'seoSettings'
	            }
	        }
	    }
	},

    navigation: [{
        id: 'dreisc-seo-settings',
        label: 'dreiscSeoSettings.general.navigation.label',
        color: '#0070ba',
        path: 'dreisc.seo.settings.index',
        icon: 'default-basic-stack-block',
        parent: 'dreisc-seo',
        position: 100
    }]
});
