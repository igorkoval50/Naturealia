import './page/dreisc-seo-rich-snippet-detail'
import './view/dreisc-seo-rich-snippet-detail-general'
import './view/dreisc-seo-rich-snippet-detail-product'
import './view/dreisc-seo-rich-snippet-detail-breadcrumb'
import './view/dreisc-seo-rich-snippet-detail-business'
import './component/dreisc-seo-rich-snippet-opening-hours-grid'
const { Module } = Shopware;
import snippetsDE_DE from './snippets/de-DE'
import snippetsEN_GB from './snippets/en-GB'

Module.register('dreisc-seo-rich-snippet', {
    type: 'plugin',
    name: 'DreiscSeoPro',
    version: '1.0.0',
    targetVersion: '1.0.0',
    color: '#9AA8B5',
    icon: 'default-basic-stack-block',

    snippets: {
        'de-DE': snippetsDE_DE,
        'en-GB': snippetsEN_GB
    },

    routes: {
	    index: {
	        component: 'sw-error',
	        path: 'index',
	        redirect: {
	            name: 'dreisc.seo.rich.snippet.detail'
	        }
	    },
	    detail: {
	        component: 'dreisc-seo-rich-snippet-detail',
	        path: 'detail',
	        redirect: {
	            name: 'dreisc.seo.rich.snippet.detail.general'
	        },
	        children: {
	            general: {
	                component: 'dreisc-seo-rich-snippet-detail-general',
	                path: 'general'
	            },
	            product: {
	                component: 'dreisc-seo-rich-snippet-detail-product',
	                path: 'product'
	            },
	            breadcrumb: {
	                component: 'dreisc-seo-rich-snippet-detail-breadcrumb',
	                path: 'breadcrumb'
	            },
	            business: {
	                component: 'dreisc-seo-rich-snippet-detail-business',
	                path: 'business'
	            }
	        }
	    }
	},

    navigation: [{
        id: 'dreisc-seo-rich-snippet',
        label: 'dreiscSeoRichSnippet.general.navigation.label',
        color: '#0070ba',
        path: 'dreisc.seo.rich.snippet.index',
        icon: 'default-basic-stack-block',
        parent: 'dreisc-seo',
        position: 30
    }]
});
