import './page/dreisc-seo-bulk-product-detail'
import './component/dreisc-seo-bulk-product-detail-tree'
import './view/dreisc-seo-bulk-product-detail-base'
const { Module } = Shopware;
import snippetsDE_DE from './snippets/de-DE'
import snippetsEN_GB from './snippets/en-GB'

Module.register('dreisc-seo-bulk-product', {
    type: 'plugin',
    name: 'DreiscSeo',
    version: '1.0.0',
    targetVersion: '1.0.0',
    color: '#9AA8B5',
    icon: 'default-basic-stack-block',

    snippets: {
        'de-DE': snippetsDE_DE,
        'en-GB': snippetsEN_GB
    },

    routes: {
	    index: {
	        component: 'sw-error',
	        path: 'index',
	        redirect: {
	            name: 'dreisc.seo.bulk.product.detail'
	        }
	    },
	    detail: {
	        component: 'dreisc-seo-bulk-product-detail',
	        path: 'detail/:seoOption?/:languageId?/:salesChannelId?/:id?',
	        redirect: {
	            name: 'dreisc.seo.bulk.product.detail.base'
	        },
	        children: {
	            base: {
	                component: 'dreisc-seo-bulk-product-detail-base',
	                path: 'base'
	            }
	        }
	    }
	},

    navigation: [{
        id: 'dreisc-seo-bulk-product',
        label: 'dreiscSeoBulkProduct.general.navigation.label',
        color: '#0070ba',
        path: 'dreisc.seo.bulk.product.index',
        icon: 'default-basic-stack-block',
        parent: 'dreisc-seo',
        position: 10
    }]
});
