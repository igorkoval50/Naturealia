const { Component } = Shopware;
import {Areas} from "./../../../dreisc-seo-bulk/helper/bulk.helper";
import template from './dreisc-seo-tabs-bulk-info-box.html.twig';
import './dreisc-seo-tabs-bulk-info-box.scss';

Component.register('dreisc-seo-tabs-bulk-info-box', {
    template,

    inject: [
        'bulkApiService'
    ],

    data() {
        return {
            showBulkInfo: false,
            dreiscSeoBulkEntity: null,
            isLoading: true
        }
    },

    props: {
        entity: {
            type: Object | null,
            required: true
        },
        area: {
            type: String,
            required: true
        },

        seoOption: {
            type: String,
            required: true
        },

        salesChannelId: {
            type: String | null,
            default() {
                return null;
            }
        }
    },

    computed: {
        currentLanguage() {
            return Shopware.Context.api.languageId;
        },

        dreiscSeoBulkTemplateName() {
            if (null === this.dreiscSeoBulkEntity || null === this.dreiscSeoBulkEntity.dreiscSeoBulkTemplate || 'undefined' === typeof this.dreiscSeoBulkEntity.dreiscSeoBulkTemplate) {
                return null;
            }

            return this.translateSnippet(
                this.dreiscSeoBulkEntity.dreiscSeoBulkTemplate.name,
                'dreiscSeoBulk'
            );
        },

        dreiscSeoBulkTemplateCategoryBreadcrumbName() {
            if (null === this.dreiscSeoBulkEntity || null === this.dreiscSeoBulkEntity.dreiscSeoBulkTemplate || null === this.dreiscSeoBulkEntity.category || 'undefined' === typeof this.dreiscSeoBulkEntity.dreiscSeoBulkTemplate) {
                return null;
            }

            return this.dreiscSeoBulkEntity.category.breadcrumb.join(' » ');
        },

        routerBulkLink() {
            if (null === this.dreiscSeoBulkEntity || null === this.dreiscSeoBulkEntity.dreiscSeoBulkTemplate || null === this.dreiscSeoBulkEntity.category || 'undefined' === typeof this.dreiscSeoBulkEntity.dreiscSeoBulkTemplate) {
                return null;
            }

            let routeName = null;
            if (Areas.PRODUCT === this.area) {
                routeName = 'dreisc.seo.bulk.product.detail';
            } else if (Areas.CATEGORY === this.area) {
                routeName = 'dreisc.seo.bulk.category.detail';
            }

            return {
                name: routeName,
                params: {
                    seoOption: this.dreiscSeoBulkEntity.seoOption,
                    languageId: this.dreiscSeoBulkEntity.languageId,
                    salesChannelId: null !== this.salesChannelId ? this.salesChannelId : '_',
                    id: this.dreiscSeoBulkEntity.categoryId
                }
            };
        },

        dreiscSeoBulkWarnText() {
            if (null === this.dreiscSeoBulkEntity || null === this.dreiscSeoBulkEntity.dreiscSeoBulkTemplate || null === this.dreiscSeoBulkEntity.category || 'undefined' === typeof this.dreiscSeoBulkEntity.dreiscSeoBulkTemplate) {
                return null;
            }

            if(true === this.dreiscSeoBulkEntity.overwrite) {
                return 'overwrite';
            }

            return null;
        }
    },

    watch: {
        entity: {
            handler() {
                this.dreiscSeoBulkEntity = null;
                this.loadDreiscSeoBulkEntity();
            }
        },
        salesChannelId: {
            handler() {
                this.dreiscSeoBulkEntity = null;
                this.loadDreiscSeoBulkEntity();
            }
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.loadDreiscSeoBulkEntity();
        },

        translateSnippet(snippet, translateOnlyIfStartsWith = null) {
            if (null !== translateOnlyIfStartsWith && !snippet.startsWith(translateOnlyIfStartsWith)) {
                return snippet;
            }

            return this.$tc(snippet);
        },

        loadDreiscSeoBulkEntity() {
            if (Areas.PRODUCT === this.area) {
                this.loadProductDreiscSeoBulkEntity();
            } else if (Areas.CATEGORY === this.area) {
                this.loadCategoryDreiscSeoBulkEntity();
            }
        },

        loadProductDreiscSeoBulkEntity() {
            if ('string' !== typeof this.entity.id || true === this.entity._isNew) {
                return;
            }

            this.showBulkInfo = true;
            this.isLoading = true;

            this.bulkApiService.getResponsibleProductSeoBulkRespectPriority(
                this.entity.id,
                this.seoOption,
                this.currentLanguage,
                this.salesChannelId
            ).then(dreiscSeoBulkEntity => {
                this.dreiscSeoBulkEntity = dreiscSeoBulkEntity;
                this.isLoading = false;
            });
        },

        loadCategoryDreiscSeoBulkEntity() {
            if ('string' !== typeof this.entity.id || true === this.entity._isNew) {
                return;
            }

            this.showBulkInfo = true;
            this.isLoading = true;

            this.bulkApiService.getResponsibleSeoBulk(
                [ this.entity.id ],
                Areas.CATEGORY,
                this.seoOption,
                this.currentLanguage,
                this.salesChannelId
            ).then(response => {
                this.dreiscSeoBulkEntity = response[0].seoBulkEntity;
                this.isLoading = false;
            });



        }
    }
});
