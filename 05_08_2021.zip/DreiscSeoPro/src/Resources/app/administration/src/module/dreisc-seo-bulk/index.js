import './page/dreisc-seo-bulk-detail'
import './component/dreisc-seo-bulk-detail-tree'
import './view/dreisc-seo-bulk-detail-base'
import './component/dreisc-seo-bulk-template-list'
import './component/dreisc-seo-bulk-template-detail'
import './component/dreisc-seo-bulk-generator'
const { Module } = Shopware;
import snippetsDE_DE from './snippets/de-DE'
import snippetsEN_GB from './snippets/en-GB'

Module.register('dreisc-seo-bulk', {
    type: 'plugin',
    name: 'DreiscSeo',
    version: '1.0.0',
    targetVersion: '1.0.0',
    color: '#9AA8B5',
    icon: 'default-basic-stack-block',

    snippets: {
        'de-DE': snippetsDE_DE,
        'en-GB': snippetsEN_GB
    },

    routes: {
	    index: {
	        component: 'sw-error',
	        path: 'index',
	        redirect: {
	            name: 'dreisc.seo.bulk.detail'
	        }
	    },
	    detail: {
	        component: 'dreisc-seo-bulk-detail',
	        path: 'detail/:id?',
	        redirect: {
	            name: 'dreisc.seo.bulk.detail.base'
	        },
	        children: {
	            base: {
	                component: 'dreisc-seo-bulk-detail-base',
	                path: 'base'
	            }
	        }
	    }
	},

    // navigation: [{ }]
});
