const { Component, Mixin } = Shopware;
const { Criteria } = Shopware.Data;
import template from './dreisc-seo-bulk-product-detail.html.twig';
import './dreisc-seo-bulk-product-detail.scss';

Component.extend('dreisc-seo-bulk-product-detail', 'dreisc-seo-bulk-detail', {
    template,

    data() {
        return {
            detailRoute: 'dreisc.seo.bulk.product.detail',
            area: 'product',
            payload: {
                templateVariablesSnippetNamespace: 'dreiscSeoBulkProduct.payload.templateVariablesDescription',
                templateVariables: [
                    { key: 'isVariant', codeSnippet: '{% if isVariant %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'productId', codeSnippet: 'product.id', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productTranslatedName', codeSnippet: 'product.translated.name', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productTranslatedDescription', codeSnippet: 'product.translated.description', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productTranslatedKeywords', codeSnippet: 'product.translated.keywords', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productProductNumber', codeSnippet: 'product.productNumber', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productManufacturerNumber', codeSnippet: 'product.manufacturerNumber', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productManufacturerId', codeSnippet: 'product.manufacturer.id', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productManufacturerTranslatedName', codeSnippet: 'product.manufacturer.translated.name', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'productManufacturerTranslatedDescription', codeSnippet: 'product.manufacturer.translated.description', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'productEan', codeSnippet: 'product.ean', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productRestockTime', codeSnippet: 'product.restockTime', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productDeliveryTimeTranslatedName', codeSnippet: 'product.deliveryTime.translated.name', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'productMarkAsTopseller', codeSnippet: '{% if product.markAsTopseller %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'productIsCloseout', codeSnippet: '{% if product.isCloseout %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'productShippingFree', codeSnippet: '{% if product.shippingFree %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'productStock', codeSnippet: 'product.stock', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productAvailableStock', codeSnippet: 'product.availableStock', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productMinPurchase', codeSnippet: 'product.minPurchase', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productMaxPurchase', codeSnippet: 'product.maxPurchase', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productPurchaseSteps', codeSnippet: 'product.purchaseSteps', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productPackUnit', codeSnippet: 'product.packUnit', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productPurchaseUnit', codeSnippet: 'product.purchaseUnit', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productReferenceUnit', codeSnippet: 'product.referenceUnit', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productWeight', codeSnippet: 'product.weight', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productWidth', codeSnippet: 'product.width', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productHeight', codeSnippet: 'product.height', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productLength', codeSnippet: 'product.length', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productReleaseDateDate', codeSnippet: 'product.releaseDate.date', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productProductProperties', codeSnippet: '{% if product.properties is defined %}\n\t{# Place your code here #}\n\t{{ dump(product.properties) }}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'productProductOptions', codeSnippet: '{% if product.options is defined %}\n\t{# Place your code here #}\n\t{{ dump(product.options) }}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'productTaxTaxRate', codeSnippet: 'product.tax.taxRate', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productSeoMetaTitle', codeSnippet: 'productSeo.metaTitle', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productSeoIsInheritedMetaTitle', codeSnippet: '{% if productSeo.isInheritedMetaTitle %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'productSeoMetaDescription', codeSnippet: 'productSeo.metaDescription', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productSeoIsInheritedMetaDescription', codeSnippet: '{% if productSeo.isInheritedMetaDescription %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'productSeoUrl', codeSnippet: 'productSeo.url', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'productSeoIsInheritedUrl', codeSnippet: '{% if productSeo.isInheritedUrl %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'mainCategoryId', codeSnippet: 'mainCategory.id', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'mainCategoryTranslatedName', codeSnippet: 'mainCategory.translated.name', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'mainCategoryTranslatedDescription', codeSnippet: 'mainCategory.translated.description', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'mainCategoryTranslatedBreadcrumb', codeSnippet: 'mainCategory.translated.breadcrumb', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'mainCategoryType', codeSnippet: 'mainCategory.type', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'mainCategorySeoMetaTitle', codeSnippet: 'mainCategorySeo.metaTitle', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'mainCategorySeoIsInheritedMetaTitle', codeSnippet: '{% if mainCategorySeo.isInheritedMetaTitle %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'mainCategorySeoMetaDescription', codeSnippet: 'mainCategorySeo.metaDescription', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'mainCategorySeoIsInheritedMetaDescription', codeSnippet: '{% if mainCategorySeo.isInheritedMetaDescription %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'mainCategorySeoUrl', codeSnippet: 'mainCategorySeo.url', showCodeSnippetInName: true, addCurvedBraces: true },
                    { key: 'mainCategorySeoIsInheritedUrl', codeSnippet: '{% if mainCategorySeo.isInheritedUrl %}\n\t{# Place your code here #}\n{% endif %}', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'languageLocaleCode', codeSnippet: 'language.locale.code', showCodeSnippetInName: false, addCurvedBraces: true },
                    { key: 'liveShopName', codeSnippet: '##shopName##', showCodeSnippetInName: false, addCurvedBraces: false },
                    { key: 'liveProductPrice', codeSnippet: '##productPrice##', showCodeSnippetInName: false, addCurvedBraces: false },
                ]
            }
        }
    }
});
