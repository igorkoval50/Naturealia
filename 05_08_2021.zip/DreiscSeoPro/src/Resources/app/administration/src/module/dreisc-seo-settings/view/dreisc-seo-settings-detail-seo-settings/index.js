import dreiscSeoRichSnippetsDetailState from "../../page/dreisc-seo-settings-detail/state";

const { Component, Mixin } = Shopware;
import template from './dreisc-seo-settings-detail-seo-settings.html.twig';
import './dreisc-seo-settings-detail-seo-settings.scss';
import './../../mixin/custom-setting';
const { mapState, mapGetters } = Shopware.Component.getComponentHelper();

Component.register('dreisc-seo-settings-detail-seo-settings', {
    template,

    data() {
        return {
            robotsTags: [
                { key: 'index,follow', name: this.$tc('dreiscSeoDataSeoTab.seoForm.robotsTags.indexFollow')},
                { key: 'noindex,follow', name: this.$tc('dreiscSeoDataSeoTab.seoForm.robotsTags.noindexFollow')},
                { key: 'index,nofollow', name: this.$tc('dreiscSeoDataSeoTab.seoForm.robotsTags.indexNoFollow')},
                { key: 'noindex,nofollow', name: this.$tc('dreiscSeoDataSeoTab.seoForm.robotsTags.noindexNoFollow')}
            ]
        }
    },

    mixins: [
        Mixin.getByName('dreisc-seo-settings-custom-setting')
    ],

    computed: {
        isInherit() {
            return null !== this.currentSalesChannelId;
        },

        bulkGeneratorGeneral() {
            return this.getActiveCustomSetting('bulkGenerator.general');
        },

        metaTagsRobotsTag() {
            return this.getActiveCustomSetting('metaTags.robotsTag');
        },

        metaTagsRobotsTagInherit() {
            return this.getInheritCustomSetting('metaTags.robotsTag');
        },

        seoUrl() {
            return this.getActiveCustomSetting('seoUrl', true);
        },

        serp() {
            return this.getActiveCustomSetting('serp', true);
        }
    }
});
