const { Component, Mixin } = Shopware;
import template from './dreisc-seo-rich-snippet-detail-breadcrumb.html.twig';
import './dreisc-seo-rich-snippet-detail-breadcrumb.scss';
import './../../../dreisc-seo-settings/mixin/custom-setting-rich-snippets';

Component.register('dreisc-seo-rich-snippet-detail-breadcrumb', {
    template,

    data() {
        return {
            showInBreadcrumbModes: [
                { key: 'notDisplay', name: this.$tc('dreiscSeoRichSnippet.detail.showInBreadcrumbModes.product.notDisplay')},
                { key: 'onlyShop', name: this.$tc('dreiscSeoRichSnippet.detail.showInBreadcrumbModes.product.onlyShop')},
                { key: 'onlyJsonLd', name: this.$tc('dreiscSeoRichSnippet.detail.showInBreadcrumbModes.product.onlyJsonLd')},
                { key: 'shopAndJsonLd', name: this.$tc('dreiscSeoRichSnippet.detail.showInBreadcrumbModes.product.shopAndJsonLd')},
            ]
        }
    },

    mixins: [
        Mixin.getByName('dreisc-seo-settings-custom-setting-rich-snippets')
    ],

    computed: {
        isInherit() {
            return null !== this.currentSalesChannelId;
        },

        breadcrumbGeneral() {
            return this.getActiveCustomSetting('richSnippets.breadcrumb.general');
        },

        breadcrumbGeneralInherit() {
            return this.getInheritCustomSetting('richSnippets.breadcrumb.general');
        },

        breadcrumbHome() {
            return this.getActiveCustomSetting('richSnippets.breadcrumb.home');
        },

        breadcrumbHomeInherit() {
            return this.getInheritCustomSetting('richSnippets.breadcrumb.home');
        },

        breadcrumbProduct() {
            return this.getActiveCustomSetting('richSnippets.breadcrumb.product');
        },

        breadcrumbProductInherit() {
            return this.getInheritCustomSetting('richSnippets.breadcrumb.product');
        }
    }
});
