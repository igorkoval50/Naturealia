const { Component } = Shopware;
import template from './dreisc-seo-redirect-detail-base.html.twig';
import './dreisc-seo-redirect-detail-base.scss';

Component.register('dreisc-seo-redirect-detail-base', {
    template,

    data() {
        return {
            redirectHttpStatusCodes: [
                { key: '301', name: '301 (Dauerhafte Weiterleitung)'},
                { key: '302', name: '302 (Temporäre Weiterleitung)'}
            ]
        }
    },

    computed: {
        showSourceRestrictionFields: {
            get() {
                const sourceType = this.dreiscSeoRedirectEntity.sourceType;
                const restrictionTypes = ['product', 'category'];

                return restrictionTypes.includes(sourceType);
            }
        },

        showSourceSalesChannelDomainRestrictionIdsField: {
            get() {
                if(this.showSourceRestrictionFields && this.dreiscSeoRedirectEntity.hasSourceSalesChannelDomainRestriction) {
                    return true;
                }

                return false;
            }
        },

        showDeviatingRedirectSalesChannelDomainFields: {
            get() {
                const redirectType = this.dreiscSeoRedirectEntity.redirectType;
                const restrictionTypes = ['product', 'category'];

                return restrictionTypes.includes(redirectType);
            }
        },

        showDeviatingRedirectSalesChannelDomainIdField: {
            get() {
                if(this.showDeviatingRedirectSalesChannelDomainFields && this.dreiscSeoRedirectEntity.hasDeviatingRedirectSalesChannelDomain) {
                    return true;
                }

                return false;
            }
        },

        considerInheritanceContext() {
            let context = Shopware.Context.api;
            context.inheritance = true;

            return context;
        }
    },

    props: {
        dreiscSeoRedirectEntity: {
            type: Object | null,
            required: true
        },
        isLoading: {
            type: Boolean,
            required: false,
            default: false
        },
        isEditMode: {
            type: Boolean,
            required: false,
            default: false
        },
        fieldErrors: {
            type: Object | null,
            required: false
        }
    },

    methods: {
        isRedirectType(type) {
            if(type === this.dreiscSeoRedirectEntity.redirectType) {
                return true;
            }

            return false;
        },

        isSourceType(type) {
            if(type === this.dreiscSeoRedirectEntity.sourceType) {
                return true;
            }

            return false;
        },

        getBreadcrumb(item) {
            let breadcrumb = [];

            if('object' !== typeof item || 0 === item.breadcrumb.length) {
                return '';
            }

            item.breadcrumb.forEach((item) => {
                breadcrumb.push(item);
            });

            /** Remove the last element */
            breadcrumb.pop();

            return breadcrumb.join(' » ');
        }
    }
});
