import './component/dreisc-seo-doku-link-form-head'
import './component/dreisc-seo-sales-channel-switch'
import './component/dreisc-seo-inherit-wrapper'
const { Module } = Shopware;
import snippetsDE_DE from './snippets/de-DE'
import snippetsEN_GB from './snippets/en-GB'
import './index.scss';

Module.register('dreisc-seo', {
    type: 'pluginx',
    name: 'DreiscSeo',
    version: '1.0.0',
    targetVersion: '1.0.0',
    color: '#9AA8B5',
    icon: 'default-action-document-view',

    snippets: {
        'de-DE': snippetsDE_DE,
        'en-GB': snippetsEN_GB
    },

    routes: {
        index: {
            component: 'sw-error',
            path: 'index',
            redirect: {
                name: 'dreisc.seo.bulk.product.detail'
            }
        }
    },

    navigation: [{
        id: 'dreisc-seo',
        label: 'dreiscSeo.general.navigation.label',
        color: '#0070ba',
        path: 'dreisc.seo.index',
        icon: 'default-action-document-view',
        position: 50
    }]
});
