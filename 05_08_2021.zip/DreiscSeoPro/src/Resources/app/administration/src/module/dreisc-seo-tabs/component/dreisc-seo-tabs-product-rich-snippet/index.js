const { Component } = Shopware;
const { mapState, mapGetters } = Shopware.Component.getComponentHelper();
import template from './dreisc-seo-tabs-product-rich-snippet.html.twig';
import './dreisc-seo-tabs-product-rich-snippet.scss';

Component.register('dreisc-seo-tabs-product-rich-snippet', {
    template,

    data() {
        return {
            bufferedFields: {
                sku: '',
                mpn: '',
            },

            itemConditions: [
                { key: null, name: this.$tc('dreiscSeoRichSnippet.detail.itemConditions.UseDefault')},
                { key: 'NewCondition', name: this.$tc('dreiscSeoRichSnippet.detail.itemConditions.NewCondition')},
                { key: 'UsedCondition', name: this.$tc('dreiscSeoRichSnippet.detail.itemConditions.UsedCondition')},
                { key: 'RefurbishedCondition', name: this.$tc('dreiscSeoRichSnippet.detail.itemConditions.RefurbishedCondition')},
                { key: 'DamagedCondition', name: this.$tc('dreiscSeoRichSnippet.detail.itemConditions.DamagedCondition')}
            ],

            availabilities: [
                { key: null, name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.UseDefault')},
                { key: 'InStock', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.InStock')},
                { key: 'LimitedAvailability', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.LimitedAvailability')},
                { key: 'InStoreOnly', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.InStoreOnly')},
                { key: 'OnlineOnly', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.OnlineOnly')},
                { key: 'Discontinued', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.Discontinued')},
                { key: 'OutOfStock', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.OutOfStock')},
                { key: 'PreOrder', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.PreOrder')},
                { key: 'PreSale', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.PreSale')},
                { key: 'SoldOut', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.SoldOut')},
            ]
        }
    },

    computed: {
        ...mapState('swProductDetail', [
            'product',
            'parentProduct',
            'customFieldSets',
            'loading'
        ]),

        ...mapGetters('swProductDetail', [
            'isLoading'
        ]),

        customFields() {
            if (!this.product.customFields) {
                this.product.customFields = this.completeCustomFieldArray({});
            }

            if(0 === Object.keys(this.product.customFields)) {
                return this.completeCustomFieldArray({});
            }

            return this.completeCustomFieldArray(this.product.customFields);
        },

        customFieldsInherit() {
            if (!this.parentProduct.customFields) {
                this.parentProduct.customFields = this.completeCustomFieldArray({});
            }

            if(0 === Object.keys(this.parentProduct.customFields)) {
                return this.completeCustomFieldArray({});
            }

            return this.completeCustomFieldArray(this.parentProduct.customFields);
        }
    },

    methods: {
        completeCustomFieldArray(arr) {
            if (!arr.hasOwnProperty('dreisc_seo_rich_snippet_item_condition')) {
                arr['dreisc_seo_rich_snippet_item_condition'] = null;
            }
            if (!arr.hasOwnProperty('dreisc_seo_rich_snippet_availability')) {
                arr['dreisc_seo_rich_snippet_availability'] = null;
            }
            if (!arr.hasOwnProperty('dreisc_seo_rich_snippet_custom_sku')) {
                arr['dreisc_seo_rich_snippet_custom_sku'] = null;
            }
            if (!arr.hasOwnProperty('dreisc_seo_rich_snippet_custom_mpn')) {
                arr['dreisc_seo_rich_snippet_custom_mpn'] = null;
            }
            if (!arr.hasOwnProperty('dreisc_seo_rich_snippet_price_valid_until_date')) {
                arr['dreisc_seo_rich_snippet_price_valid_until_date'] = null;
            }

            return arr;
        }
    }
});
