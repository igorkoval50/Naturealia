const { Component, Mixin } = Shopware;
import template from './dreisc-seo-rich-snippet-detail-product.html.twig';
import './dreisc-seo-rich-snippet-detail-product.scss';
import './../../../dreisc-seo-settings/mixin/custom-setting-rich-snippets';

Component.register('dreisc-seo-rich-snippet-detail-product', {
    template,

    data() {
        return {
            itemConditions: [
                { key: 'NewCondition', name: this.$tc('dreiscSeoRichSnippet.detail.itemConditions.NewCondition')},
                { key: 'UsedCondition', name: this.$tc('dreiscSeoRichSnippet.detail.itemConditions.UsedCondition')},
                { key: 'RefurbishedCondition', name: this.$tc('dreiscSeoRichSnippet.detail.itemConditions.RefurbishedCondition')},
                { key: 'DamagedCondition', name: this.$tc('dreiscSeoRichSnippet.detail.itemConditions.DamagedCondition')}
            ],

            availabilities: [
                { key: 'InStock', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.InStock')},
                { key: 'LimitedAvailability', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.LimitedAvailability')},
                { key: 'InStoreOnly', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.InStoreOnly')},
                { key: 'OnlineOnly', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.OnlineOnly')},
                { key: 'Discontinued', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.Discontinued')},
                { key: 'OutOfStock', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.OutOfStock')},
                { key: 'PreOrder', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.PreOrder')},
                { key: 'PreSale', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.PreSale')},
                { key: 'SoldOut', name: this.$tc('dreiscSeoRichSnippet.detail.availabilities.SoldOut')},
            ],

            skuCompilations: [
                { key: 'productNumber', name: this.$tc('dreiscSeoRichSnippet.detail.skuCompilations.productNumber')},
                { key: 'manufacturerNumberOtherwiseProductNumber', name: this.$tc('dreiscSeoRichSnippet.detail.skuCompilations.manufacturerNumberOtherwiseProductNumber')}
            ],

            mpnCompilations: [
                { key: 'productNumber', name: this.$tc('dreiscSeoRichSnippet.detail.mpnCompilations.productNumber')},
                { key: 'manufacturerNumberOtherwiseProductNumber', name: this.$tc('dreiscSeoRichSnippet.detail.mpnCompilations.manufacturerNumberOtherwiseProductNumber')}
            ],

            priceValidUntilIntervals: [
                { key: 'notDisplay', name: this.$tc('dreiscSeoRichSnippet.detail.priceValidUntilIntervals.notDisplay')},
                { key: 'today', name: this.$tc('dreiscSeoRichSnippet.detail.priceValidUntilIntervals.today')},
                { key: '1day', name: this.$tc('dreiscSeoRichSnippet.detail.priceValidUntilIntervals.1day')},
                { key: '1week', name: this.$tc('dreiscSeoRichSnippet.detail.priceValidUntilIntervals.1week')},
                { key: '2week', name: this.$tc('dreiscSeoRichSnippet.detail.priceValidUntilIntervals.2week')},
                { key: '1month', name: this.$tc('dreiscSeoRichSnippet.detail.priceValidUntilIntervals.1month')},
                { key: 'customDays', name: this.$tc('dreiscSeoRichSnippet.detail.priceValidUntilIntervals.customDays')},
            ],

            reviewAuthorCompilations: [
                { key: 'notDisplay', name: this.$tc('dreiscSeoRichSnippet.detail.reviewAuthorCompilations.notDisplay')},
                { key: 'staticSnippet', name: this.$tc('dreiscSeoRichSnippet.detail.reviewAuthorCompilations.staticSnippet')},
                { key: 'firstName', name: this.$tc('dreiscSeoRichSnippet.detail.reviewAuthorCompilations.firstName')},
                { key: 'firstNameAndFirstLetterOfLastName', name: this.$tc('dreiscSeoRichSnippet.detail.reviewAuthorCompilations.firstNameAndFirstLetterOfLastName')},
                { key: 'firstNameAndLastName', name: this.$tc('dreiscSeoRichSnippet.detail.reviewAuthorCompilations.firstNameAndLastName')},
            ]
        }
    },

    mixins: [
        Mixin.getByName('dreisc-seo-settings-custom-setting-rich-snippets')
    ],

    computed: {
        isInherit() {
            return null !== this.currentSalesChannelId;
        },

        productOfferItemCondition() {
            return this.getActiveCustomSetting('richSnippets.product.offer.itemCondition');
        },

        productOfferItemConditionInherit() {
            return this.getInheritCustomSetting('richSnippets.product.offer.itemCondition');
        },

        productOfferAvailability() {
            return this.getActiveCustomSetting('richSnippets.product.offer.availability');
        },

        productOfferAvailabilityInherit() {
            return this.getInheritCustomSetting('richSnippets.product.offer.availability');
        },

        productGeneral() {
            return this.getActiveCustomSetting('richSnippets.product.general');
        },

        productGeneralInherit() {
            return this.getInheritCustomSetting('richSnippets.product.general');
        },

        productPriceValidUntil() {
            return this.getActiveCustomSetting('richSnippets.product.priceValidUntil');
        },

        productPriceValidUntilInherit() {
            return this.getInheritCustomSetting('richSnippets.product.priceValidUntil');
        },

        productReviewAuthor() {
            return this.getActiveCustomSetting('richSnippets.product.review.author');
        },

        productReviewAuthorInherit() {
            return this.getInheritCustomSetting('richSnippets.product.review.author');
        },

        productOfferSeller() {
            return this.getActiveCustomSetting('richSnippets.product.offer.seller');
        },

        productOfferSellerInherit() {
            return this.getInheritCustomSetting('richSnippets.product.offer.seller');
        }
    }
});
