const { Component } = Shopware;
import template from './dreisc-seo-tabs-social-media.html.twig';
import './dreisc-seo-tabs-social-media.scss';
import { LengthCalculatorHelper, LengthCalculationType } from './../../helper/length.calculator.helper';

Component.register('dreisc-seo-tabs-social-media', {
    template,

    inject: [
        'dreiscSeoCustomConfigApiService',
    ],

    props: {
        area: {
            type: String,
            required: true
        },

        entity: {
            type: Object | null,
            required: true
        },

        inheritedEntity: {
            type: Object | null,
            default() {
                return null;
            }
        },

        isLoading: {
            type: Boolean,
            default() {
                return false;
            }
        }
    },

    data() {
        return {
            customConfig: null,
            hasParent: true,
            entityFields: {
                dreisc_seo_facebook_title: null,
                dreisc_seo_facebook_description: null,
                dreisc_seo_facebook_image: null,
                dreisc_seo_twitter_title: null,
                dreisc_seo_twitter_description: null,
                dreisc_seo_twitter_image: null
            },
        }
    },

    computed: {
        customFields() {
            if (null === this.entity) {
                return this.completeCustomFieldArray({});
            }

            if (!this.entity.customFields) {
                this.entity.customFields = this.completeCustomFieldArray({});
            }

            if(0 === Object.keys(this.entity.customFields)) {
                return this.completeCustomFieldArray({});
            }

            return this.completeCustomFieldArray(this.entity.customFields);
        },

        customFieldsInherit() {
            if (null === this.inheritedEntity) {
                return this.completeCustomFieldArray({});
            }

            if (!this.inheritedEntity.customFields) {
                this.inheritedEntity.customFields = this.completeCustomFieldArray({});
            }

            if(0 === Object.keys(this.inheritedEntity.customFields)) {
                return this.completeCustomFieldArray({});
            }

            return this.completeCustomFieldArray(this.inheritedEntity.customFields);
        },

        facebookTitleLengthConfig() {
            return this.getLengthConfig(
                this.entityFields.dreisc_seo_facebook_title,
                'facebookTitle'
            );
        },

        facebookTitleLabel() {
            return this.addCharCounter(
                this.$tc('dreiscSeoDataSeoTab.socialMedia.fields.label.facebookTitle'),
                this.entityFields.dreisc_seo_facebook_title,
                'facebookTitle'
            );
        },

        facebookDescriptionLengthConfig() {
            return this.getLengthConfig(
                this.entityFields.dreisc_seo_facebook_description,
                'facebookDescription'
            );
        },

        facebookDescriptionLabel() {
            return this.addCharCounter(
                this.$tc('dreiscSeoDataSeoTab.socialMedia.fields.label.facebookDescription'),
                this.entityFields.dreisc_seo_facebook_description,
                'facebookDescription'
            );
        },

        twitterTitleLengthConfig() {
            return this.getLengthConfig(
                this.entityFields.dreisc_seo_twitter_title,
                'twitterTitle'
            );
        },

        twitterTitleLabel() {
            return this.addCharCounter(
                this.$tc('dreiscSeoDataSeoTab.socialMedia.fields.label.twitterTitle'),
                this.entityFields.dreisc_seo_twitter_title,
                'twitterTitle'
            );
        },

        twitterDescriptionLengthConfig() {
            return this.getLengthConfig(
                this.entityFields.dreisc_seo_twitter_description,
                'twitterDescription'
            );
        },

        twitterDescriptionLabel() {
            return this.addCharCounter(
                this.$tc('dreiscSeoDataSeoTab.socialMedia.fields.label.twitterDescription'),
                this.entityFields.dreisc_seo_twitter_description,
                'twitterDescription'
            );
        }
    },

    created() {
        this.createdComponent();
        this.loadEntityFields();
    },

    methods: {
        createdComponent() {
            this.dreiscSeoCustomConfigApiService.getCustomConfig().then(customConfigPromise => {
                this.customConfig = customConfigPromise.defaultCustomSettings;
            });
        },

        completeCustomFieldArray(arr) {
            if (!arr.hasOwnProperty('dreisc_seo_facebook_title')) {
                arr['dreisc_seo_facebook_title'] = null;
            }
            if (!arr.hasOwnProperty('dreisc_seo_facebook_description')) {
                arr['dreisc_seo_facebook_description'] = null;
            }
            if (!arr.hasOwnProperty('dreisc_seo_facebook_image')) {
                arr['dreisc_seo_facebook_image'] = null;
            }
            if (!arr.hasOwnProperty('dreisc_seo_twitter_title')) {
                arr['dreisc_seo_twitter_title'] = null;
            }
            if (!arr.hasOwnProperty('dreisc_seo_twitter_description')) {
                arr['dreisc_seo_twitter_description'] = null;
            }
            if (!arr.hasOwnProperty('dreisc_seo_twitter_image')) {
                arr['dreisc_seo_twitter_image'] = null;
            }

            return arr;
        },

        removeMedia(plattform) {
            switch (plattform) {
                case 'twitter':
                    this.entityFields.dreisc_seo_twitter_image = null;
                    break;
                case 'facebook':
                    this.entityFields.dreisc_seo_facebook_image = null;
                    break;
            }
        },

        setMedia(plattform, media) {
            switch (plattform) {
                case 'twitter':
                    this.entityFields.dreisc_seo_twitter_image = media.id;
                    break;
                case 'facebook':
                    this.entityFields.dreisc_seo_facebook_image = media.id;
                    break;
            }

            this.$forceUpdate();
        },

        successfulUpload(plattform, media) {
            switch (plattform) {
                case 'twitter':
                    this.entityFields.dreisc_seo_twitter_image = media.targetId;
                    break;
                case 'facebook':
                    this.entityFields.dreisc_seo_facebook_image = media.targetId;
                    break;
            }
        },

        addCharCounter(label, fieldValue, fieldKey) {
            const lengthConfig = this.getLengthConfig(fieldValue, fieldKey);
            let lengthString;

            if (null === lengthConfig) {
                return `${label}`;
            }

            if(lengthConfig.calculationType === LengthCalculationType.pixelLength) {
                lengthString = this.$tc('dreiscSeoDataSeoTab.seoForm.pixel');
            } else {
                lengthString = this.$tc('dreiscSeoDataSeoTab.seoForm.chars');
            }

            return `${label} (${lengthConfig.currentLength}/${lengthConfig.maxLength} ${lengthString})`;
        },

        getLengthConfig(fieldValue, fieldKey) {
            let calculationType = null;
            let currentLength = 0;

            if (null === this.customConfig) {
                return null;
            }

            if ('string' === typeof fieldValue) {
                currentLength = fieldValue.length;
            }

            return {
                calculationType: LengthCalculationType.charLength,
                currentLength: currentLength,
                maxLength: this.customConfig.socialMedia[fieldKey].lengthConfig.maxLength,
                recommendedLengthStart: this.customConfig.socialMedia[fieldKey].lengthConfig.recommendedLengthStart,
                recommendedLengthEnd: this.customConfig.socialMedia[fieldKey].lengthConfig.recommendedLengthEnd
            };
        },

        /**
         * We trigger the change event for keyup, so that we can update
         * the string length counter immediately
         */
        onKeyUp(event, props) {
            props.updateCurrentValue(event.target.value);
        },

        loadEntityFields() {
            this.entityFields.dreisc_seo_facebook_title = this.customFields.dreisc_seo_facebook_title;
            this.entityFields.dreisc_seo_facebook_description = this.customFields.dreisc_seo_facebook_description;
            this.entityFields.dreisc_seo_facebook_image = this.customFields.dreisc_seo_facebook_image;
            this.entityFields.dreisc_seo_twitter_title = this.customFields.dreisc_seo_twitter_title;
            this.entityFields.dreisc_seo_twitter_description = this.customFields.dreisc_seo_twitter_description;
            this.entityFields.dreisc_seo_twitter_image = this.customFields.dreisc_seo_twitter_image;
        }
    },

    watch: {
        'entityFields': {
            deep: true,
            handler() {
                this.customFields.dreisc_seo_facebook_title = this.entityFields.dreisc_seo_facebook_title;
                this.customFields.dreisc_seo_facebook_description = this.entityFields.dreisc_seo_facebook_description;
                this.customFields.dreisc_seo_facebook_image = this.entityFields.dreisc_seo_facebook_image;
                this.customFields.dreisc_seo_twitter_title = this.entityFields.dreisc_seo_twitter_title;
                this.customFields.dreisc_seo_twitter_description = this.entityFields.dreisc_seo_twitter_description;
                this.customFields.dreisc_seo_twitter_image = this.entityFields.dreisc_seo_twitter_image;
            }
        },
        'customFields': {
            deep: true,
            handler() {
                this.loadEntityFields();
            }
        }
    }
});
