const { Component } = Shopware;
import template from './dreisc-seo-tabs-seo-url.html.twig';
import './dreisc-seo-tabs-seo-url.scss';

Component.extend('dreisc-seo-tabs-seo-url', 'sw-seo-url', {
    template,

    inject: [
        'dreiscSeoCustomConfigApiService'
    ],

    props: {
        area: {
            type: String,
            required: true
        },

        hasParent: {
            type: Boolean,
            required: true
        },

        entity: {
            type: Object | null,
            required: true
        },

        inheritedEntity: {
            type: Object | null,
            default() {
                return null;
            }
        }
    },

    data() {
        return {
            customConfig: null,
            canonicalData: {},
            canonicalInheritData: {},

            canonicalLinkTypes: [
                { key: null, name: this.$tc('dreiscSeoDataSeoTab.seoUrl.canonicalLinkTypes.UseSeoPath')},
                { key: 'ExternalUrl', name: this.$tc('dreiscSeoDataSeoTab.seoUrl.canonicalLinkTypes.ExternalUrl')},
                { key: 'ProductUrl', name: this.$tc('dreiscSeoDataSeoTab.seoUrl.canonicalLinkTypes.ProductUrl')},
                { key: 'CategoryUrl', name: this.$tc('dreiscSeoDataSeoTab.seoUrl.canonicalLinkTypes.CategoryUrl')}
            ],

            canonicalLinkVariantTypes: [
                { key: null, name: this.$tc('dreiscSeoDataSeoTab.seoUrl.canonicalLinkTypes.InheritValue')},
                { key: 'UseSeoPath', name: this.$tc('dreiscSeoDataSeoTab.seoUrl.canonicalLinkTypes.UseSeoPath')},
                { key: 'ExternalUrl', name: this.$tc('dreiscSeoDataSeoTab.seoUrl.canonicalLinkTypes.ExternalUrl')},
                { key: 'ProductUrl', name: this.$tc('dreiscSeoDataSeoTab.seoUrl.canonicalLinkTypes.ProductUrl')},
                { key: 'CategoryUrl', name: this.$tc('dreiscSeoDataSeoTab.seoUrl.canonicalLinkTypes.CategoryUrl')}
            ]
        }
    },

    computed: {
        defaultSalesChannelId() {
            if(null === this.customConfig) {
                return null;
            }

            if (this.customConfig.hasOwnProperty('seoUrl') && this.customConfig.seoUrl.hasOwnProperty('defaultSalesChannelId')) {
                /** Check for valid id hash */
                if (32 === this.customConfig.seoUrl.defaultSalesChannelId.length) {
                    return this.customConfig.seoUrl.defaultSalesChannelId;
                }
            }

            return null;
        },

        customFields() {
            if (null === this.entity) {
                return this.completeCustomFieldArray({});
            }

            if (!this.entity.customFields) {
                this.entity.customFields = this.completeCustomFieldArray({});
            }

            if(0 === Object.keys(this.entity.customFields)) {
                return this.completeCustomFieldArray({});
            }

            return this.completeCustomFieldArray(this.entity.customFields);
        },

        customFieldsInherit() {
            if (null === this.inheritedEntity) {
                return this.completeCustomFieldArray({});
            }

            if (!this.inheritedEntity.customFields) {
                this.inheritedEntity.customFields = this.completeCustomFieldArray({});
            }

            if(0 === Object.keys(this.inheritedEntity.customFields)) {
                return this.completeCustomFieldArray({});
            }

            return this.completeCustomFieldArray(this.inheritedEntity.customFields);
        },

        considerInheritanceContext() {
            let context = Shopware.Context.api;
            context.inheritance = true;

            return context;
        }
    },

    created() {
        this.createComponent();
    },

    methods: {
        createComponent() {
            this.dreiscSeoCustomConfigApiService.getCustomConfig().then(customConfigPromise => {
                this.customConfig = customConfigPromise.defaultCustomSettings;
            });
        },

        onSalesChannelChanged(salesChannelId) {
            this.currentSalesChannelId = salesChannelId;
            this.refreshCurrentSeoUrl();
        },

        completeCustomFieldArray(arr) {
            /**
             * dreisc_seo_canonical_link_type
             * */
            if (!arr.hasOwnProperty('dreisc_seo_canonical_link_type') || null === arr['dreisc_seo_canonical_link_type']) {
                arr['dreisc_seo_canonical_link_type'] = {};
            } else if (arr.hasOwnProperty('dreisc_seo_canonical_link_type') && Array.isArray(arr['dreisc_seo_canonical_link_type'])) {
                /** Bugfix: Convert Array back to an object. This bug occurs after saved empty */
                if (0 === arr['dreisc_seo_canonical_link_type'].length) {
                    arr['dreisc_seo_canonical_link_type'] = {};
                }
            }

            if (
                null !== this.currentSalesChannelId &&
                !arr['dreisc_seo_canonical_link_type'].hasOwnProperty(this.currentSalesChannelId)
            ) {
                arr['dreisc_seo_canonical_link_type'][this.currentSalesChannelId] = null;
            }

            /**
             * dreisc_seo_canonical_link_reference
             * */
            if (!arr.hasOwnProperty('dreisc_seo_canonical_link_reference') || null === arr['dreisc_seo_canonical_link_reference']) {
                arr['dreisc_seo_canonical_link_reference'] = {};
            } else if (arr.hasOwnProperty('dreisc_seo_canonical_link_reference') && Array.isArray(arr['dreisc_seo_canonical_link_reference'])) {
                /** Bugfix: Convert Array back to an object. This bug occurs after saved empty */
                if (0 === arr['dreisc_seo_canonical_link_reference'].length) {
                    arr['dreisc_seo_canonical_link_reference'] = {};
                }
            }

            if (
                null !== this.currentSalesChannelId &&
                !arr['dreisc_seo_canonical_link_reference'].hasOwnProperty(this.currentSalesChannelId)
            ) {
                arr['dreisc_seo_canonical_link_reference'][this.currentSalesChannelId] = null;
            }

            return arr;
        },

        loadCanonicalData() {
            this.canonicalData = {
                dreisc_seo_canonical_link_type: this.customFields.dreisc_seo_canonical_link_type[this.currentSalesChannelId],
                dreisc_seo_canonical_link_reference: this.customFields.dreisc_seo_canonical_link_reference[this.currentSalesChannelId]
            };

            this.canonicalInheritData = {
                dreisc_seo_canonical_link_type: this.customFieldsInherit.dreisc_seo_canonical_link_type[this.currentSalesChannelId],
                dreisc_seo_canonical_link_reference: this.customFieldsInherit.dreisc_seo_canonical_link_reference[this.currentSalesChannelId]
            };
        },

        getBreadcrumb(item) {
            let breadcrumb = [];

            if('object' !== typeof item || 0 === item.breadcrumb.length) {
                return '';
            }

            item.breadcrumb.forEach((item) => {
                breadcrumb.push(item);
            });

            /** Remove the last element */
            breadcrumb.pop();

            return breadcrumb.join(' » ');
        }
    },

    watch: {
        customFields: {
            deep: true,
            handler() {
                this.loadCanonicalData();
            }
        },

        customFieldsInherit: {
            deep: true,
            handler() {
                this.loadCanonicalData();
            }
        },

        'currentSalesChannelId'() {
            this.loadCanonicalData();
        },

        canonicalData: {
            deep: true,
            handler() {
                this.customFields.dreisc_seo_canonical_link_type[this.currentSalesChannelId] = this.canonicalData.dreisc_seo_canonical_link_type;
                this.customFields.dreisc_seo_canonical_link_reference[this.currentSalesChannelId] = this.canonicalData.dreisc_seo_canonical_link_reference;

                this.customFieldsInherit.dreisc_seo_canonical_link_type[this.currentSalesChannelId] = this.canonicalInheritData.dreisc_seo_canonical_link_type;
                this.customFieldsInherit.dreisc_seo_canonical_link_reference[this.currentSalesChannelId] = this.canonicalInheritData.dreisc_seo_canonical_link_reference;
            }
        }
    }
});
