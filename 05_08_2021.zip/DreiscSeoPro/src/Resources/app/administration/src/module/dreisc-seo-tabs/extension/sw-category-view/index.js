const { Component } = Shopware;
import template from './dreisc-seo-tabs-sw-category-view.html.twig';
import './dreisc-seo-tabs-sw-category-view.scss';

Component.override('sw-category-view', {
    template
});
