const { Component, Mixin } = Shopware;
import template from './dreisc-seo-rich-snippet-detail-business.html.twig';
import './dreisc-seo-rich-snippet-detail-business.scss';
import './../../../dreisc-seo-settings/mixin/custom-setting-rich-snippets';

Component.register('dreisc-seo-rich-snippet-detail-business', {
    template,

    data() {
        return {
            logoGeneralCurrentSalesChannel: {
                active: null,
                url: null,
                logo: null
            }
        }
    },

    mixins: [
        Mixin.getByName('dreisc-seo-settings-custom-setting-rich-snippets')
    ],

    computed: {
        isInherit() {
            return null !== this.currentSalesChannelId;
        },

        logoGeneral() {
            return this.getActiveCustomSetting('richSnippets.logo.general');
        },

        logoGeneralInherit() {
            return this.getInheritCustomSetting('richSnippets.logo.general');
        },

        localBusinessGeneral() {
            return this.getActiveCustomSetting('richSnippets.localBusiness.general');
        },

        localBusinessGeneralInherit() {
            return this.getInheritCustomSetting('richSnippets.localBusiness.general');
        },

        localBusinessAddress() {
            return this.getActiveCustomSetting('richSnippets.localBusiness.address');
        },

        localBusinessAddressInherit() {
            return this.getInheritCustomSetting('richSnippets.localBusiness.address');
        },

        openingHoursSpecification() {
            return this.getActiveCustomSetting('richSnippets.localBusiness.openingHoursSpecification');
        },

        openingHoursSpecificationInherit() {
            return this.getInheritCustomSetting('richSnippets.localBusiness.openingHoursSpecification');
        }
    },

    methods: {
        removeLogoMedia() {
            if (0 === Object.keys(this.customSettings).length) {
                return;
            }

            this.logoGeneral.logo = null;
        },

        setMediaLogo([ media ]) {
            if (0 === Object.keys(this.customSettings).length) {
                return;
            }

            this.logoGeneral.logo = media.id
        }
    }
});
