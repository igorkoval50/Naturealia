const { Component, Mixin, StateDeprecated, Context } = Shopware;
const { Criteria } = Shopware.Data;
import template from './dreisc-seo-bulk-detail.html.twig';
import './dreisc-seo-bulk-detail.scss';
import './mixin/detail';
import './mixin/init';
import './mixin/repository';
import './mixin/route';
import './mixin/snippet';
import './mixin/tree';
import { SeoOptions, SeoOptionsWhichRequiredSalesChannel } from "../../helper/bulk.helper";

Component.register('dreisc-seo-bulk-detail', {
    template,

    inject: [
        'repositoryFactory',
        'bulkApiService'
    ],

    mixins: [
        Mixin.getByName('dreisc-seo-bulk-detail-detail'),
        Mixin.getByName('dreisc-seo-bulk-detail-init'),
        Mixin.getByName('dreisc-seo-bulk-detail-repository'),
        Mixin.getByName('dreisc-seo-bulk-detail-route'),
        Mixin.getByName('dreisc-seo-bulk-detail-snippet'),
        Mixin.getByName('dreisc-seo-bulk-detail-tree'),
        Mixin.getByName('notification'),
        Mixin.getByName('discard-detail-page-changes')('dreiscSeoBulk')
    ],

    data() {
        return {
            detailRoute: '',
            area: '',
            payload: {
                templateVariables: []
            },

            dreiscSeoBulkEntity: null,
            dreiscSeoBulkId: null,
            isCreateMode: false,
            isEditMode: false,
            isLoading: false,
            isSaveSuccessful: false,
            showSaveButton: false,
            showTabs: false,
            showDeleteModal: false,
            fieldErrors: {
                dreiscSeoBulkTemplateId: null
            },
            /** Tree data */
            isLoadingInitialData: false,
            items: [],
            activeItemId: null,
            activeItem: null,
            disableContextMenu: false,

            /** Bulk data */
            settingScope: {
                seoOption: null,
                languageId: null,
                salesChannelId: null
            },
            bulkTemplates: [],

            /** Route/Tree loading */
            setSalesChannelIdPlaceholder: false,
            componentCreationIsRunning: true,
            reloadComponentAfterLoading: false,

            /** Generator **/
            showGenerator: false
        };
    },

    created() {
        this.createdComponent();
    },

    watch: {
        '$route.params.id'() {
            this.activeItemId = this.$route.params.id;
            this.setDetailPage();
        },

        'settingScope.seoOption'() {
            this.settingScopeChanged();
        },

        'settingScope.languageId'() {
            this.settingScopeChanged();
        },

        'settingScope.salesChannelId'() {
            this.settingScopeChanged();
        }
    }
});
