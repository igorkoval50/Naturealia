// Store
export default {
    namespaced: true,

    state() {
        return {
            stateValue: 'VUEX Value'
        };
    },

    mutations: {
        setStateValue(state, newValue) {
            state.stateValue = newValue;
        }
    },

    getters: {

    }
};
