const { Component, Mixin, Context } = Shopware;
const { Criteria } = Shopware.Data;

import template from './dreisc-seo-redirect-detail.html.twig';
import './dreisc-seo-redirect-detail.scss';

Component.register('dreisc-seo-redirect-detail', {
    template,

    inject: [
        'repositoryFactory',
        'redirectService'
    ],

    mixins: [
        Mixin.getByName('notification'),
        Mixin.getByName('discard-detail-page-changes')('dreiscSeoRedirect')
    ],

    data() {
        return {
            dreiscSeoRedirectEntity: null,
            dreiscSeoRedirectId: null,
            showDeleteModal: false,
            isEditMode: false,
            isLoading: false,
            isSaveSuccessful: false,
            showTabs: false,
            fieldErrors: {
                sourceSalesChannelDomainId: null,
                sourcePath: null,
                sourceProductId: null,
                sourceCategoryId: null,
                redirectSalesChannelDomainId: null,
                redirectPath: null,
                redirectUrl: null,
                redirectProductId: null,
                redirectCategoryId: null
            }
        };
    },

    created() {
        this.createdComponent();
    },

    computed: {
        dreiscSeoRedirectRepository() {
            return this.repositoryFactory.create('dreisc_seo_redirect');
        },

        salesChannelDomainRepository() {
            return this.repositoryFactory.create('sales_channel_domain');
        },

        isCreateMode() {
            return this.$route.name.includes('create');
        }

    },

    methods: {
        createdComponent() {
            this.isLoading = true;

            if (this.$route.params.id) {
                this.dreiscSeoRedirectId = this.$route.params.id;

                if (false === this.isCreateMode) {
                    const criteria = new Criteria();

                    this.dreiscSeoRedirectRepository.get(this.dreiscSeoRedirectId, Context.api, criteria).then((dreiscSeoRedirectEntity) => {
                        this.dreiscSeoRedirectEntity = dreiscSeoRedirectEntity;
                        this.isLoading = false;
                    });
                }
            }

            if (this.$route.params.edit === 'edit') {
                this.isEditMode = true;
            }
        },

        onSave() {
            this.isSaveSuccessful = false;
            this.isLoading = true;

            if(true !== this.isFormValid()) {
                this.isLoading = false;

                this.createNotificationError({
                    title: this.$tc('dreiscSeoRedirect.detail.notification.titleSaveError'),
                    message: this.$tc('dreiscSeoRedirect.detail.notification.messageSaveError')
                });

                return;
            }

            return this.dreiscSeoRedirectRepository.save(this.dreiscSeoRedirectEntity, Context.api).then(() => {
                this.isLoading = false;
                this.isSaveSuccessful = true;

                this.createdComponent();
            }).catch((exception) => {
                this.createNotificationError({
                    title: this.$tc('dreiscSeoRedirect.detail.notification.titleSaveError'),
                    message: this.$tc('dreiscSeoRedirect.detail.notification.messageSaveError')
                });

                this.isLoading = false;
            });
        },

        isFormValid() {
            let isValid = true;

            /** Auto correct source path (slash) */
            if (this.dreiscSeoRedirectEntity.sourcePath && this.dreiscSeoRedirectEntity.sourcePath.startsWith('/')) {
                this.dreiscSeoRedirectEntity.sourcePath = this.dreiscSeoRedirectEntity.sourcePath.slice(1);
            }

            /** Auto correct redirect path (slash) */
            if (this.dreiscSeoRedirectEntity.redirectPath && this.dreiscSeoRedirectEntity.redirectPath.startsWith('/')) {
                this.dreiscSeoRedirectEntity.redirectPath = this.dreiscSeoRedirectEntity.redirectPath.slice(1);
            }

            /** Disable source restriction, if no domains are defined */
            if(
                this.dreiscSeoRedirectEntity.hasSourceSalesChannelDomainRestriction &&
                !Array.isArray(this.dreiscSeoRedirectEntity.sourceSalesChannelDomainRestrictionIds)
            ) {
                this.dreiscSeoRedirectEntity.hasSourceSalesChannelDomainRestriction = false;
            }

            /** Disable deviating redirect domain, if no domain is defined */
            if(
                this.dreiscSeoRedirectEntity.hasDeviatingRedirectSalesChannelDomain &&
                'string' !== typeof(this.dreiscSeoRedirectEntity.deviatingRedirectSalesChannelDomainId)
            ) {
                this.dreiscSeoRedirectEntity.hasDeviatingRedirectSalesChannelDomain = false;
            }

            /** Reset the errors */
            Object.keys(this.fieldErrors).forEach((errorKey) => {
                this.fieldErrors[errorKey] = null;
            });

            switch (this.dreiscSeoRedirectEntity.sourceType) {
                case 'url':
                    if(!this.dreiscSeoRedirectEntity.sourceSalesChannelDomainId || 0 === this.dreiscSeoRedirectEntity.sourceSalesChannelDomainId.length) {
                        isValid = false;
                        this.fieldErrors.sourceSalesChannelDomainId = this.generateErrorObject(
                            this.$tc('dreiscSeoRedirect.detailBase.fields.errors.defaultError')
                        );
                    }

                    if(!this.dreiscSeoRedirectEntity.sourcePath || 0 === this.dreiscSeoRedirectEntity.sourcePath.length) {
                        isValid = false;
                        this.fieldErrors.sourcePath = this.generateErrorObject(
                            this.$tc('dreiscSeoRedirect.detailBase.fields.errors.defaultError')
                        );
                    }

                    break;

                case 'product':
                    if(!this.dreiscSeoRedirectEntity.sourceProductId || 0 === this.dreiscSeoRedirectEntity.sourceProductId.length) {
                        isValid = false;
                        this.fieldErrors.sourceProductId = this.generateErrorObject(
                            this.$tc('dreiscSeoRedirect.detailBase.fields.errors.defaultError')
                        );
                    }

                    break;

                case 'category':
                    if(!this.dreiscSeoRedirectEntity.sourceCategoryId || 0 === this.dreiscSeoRedirectEntity.sourceCategoryId.length) {
                        isValid = false;
                        this.fieldErrors.sourceCategoryId = this.generateErrorObject(
                            this.$tc('dreiscSeoRedirect.detailBase.fields.errors.defaultError')
                        );
                    }

                    break;
            }

            switch (this.dreiscSeoRedirectEntity.redirectType) {
                case 'url':
                    if(!this.dreiscSeoRedirectEntity.redirectSalesChannelDomainId || 0 === this.dreiscSeoRedirectEntity.redirectSalesChannelDomainId.length) {
                        isValid = false;
                        this.fieldErrors.redirectSalesChannelDomainId = this.generateErrorObject(
                            this.$tc('dreiscSeoRedirect.detailBase.fields.errors.defaultError')
                        );
                    }

                    // if(!this.dreiscSeoRedirectEntity.redirectPath || 0 === this.dreiscSeoRedirectEntity.redirectPath.length) {
                    //     isValid = false;
                    //     this.fieldErrors.redirectPath = this.generateErrorObject(
                    //         this.$tc('dreiscSeoRedirect.detailBase.fields.errors.defaultError')
                    //     );
                    // }

                    break;

                case 'externalUrl':
                    if(!this.dreiscSeoRedirectEntity.redirectUrl || 0 === this.dreiscSeoRedirectEntity.redirectUrl.length) {
                        isValid = false;
                        this.fieldErrors.redirectUrl = this.generateErrorObject(
                            this.$tc('dreiscSeoRedirect.detailBase.fields.errors.defaultError')
                        );
                    }

                    break;

                case 'product':
                    if(!this.dreiscSeoRedirectEntity.redirectProductId || 0 === this.dreiscSeoRedirectEntity.redirectProductId.length) {
                        isValid = false;
                        this.fieldErrors.redirectProductId = this.generateErrorObject(
                            this.$tc('dreiscSeoRedirect.detailBase.fields.errors.defaultError')
                        );
                    }

                    break;

                case 'category':
                    if(!this.dreiscSeoRedirectEntity.redirectCategoryId || 0 === this.dreiscSeoRedirectEntity.redirectCategoryId.length) {
                        isValid = false;
                        this.fieldErrors.redirectCategoryId = this.generateErrorObject(
                            this.$tc('dreiscSeoRedirect.detailBase.fields.errors.defaultError')
                        );
                    }

                    break;
            }

            return isValid;
        },

        generateErrorObject(error) {
            return {
                code: 'ERROR',
                detail: error
            };
        },

        saveFinish() {
            this.isSaveSuccessful = false;
            this.isEditMode = false;
        },

        onActivateEditMode() {
            this.isEditMode = true;
        },

        onAbortButtonClick() {
            this.discardChanges();

            if (this.isCreateMode === true) {
                if(this.$route.meta && this.$route.meta.parentPath) {
                    this.$router.push({name: this.$route.meta.parentPath});
                }

                this.isLoading = false;
            }

            this.isEditMode = false;
        },

        onConfirmDelete(dreiscSeoRedirectId) {
            this.showDeleteModal = false;

            /**
             * This is a workaround because the entity is not deletable by the shopware DAL
             * @see: https://issues.shopware.com/issues/NEXT-7866
             */
            this.redirectService.deleteSeoRedirect(dreiscSeoRedirectId).then(() => {
                this.$router.push({
                    name: 'dreisc.seo.redirect.list'
                });
            });

            // return this.dreiscSeoRedirectRepository.delete(dreiscSeoRedirectId, Context.api).then(() => {
            //     this.$router.push({
            //         name: 'dreisc.seo.redirect.list'
            //     });
            // });
        }
    }
});
