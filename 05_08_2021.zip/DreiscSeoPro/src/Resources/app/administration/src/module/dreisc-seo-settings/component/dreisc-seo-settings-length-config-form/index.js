const { Component } = Shopware;
import template from './dreisc-seo-settings-length-config-form.html.twig';
import './dreisc-seo-settings-length-config-form.scss';
import dreiscSeoSettingsDetailState from './../../page/dreisc-seo-settings-detail/state';
const { mapPageErrors, mapState, mapGetters } = Shopware.Component.getComponentHelper();

Component.register('dreisc-seo-settings-length-config-form', {
    template,

    props: {
        headline: {
            type: String,
            required: true
        },

        isLoading: {
            type: Boolean,
            required: true
        },

        customSettings: {
            type: Object || null,
            required: true
        },

        dataKey: {
            type: String,
            required: true
        },

        dataRootKey: {
            type: String,
            default() {
                return 'metaTags';
            }
        },

        configType: {
            type: String,
            default() {
                return 'chars';
            }
        },

        dokuLink: {
            type: String || null,
            default() {
                return null;
            }
        }
    },

    data() {
        return {}
    },

    computed: {
        ...mapState('dreiscSeoSettingsDetailState', [
            'fieldErrors'
        ]),

        recommendedLengthStartModel: {
            get() {
                const lengthConfig = this.getLengthConfig();
                if(null === lengthConfig) {
                    return null;
                }

                return lengthConfig.recommendedLengthStart;
            },

            set(value) {
                const lengthConfig = this.getLengthConfig();
                if(null === lengthConfig) {
                    return;
                }

                lengthConfig.recommendedLengthStart = value;
            }
        },

        recommendedLengthEndModel: {
            get() {
                const lengthConfig = this.getLengthConfig();
                if(null === lengthConfig) {
                    return null;
                }

                return lengthConfig.recommendedLengthEnd;
            },

            set(value) {
                const lengthConfig = this.getLengthConfig();
                if(null === lengthConfig) {
                    return;
                }

                lengthConfig.recommendedLengthEnd = value;
            }
        },

        maxLengthModel: {
            get() {
                const lengthConfig = this.getLengthConfig();
                if(null === lengthConfig) {
                    return null;
                }

                return lengthConfig.maxLength;
            },

            set(value) {
                const lengthConfig = this.getLengthConfig();
                if(null === lengthConfig) {
                    return;
                }

                lengthConfig.maxLength = value;
            }
        }
    },

    methods: {
        getLengthConfig() {
            if (0 === Object.keys(this.customSettings).length) {
                return null;
            }

            if (0 === Object.keys(this.customSettings[this.dataRootKey]).length) {
                console.warn('this.customSettings.' + this.dataRootKey + ' is not set');
                return null;
            }

            if (0 === Object.keys(this.customSettings[this.dataRootKey][this.dataKey]).length) {
                console.warn('this.customSettings.' + this.dataRootKey + '.' + this.dataKey + ' is not set');
                return null;
            }

            return this.customSettings[this.dataRootKey][this.dataKey].lengthConfig;
        }
    }
});
