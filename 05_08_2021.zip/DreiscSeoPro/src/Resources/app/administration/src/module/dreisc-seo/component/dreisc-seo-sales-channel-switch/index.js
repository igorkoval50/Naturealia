const { Component } = Shopware;
import template from './dreisc-seo-sales-channel-switch.html.twig';
import './dreisc-seo-sales-channel-switch.scss';

/**
 * - Possibility to set an initial value for the sales channel
 */
Component.extend('dreisc-seo-sales-channel-switch', 'sw-sales-channel-switch', {
    template,

    props: {
        defaultSalesChannelId: {
            type: String|null
        }
    },

    data() {
        return {}
    },

    created() {
        this.applyDefaultSalesChannelId();
    },

    watch: {
        defaultSalesChannelId() {
            this.applyDefaultSalesChannelId();
        }
    },

    methods: {
        applyDefaultSalesChannelId() {
            /** Abort, if the salesChannelId is not empty */
            if ('' !== this.salesChannelId) {
                return;
            }

            /** Abort if default sales channel is null */
            if (null === this.defaultSalesChannelId) {
                return;
            }

            this.onChange(this.defaultSalesChannelId);
        }
    }
});
