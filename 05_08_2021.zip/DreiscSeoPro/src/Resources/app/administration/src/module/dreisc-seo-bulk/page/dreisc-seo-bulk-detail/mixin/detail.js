import {SeoOptions} from "../../../helper/bulk.helper";
const { Mixin } = Shopware;
const { Criteria } = Shopware.Data;

Mixin.register('dreisc-seo-bulk-detail-detail', {
    methods: {
        setDetailPage() {
            if (null === this.activeItemId) {
                return;
            }

            const categoryId = this.activeItemId;

            /** Load the bulk details */
            this.loadDetails(categoryId);

            /** Load the available bulk templates */
            this.loadBulkTemplates();

            /** Reset the errors */
            this.resetErrors();
        },

        loadDetails(categoryId) {
            /** Reset the seo bulk entity to empty the formular */
            this.dreiscSeoBulkEntity = null;

            /** Abort, if the selected seo option requires a sales channel and no sales channel is set */
            if (this.isSalesChannelRequired) {
                if (null === this.settingScope.salesChannelId) {
                    return;
                }
            }

            this.isCreateMode = false;
            this.isEditMode = false;
            this.isLoading = true;

            this.getDreiscSeoBulk(
                categoryId,
                this.area,
                this.settingScope.seoOption,
                this.settingScope.languageId,
                this.settingScope.salesChannelId
            ).then((items) => {
                if(items.total > 0) {
                    this.dreiscSeoBulkEntity = items.first();
                    this.isEditMode = true;
                    this.isLoading = false;
                } else {
                    this.dreiscSeoBulkEntity = this.dreiscSeoBulkRepository.create();
                    this.dreiscSeoBulkEntity.categoryId = categoryId;
                    this.dreiscSeoBulkEntity.area = this.area;
                    this.dreiscSeoBulkEntity.seoOption = this.settingScope.seoOption;
                    this.dreiscSeoBulkEntity.languageId = this.settingScope.languageId;
                    this.dreiscSeoBulkEntity.salesChannelId = this.settingScope.salesChannelId;
                    this.isLoading = false;
                }

                this.dreiscSeoBulkId = this.dreiscSeoBulkEntity.id;

                return items;
            });
        },

        loadBulkTemplates() {
            this.getDreiscSeoBulkTemplates(
                this.area,
                this.settingScope.seoOption
            ).then((seoBulkTemplates) => {
                seoBulkTemplates.forEach(seoBulkTemplate => {
                    seoBulkTemplate.displayName = this.translateSnippet(seoBulkTemplate.name, 'dreiscSeoBulk');
                });

                /** Sort for name */
                if (seoBulkTemplates.length) {
                    seoBulkTemplates.sort((a, b) => {
                        return ('' + a.displayName).localeCompare(b.displayName);
                    });
                }

                this.bulkTemplates = seoBulkTemplates;
            });
        },

        onReloadBulkTemplates() {
            this.loadBulkTemplates();

            /** Update the template information of the visible categories */
            this.updateBulkTemplateInformationOfVisibleCategories();
        },

        resetErrors() {
            /** Reset the errors */
            Object.keys(this.fieldErrors).forEach((errorKey) => {
                this.fieldErrors[errorKey] = null;
            });
        },

        isFormValid() {
            let isValid = true;

            /** Reset the errors */
            this.resetErrors();

            if(null === this.dreiscSeoBulkEntity.dreiscSeoBulkTemplateId || 'undefined' === typeof this.dreiscSeoBulkEntity.dreiscSeoBulkTemplateId) {
                isValid = false;
                this.fieldErrors.dreiscSeoBulkTemplateId = this.generateErrorObject(
                    this.$tc('dreiscSeoBulk.detailBase.fields.errors.defaultError')
                );
            }

            return isValid;
        },

        generateErrorObject(error) {
            return {
                code: 'ERROR',
                detail: error
            };
        },

        onSave() {
            this.isSaveSuccessful = false;
            this.showSaveButton = true;
            this.isLoading = true;

            if(true !== this.isFormValid()) {
                this.isLoading = false;
                this.showSaveButton = false;

                this.createNotificationError({
                    title: this.$tc('dreiscSeoBulk.detail.notification.titleSaveError'),
                    message: this.$tc('dreiscSeoBulk.detail.notification.messageSaveError')
                });

                return;
            }

            return this.dreiscSeoBulkRepository.save(this.dreiscSeoBulkEntity, Shopware.Context.api).then(() => {
                this.isLoading = false;
                this.isSaveSuccessful = true;

                /** Reload the details, if its was a new entry */
                if (this.dreiscSeoBulkEntity.isNew()) {
                    this.loadDetails(this.dreiscSeoBulkEntity.categoryId);
                    this.dreiscSeoBulkEntity = null;
                }

                /** Update the template information of the visible categories */
                this.updateBulkTemplateInformationOfVisibleCategories();
            }).catch((exception) => {
                this.createNotificationError({
                    title: this.$tc('dreiscSeoBulk.detail.notification.titleSaveError'),
                    message: this.$tc('dreiscSeoBulk.detail.notification.messageSaveError')
                });

                this.isLoading = false;
                this.showSaveButton = false;
                throw exception;
            });
        },

        saveFinish() {
            this.isSaveSuccessful = false;
            this.showSaveButton = false;
            this.isCreateMode = false;
            this.isEditMode = true;
        },

        onActivateCreateMode() {
            this.isCreateMode = true;
        },

        onAbortButtonClick() {
            this.discardChanges();

            if (this.isCreateMode === true) {
                if(this.$route.meta && this.$route.meta.parentPath) {
                    this.$router.push({name: this.$route.meta.parentPath});
                }

                this.isLoading = false;
            }

            this.isEditMode = false;
        },

        onConfirmDelete() {
            this.showDeleteModal = false;

            return this.dreiscSeoBulkRepository.delete(this.dreiscSeoBulkEntity.id, Shopware.Context.api).then(() => {
                /** Reload the details */
                this.loadDetails(this.dreiscSeoBulkEntity.categoryId);

                /** Update the template information of the visible categories */
                this.updateBulkTemplateInformationOfVisibleCategories();

                this.dreiscSeoBulkEntity = null;
                this.isEditMode = false;
            });
        }
    }
});
