const { Component } = Shopware;
import template from './dreisc-seo-tabs-length-status-bar.html.twig';
import './dreisc-seo-tabs-length-status-bar.scss';

Component.register('dreisc-seo-tabs-length-status-bar', {
    template,

    props: {
        lengthConfig: {
            type: Object | null,
            required: true
        },

        errorIfEmpty: {
            type: Boolean,
            default() {
                return false;
            }
        }
    },

    data() {
        return {
            backgroundColors: {
                ok: '#1cb841',
                risk: '#CCCC00',
                warning: '#df7514',
                error: '#e09191'
            }
        }
    },

    computed: {
        progressStyles() {
            let backgroundColor = this.backgroundColors.ok;
            let width = 0;

            if(null === this.lengthConfig) {
                return {
                    width: width,
                    backgroundColor: backgroundColor
                };
            }

            width = this.calculatePercent(this.lengthConfig) + '%';

            if (true === this.errorIfEmpty && this.lengthConfig.currentLength <= 0) {
                backgroundColor = this.backgroundColors.error;
                width = '100%';
            } else if (this.lengthConfig.currentLength < this.lengthConfig.recommendedLengthStart) {
                backgroundColor = this.backgroundColors.warning;
            } else if (this.lengthConfig.currentLength > this.lengthConfig.maxLength) {
                backgroundColor = this.backgroundColors.warning;
            } else if (this.lengthConfig.currentLength > this.lengthConfig.recommendedLengthEnd) {
                backgroundColor = this.backgroundColors.risk;
            }

            return {
                width: width,
                backgroundColor: backgroundColor
            };

        }
    },

    methods: {
        calculatePercent(lengthConfig) {
            const percent = Math.floor(100 / lengthConfig.maxLength * lengthConfig.currentLength);

            if (percent < 0) {
                return 0;
            } else if (percent > 100) {
                return 100;
            }

            return percent;
        }
    }
});
