const { Component, Context } = Shopware;
import template from './dreisc-seo-redirect-sales-channel-domain-select.html.twig';
import './dreisc-seo-redirect-sales-channel-domain-select.scss';
const { Criteria } = Shopware.Data;

Component.register('dreisc-seo-redirect-sales-channel-domain-select', {
    template,

    inject: ['repositoryFactory'],

    props: {
        promotion: {
            type: Object,
            required: false,
            default: null
        },
        dreiscSeoRedirectEntity: {
            type: Object,
            required: false,
            default: null
        },
        fieldName: {
            type: String,
            required: true
        }
    },

    data() {
        return {
            salesChannelDomains: []
        };
    },

    computed: {
        salesChannelDomainRepository() {
            return this.repositoryFactory.create('sales_channel_domain');
        },

        salesChannelDomainIds: {
            get() {
                if (null === this.dreiscSeoRedirectEntity[this.fieldName] || 'undefined' === typeof this.dreiscSeoRedirectEntity[this.fieldName]) {
                    return [];
                }

                return this.dreiscSeoRedirectEntity[this.fieldName];
            },

            set(salesChannelDomainIds) {
                this.dreiscSeoRedirectEntity[this.fieldName] = salesChannelDomainIds;
            }
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.salesChannelDomainRepository.search(new Criteria(), Context.api).then((searchresult) => {
                this.salesChannelDomains = searchresult;
            });
        }
    }
});
