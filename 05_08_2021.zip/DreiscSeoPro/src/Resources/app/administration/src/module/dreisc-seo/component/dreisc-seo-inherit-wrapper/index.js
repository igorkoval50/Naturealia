const { Component } = Shopware;
import template from './dreisc-seo-inherit-wrapper.html.twig';
import './dreisc-seo-inherit-wrapper.scss';

/**
 * - helpText support for inherit wrapper
 * - date-field support
 * - fix of the removeInheritance
 */
Component.extend('dreisc-seo-inherit-wrapper', 'sw-inherit-wrapper', {
    template,

    props: {
        helpText: {
            type: String|null
        }
    },

    methods: {
        /**
         * If a value was already assigned to the main product, it was no longer possible to define a
         * different value for the variant. This is adjusted with this workaround.
         */
        removeInheritance(newValue = this.currentValue) {
            this.$super('removeInheritance', null);
            this.$super('removeInheritance', newValue);
        },

        updateCurrentValue(value) {
            if(null === value) {
                this.currentValue = null;
            } else if ('object' === typeof value && value.hasOwnProperty(0) && value[0] instanceof Date) {
                /**
                 * We have a datefield an use the second argument of the onChange method
                 * @see: https://flatpickr.js.org/events/#hooks
                 **/
                this.currentValue = arguments[1];
            } else {
                /** Default */
                this.currentValue = value;
            }
        }
    }
});
