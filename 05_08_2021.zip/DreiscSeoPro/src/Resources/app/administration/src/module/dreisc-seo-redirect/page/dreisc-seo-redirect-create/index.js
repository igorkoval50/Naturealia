const { Component } = Shopware;
const { Criteria } = Shopware.Data;
import template from './dreisc-seo-redirect-create.html.twig';
import './dreisc-seo-redirect-create.scss';
import utils from 'src/core/service/util.service';

Component.extend('dreisc-seo-redirect-create', 'dreisc-seo-redirect-detail', {
    template,

    beforeRouteEnter(to, from, next) {
        if (to.name.includes('dreisc.seo.redirect.create') && !to.params.id) {
            to.params.id = utils.createId();
        }

        next();
    },

    methods: {
        createdComponent() {
            this.dreiscSeoRedirectEntity = this.dreiscSeoRedirectRepository.create(Shopware.Context.api, this.$route.params.id);
            this.$super('createdComponent');
            this.setDefaultValues();

            this.isLoading = false;
            this.isEditMode = true;
        },

        setDefaultValues() {
            this.dreiscSeoRedirectEntity.active = true;
            this.dreiscSeoRedirectEntity.redirectHttpStatusCode = '301';
            this.dreiscSeoRedirectEntity.sourceType = 'url';
            this.dreiscSeoRedirectEntity.redirectType = 'url';

            if ('string' === typeof this.$route.params.redirectEntity) {
                if ('product' === this.$route.params.redirectEntity) {
                    this.dreiscSeoRedirectEntity.sourceType = this.$route.params.redirectEntity;

                    if ('string' === typeof this.$route.params.entityId) {
                        this.dreiscSeoRedirectEntity.sourceProductId = this.$route.params.entityId;
                    }
                }

                else if ('category' === this.$route.params.redirectEntity) {
                    this.dreiscSeoRedirectEntity.sourceType = this.$route.params.redirectEntity;

                    if ('string' === typeof this.$route.params.entityId) {
                        this.dreiscSeoRedirectEntity.sourceCategoryId = this.$route.params.entityId;
                    }
                }
            }

            /** Load the first sales channel domain */
            const criteria = new Criteria(1, 1);
            this.salesChannelDomainRepository.search(criteria, Shopware.Context.api).then((searchResult) => {
                if(searchResult && searchResult[0] && searchResult[0].id) {
                    this.dreiscSeoRedirectEntity.sourceSalesChannelDomainId = searchResult[0].id;
                    this.dreiscSeoRedirectEntity.redirectSalesChannelDomainId = searchResult[0].id;
                }
            }).catch(() => {
                this.isLoading = false;
            });
        },

        saveFinish() {
            this.isSaveSuccessful = false;
            this.$router.push({name: 'dreisc.seo.redirect.detail', params: {id: this.dreiscSeoRedirectEntity.id}});
        },

        onSave() {
            this.$super('onSave');
        }
    }
});
