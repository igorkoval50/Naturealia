import './page/dreisc-seo-bulk-category-detail'
import './component/dreisc-seo-bulk-category-detail-tree'
import './view/dreisc-seo-bulk-category-detail-base'
const { Module } = Shopware;
import snippetsDE_DE from './snippets/de-DE'
import snippetsEN_GB from './snippets/en-GB'

Module.register('dreisc-seo-bulk-category', {
    type: 'plugin',
    name: 'DreiscSeo',
    version: '1.0.0',
    targetVersion: '1.0.0',
    color: '#9AA8B5',
    icon: 'default-basic-stack-block',

    snippets: {
        'de-DE': snippetsDE_DE,
        'en-GB': snippetsEN_GB
    },

    routes: {
	    index: {
	        component: 'sw-error',
	        path: 'index',
	        redirect: {
	            name: 'dreisc.seo.bulk.category.detail'
	        }
	    },
	    detail: {
	        component: 'dreisc-seo-bulk-category-detail',
            path: 'detail/:seoOption?/:languageId?/:salesChannelId?/:id?',
	        redirect: {
	            name: 'dreisc.seo.bulk.category.detail.base'
	        },
	        children: {
	            base: {
	                component: 'dreisc-seo-bulk-category-detail-base',
	                path: 'base'
	            }
	        }
	    }
	},

    navigation: [{
        id: 'dreisc-seo-bulk-category',
        label: 'dreiscSeoBulkCategory.general.navigation.label',
        color: '#0070ba',
        path: 'dreisc.seo.bulk.category.index',
        icon: 'default-basic-stack-block',
        parent: 'dreisc-seo',
        position: 20
    }]
});
