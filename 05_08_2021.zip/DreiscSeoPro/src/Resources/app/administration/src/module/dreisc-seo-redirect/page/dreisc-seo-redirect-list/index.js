const { Component, Mixin, Context } = Shopware;
const { Criteria } = Shopware.Data;
import template from './dreisc-seo-redirect-list.html.twig';
import './dreisc-seo-redirect-list.scss';

Component.register('dreisc-seo-redirect-list', {
    template,

    inject: [
        'repositoryFactory',
        'redirectService'
    ],

    mixins: [
        Mixin.getByName('notification'),
        Mixin.getByName('listing')
    ],

    data() {
        return {
            dreiscSeoRedirectEntities: null,
            showImportExport: false,
            sortBy: 'id',
            sortDirection: 'DESC',
            naturalSorting: true,
            isLoading: false,
            showDeleteModal: false,
            createRoute: 'dreisc.seo.redirect.create',
            detailRoute: 'dreisc.seo.redirect.detail'
        };
    },

    metaInfo() {
        return {
            title: this.$createTitle()
        };
    },

    computed: {
        dreiscSeoRedirectRepository() {
            return this.repositoryFactory.create('dreisc_seo_redirect');
        },

        listColumns() {
            return this.getListColumns();
        },

        hasValidCreateRoute() {
            const link = this.$router.resolve({
                name: this.createRoute
            });

            if (link && link.href !== '#/' && link.href !== '/') {
                return true;
            }

            return false;
        }
    },

    methods: {
        onInlineEditSave(promise, customer) {
            promise.then(() => {
                this.createNotificationSuccess({
                    title: this.$tc('dreiscSeoRedirect.list.notification.titleSaveSuccess'),
                    message: this.$tc('dreiscSeoRedirect.list.notification.messageSaveSuccess', 0, {name: customer.sourceUrl})
                });
            }).catch(() => {
                this.getList();
                this.createNotificationError({
                    title: this.$tc('dreiscSeoRedirect.list.notification.titleSaveError'),
                    message: this.$tc('dreiscSeoRedirect.list.notification.messageSaveError')
                });
            });
        },

        getList() {
            this.isLoading = true;
            const criteria = new Criteria(this.page, this.limit);

            criteria.setTerm(this.term);
            criteria.addSorting(Criteria.sort(this.sortBy, this.sortDirection, this.naturalSorting));
            criteria.addAssociation('sourceSalesChannelDomain');
            criteria.addAssociation('sourceProduct');
            criteria.addAssociation('sourceCategory');
            criteria.addAssociation('redirectSalesChannelDomain');
            criteria.addAssociation('redirectProduct');
            criteria.addAssociation('redirectCategory');

            this.dreiscSeoRedirectRepository.search(criteria, Context.api).then((items) => {
                this.total = items.total;
                this.dreiscSeoRedirectEntities = items;
                this.isLoading = false;

                return items;
            }).catch(() => {
                this.isLoading = false;
            });
        },

        onDelete(id) {
            this.showDeleteModal = id;
        },

        onCloseDeleteModal() {
            this.showDeleteModal = false;
        },

        onConfirmDelete(id) {
            this.showDeleteModal = false;

            /**
             * This is a workaround because the entity is not deletable by the shopware DAL
             * @see: https://issues.shopware.com/issues/NEXT-7866
             */
            this.redirectService.deleteSeoRedirect(id).then(() => {
                this.getList();
            });

            // return this.dreiscSeoRedirectRepository.delete(id, Context.api).then(() => {
            //     this.getList();
            // });
        },

        getListColumns() {

            return [{
				property: 'active',
				inlineEdit: 'boolean',
				label: this.$tc('dreiscSeoRedirect.list.columns.labels.active'),
				allowResize: true,
				align: 'center',
				width: '80px'
        	},{
				property: 'sourceType',
				label: this.$tc('dreiscSeoRedirect.list.columns.labels.sourcePath'),
				allowResize: true,
				routerLink: 'dreisc.seo.redirect.detail'
        	},{
				property: 'redirectType',
				label: this.$tc('dreiscSeoRedirect.list.columns.labels.redirectUrl'),
				allowResize: true,
				routerLink: 'dreisc.seo.redirect.detail'
        	},{
				property: 'redirectHttpStatusCode',
				label: this.$tc('dreiscSeoRedirect.list.columns.labels.redirectHttpStatusCode'),
				allowResize: true,
				routerLink: 'dreisc.seo.redirect.detail'
        	}];
        },

        getSourcePreview(item) {
            let sourcePreview = '';

            switch (item.sourceType) {
                case 'url':
                    if(item.sourceSalesChannelDomain) {
                        sourcePreview+= item.sourceSalesChannelDomain.url;
                    }

                    /** Add a slash, if the domain don't ends with it */
                    if(!sourcePreview.endsWith('/')) {
                        sourcePreview+= '/';
                    }

                    sourcePreview+= item.sourcePath;
                    break;

                case 'product':
                    sourcePreview+= this.$tc('dreiscSeoRedirect.list.columns.types.product');

                    if(item.sourceProduct) {
                        sourcePreview+= item.sourceProduct.translated.name;
                    }
                    break;


                case 'category':
                    sourcePreview+= this.$tc('dreiscSeoRedirect.list.columns.types.category');

                    if(item.sourceCategory) {
                        sourcePreview+= item.sourceCategory.translated.name;
                    }
                    break;

                default:
                    sourcePreview+= item.sourceType;
            }

            return sourcePreview;
        },

        getRedirectPreview(item) {
            let redirectPreview = '';

            switch (item.redirectType) {
                case 'url':
                    if(item.redirectSalesChannelDomain) {
                        redirectPreview+= item.redirectSalesChannelDomain.url;
                    }

                    /** Add a slash, if the domain don't ends with it */
                    if(!redirectPreview.endsWith('/')) {
                        redirectPreview+= '/';
                    }

                    if(null !== item.redirectPath) {
                        redirectPreview+= item.redirectPath;
                    }

                    break;
                case 'externalUrl':
                    redirectPreview+= item.redirectUrl;
                    break;

                case 'product':
                    redirectPreview+= this.$tc('dreiscSeoRedirect.list.columns.types.product');

                    if(item.redirectProduct) {
                        redirectPreview+= item.redirectProduct.translated.name;
                    }
                    break;


                case 'category':
                    redirectPreview+= this.$tc('dreiscSeoRedirect.list.columns.types.category');

                    if(item.redirectCategory) {
                        redirectPreview+= item.redirectCategory.translated.name;
                    }
                    break;

                default:
                    redirectPreview+= item.redirectType;
            }

            return redirectPreview;
        }
    }
});
