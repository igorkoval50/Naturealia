import {SeoOptions} from "../../helper/bulk.helper";

const { Component, Mixin } = Shopware;
const { Criteria, EntityCollection } = Shopware.Data;
const { warn } = Shopware.Utils.debug;
const utils = Shopware.Utils;
import template from './dreisc-seo-bulk-template-detail.html.twig';
import './dreisc-seo-bulk-template-detail.scss';

Component.register('dreisc-seo-bulk-template-detail', {
    template,

    inject: [
        'bulkApiService',
        'entityMappingService'
    ],

    data() {
        return {
            templatePreview: {
                isInit: false,
                isLoading: false,
                isValid: false,
                showErrorMsg: false,
                errorMsg: '',
                renderedTemplate: '',
                previewProduct: null
            },
            editorConfig: {
                enableBasicAutocompletion: true
            },
            fieldErrors: {
                name: null
            },
            selectedTemplateVariable: null
        }
    },

    props: {
        currentBulkTemplate: {
            type: Object,
            default() {
                return {};
            }
        },
        settingScope: {
            type: Object | null,
            required: true
        },
        payload: {
            type: Object | null,
            required: true
        },
        activeItemId: {
            type: Object | null,
            required: true
        },
        area: {
            type: String | null,
            required: true
        }
    },

    computed: {
        showPreviewProduct() {
            if (this.area === 'product') {
                return true;
            }

            return false;
        },

        isPreviewProductValid() {
            if (false === this.showPreviewProduct) {
                return true;
            }

            if (null !== this.previewReferenceId) {
                return true;
            }

            return false;
        },

        previewReferenceId() {
            if (this.showPreviewProduct) {
                return this.templatePreview.previewProduct;
            }

            return this.activeItemId;
        },

        templateVariables() {
            const templateVariables = this.payload.templateVariables;

            templateVariables.forEach(templateVariable => {
                templateVariable.name = this.$tc(`${this.payload.templateVariablesSnippetNamespace}.${templateVariable.key}`);

                if (templateVariable.showCodeSnippetInName && true === templateVariable.showCodeSnippetInName) {
                    templateVariable.name = `<b>${templateVariable.name}</b> (${templateVariable.codeSnippet})`;
                }
            });

            return templateVariables;
        },

        considerInheritanceContext() {
            let context = Shopware.Context.api;
            context.inheritance = true;

            return context;
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.debounceUpdateTemplatePreview();
        },

        onCancel() {
            this.$emit('onCancel', this.currentBulkTemplate);
        },

        onSave() {
            if (true === this.isFormValid()) {
                this.$emit('onSave', this.currentBulkTemplate);
            }
        },

        onSelectInput(key) {
            const vueEditor = this.$refs.templateEditor;
            const editor = vueEditor.editor;
            const selectedTemplate = this.getTemplateVariableByKey(key);

            if(null === selectedTemplate) {
                return;
            }

            /** Insert variable */
            if (true === selectedTemplate.addCurvedBraces) {
                editor.session.insert(editor.getCursorPosition(), `{{ ${selectedTemplate.codeSnippet} }}`);
            } else {
                editor.session.insert(editor.getCursorPosition(), selectedTemplate.codeSnippet);
            }

            /** Reset selection */
            this.selectedTemplateVariable = null;
        },

        onInput() {
            this.debounceUpdateTemplatePreview();
        },

        debounceUpdateTemplatePreview: utils.debounce(function updateTemplatePreview() {
            /** Abort, if preview product is not valid */
            if (false === this.isPreviewProductValid) {
                return;
            }
            /** Set as isInit */
            this.templatePreview.isInit = true;

            /** Activate loading */
            this.templatePreview.isLoading = true;

            this.bulkApiService.getTemplatePreview(
                this.area,
                this.previewReferenceId,
                this.settingScope.seoOption,
                this.settingScope.languageId,
                this.settingScope.salesChannelId,
                this.currentBulkTemplate.template,
                this.currentBulkTemplate.spaceless
            ).then(templateResponse => {
                /** Disable loading */
                this.templatePreview.isLoading = false;

                if (true === templateResponse.success) {
                    /** Set the valid flag */
                    this.templatePreview.isValid = true;

                    /** Fetch the rendered template */
                    this.templatePreview.renderedTemplate = templateResponse.renderedTemplate;
                } else {
                    /** Set the valid flag */
                    this.templatePreview.isValid = false;

                    /** Set the error message */
                    this.templatePreview.errorMsg = templateResponse.error;
                }
            });
        }, 500),

        resetErrors() {
            /** Reset the errors */
            Object.keys(this.fieldErrors).forEach((errorKey) => {
                this.fieldErrors[errorKey] = null;
            });
        },

        isFormValid() {
            let isValid = true;

            /** Reset the errors */
            this.resetErrors();

            if(null === this.currentBulkTemplate.name || 'undefined' === typeof this.currentBulkTemplate.name) {
                isValid = false;
                this.fieldErrors.name = this.generateErrorObject(
                    this.$tc('dreiscSeoBulk.detailBase.fields.errors.defaultError')
                );
            }

            return isValid;
        },

        generateErrorObject(error) {
            return {
                code: 'ERROR',
                detail: error
            };
        },

        completerFunction()  {
            return (function completerWrapper() {
                function completerFunction() {
                    const properties = [];
                    properties.push({
                        value: 'AAAAAA'
                    });

                    properties.push({
                        value: 'BBBBB'
                    });

                    return properties;
                }
                return completerFunction;
            }());
        },

        getTemplateVariableByKey(key) {
            let selectedTemplate = null;

            this.payload.templateVariables.forEach((template) => {
                if (template.key && key === template.key) {
                    selectedTemplate = template;
                }
            });

            return selectedTemplate;
        }
    }
});
