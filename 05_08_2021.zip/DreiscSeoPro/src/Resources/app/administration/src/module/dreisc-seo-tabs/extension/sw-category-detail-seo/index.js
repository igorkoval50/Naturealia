const { Component } = Shopware;
import template from './dreisc-seo-tabs-sw-category-detail-seo.html.twig';
import './dreisc-seo-tabs-sw-category-detail-seo.scss';

Component.override('sw-category-detail-seo', {
    template
});
