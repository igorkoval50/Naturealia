export const LengthCalculationType = {
    charLength: 'charLength',
    pixelLength: 'pixelLength'
};

export const LengthCalculatorHelper = {
    truncateString,
    calculatePixel,
    ord
};

function truncateString(string, maxChars, maxPixel, pixelTable) {
    if (null === string) {
        return '';
    }

    const currentStringLength = string.length;
    if (0 === currentStringLength) {
        return '';
    }

    /** Caluculate the pixel length */
    if (null !== maxPixel && null !== pixelTable) {
        const currentStringPixel = calculatePixel(string, pixelTable);

        /** Make sure that the min pixel width of 50 pixel is set, otherwise we get a error in the calculation */
        if (maxPixel < 50) {
            maxPixel = 50;
        }

        if(currentStringPixel > maxPixel) {
            return getTruncatedString(string, maxPixel, pixelTable);
        }
    }

    if (null !== maxChars && currentStringLength > maxChars) {
        string = string.substr(0,(maxChars - 4)) + ' ...';
    }

    return string;
}

function calculatePixel(string, pixelTable) {

    const chars = string.split('');
    let pixelLength = 0;

    chars.forEach((char) => {
        let ord = LengthCalculatorHelper.ord(char);
        let charPixelLength = parseFloat(pixelTable[ord]);

        // console.log(char + '» ord:' + ord + '» pixel:' + charPixelLength);

        /** Set default length if no defined */
        if (charPixelLength <= 0 || isNaN(charPixelLength)) {
            charPixelLength = parseFloat(pixelTable['default']);
        }

        pixelLength+= charPixelLength;
    });

    return Math.ceil(pixelLength);
}

function ord(string) {
    //  discuss at: https://locutus.io/php/ord/
    // original by: Kevin van Zonneveld (https://kvz.io)
    // bugfixed by: Onno Marsman (https://twitter.com/onnomarsman)
    // improved by: Brett Zamir (https://brett-zamir.me)
    //    input by: incidence
    //   example 1: ord('K')
    //   returns 1: 75
    //   example 2: ord('\uD800\uDC00'); // surrogate pair to create a single Unicode character
    //   returns 2: 65536

    var str = string + '';
    var code = str.charCodeAt(0);

    if (code >= 0xD800 && code <= 0xDBFF) {
        // High surrogate (could change last hex to 0xDB7F to treat
        // high private surrogates as single characters)
        var hi = code;
        if (str.length === 1) {
            // This is just a high surrogate with no following low surrogate,
            // so we return its value;
            return code
            // we could also throw an error as it is not a complete character,
            // but someone may want to know
        }
        var low = str.charCodeAt(1);
        return ((hi - 0xD800) * 0x400) + (low - 0xDC00) + 0x10000
    }
    if (code >= 0xDC00 && code <= 0xDFFF) {
        // Low surrogate
        // This is just a low surrogate with no preceding high surrogate,
        // so we return its value;
        return code
        // we could also throw an error as it is not a complete character,
        // but someone may want to know
    }

    return code;
}

function getTruncatedString(string, maxPixel, pixelTable) {
    const postfixString = ' ...';
    string = string.substr(0,(string.length - 1));

    const currentStringPixel = calculatePixel(string + postfixString, pixelTable);
    if(currentStringPixel > maxPixel) {
        return getTruncatedString(string, maxPixel, pixelTable)
    }

    return string + postfixString;
}
