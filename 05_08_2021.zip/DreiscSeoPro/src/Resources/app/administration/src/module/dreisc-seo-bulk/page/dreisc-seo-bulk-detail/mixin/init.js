import {SeoOptions} from "../../../helper/bulk.helper";

const { Mixin } = Shopware;

Mixin.register('dreisc-seo-bulk-detail-init', {
    methods: {
        reloadComponent() {
            if(true === this.componentCreationIsRunning) {
                this.reloadComponentAfterLoading = true;
                return;
            }

            /** Reset flag */
            this.reloadComponentAfterLoading = false;

            /** Start */
            this.componentCreationIsRunning = true;
            this.createdComponent();
        },

        finishInitialLoading() {
            this.componentCreationIsRunning = false;

            if (true === this.reloadComponentAfterLoading) {
                this.reloadComponent();
            }
        },

        createdComponent() {
            /** Set the seo option, if it's defined in the url */
            if (this.$route.params.seoOption) {
                this.settingScope.seoOption = this.$route.params.seoOption;
            } else {
                /** Set default value */
                this.settingScope.seoOption = SeoOptions.META_TITLE
            }

            /** Set the language, if it's defined in the url */
            if (this.$route.params.languageId) {
                this.settingScope.languageId = this.$route.params.languageId;
            } else {
                /** Set default value */
                this.settingScope.languageId = Shopware.Context.api.languageId;
            }

            /** Set the sales channel, if it's defined in the url */
            if (this.$route.params.salesChannelId && '_' !== this.$route.params.salesChannelId) {
                this.settingScope.salesChannelId = this.$route.params.salesChannelId;
            }

            /** Load the detail page */
            if (this.$route.params.id) {
                this.activeItemId = this.$route.params.id;
                this.setDetailPage();
            }


            if(this.isSalesChannelRequired && null === this.settingScope.salesChannelId) {
                /** Do not load the tree, because the sales channel is missing */
                this.resetTree();
                this.finishInitialLoading();
            } else {
                /** Loads the information of the sales channel, if active */
                this.fetchActiveSalesChannel().then(salesChannel => {
                    /** Load the tree */
                    this.getItems(null, salesChannel).then(() => {
                        this.loadActiveItemPath(salesChannel);
                    });
                });


            }

        }
    }
});
