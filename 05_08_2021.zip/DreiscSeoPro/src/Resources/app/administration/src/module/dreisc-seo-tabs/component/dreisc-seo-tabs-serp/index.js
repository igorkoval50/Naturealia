const { Component } = Shopware;
const { Criteria } = Shopware.Data;
import template from './dreisc-seo-tabs-serp.html.twig';
import './dreisc-seo-tabs-serp.scss';
import { LengthCalculatorHelper } from './../../helper/length.calculator.helper';

Component.register('dreisc-seo-tabs-serp', {
    template,

    inject: [
        'dreiscSeoCustomConfigApiService',
        'repositoryFactory'
    ],

    props: {
        entity: {
            type: Object | null,
            required: true
        },
        inheritedEntity: {
            type: Object | null,
            default: () => {
                return null;
            }
        },
        externalLoading: {
            type: Boolean,
            required: true
        }
    },

    data() {
        return {
            customConfig: null,
            currentSalesChannelId: null,
            currentSalesChannelEntity: null,
            currentSalesChannelDomainEntity: null,
            previewMode: 'desktop',
            loading: false
        }
    },

    computed: {
        salesChannelRepository() {
            return this.repositoryFactory.create('sales_channel');
        },

        currentLanguageId() {
            return Shopware.Context.api.languageId;
        },

        defaultSalesChannelId() {
            if(null === this.customConfig) {
                return null;
            }

            if (this.customConfig.hasOwnProperty('serp') && this.customConfig.serp.hasOwnProperty('defaultSalesChannelId')) {
                /** Check for valid id hash */
                if (32 === this.customConfig.serp.defaultSalesChannelId.length) {
                    return this.customConfig.serp.defaultSalesChannelId;
                }
            }

            return null;
        },

        isLoading: {
            get() {
                return !!(this.loading || this.externalLoading);
            },

            set(value) {
                this.loading = value;
            }
        },

        activeDomain() {
            if (null === this.currentSalesChannelDomainEntity) {
                return '';
            }

            let domain = this.currentSalesChannelDomainEntity.url;
            domain = domain.replace('https://', '');
            domain = domain.replace('http://', '');

            return domain.split('/').shift();
        },

        metaTitle() {
            let metaTitle = '';
            if(null === this.entity || null === this.customConfig) {
                return null;
            }

            if ('string' === typeof this.entity.metaTitle) {
                metaTitle = this.entity.metaTitle;
            } else if (null !== this.inheritedEntity && null === this.entity.metaTitle && 'string' === typeof this.inheritedEntity.metaTitle) {
                metaTitle = this.inheritedEntity.metaTitle;
            }

            return LengthCalculatorHelper.truncateString(
                metaTitle,
                null,
                this.customConfig.metaTags.metaTitle.lengthConfig.maxLength,
                this.customConfig.pixelTable
            );
        },

        metaDescription() {
            let metaDescription = '';
            if(null === this.entity || null === this.customConfig) {
                return null;
            }

            if ('string' === typeof this.entity.metaDescription) {
                metaDescription = this.entity.metaDescription;
            } else if (null !== this.inheritedEntity && null === this.entity.metaDescription && 'string' === typeof this.inheritedEntity.metaDescription) {
                metaDescription = this.inheritedEntity.metaDescription;
            }

            return LengthCalculatorHelper.truncateString(
                metaDescription,
                this.customConfig.metaTags.metaDescription.lengthConfig.maxLength,
                null,
                null
            );
        }
    },

    created() {
        this.createComponent();
    },

    watch: {
        currentLanguageId() {
            this.loadSalesChannelData();
        }
    },

    methods: {
        createComponent() {
            this.dreiscSeoCustomConfigApiService.getCustomConfig().then(customConfigPromise => {
                this.customConfig = customConfigPromise.defaultCustomSettings;
            });
        },

        onSalesChannelChanged(salesChannelId) {
            if (null === salesChannelId) {
                return;
            }

            this.currentSalesChannelId = salesChannelId;
            this.loadSalesChannelData();
        },

        loadSalesChannelData() {
            if (null === this.currentSalesChannelId) {
                this.currentSalesChannelEntity = null;
                this.currentSalesChannelDomainEntity = null;
                return;
            }

            this.isLoading = true;

            const criteria = new Criteria();
            criteria.addAssociation('domains');

            this.salesChannelRepository.get(
                this.currentSalesChannelId,
                Shopware.Context.api,
                criteria
            ).then((salesChannelEntity) => {
                this.isLoading = false;

                // Check, if it is headless (from Defaults.php)
                if (salesChannelEntity === null || 'f183ee5650cf4bdb8a774337575067a6' === salesChannelEntity.typeId) {
                    /** Is headless */
                    this.currentSalesChannelEntity = null;
                    this.currentSalesChannelDomainEntity = null;
                    return;
                }

                /** Filter out, if domain has not the same language id */
                const filteredDomainCollection = salesChannelEntity.domains.filter(domainEntity => {
                    return this.currentLanguageId === domainEntity.languageId;
                });

                /** Abort, if no domain found */
                if (0 === filteredDomainCollection) {
                    this.currentSalesChannelEntity = salesChannelEntity;
                    this.currentSalesChannelDomainEntity = null;
                    return;
                }

                this.currentSalesChannelEntity = salesChannelEntity;
                this.currentSalesChannelDomainEntity = filteredDomainCollection.first();
            });
        }
    }
});
