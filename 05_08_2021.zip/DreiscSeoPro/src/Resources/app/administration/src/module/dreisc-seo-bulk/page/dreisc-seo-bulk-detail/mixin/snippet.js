import {SeoOptions} from "../../../helper/bulk.helper";
const { Mixin } = Shopware;
const { Criteria } = Shopware.Data;

Mixin.register('dreisc-seo-bulk-detail-snippet', {
    methods: {
        translateSnippet(snippet, translateOnlyIfStartsWith = null) {
            if (null !== translateOnlyIfStartsWith && !snippet.startsWith(translateOnlyIfStartsWith)) {
                return snippet;
            }

            return this.$tc(snippet);
        }
    }
});
