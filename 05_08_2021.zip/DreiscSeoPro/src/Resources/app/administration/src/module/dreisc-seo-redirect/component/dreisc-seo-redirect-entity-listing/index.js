const { Component } = Shopware;
import template from './dreisc-seo-redirect-entity-listing.html.twig';
import './dreisc-seo-redirect-entity-listing.scss';

Component.extend('dreisc-seo-redirect-entity-listing', 'sw-entity-listing', {
    template,

    inject: [
        'redirectService'
    ],

    methods: {
        deleteItems() {
            this.isBulkLoading = true;
            const promises = [];

            Object.values(this.selection).forEach((selectedProxy) => {
                promises.push(this.redirectService.deleteSeoRedirect(selectedProxy.id));
            });

            return Promise.all(promises).then(() => {
                return this.deleteItemsFinish();
            }).catch(() => {
                return this.deleteItemsFinish();
            });
        }
    }
});
