import {SeoOptions, SeoOptionsWhichRequiredSalesChannel} from "../../../helper/bulk.helper";
const { Criteria } = Shopware.Data;
const { State, Mixin } = Shopware;

Mixin.register('dreisc-seo-bulk-detail-repository', {
    computed: {
        categoryRepository() {
            return this.repositoryFactory.create('category');
        },

        dreiscSeoBulkRepository() {
            return this.repositoryFactory.create('dreisc_seo_bulk');
        },

        dreiscSeoBulkTemplateRepository() {
            return this.repositoryFactory.create('dreisc_seo_bulk_template');
        },

        salesChannelRepository() {
            return this.repositoryFactory.create('sales_channel');
        }
    },

    methods: {
        fetchActiveSalesChannel() {
            return new Promise((resolve, reject) => {
                if (null === this.settingScope.salesChannelId) {
                    resolve(null);
                } else {
                    const criteria = new Criteria();

                    this.salesChannelRepository.get(
                        this.settingScope.salesChannelId,
                        Shopware.Context.api,
                        criteria
                    ).then((salesChannelEntity) => {
                        resolve(salesChannelEntity);
                    });
                }
            })
        },

        getDreiscSeoBulk(categoryId, area, seoOption, languageId, salesChannelId = null) {
            const criteria = new Criteria(1, 500);

            criteria.addFilter(Criteria.multi('AND', [
                Criteria.equals('categoryId', categoryId),
                Criteria.equals('area', area),
                Criteria.equals('seoOption', seoOption),
                Criteria.equals('languageId', languageId),
                Criteria.equals('salesChannelId', salesChannelId)
            ]));

            return this.dreiscSeoBulkRepository.search(criteria, Shopware.Context.api);
        },

        getDreiscSeoBulkTemplates(area, seoOption) {
            const criteria = new Criteria(1, 500);

            criteria.addFilter(Criteria.multi('AND', [
                Criteria.equals('area', area),
                Criteria.equals('seoOption', seoOption)
            ]));

            return this.dreiscSeoBulkTemplateRepository.search(criteria, Shopware.Context.api);
        }
    }
});
