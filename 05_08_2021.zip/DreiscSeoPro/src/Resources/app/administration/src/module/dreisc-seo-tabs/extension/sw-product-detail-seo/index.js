const { Component } = Shopware;
const { mapState } = Component.getComponentHelper();
import template from './dreisc-seo-tabs-sw-product-detail-seo.html.twig';
import './dreisc-seo-tabs-sw-product-detail-seo.scss';

Component.override('sw-product-detail-seo', {
    template,

    computed: {
        ...mapState('swProductDetail', [
            'parentProduct'
        ])
    },

    methods: {
        /**
         * Copied from: platform/src/Administration/Resources/app/administration/src/module/sw-product/view/sw-product-detail-base/index.js
         * @param mainCategory
         */
        onMainCategoryAdded(mainCategory) {
            this.product.mainCategories.push(mainCategory);
        }
    }
});
