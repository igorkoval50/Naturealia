const { Component, Context } = Shopware;
import template from './dreisc-seo-redirect-redirect-sales-channel-domain-form.html.twig';
import './dreisc-seo-redirect-redirect-sales-channel-domain-form.scss';
const { Criteria } = Shopware.Data;

Component.register('dreisc-seo-redirect-redirect-sales-channel-domain-form', {
    template,

    inject: [
        'repositoryFactory'
    ],

    props: {
        dreiscSeoRedirectEntity: {
            type: Object | null,
            required: true
        },
        isEditMode: {
            type: Boolean,
            required: false,
            default: false
        },
        fieldErrors: {
            type: Object | null,
            required: false
        }
    },

    data() {
        return {
            salesChannelDomainEntity: null
        }
    },

    computed: {
        salesChannelDomainRepository() {
            return this.repositoryFactory.create('sales_channel_domain');
        },

        absoluteSourceUrl() {
            let url = this.salesChannelDomainEntity.url;

            /** Add a slash, if the domain don't ends with it */
            if(!url.endsWith('/')) {
                url+= '/';
            }

            /** Add the redirect path */
            if(null !== this.dreiscSeoRedirectEntity && null !== this.dreiscSeoRedirectEntity.redirectPath) {
                url+= this.dreiscSeoRedirectEntity.redirectPath;
            }

            return url;
        }
    },

    watch: {
        /** Refresh the salesChannelDomainEntity, when the salesChannelDomain was changed */
        'dreiscSeoRedirectEntity.redirectSalesChannelDomainId': {
            handler() {
                this.loadSalesChannelDomain();
            }
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            if(null !== this.dreiscSeoRedirectEntity) {
                this.loadSalesChannelDomain();
            }
        },

        loadSalesChannelDomain() {
            if(null === this.dreiscSeoRedirectEntity || undefined === this.dreiscSeoRedirectEntity.redirectSalesChannelDomainId) {
                return;
            }

            const criteria = new Criteria();

            this.salesChannelDomainRepository.get(
                this.dreiscSeoRedirectEntity.redirectSalesChannelDomainId,
                Context.api,
                criteria
            ).then((salesChannelDomainEntity) => {
                this.salesChannelDomainEntity = salesChannelDomainEntity;
            });
        }
    }
});
