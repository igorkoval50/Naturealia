const { Component } = Shopware;
import template from './dreisc-seo-rich-snippet-opening-hours-grid.html.twig';
import './dreisc-seo-rich-snippet-opening-hours-grid.scss';

//Component.extend('dreisc-seo-rich-snippet-opening-hours-grid', 'sw-data-grid', {
Component.register('dreisc-seo-rich-snippet-opening-hours-grid', {
    template,

    props: {
        isInherit: {
            type: Boolean | null,
            required: true
        },
        openingHoursSpecification: {
            type: Object | null,
            required: true
        },
        openingHoursSpecificationInherit: {
            type: Object | null,
            required: true
        }
    },

    data() {
        return {
            datepickerConfig: {
                enableTime: true,
                dateFormat: 'H:i',
                altFormat: 'H:i'
            },
            columns: [
                { property: 'active', label: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.columns.active'), rawData: true },
                { property: 'dayOfWeekString', label: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.columns.dayOfWeekString'), rawData: true },
                { property: 'opens', label: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.columns.opens'), rawData: true },
                { property: 'closes', label: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.columns.closes'), rawData: true }
            ],
            dataSource: [
                {
                    id: 'monday',
                    active: false,
                    dayOfWeekString: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.dataSource.dayOfWeek.monday'),
                    opens: '09:00',
                    closes: '18:00'
                },{
                    id: 'tuesday',
                    active: false,
                    dayOfWeekString: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.dataSource.dayOfWeek.tuesday'),
                    opens: '09:00',
                    closes: '18:00'
                },{
                    id: 'wednesday',
                    active: false,
                    dayOfWeekString: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.dataSource.dayOfWeek.wednesday'),
                    opens: '09:00',
                    closes: '18:00'
                },{
                    id: 'thursday',
                    active: false,
                    dayOfWeekString: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.dataSource.dayOfWeek.thursday'),
                    opens: '09:00',
                    closes: '18:00'
                },{
                    id: 'friday',
                    active: false,
                    dayOfWeekString: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.dataSource.dayOfWeek.friday'),
                    opens: '09:00',
                    closes: '18:00'
                },{
                    id: 'saturday',
                    active: false,
                    dayOfWeekString: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.dataSource.dayOfWeek.saturday'),
                    opens: '09:00',
                    closes: '18:00'
                },{
                    id: 'sunday',
                    active: false,
                    dayOfWeekString: this.$tc('dreiscSeoRichSnippet.openingHoursGrid.dataSource.dayOfWeek.sunday'),
                    opens: '09:00',
                    closes: '18:00'
                }
            ]
        }
    },

    watch: {
        openingHoursSpecification() {
            if (null === this.openingHoursSpecification) {
                return;
            }

            /** Iterate all data sources to match the fields */
            this.dataSource.forEach(dataItem => {
                const dayOfWeek = dataItem.id;

                if (this.openingHoursSpecification.hasOwnProperty(dayOfWeek)) {
                    dataItem.active = this.openingHoursSpecification[dayOfWeek].active;
                    dataItem.opens = this.openingHoursSpecification[dayOfWeek].opens;
                    dataItem.closes = this.openingHoursSpecification[dayOfWeek].closes;

                    if (null !== this.openingHoursSpecificationInherit && this.openingHoursSpecificationInherit.hasOwnProperty(dayOfWeek)) {
                        dataItem.activeInherit = this.openingHoursSpecificationInherit[dayOfWeek].active;
                        dataItem.opensInherit = this.openingHoursSpecificationInherit[dayOfWeek].opens;
                        dataItem.closesInherit = this.openingHoursSpecificationInherit[dayOfWeek].closes;

                        if (null === dataItem.opens && null !== dataItem.opensInherit) {
                            dataItem.opens = dataItem.opensInherit;
                        }

                        if (null === dataItem.closes && null !== dataItem.closesInherit) {
                            dataItem.closes = dataItem.closesInherit;
                        }
                    } else {
                        dataItem.activeInherit = null;
                        dataItem.opensInherit = null;
                        dataItem.closesInherit = null;
                    }

                    if ('' === dataItem.opens) {
                        dataItem.opens = '09:00';
                    }

                    if ('' === dataItem.closes) {
                        dataItem.closes = '18:00';
                    }
                }
            });
        },

        dataSource: {
            deep: true,
            handler() {
                const specification = [];

                /** Merge the specifications in the custom settings array */
                this.dataSource.forEach(dataItem => {
                    const dayOfWeek = dataItem.id;

                    if (this.openingHoursSpecification.hasOwnProperty(dayOfWeek)) {
                        this.openingHoursSpecification[dayOfWeek].active = dataItem.active;
                        this.openingHoursSpecification[dayOfWeek].opens = dataItem.opens;
                        this.openingHoursSpecification[dayOfWeek].closes = dataItem.closes;
                    }
                });
            }
        }
    }
});
