const { Mixin } = Shopware;

Mixin.register('dreisc-seo-bulk-detail-route', {
    methods: {
        updateRoute(id = null) {
            const seoOption = this.settingScope.seoOption;
            const languageId = this.settingScope.languageId;
            const salesChannelId = true === this.setSalesChannelIdPlaceholder ? '_' : this.settingScope.salesChannelId;
            let reinitializeComponent = false;

            /** Reinitialize, if there was a change in the scope setting */
            if(
                seoOption !== this.$route.params.seoOption ||
                languageId !== this.$route.params.languageId ||
                salesChannelId !== this.$route.params.salesChannelId
            ) {
                reinitializeComponent = true;
            }

            this.$router.push({
                name: this.detailRoute,
                params: {
                    id: id,
                    seoOption: seoOption,
                    languageId: languageId,
                    salesChannelId: salesChannelId
                }
            });

            /** Reinitialize, if there was a change in the scope setting */
            if(reinitializeComponent) {
                /** Reinitialize the component */
                this.reloadComponent();
            }
        }
    }
});
