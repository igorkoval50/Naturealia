const { Component } = Shopware;
import {Areas} from "./../../../dreisc-seo-bulk/helper/bulk.helper";
import template from './dreisc-seo-tabs-sw-category-detail-base.html.twig';
import './dreisc-seo-tabs-sw-category-detail-base.scss';

Component.override('sw-category-detail-base', {
    template,

    inject: [ 'dreiscSeoCustomConfigApiService' ],

    data() {
        return {
            customConfig: null,
            area: Areas.CATEGORY
        }
    },

    created() {
        this.getCustomConfig();
    },

    methods: {
        getCustomConfig() {
            this.dreiscSeoCustomConfigApiService.getCustomConfig().then(customConfigPromise => {
                this.customConfig = customConfigPromise.defaultCustomSettings;
            });
        }
    }
});
