const { Component } = Shopware;
import template from './dreisc-seo-tabs-sw-category-seo-form.html.twig';
import './dreisc-seo-tabs-sw-category-seo-form.scss';
import dreiscSeoTabsSeoFormState from './../../component/dreisc-seo-tabs-seo-form/state';
import { LengthCalculatorHelper, LengthCalculationType } from './../../helper/length.calculator.helper';

Component.override('sw-category-seo-form', {
    template,

    inject: [
        'dreiscSeoCustomConfigApiService',
    ],

    data() {
        return {
            customConfig: null,

            robotsTags: [
                { key: null, name: this.$tc('dreiscSeoDataSeoTab.seoForm.robotsTags.useDefault')},
                { key: 'index,follow', name: this.$tc('dreiscSeoDataSeoTab.seoForm.robotsTags.indexFollow')},
                { key: 'noindex,follow', name: this.$tc('dreiscSeoDataSeoTab.seoForm.robotsTags.noindexFollow')},
                { key: 'index,nofollow', name: this.$tc('dreiscSeoDataSeoTab.seoForm.robotsTags.indexNoFollow')},
                { key: 'noindex,nofollow', name: this.$tc('dreiscSeoDataSeoTab.seoForm.robotsTags.noindexNoFollow')}
            ]
        }
    },

    computed: {
        metaTitleLengthConfig() {
            return this.getLengthConfig('metaTitle');
        },

        metaDescriptionLengthConfig() {
            return this.getLengthConfig('metaDescription');
        },

        keywordsLengthConfig() {
            return this.getLengthConfig('keywords');
        },

        labelMetaTitle() {
            let label = this.$tc('sw-product.seoForm.labelMetaTitle');

            /** Add char counter to label */
            label = this.addCharCounter(label, 'metaTitle');

            return label;
        },

        labelMetaDescription() {
            let label = this.$tc('sw-product.seoForm.labelMetaDescription');

            /** Add char counter to label */
            label = this.addCharCounter(label, 'metaDescription');

            return label;
        },

        labelKeywords() {
            let label = this.$tc('sw-product.seoForm.labelKeywords');

            /** Add char counter to label */
            label = this.addCharCounter(label, 'keywords');

            return label;
        },

        customFields() {
            if (null === this.category) {
                return {};
            }

            if (!this.category.customFields) {
                this.category.customFields = this.completeCustomFieldArray({});
            }

            if(0 === Object.keys(this.category.customFields)) {
                return this.completeCustomFieldArray({});
            }

            return this.completeCustomFieldArray(this.category.customFields);
        }
    },

    created() {
        this.createdComponent();
    },

    beforeCreate() {
        if (!Shopware.State.list().includes('dreiscSeoTabsSeoFormState')) {
            Shopware.State.registerModule('dreiscSeoTabsSeoFormState', dreiscSeoTabsSeoFormState);
        }
    },

    beforeDestroy() {
        if (Shopware.State.list().includes('dreiscSeoTabsSeoFormState')) {
            Shopware.State.unregisterModule('dreiscSeoTabsSeoFormState');
        }
    },

    methods: {
        createdComponent() {
            Shopware.State.commit('dreiscSeoTabsSeoFormState/setStateValue', this.category.id);
            this.dreiscSeoCustomConfigApiService.getCustomConfig().then(customConfigPromise => {
                this.customConfig = customConfigPromise.defaultCustomSettings;
            });
        },

        addCharCounter(label, fieldKey)
        {
            const lengthConfig = this.getLengthConfig(fieldKey);
            let lengthString;

            if (null === lengthConfig) {
                const strLength = this.getFieldLength(fieldKey, LengthCalculationType.charLength);

                return `${label} (${strLength})`;
            }

            if(lengthConfig.calculationType === LengthCalculationType.pixelLength) {
                lengthString = this.$tc('dreiscSeoDataSeoTab.seoForm.pixel');
            } else {
                lengthString = this.$tc('dreiscSeoDataSeoTab.seoForm.chars');
            }

            return `${label} (${lengthConfig.currentLength}/${lengthConfig.maxLength} ${lengthString})`;
        },

        getLengthConfig(fieldKey) {
            let calculationType = null;

            if (null === this.customConfig) {
                return null;
            }

            if('metaTitle' === fieldKey) {
                calculationType = LengthCalculationType.pixelLength;
            } else {
                calculationType = LengthCalculationType.charLength;
            }

            return {
                calculationType: calculationType,
                currentLength: this.getFieldLength(fieldKey, calculationType),
                maxLength: this.customConfig.metaTags[fieldKey].lengthConfig.maxLength,
                recommendedLengthStart: this.customConfig.metaTags[fieldKey].lengthConfig.recommendedLengthStart,
                recommendedLengthEnd: this.customConfig.metaTags[fieldKey].lengthConfig.recommendedLengthEnd
            };
        },

        getFieldLength(fieldKey, calculationType) {
            if ('string' === typeof this.category[fieldKey]) {
                if (LengthCalculationType.pixelLength === calculationType) {
                    return LengthCalculatorHelper.calculatePixel(this.category[fieldKey], this.customConfig.pixelTable)
                } else {
                    return this.category[fieldKey].length;
                }

            }

            return 0;
        },

        completeCustomFieldArray(arr) {
            if (!arr.hasOwnProperty('dreisc_seo_robots_tag')) {
                arr['dreisc_seo_robots_tag'] = null;
            }

            return arr;
        },

        /**
         * We trigger the change event for keyup, so that we can update
         * the string length counter immediately
         */
        onKeyUp(event, props) {
            props.updateCurrentValue(event.target.value);
        }
    }
});
