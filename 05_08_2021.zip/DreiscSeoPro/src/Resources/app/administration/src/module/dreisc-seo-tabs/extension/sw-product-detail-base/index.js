const { Component } = Shopware;
import {Areas} from "./../../../dreisc-seo-bulk/helper/bulk.helper";
import template from './dreisc-seo-tabs-sw-product-detail-base.html.twig';
import './dreisc-seo-tabs-sw-product-detail-base.scss';

Component.override('sw-product-detail-base', {
    template,

    inject: [ 'dreiscSeoCustomConfigApiService' ],

    data() {
        return {
            customConfig: null,
            area: Areas.PRODUCT
        }
    },

    created() {
        this.getCustomConfig();
    },

    methods: {
        getCustomConfig() {
            this.dreiscSeoCustomConfigApiService.getCustomConfig().then(customConfigPromise => {
                this.customConfig = customConfigPromise.defaultCustomSettings;
            });
        }
    }
});
