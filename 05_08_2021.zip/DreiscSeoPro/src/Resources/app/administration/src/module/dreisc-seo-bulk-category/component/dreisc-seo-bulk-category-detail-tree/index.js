const { Component } = Shopware;
import template from './dreisc-seo-bulk-category-detail-tree.html.twig';
import './dreisc-seo-bulk-category-detail-tree.scss';

Component.extend('dreisc-seo-bulk-category-detail-tree', 'dreisc-seo-bulk-detail-tree', {
    template
});
