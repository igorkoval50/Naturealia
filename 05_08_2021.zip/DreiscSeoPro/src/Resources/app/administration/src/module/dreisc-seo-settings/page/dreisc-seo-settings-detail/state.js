// Store
export default {
    namespaced: true,

    state() {
        return {
            customSettings: {},
            loading: false,

            salesChannelCustomSettings: {},
            currentSalesChannelCustomSettings: {},
            currentSalesChannelId: null,

            fieldErrors: {
                metaTags_metaTitle_lengthConfig_recommendedLengthStart: null,
                metaTags_metaTitle_lengthConfig_recommendedLengthEnd: null,
                metaTags_metaTitle_lengthConfig_maxLength: null,
                metaTags_metaDescription_lengthConfig_recommendedLengthStart: null,
                metaTags_metaDescription_lengthConfig_recommendedLengthEnd: null,
                metaTags_metaDescription_lengthConfig_maxLength: null,
                metaTags_keywords_lengthConfig_recommendedLengthStart: null,
                metaTags_keywords_lengthConfig_recommendedLengthEnd: null,
                metaTags_keywords_lengthConfig_maxLength: null
            },

            dreiscSeoCustomConfigApiService: null
        };
    },

    mutations: {
        setLoading(state, loading) {
            state.loading = loading;
        },

        setDreiscSeoCustomConfigApiService(state, dreiscSeoCustomConfigApiService) {
            state.dreiscSeoCustomConfigApiService = dreiscSeoCustomConfigApiService;
        },

        changeSalesChannelCustomSettings(state, salesChannelId) {
            state.currentSalesChannelId = salesChannelId;

            if(null === salesChannelId) {
                state.currentSalesChannelCustomSettings = {};
            } else {
                state.currentSalesChannelCustomSettings = state.salesChannelCustomSettings[salesChannelId];
            }
        },

        loadCustomSettings(state) {
            state.customSettings = {};

            if (null === state.dreiscSeoCustomConfigApiService) {
                return;
            }

            state.dreiscSeoCustomConfigApiService.getCustomConfig(true).then(customConfigPromise => {
                state.customSettings = customConfigPromise.defaultCustomSettings;
                state.salesChannelCustomSettings = customConfigPromise.salesChannelCustomSettings;
            });
        },

        saveCustomSettings(state, callback) {
            state.loading = true;

            console.log('state.customSettings');
            console.log(state.customSettings);

            state.dreiscSeoCustomConfigApiService.saveCustomConfig(state.customSettings, state.salesChannelCustomSettings).then(() => {
                state.loading = false;

                /** Reload the data */
                state.dreiscSeoCustomConfigApiService.getCustomConfig(true).then(customConfigPromise => {
                    state.customSettings = customConfigPromise.defaultCustomSettings;

                    if ('function' === typeof callback) {
                        callback();
                    }
                });
            });
        }
    },

    getters: {
        isLoading: (state) => {
            return state.loading ||
                0 === Object.keys(state.customSettings).length ||
                null === state.dreiscSeoCustomConfigApiService;
        }
    }
};
