const { Component, Mixin, Context } = Shopware;
import template from './dreisc-seo-rich-snippet-detail.html.twig';
import './dreisc-seo-rich-snippet-detail.scss';
import dreiscSeoRichSnippetsDetailState from './../../../dreisc-seo-settings/page/dreisc-seo-settings-detail/state';
const { mapPageErrors, mapState, mapGetters } = Shopware.Component.getComponentHelper();
import './../../../dreisc-seo-settings/mixin/custom-setting-rich-snippets';

Component.register('dreisc-seo-rich-snippet-detail', {
    template,

    inject: [
        'repositoryFactory',
        'dreiscSeoCustomConfigApiService'
    ],

    mixins: [
        Mixin.getByName('notification'),
        Mixin.getByName('dreisc-seo-settings-custom-setting-rich-snippets')
    ],

    data() {
        return {
            isSaveSuccessful: false
        };
    },

    created() {
        this.createdComponent();
    },

    computed: {
        ...mapState('dreiscSeoRichSnippetsDetailState', [
            'customSettings', 'fieldErrors'
        ]),

        ...mapGetters('dreiscSeoRichSnippetsDetailState', [
            'isLoading'
        ]),

        general() {
            return this.getActiveCustomSetting('richSnippets.general');
        },

        generalInherit() {
            return this.getInheritCustomSetting('richSnippets.general');
        },

        isLdJsonActive() {
            if (0 === Object.keys(this.customSettings).length) {
                return false;
            }

            if (true === this.general.active || (null === this.general.active && true === this.generalInherit.active)) {
                return true;
            }

            return false;
        }
    },

    beforeCreate() {
        if (!Shopware.State.list().includes('dreiscSeoRichSnippetsDetailState')) {
            Shopware.State.registerModule('dreiscSeoRichSnippetsDetailState', dreiscSeoRichSnippetsDetailState);
        }
    },

    beforeDestroy() {
        if (Shopware.State.list().includes('dreiscSeoRichSnippetsDetailState')) {
            Shopware.State.unregisterModule('dreiscSeoRichSnippetsDetailState');
        }
    },

    methods: {
        createdComponent() {
            Shopware.State.commit(
                'dreiscSeoRichSnippetsDetailState/setDreiscSeoCustomConfigApiService',
                this.dreiscSeoCustomConfigApiService
            );

            Shopware.State.commit('dreiscSeoRichSnippetsDetailState/loadCustomSettings');
        },

        onSave() {
            if(true !== this.isFormValid()) {
                this.createNotificationError({
                    title: this.$tc('dreiscSeoRichSnippet.detailSeoSettings.notification.titleSaveError'),
                    message: this.$tc('dreiscSeoRichSnippet.detailSeoSettings.notification.messageSaveError')
                });

                return;
            }

            Shopware.State.commit('dreiscSeoRichSnippetsDetailState/saveCustomSettings', () => {
                this.isSaveSuccessful = true;
            });
        },

        saveFinish() {
            this.isSaveSuccessful = false;
        },

        isFormValid() {
            let isValid = true;

            /** Reset the errors */
            Object.keys(this.fieldErrors).forEach((errorKey) => {
                this.fieldErrors[errorKey] = null;
            });

            return isValid;
        },

        generateErrorObject(error) {
            return {
                code: 'ERROR',
                detail: error
            };
        }
    }
});
