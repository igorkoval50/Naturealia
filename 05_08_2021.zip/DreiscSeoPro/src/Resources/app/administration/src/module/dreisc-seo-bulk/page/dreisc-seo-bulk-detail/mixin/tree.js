import {SeoOptionsWhichRequiredSalesChannel} from "../../../helper/bulk.helper";
const { Criteria } = Shopware.Data;
const { Mixin } = Shopware;

Mixin.register('dreisc-seo-bulk-detail-tree', {
    computed: {
        isSalesChannelRequired() {
            if (null === this.settingScope.seoOption) {
                return false;
            }

            if (SeoOptionsWhichRequiredSalesChannel.includes(this.settingScope.seoOption)) {
                return true;
            }

            return false;
        }
    },

    methods: {
        changeItem(selectedItem) {
            this.updateRoute(selectedItem.id);
        },

        resetTree() {
            /** Reset the active item */
            this.activeItem = null;

            /** Reset items */
            this.items = [];
        },

        getItems(parentId = null, salesChannel = null) {
            const criteria = new Criteria(1, 500);

            /**
             * We load all categories, to make sure that the service and footer
             * categories are available. See additional information under:
             * https://de.dreischild.com/docs/seo-professional/changelog#version-652
             * */
            salesChannel = null;

            if(null === parentId) {
                /** Set flag for initial loading */
                this.isLoadingInitialData = true;

                /** Reset the tree */
                this.resetTree();
            }

            /** Loads only the navigation category as root, if an sales channel entity is set */
            if(null === parentId && salesChannel && salesChannel.navigationCategoryId) {
                criteria.addFilter(
                    Criteria.equals('category.id', salesChannel.navigationCategoryId)
                );
            } else {
                criteria.addFilter(
                    Criteria.equals('category.parentId', parentId)
                );
            }

            criteria.addAssociation('navigationSalesChannels');

            return this.categoryRepository.search(criteria, Shopware.Context.api).then((categories) => {
                this.items = this.items.concat(categories);
                this.isLoadingInitialData = false;

                /** Fetch all loaded id and set the backup the name */
                const categoryIds = [];
                categories.forEach(category => {
                    categoryIds.push(category.id);
                    category.nameBackup = category.name || category.translated.name;
                });

                /** Updates the bulk template information for the new categories */
                this.updateCategoriesBulkTemplateInformation(categoryIds);

                return categories;
            }).catch(() => {
            });
        },

        updateBulkTemplateInformationOfVisibleCategories() {
            /** Fetch all ids and reset the loaded flag */
            const categoryIds = [];
            this.items.forEach(category => {
                category.seoBulkBulkTemplateInformationLoaded = false;
                categoryIds.push(category.id);
            });

            /** Update the template informations */
            if (categoryIds.length > 0) {
                this.updateCategoriesBulkTemplateInformation(categoryIds);
            }
        },

        updateCategoriesBulkTemplateInformation(categoryIds) {
            this.bulkApiService.getResponsibleSeoBulk(
                categoryIds,
                this.area,
                this.settingScope.seoOption,
                this.settingScope.languageId,
                this.settingScope.salesChannelId
            ).then(seoBulkInformation => {
                seoBulkInformation.forEach(information => {
                    let category = this.findItemByCategoryId(information.categoryId);

                    if (null !== category) {
                        /** Apply the information to the entity, so that we can work with it in the template */
                        category.seoBulkEntity = information.seoBulkEntity;
                        category.seoBulkBulkTemplateInformationLoaded = true;
                    }
                });
            });
        },

        loadActiveItemPath(salesChannel = null) {
            if (null == this.activeItemId) {
                this.finishInitialLoading();
                return;
            }

            this.categoryRepository.get(this.activeItemId, Shopware.Context.api).then((ItemEntity) => {
                if (!ItemEntity.path) {
                    this.finishInitialLoading();
                    return;
                }

                const parentPath = ItemEntity.path;
                if (!parentPath) {
                    this.finishInitialLoading();
                    return;
                }

                let parentIds = parentPath.split('|').reverse();
                parentIds = parentIds.filter((parent) => {
                    return parent !== '';
                });

                /** Abort the progress, if the active item is not a child of the active navigationC categoryId */
                if(null !== salesChannel && salesChannel.navigationCategoryId) {
                    if (!parentIds.includes(salesChannel.navigationCategoryId)) {
                        this.finishInitialLoading();
                        return;
                    }
                }

                const promises = [];
                parentIds.forEach((id) => {
                    promises.push(this.getItems(id));
                });

                Promise.all(promises).then(() => {
                    this.activeItem = ItemEntity;
                    this.finishInitialLoading();
                });
            });
        },

        settingScopeChanged() {
            /** Set default values */
            this.setSalesChannelIdPlaceholder = false;

            /** Abort,if the setting scope is not complete */
            if (null === this.settingScope.seoOption || null === this.settingScope.languageId) {
                return;
            }

            /** Make sure that the sales channel is null if the seo option does not need it */
            if (!SeoOptionsWhichRequiredSalesChannel.includes(this.settingScope.seoOption)) {
                this.settingScope.salesChannelId = null;
            }

            /** Set a dummy value for the sales channel, if it is not set, so that the id parameter works */
            if (null === this.settingScope.salesChannelId) {
                this.setSalesChannelIdPlaceholder = true;
            }

            this.updateRoute(this.$route.params.id);
        },

        findItemByCategoryId(categoryId) {
            let result = null;

            this.items.forEach(category => {
                if (categoryId === category.id) {
                    result = category;
                }
            });

            return result;
        }
    }
});
