const { Component, Mixin } = Shopware;
import template from './dreisc-seo-rich-snippet-detail-general.html.twig';
import './dreisc-seo-rich-snippet-detail-general.scss';
import './../../../dreisc-seo-settings/mixin/custom-setting-rich-snippets';

Component.register('dreisc-seo-rich-snippet-detail-general', {
    template,

    data() {
        return {
        }
    },

    mixins: [
        Mixin.getByName('dreisc-seo-settings-custom-setting-rich-snippets')
    ],

    computed: {
        isInherit() {
            return null !== this.currentSalesChannelId;
        },

        general() {
            return this.getActiveCustomSetting('richSnippets.general');
        },

        generalInherit() {
            return this.getInheritCustomSetting('richSnippets.general');
        }
    }
});
