const { Component } = Shopware;
import template from './dreisc-seo-bulk-product-detail-tree.html.twig';
import './dreisc-seo-bulk-product-detail-tree.scss';

Component.extend('dreisc-seo-bulk-product-detail-tree', 'dreisc-seo-bulk-detail-tree', {
    template
});
