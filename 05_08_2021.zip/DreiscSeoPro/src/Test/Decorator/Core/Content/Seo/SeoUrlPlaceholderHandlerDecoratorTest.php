<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Decorator\Core\Content\Seo;

use DreiscSeoPro\Core\CustomSetting\CustomSettingLoader;
use DreiscSeoPro\Core\CustomSetting\CustomSettingSaver;
use DreiscSeoPro\Core\Foundation\CustomSettingEntity\CustomSettingEntityStruct;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\Test\TestCaseBase\AdminApiTestBehaviour;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Decorator\Core\Content\Seo\SeoUrlPlaceholderHandlerDecorator;

class SeoUrlPlaceholderHandlerDecoratorTest extends TestCase
{
    use IntegrationTestBehaviour;
    use AdminApiTestBehaviour;

    /**
     * @var SeoUrlPlaceholderHandlerDecorator
     */
    private $seoUrlPlaceholderHandlerDecorator;

    /**
     * @var CustomSettingLoader
     */
    private $customSettingLoader;

    /**
     * @var CustomSettingSaver
     */
    private $customSettingSaver;

    protected function setUp(): void
    {
        $this->seoUrlPlaceholderHandlerDecorator = $this->getContainer()->get(SeoUrlPlaceholderHandlerDecorator::class);
        $this->customSettingLoader = $this->getContainer()->get(CustomSettingLoader::class);
        $this->customSettingSaver = $this->getContainer()->get(CustomSettingSaver::class);
    }

    public function dataProvider_replacement_url(): array
    {
        return [
            /** Start page */
            [ 'http://www.shopware-dev.de/' ],
            /** Product with reviews and image */
            [ 'http://www.shopware-dev.de/detail/3848d63292714905aa86008fd973693a' ],
            /** Product with aggregated offers */
            [ 'http://www.shopware-dev.de/detail/a8c822612b1a4c92a61b90cf53b90235' ],
            /** Product listing */
            [ 'http://www.shopware-dev.de/navigation/c542db9e9d964fe29a15061440a68730' ],
            /** Search page */
            [ 'http://www.shopware-dev.de/search?search=product' ]
        ];
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     *
     * @dataProvider dataProvider_replacement_url
     * @param $url
     */
    public function test_replacement($url): void
    {
        /** Load the content of the url */
        $this->getBrowser()->request(
            'GET',
            $url,
            []
        );

        /** Check page status */
        $this->assertTrue($this->getBrowser()->getResponse()->isOk());
        $this->assertFalse($this->getBrowser()->getResponse()->isNotFound());

        /** Fetch the response */
        $response = $this->getBrowser()->getResponse()->getContent();

        /** Test for itemtype */
        $this->assertDoesNotMatchRegularExpression('/itemtype\s{0,}=\s{0,}[\"|\'][\S\s]*?[\"|\']/m', $response);

        /** Test for itemprop */
        $this->assertDoesNotMatchRegularExpression('/itemprop\s{0,}=\s{0,}[\"|\'][\S\s]*?[\"|\']/m', $response);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     *
     * @dataProvider dataProvider_replacement_url
     * @param $url
     * @throws InconsistentCriteriaIdsException
     */
    public function test_inactive_ld_json_support($url): void
    {
        $customSettings = $this->customSettingLoader->load();
        $customSettings->getRichSnippets()->getGeneral()->setActive(false);
        $this->customSettingSaver->save($customSettings);

        /** Load the content of the url */
        $this->getBrowser()->request(
            'GET',
            $url,
            []
        );

        /** Check page status */
        $this->assertTrue($this->getBrowser()->getResponse()->isOk());
        $this->assertFalse($this->getBrowser()->getResponse()->isNotFound());

        /** Fetch the response */
        $response = $this->getBrowser()->getResponse()->getContent();

        /** We expect itemtype items */
        $this->assertMatchesRegularExpression('/itemtype\s{0,}=\s{0,}[\"|\'][\S\s]*?[\"|\']/m', $response);

        /** We expect itemtype items */
        $this->assertMatchesRegularExpression('/itemprop\s{0,}=\s{0,}[\"|\'][\S\s]*?[\"|\']/m', $response);

        /** Restore */
        $customSettings->getRichSnippets()->getGeneral()->setActive(true);
        $this->customSettingSaver->save($customSettings);
    }

    /**
     * Check that there is no tag like  <meta content="SW-1001"/>
     */
    public function test_bugfix_invalid_meta_tags(): void
    {
        $this->markTestIncomplete('There are tag like <meta content="SW-1001"/> in the sourcecode');
        return;

        /** Load the content of the url */
        $this->getBrowser()->request(
            'GET',
            'http://www.shopware-dev.de/detail/3848d63292714905aa86008fd973693a',
            []
        );

        /** Check page status */
        $this->assertTrue($this->getBrowser()->getResponse()->isOk());
        $this->assertFalse($this->getBrowser()->getResponse()->isNotFound());

        /** Fetch the response */
        $response = $this->getBrowser()->getResponse()->getContent();

        /** Check if the ordernumber is correct */
        $this->assertRegExp('/<title[\S\s]*?>[\S\s]*?Standard Produkt 1001 \| SW-1001[\S\s]*?<\/title>/m', $response);

        /** Check, that there is no invalid meta tag */
        $this->assertNotRegExp('/ <meta[\S\s]*?content="SW-1001"\/>/m', $response);
    }
}
