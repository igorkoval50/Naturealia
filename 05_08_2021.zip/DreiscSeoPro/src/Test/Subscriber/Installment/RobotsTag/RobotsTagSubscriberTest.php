<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Subscriber\Installment\RobotsTag;

use DreiscCli\Core\Content\SalesChannel\SalesChannelRepository;
use DreiscSeoPro\Core\Content\Category\CategoryEnum;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\Product\ProductEnum;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\CustomSetting\CustomSettingLoader;
use DreiscSeoPro\Core\CustomSetting\CustomSettingSaver;
use DreiscSeoPro\Core\Foundation\Context\ContextFactory;
use DreiscSeoPro\Core\Foundation\Dal\EntityRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Test\TestCaseBase\AdminApiTestBehaviour;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Subscriber\Installment\RobotsTag\RobotsTagSubscriber;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;

class RobotsTagSubscriberTest extends TestCase
{
    use IntegrationTestBehaviour;
    use AdminApiTestBehaviour;

    /**
     * @var RobotsTagSubscriber
     */
    private $robotsTagSubscriber;

    /**
     * @var SalesChannelRepository
     */
    private $salesChannelRepository;

    /**
     * @var ContextFactory
     */
    private $contextFactory;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var CustomSettingLoader
     */
    private $customSettingLoader;

    /**
     * @var CustomSettingSaver
     */
    private $customSettingSaver;

    protected function setUp(): void
    {
        $this->robotsTagSubscriber = $this->getContainer()->get(RobotsTagSubscriber::class);
        $this->salesChannelRepository = $this->getContainer()->get(SalesChannelRepository::class);
        $this->contextFactory = $this->getContainer()->get(ContextFactory::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
        $this->customSettingLoader = $this->getContainer()->get(CustomSettingLoader::class);
        $this->customSettingSaver = $this->getContainer()->get(CustomSettingSaver::class);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_robotsTag_product_default(): void
    {
        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006);

        /** We expect "index,follow" as default */
        $this->assertSame('index,follow', $robotsTagContent);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_robotsTag_product_customValue_normalProduct(): void
    {
        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1001,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_ROBOTS_TAG,
            'noindex,nofollow'
        );

        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1001);

        $this->assertSame('noindex,nofollow', $robotsTagContent);
    }

    public function test_robotsTag_product_customValue_variantProduct(): void
    {
        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1006,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_ROBOTS_TAG,
            'noindex,follow'
        );

        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $this->assertSame('noindex,follow', $robotsTagContent);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_robotsTag_product_changeDefaultRobotsTag(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /** Update */
        $customSetting->getMetaTags()->getRobotsTag()
            ->setDefaultRobotsTagProduct('default,product');
        $this->customSettingSaver->save($customSetting);

        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $this->assertSame('default,product', $robotsTagContent);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_robotsTag_product_changeDefaultRobotsTag_differentSalesChannel(): void
    {
        $customSetting = $this->customSettingLoader->load(DemoDataIds::SALES_CHANNEL__GB_SHOP);
        $customSettingBackup = clone $customSetting;

        /** Update */
        $customSetting->getMetaTags()->getRobotsTag()
            ->setDefaultRobotsTagProduct('default,product,sales_channel');
        $this->customSettingSaver->save($customSetting, DemoDataIds::SALES_CHANNEL__GB_SHOP);

        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);
        $this->assertSame('index,follow', $robotsTagContent);

        $robotsTagContent = $this->fetchRobotsTagContent('http://gbshop.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);
        $this->assertSame('default,product,sales_channel', $robotsTagContent);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup, DemoDataIds::SALES_CHANNEL__GB_SHOP);
    }

    public function test_robotsTag_category_default(): void
    {
        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        /** We expect "index,follow" as default */
        $this->assertSame('index,follow', $robotsTagContent);
    }

    public function test_robotsTag_category_customValue(): void
    {
        $this->setCustomFieldSetting(
            $this->categoryRepository,
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            CategoryEnum::CUSTOM_FIELD__DREISC_SEO_ROBOTS_TAG,
            'noindex,nofollow'
        );

        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        $this->assertSame('noindex,nofollow', $robotsTagContent);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_robotsTag_category_changeDefaultRobotsTag(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /** Update */
        $customSetting->getMetaTags()->getRobotsTag()
            ->setDefaultRobotsTagCategory('default,category');
        $this->customSettingSaver->save($customSetting);

        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        $this->assertSame('default,category', $robotsTagContent);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_robotsTag_category_changeDefaultRobotsTag_differentSalesChannel(): void
    {
        $customSetting = $this->customSettingLoader->load(DemoDataIds::SALES_CHANNEL__GB_SHOP);
        $customSettingBackup = clone $customSetting;

        /** Update */
        $customSetting->getMetaTags()->getRobotsTag()
            ->setDefaultRobotsTagCategory('default,category,sales_channel');
        $this->customSettingSaver->save($customSetting, DemoDataIds::SALES_CHANNEL__GB_SHOP);

        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);
        $this->assertSame('index,follow', $robotsTagContent);

        $robotsTagContent = $this->fetchRobotsTagContent('http://gbshop.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__GB_PRODUCTS);
        $this->assertSame('default,category,sales_channel', $robotsTagContent);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup, DemoDataIds::SALES_CHANNEL__GB_SHOP);
    }

    public function test_robotsTag_servicePage_customValue(): void
    {
        $this->setCustomFieldSetting(
            $this->categoryRepository,
            DemoDataIds::FOOTER_CATEGORY__MAIN_SHOP__SHOP_SERVICE__IMPRESSUM,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            CategoryEnum::CUSTOM_FIELD__DREISC_SEO_ROBOTS_TAG,
            'noindex,nofollow,impressum'
        );

        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/navigation/' . DemoDataIds::FOOTER_CATEGORY__MAIN_SHOP__SHOP_SERVICE__IMPRESSUM);

        $this->assertSame('noindex,nofollow,impressum', $robotsTagContent);
    }

    public function test_robotsTag_home_default(): void
    {
        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/');

        /** We expect "index,follow" as default */
        $this->assertSame('index,follow', $robotsTagContent);
    }

    public function test_robotsTag_home_customValue(): void
    {
        $this->setCustomFieldSetting(
            $this->categoryRepository,
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            CategoryEnum::CUSTOM_FIELD__DREISC_SEO_ROBOTS_TAG,
            'home,page'
        );

        $robotsTagContent = $this->fetchRobotsTagContent('http://www.shopware-dev.de/');

        $this->assertSame('home,page', $robotsTagContent);
    }

    public function test_noIndexRequestParameterConfig_withCustomFieldValue(): void
    {
        $this->setCustomFieldSetting(
            $this->categoryRepository,
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            CategoryEnum::CUSTOM_FIELD__DREISC_SEO_ROBOTS_TAG,
            'index,customValue'
        );

        $robotsTagContent = $this->fetchRobotsTagContent(sprintf(
            'http://%s/navigation/%s?%s',
            'www.shopware-dev.de',
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            'sort=name-desc'
        ));

        /** We expect "noindex,customValue" because sort is not "name-asc" */
        $this->assertSame('noindex,customValue', $robotsTagContent);
    }

    public function test_noIndexRequestParameterConfig_sortAsc(): void
    {
        $robotsTagContent = $this->fetchRobotsTagContent(sprintf(
            'http://%s/navigation/%s?%s',
            'www.shopware-dev.de',
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            'sort=name-asc'
        ));

        /** We expect "index,follow" because sort is "name-asc" */
        $this->assertSame('index,follow', $robotsTagContent);
    }

    public function test_noIndexRequestParameterConfig_p1(): void
    {
        $robotsTagContent = $this->fetchRobotsTagContent(sprintf(
            'http://%s/navigation/%s?%s',
            'www.shopware-dev.de',
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            'sort=name-asc&p=1'
        ));

        /** We expect "index,follow" because p is "1" */
        $this->assertSame('index,follow', $robotsTagContent);
    }

    public function test_noIndexRequestParameterConfig_p2(): void
    {
        $robotsTagContent = $this->fetchRobotsTagContent(sprintf(
            'http://%s/navigation/%s?%s',
            'www.shopware-dev.de',
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            'sort=name-asc&p=2'
        ));

        /** We expect "noindex,follow" because p is "2" */
        $this->assertSame('noindex,follow', $robotsTagContent);
    }

    public function test_noIndexRequestParameterConfig_sortDesc(): void
    {
        $robotsTagContent = $this->fetchRobotsTagContent(sprintf(
            'http://%s/navigation/%s?%s',
            'www.shopware-dev.de',
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            'sort=name-desc'
        ));

        /** We expect "noindex,follow" because the sort is not "name-asc" */
        $this->assertSame('noindex,follow', $robotsTagContent);
    }

    private function fetchRobotsTagContent($url)
    {
        $this->getBrowser()->request(
            'GET',
            $url,
            []
        );

        $response = $this->getBrowser()->getResponse()->getContent();

        preg_match('/<meta[\s]*?name="robots"[\s]*?content="([\s\S]*?)"/m', $response, $robotsTagMatch);
        $this->assertNotEmpty($robotsTagMatch, 'Missing robots tag');

        return $robotsTagMatch[1];
    }

    private function setCustomFieldSetting(EntityRepository $entityRepository, string $referenceId, string $salesChannelId, string $customField, ?string $customFieldValue)
    {
        /** Fetch the language id the sales channel */
        /** @var SalesChannelEntity $salesChannel */
        $salesChannel = $this->salesChannelRepository->search(new Criteria([ $salesChannelId ]))->first();
        if (null === $salesChannel) {
            throw new \RuntimeException('Invalid sales channel id: ' . $salesChannelId);
        }

        /** Create the context */
        $context = $this->contextFactory->createContext(
            (new ContextFactory\Struct\ContextStruct())
                ->setLanguageIdChain([ $salesChannel->getLanguageId() ])
        );

        /** Update the product */
        $entityRepository->upsert([
            [
                'id' => $referenceId,
                'customFields' => [
                    $customField => $customFieldValue
                ]
            ]
        ], $context);
    }
}
