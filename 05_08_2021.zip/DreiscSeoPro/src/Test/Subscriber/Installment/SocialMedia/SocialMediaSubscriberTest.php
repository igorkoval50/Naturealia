<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Subscriber\Installment\SocialMedia;

use DreiscCli\Core\Content\SalesChannel\SalesChannelRepository;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\Media\MediaRepository;
use DreiscSeoPro\Core\Content\Product\ProductEnum;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\CustomSetting\CustomSettingLoader;
use DreiscSeoPro\Core\CustomSetting\CustomSettingSaver;
use DreiscSeoPro\Core\Foundation\Context\ContextFactory;
use DreiscSeoPro\Core\Foundation\Dal\EntityRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Content\Media\MediaEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Test\TestCaseBase\AdminApiTestBehaviour;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Subscriber\Installment\SocialMedia\SocialMediaSubscriber;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;

class SocialMediaSubscriberTest extends TestCase
{
    use IntegrationTestBehaviour;
    use AdminApiTestBehaviour;

    /**
     * @var SocialMediaSubscriber
     */
    private $socialMediaSubscriber;

    /**
     * @var SalesChannelRepository
     */
    private $salesChannelRepository;

    /**
     * @var ContextFactory
     */
    private $contextFactory;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var CustomSettingLoader
     */
    private $customSettingLoader;

    /**
     * @var CustomSettingSaver
     */
    private $customSettingSaver;

    /**
     * @var MediaRepository
     */
    private $mediaRepository;

    protected function setUp(): void
    {
        $this->socialMediaSubscriber = $this->getContainer()->get(SocialMediaSubscriber::class);
        $this->salesChannelRepository = $this->getContainer()->get(SalesChannelRepository::class);
        $this->contextFactory = $this->getContainer()->get(ContextFactory::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
        $this->customSettingLoader = $this->getContainer()->get(CustomSettingLoader::class);
        $this->customSettingSaver = $this->getContainer()->get(CustomSettingSaver::class);
        $this->mediaRepository = $this->getContainer()->get(MediaRepository::class);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_socialMedia_product_default(): void
    {
        /** Fetch the page response */
        $response = $this->fetchResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        /** Check the meta fields */
        $this->assertSame(
            'Varianten SW-1006.1 | Red | Iron | XL | SW-1006.1',
            $this->fetchMetaTagByProperty($response, 'og:title')
        );

        $this->assertSame(
            'Lorem ipsum [de-DE] dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed…',
            $this->fetchMetaTagByProperty($response, 'og:description')
        );

        $this->assertStringEndsWith(
            'demostore-logo.png',
            $this->fetchMetaTagByProperty($response, 'og:image')
        );

        $this->assertSame(
            'Dreischild',
            $this->fetchMetaTagByProperty($response, 'product:brand')
        );

        $this->assertSame(
            'http://www.shopware-dev.de/Varianten-SW-1006.1/SW-1006.1',
            str_replace(' ', '', $this->fetchMetaTagByProperty($response, 'product:product_link'))
        );

        $this->assertSame(
            'Varianten SW-1006.1 | Red | Iron | XL | SW-1006.1',
            $this->fetchMetaTagByProperty($response, 'twitter:title')
        );

        $this->assertSame(
            'Lorem ipsum [de-DE] dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed…',
            $this->fetchMetaTagByProperty($response, 'twitter:description')
        );

        $this->assertStringContainsString(
            '/bundles/storefront/?',
            $this->fetchMetaTagByProperty($response, 'twitter:image')
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_socialMedia_product_customValue_normalProduct(): void
    {
        $randomMediaEntity = $this->getRandomMedia();

        $this->setCustomFieldSettings(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1001,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            [
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_TITLE => 'FACEBOOK_TITLE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_DESCRIPTION => 'FACEBOOK_DESCRIPTION',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_IMAGE => $randomMediaEntity->getId(),
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_TITLE => 'TWITTER_TITLE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_DESCRIPTION => 'TWITTER_DESCRIPTION',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_IMAGE => $randomMediaEntity->getId()
            ]
        );

        /** Fetch the page response */
        $response = $this->fetchResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1001);

        /** Check the meta fields */
        $this->assertSame(
            'FACEBOOK_TITLE',
            $this->fetchMetaTagByProperty($response, 'og:title')
        );

        $this->assertSame(
            'FACEBOOK_DESCRIPTION',
            $this->fetchMetaTagByProperty($response, 'og:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'og:image')
        );

        $this->assertSame(
            'TWITTER_TITLE',
            $this->fetchMetaTagByProperty($response, 'twitter:title')
        );

        $this->assertSame(
            'TWITTER_DESCRIPTION',
            $this->fetchMetaTagByProperty($response, 'twitter:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'twitter:image')
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_socialMedia_product_customValue_variantProduct(): void
    {
        $randomMediaEntity = $this->getRandomMedia();

        $this->setCustomFieldSettings(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1006,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            [
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_TITLE => 'FACEBOOK_TITLE_CONSIDER_INHERITANCE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_DESCRIPTION => 'FACEBOOK_DESCRIPTION_CONSIDER_INHERITANCE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_IMAGE => $randomMediaEntity->getId(),
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_TITLE => 'TWITTER_TITLE_CONSIDER_INHERITANCE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_DESCRIPTION => 'TWITTER_DESCRIPTION_CONSIDER_INHERITANCE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_IMAGE => $randomMediaEntity->getId()
            ]
        );

        /** Fetch the page response */
        $response = $this->fetchResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        /** Check the meta fields */
        $this->assertSame(
            'FACEBOOK_TITLE_CONSIDER_INHERITANCE',
            $this->fetchMetaTagByProperty($response, 'og:title')
        );

        $this->assertSame(
            'FACEBOOK_DESCRIPTION_CONSIDER_INHERITANCE',
            $this->fetchMetaTagByProperty($response, 'og:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'og:image')
        );

        $this->assertSame(
            'TWITTER_TITLE_CONSIDER_INHERITANCE',
            $this->fetchMetaTagByProperty($response, 'twitter:title')
        );

        $this->assertSame(
            'TWITTER_DESCRIPTION_CONSIDER_INHERITANCE',
            $this->fetchMetaTagByProperty($response, 'twitter:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'twitter:image')
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_socialMedia_category_default(): void
    {
        /** Fetch the page response */
        $response = $this->fetchResponse('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        /** Check the meta fields */
        $this->assertSame(
            'website',
            $this->fetchMetaTagByProperty($response, 'og:type')
        );

        $this->assertSame(
            'Demostore',
            $this->fetchMetaTagByProperty($response, 'og:site_name')
        );

        $this->assertSame(
            '',
            $this->fetchMetaTagByProperty($response, 'og:title')
        );

        $this->assertSame(
            'Beschreibung der Kategorie: 3fa301fbf6a043d6b90e45d6a28e89d7',
            $this->fetchMetaTagByProperty($response, 'og:description')
        );

        $this->assertStringEndsWith(
            '/demostore-logo.png',
            $this->fetchMetaTagByProperty($response, 'og:image')
        );

        $this->assertSame(
            '',
            $this->fetchMetaTagByProperty($response, 'twitter:title')
        );

        $this->assertSame(
            'Beschreibung der Kategorie: 3fa301fbf6a043d6b90e45d6a28e89d7',
            $this->fetchMetaTagByProperty($response, 'twitter:description')
        );

        $this->assertStringEndsWith(
            '/demostore-logo.png',
            $this->fetchMetaTagByProperty($response, 'twitter:image')
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_socialMedia_category_customValue(): void
    {
        $randomMediaEntity = $this->getRandomMedia();

        $this->setCustomFieldSettings(
            $this->categoryRepository,
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            [
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_TITLE => 'FACEBOOK_TITLE_CAT',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_DESCRIPTION => 'FACEBOOK_DESCRIPTION_CAT',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_IMAGE => $randomMediaEntity->getId(),
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_TITLE => 'TWITTER_TITLE_CAT',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_DESCRIPTION => 'TWITTER_DESCRIPTION_CAT',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_IMAGE => $randomMediaEntity->getId()
            ]
        );

        /** Fetch the page response */
        $response = $this->fetchResponse('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        /** Check the meta fields */
        $this->assertSame(
            'FACEBOOK_TITLE_CAT',
            $this->fetchMetaTagByProperty($response, 'og:title')
        );

        $this->assertSame(
            'FACEBOOK_DESCRIPTION_CAT',
            $this->fetchMetaTagByProperty($response, 'og:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'og:image')
        );

        $this->assertSame(
            'TWITTER_TITLE_CAT',
            $this->fetchMetaTagByProperty($response, 'twitter:title')
        );

        $this->assertSame(
            'TWITTER_DESCRIPTION_CAT',
            $this->fetchMetaTagByProperty($response, 'twitter:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'twitter:image')
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_socialMedia_servicePage_customValue(): void
    {
        $randomMediaEntity = $this->getRandomMedia();

        $this->setCustomFieldSettings(
            $this->categoryRepository,
            DemoDataIds::FOOTER_CATEGORY__MAIN_SHOP__SHOP_SERVICE__IMPRESSUM,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            [
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_TITLE => 'FACEBOOK_TITLE_SERVICE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_DESCRIPTION => 'FACEBOOK_DESCRIPTION_SERVICE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_IMAGE => $randomMediaEntity->getId(),
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_TITLE => 'TWITTER_TITLE_SERVICE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_DESCRIPTION => 'TWITTER_DESCRIPTION_SERVICE',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_IMAGE => $randomMediaEntity->getId()
            ]
        );

        /** Fetch the page response */
        $response = $this->fetchResponse('http://www.shopware-dev.de/navigation/' . DemoDataIds::FOOTER_CATEGORY__MAIN_SHOP__SHOP_SERVICE__IMPRESSUM);

        /** Check the meta fields */
        $this->assertSame(
            'FACEBOOK_TITLE_SERVICE',
            $this->fetchMetaTagByProperty($response, 'og:title')
        );

        $this->assertSame(
            'FACEBOOK_DESCRIPTION_SERVICE',
            $this->fetchMetaTagByProperty($response, 'og:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'og:image')
        );

        $this->assertSame(
            'TWITTER_TITLE_SERVICE',
            $this->fetchMetaTagByProperty($response, 'twitter:title')
        );

        $this->assertSame(
            'TWITTER_DESCRIPTION_SERVICE',
            $this->fetchMetaTagByProperty($response, 'twitter:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'twitter:image')
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_socialMedia_home_customValue(): void
    {
        $randomMediaEntity = $this->getRandomMedia();

        $this->setCustomFieldSettings(
            $this->categoryRepository,
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            [
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_TITLE => 'FACEBOOK_TITLE_HOME',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_DESCRIPTION => 'FACEBOOK_DESCRIPTION_HOME',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_FACEBOOK_IMAGE => $randomMediaEntity->getId(),
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_TITLE => 'TWITTER_TITLE_HOME',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_DESCRIPTION => 'TWITTER_DESCRIPTION_HOME',
                ProductEnum::CUSTOM_FIELD__DREISC_SEO_TWITTER_IMAGE => $randomMediaEntity->getId()
            ]
        );

        /** Fetch the page response */
        $response = $this->fetchResponse('http://www.shopware-dev.de/');

        /** Check the meta fields */
        $this->assertSame(
            'FACEBOOK_TITLE_HOME',
            $this->fetchMetaTagByProperty($response, 'og:title')
        );

        $this->assertSame(
            'FACEBOOK_DESCRIPTION_HOME',
            $this->fetchMetaTagByProperty($response, 'og:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'og:image')
        );

        $this->assertSame(
            'TWITTER_TITLE_HOME',
            $this->fetchMetaTagByProperty($response, 'twitter:title')
        );

        $this->assertSame(
            'TWITTER_DESCRIPTION_HOME',
            $this->fetchMetaTagByProperty($response, 'twitter:description')
        );

        $this->assertStringEndsWith(
            $randomMediaEntity->getUrl(),
            $this->fetchMetaTagByProperty($response, 'twitter:image')
        );
    }

    /**
     * @return MediaEntity
     * @throws InconsistentCriteriaIdsException
     */
    private function getRandomMedia(): MediaEntity
    {
        $idSearchResult = $this->mediaRepository->searchIds(new Criteria());
        $mediaId = $idSearchResult->firstId();

        if (null === $mediaId) {
            throw new \RuntimeException('No media found');
        }

        $mediaEntity = $this->mediaRepository->get($mediaId);
        if (null === $mediaEntity) {
            throw new \RuntimeException('Media data cannot be loaded');
        }

        return $mediaEntity;
    }

    private function fetchResponse($url)
    {
        $this->getBrowser()->request(
            'GET',
            $url,
            []
        );

        return $this->getBrowser()->getResponse()->getContent();
    }

    /**
     * @param string $response
     * @param string $property
     * @return string|null
     */
    private function fetchMetaTagByProperty(string $response, string $property): ?string
    {
        preg_match('/<meta[\s]*?property="' . $property . '"[\s]*?content="([\s\S]*?)"/m', $response, $propertyMatch);
        if(empty($propertyMatch)) {
            return null;
        }

        return $propertyMatch[1];
    }

    /**
     * @param string $response
     * @param string $name
     * @return string|null
     */
    private function fetchMetaTagByName(string $response, string $name): ?string
    {
        preg_match('/<meta[\s]*?name="' . $name . '"[\s]*?content="([\s\S]*?)"/m', $response, $propertyMatch);
        if(empty($propertyMatch)) {
            return null;
        }

        return $propertyMatch[1];
    }

    private function setCustomFieldSettings(EntityRepository $entityRepository, string $referenceId, string $salesChannelId, array $customFields)
    {
        /** Fetch the language id the sales channel */
        /** @var SalesChannelEntity $salesChannel */
        $salesChannel = $this->salesChannelRepository->search(new Criteria([ $salesChannelId ]))->first();
        if (null === $salesChannel) {
            throw new \RuntimeException('Invalid sales channel id: ' . $salesChannelId);
        }

        /** Create the context */
        $context = $this->contextFactory->createContext(
            (new ContextFactory\Struct\ContextStruct())
                ->setLanguageIdChain([ $salesChannel->getLanguageId() ])
        );

        /** Update the product */
        $entityRepository->upsert([
            [
                'id' => $referenceId,
                'customFields' => $customFields
            ]
        ], $context);
    }
}
