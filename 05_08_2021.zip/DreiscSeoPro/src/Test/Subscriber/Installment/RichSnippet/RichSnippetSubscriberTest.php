<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Subscriber\Installment\RichSnippet;

use DreiscCli\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Content\Country\CountryRepository;
use DreiscSeoPro\Core\Content\Media\MediaRepository;
use DreiscSeoPro\Core\Content\Product\ProductEnum;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Content\SalesChannel\SalesChannelRepository;
use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\CustomSetting\CustomSettingLoader;
use DreiscSeoPro\Core\CustomSetting\CustomSettingSaver;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Breadcrumb\HomeStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Breadcrumb\ProductStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\LocalBusiness\OpeningHoursSpecification\SpecificationStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Product\GeneralStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Product\Offer\AvailabilityStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Product\Offer\ItemConditionStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Product\PriceValidUntilStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Product\Review\AuthorStruct;
use DreiscSeoPro\Core\Foundation\Context\ContextFactory;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Subscriber\Installment\RichSnippet\RichSnippetSubscriber;
use Shopware\Core\Content\Media\MediaEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\MultiFilter;
use Shopware\Core\Framework\Test\TestCaseBase\AdminApiTestBehaviour;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Subscriber\Installment\RichSnippet\BaseInformationSubscriber;
use Shopware\Core\Framework\Test\TestCaseBase\KernelLifecycleManager;
use Shopware\Core\System\Country\CountryEntity;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;
use Shopware\Storefront\Test\Controller\StorefrontControllerTestBehaviour;

class RichSnippetSubscriberTest extends TestCase
{
    use IntegrationTestBehaviour;
    use StorefrontControllerTestBehaviour;

    /**
     * @var RichSnippetSubscriber
     */
    private $richSnippetSubscriber;

    /**
     * @var CustomSettingLoader
     */
    private $customSettingLoader;

    /**
     * @var CustomSettingSaver
     */
    private $customSettingSaver;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var SalesChannelRepository
     */
    protected $salesChannelRepository;

    /**
     * @var MediaRepository
     */
    protected $mediaRepository;

    /**
     * @var CountryRepository
     */
    protected $countryRepository;

    /**
     * @var ContextFactory
     */
    protected $contextFactory;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    protected function setUp(): void
    {
        $this->richSnippetSubscriber = $this->getContainer()->get(RichSnippetSubscriber::class);
        $this->customSettingLoader = $this->getContainer()->get(CustomSettingLoader::class);
        $this->customSettingSaver = $this->getContainer()->get(CustomSettingSaver::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->mediaRepository = $this->getContainer()->get(MediaRepository::class);
        $this->countryRepository = $this->getContainer()->get(CountryRepository::class);
        $this->contextFactory = $this->getContainer()->get(ContextFactory::class);
        $this->salesChannelRepository = $this->getContainer()->get(SalesChannelRepository::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
    }

    public function test_product_de_defaultNoImageNoReview(): void
    {
        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/84df42e095134ba3ab239723a5ab9697');

        /** Make sure, that there is a product array */
        $this->assertNotEmpty($ldArray['Product']);

        /** There should be only one product */
        $this->assertCount(1, $ldArray['Product']);

        /** Calculate the date until the offer is valid */
        $date = new \DateTime('now');
        $priceValidUntil = $date->format('Y-m-d');

        /** Check, if the array is the same */
        $this->assertSame([
            '@context' => 'https://schema.org/',
            '@type' => 'Product',
            'name' => 'Mehreren Kategorien zugewiesen',
            'description' => 'Beschreibung 84df42e095134ba3ab239723a5ab9697',
            'sku' => 'SW-1004',
            'mpn' => 'SW-1004',
            'brand' => [
                '@type' => 'Brand',
                'name' => 'Dreischild',
            ],
            'offers' =>  [
                0 => [
                    '@type' => 'Offer',
                    'availability' => 'https://schema.org/InStock',
                    'itemCondition' => 'https://schema.org/NewCondition',
                    'priceCurrency' => 'EUR',
                    'priceValidUntil' => $priceValidUntil,
                    'url' => 'http://www.shopware-dev.de/Mehreren-Kategorien-zugewiesen/SW-1004',
                    'price' => 119,
                ]
            ]
        ], $ldArray['Product'][0]);
    }

    public function test_product_en_defaultNoImageNoReview(): void
    {
        $ldArray = $this->fetchLdArray('http://gbshop.shopware-dev.de/detail/84df42e095134ba3ab239723a5ab9697');

        /** Make sure, that there is a product array */
        $this->assertNotEmpty($ldArray['Product']);

        /** There should be only one product */
        $this->assertCount(1, $ldArray['Product']);

        /** Calculate the date until the offer is valid */
        $date = new \DateTime('now');
        $priceValidUntil = $date->format('Y-m-d');

        /** Check, if the array is the same */
        $this->assertSame([
            '@context' => 'https://schema.org/',
            '@type' => 'Product',
            'name' => 'Assigned to many categories',
            'description' => 'Description 84df42e095134ba3ab239723a5ab9697',
            'sku' => 'SW-1004',
            'mpn' => 'SW-1004',
            'brand' => [
                '@type' => 'Brand',
              'name' => 'Dreischild',
            ],
            'offers' =>  [
                0 => [
                    '@type' => 'Offer',
                    'availability' => 'https://schema.org/InStock',
                    'itemCondition' => 'https://schema.org/NewCondition',
                    'priceCurrency' => 'GBP',
                    'priceValidUntil' => $priceValidUntil,
                    'url' => 'http://gbshop.shopware-dev.de/Assigned-to-many-categories/SW-1004',
                    'price' => 106.1
              ]
            ]
        ], $ldArray['Product'][0]);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_product_de_testReviewAndImage(): void
    {
        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1001);

        /** Make sure, that there is a product array */
        $this->assertNotEmpty($ldArray['Product']);

        /** There should be only one product */
        $this->assertCount(1, $ldArray['Product']);

        /** Make sure, that the aggregateRating and the review data exist */
        $this->assertNotEmpty($ldArray['Product'][0]['aggregateRating']);
        $this->assertNotEmpty($ldArray['Product'][0]['review']);

        /** Check the aggregateRating data */
        $this->assertSame([
            '@type' => 'AggregateRating',
            'ratingValue' => 3.5,
            'bestRating' => '5',
            'ratingCount' => 2
        ], $ldArray['Product'][0]['aggregateRating']);

        /** Check the review data */
        $this->assertSame([
            [
                '@type' => 'Review',
                'datePublished' => '2019-04-07T11:35:00',
                'name' => 'TOP!',
                'description' => 'Klare Empfehlung',
                'author' => 'Kunde'
            ],[
                '@type' => 'Review',
                'datePublished' => '2019-04-06T12:55:20',
                'name' => 'Schlechte Qualität',
                'description' => 'Leider taugt das Produkt nichts',
                'author' => 'Kunde'
            ]
        ], $ldArray['Product'][0]['review']);

        /** Check the image data */
        $this->assertNotEmpty($ldArray['Product'][0]['image']);
        $this->assertCount(1, $ldArray['Product'][0]['image']);
        $this->assertStringContainsString('/media/', $ldArray['Product'][0]['image'][0]);
        $this->assertStringEndsWith('.jpg', $ldArray['Product'][0]['image'][0]);
    }

    public function test_product_de_testAggregateOffer(): void
    {
        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure, that there is a product array */
        $this->assertNotEmpty($ldArray['Product']);

        /** There should be only one product */
        $this->assertCount(1, $ldArray['Product']);

        /** Make sure there is a aggregate offer instead of an single offer */
        $this->assertNotEmpty($ldArray['Product'][0]['offers']);
        $this->assertCount(1, $ldArray['Product'][0]['offers']);
        $this->assertSame('AggregateOffer', $ldArray['Product'][0]['offers'][0]['@type']);

        /** Make sure, that there is no price as a abse field */
        $this->assertArrayNotHasKey('price', $ldArray['Product'][0]['offers'][0]);

        /** Check other base fields */
        $this->assertSame(110, $ldArray['Product'][0]['offers'][0]['lowPrice']);
        $this->assertSame(119, $ldArray['Product'][0]['offers'][0]['highPrice']);
        $this->assertSame(3, $ldArray['Product'][0]['offers'][0]['offerCount']);
        $this->assertSame('http://www.shopware-dev.de/Produkt-mit-Staffelpreisen/SW-1007', $ldArray['Product'][0]['offers'][0]['url']);

        /** Calculate the date until the offer is valid */
        $date = new \DateTime('now');
        $priceValidUntil = $date->format('Y-m-d');

        /** Check the sub offers */
        $this->assertCount(3, $ldArray['Product'][0]['offers'][0]['offers']);
        $this->assertSame([
            '@type' => 'Offer',
            'priceCurrency' => 'EUR',
            'price' => 115,
            'availability' => 'https://schema.org/InStock',
            'itemCondition' => 'https://schema.org/NewCondition',
            'url' => 'http://www.shopware-dev.de/Produkt-mit-Staffelpreisen/SW-1007',
            'priceValidUntil' => $priceValidUntil
        ], $ldArray['Product'][0]['offers'][0]['offers'][1]);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_breadcrumb_de_home(): void
    {
        /** Check if there a no ld json data */
        $this->assertNoLdJsonData('http://www.shopware-dev.de/');
    }

    public function test_breadcrumb_de_search(): void
    {
        /** Check if there a no ld json data */
        $this->assertNoLdJsonData('http://www.shopware-dev.de/search?search=produkt');
    }

    public function test_breadcrumb_de_product(): void
    {
        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/3848d63292714905aa86008fd973693a');

        /** Make sure, that there is a BreadcrumbList array */
        $this->assertNotEmpty($ldArray['BreadcrumbList']);

        /** There should be only one BreadcrumbList */
        $this->assertCount(1, $ldArray['BreadcrumbList']);

        $isSetProductNavigationSeoUrl = $this->isUrlSet(
            'Produkte/',
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe()
        );

        /** Check complete array */
        $this->assertSame([
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                0 => [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Hauptnavigation',
                    'item' => 'http://www.shopware-dev.de/navigation/fdb2de5abc7a497499f2358ba9b2aa75'
                ],[
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'Produkte',
                    'item' => $isSetProductNavigationSeoUrl ? 'http://www.shopware-dev.de/Produkte/' : 'http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS,
                ],[
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => 'Standard-Produkte',
                    'item' => 'http://www.shopware-dev.de/Produkte/Standard-Produkte/'
                ]
            ]
        ], $ldArray['BreadcrumbList'][0]);
    }

    public function test_breadcrumb_en_product(): void
    {
        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/en/detail/3848d63292714905aa86008fd973693a');

        /** Make sure, that there is a BreadcrumbList array */
        $this->assertNotEmpty($ldArray['BreadcrumbList']);

        /** There should be only one BreadcrumbList */
        $this->assertCount(1, $ldArray['BreadcrumbList']);

        $isSetProductNavigationSeoUrl = $this->isUrlSet(
            'Products/',
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdEn()
        );

        /** Check complete array */
        $this->assertSame([
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                0 => [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Main navigation',
                    'item' => 'http://www.shopware-dev.de/en/navigation/fdb2de5abc7a497499f2358ba9b2aa75'
                ],[
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'Products',
                    'item' => $isSetProductNavigationSeoUrl ? 'http://www.shopware-dev.de/en/Products/' : 'http://www.shopware-dev.de/en/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS,
                ],[
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => 'Standard-Products',
                    'item' => 'http://www.shopware-dev.de/en/Products/Standard-Products/'
                ]
            ]
        ], $ldArray['BreadcrumbList'][0]);
    }

    public function test_breadcrumb_de_category(): void
    {
        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/navigation/e403cec98def4844affc68465632b15d');

        /** Make sure, that there is a BreadcrumbList array */
        $this->assertNotEmpty($ldArray['BreadcrumbList']);

        /** There should be only one BreadcrumbList */
        $this->assertCount(1, $ldArray['BreadcrumbList']);

        $isSetProductNavigationSeoUrl = $this->isUrlSet(
            'Produkte/',
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe()
        );

        /** Check complete array */
        $this->assertSame([
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                0 => [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Produkte',
                    'item' => $isSetProductNavigationSeoUrl ? 'http://www.shopware-dev.de/Produkte/' : 'http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS,
                ],[
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'Main-Produkte',
                    'item' => 'http://www.shopware-dev.de/Produkte/Main-Produkte/'
                ]
            ]
        ], $ldArray['BreadcrumbList'][0]);
    }

    public function test_breadcrumb_en_category(): void
    {
        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/en/navigation/e403cec98def4844affc68465632b15d');

        /** Make sure, that there is a BreadcrumbList array */
        $this->assertNotEmpty($ldArray['BreadcrumbList']);

        /** There should be only one BreadcrumbList */
        $this->assertCount(1, $ldArray['BreadcrumbList']);

        $isSetProductNavigationSeoUrl = $this->isUrlSet(
            'Products/',
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdEn()
        );

        /** Check complete array */
        $this->assertSame([
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                0 => [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Products',
                    'item' => $isSetProductNavigationSeoUrl ? 'http://www.shopware-dev.de/en/Products/' : 'http://www.shopware-dev.de/en/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS,
                ],[
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'Main-Products',
                    'item' => 'http://www.shopware-dev.de/en/Products/Main-Products/'
                ]
            ]
        ], $ldArray['BreadcrumbList'][0]);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_inactive_ld_json(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSetting->getRichSnippets()->getGeneral()->setActive(false);
        $this->customSettingSaver->save($customSetting);

        /** Check if there a no ld json support */
        $this->assertNoLdJsonData('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Restore */
        $customSetting->getRichSnippets()->getGeneral()->setActive(true);
        $this->customSettingSaver->save($customSetting);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_product_offer_sellerName(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSetting->getRichSnippets()->getProduct()->getOffer()->getSeller()->setName('Dreischild GmbH');
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/84df42e095134ba3ab239723a5ab9697');

        /** Calculate the date until the offer is valid */
        $date = new \DateTime('now');
        $priceValidUntil = $date->format('Y-m-d');

        /** Check, if the array is the same */
        $this->assertSame([
            '@type' => 'Offer',
            'availability' => 'https://schema.org/InStock',
            'itemCondition' => 'https://schema.org/NewCondition',
            'priceCurrency' => 'EUR',
            'priceValidUntil' => $priceValidUntil,
            'seller' => [
                '@type' => 'Organization',
                'name' => 'Dreischild GmbH'
            ],
            'url' => 'http://www.shopware-dev.de/Mehreren-Kategorien-zugewiesen/SW-1004',
            'price' => 119,
        ], $ldArray['Product'][0]['offers'][0]);

        /** Restore */
        $customSetting->getRichSnippets()->getProduct()->getOffer()->getSeller()->setName('');
        $this->customSettingSaver->save($customSetting);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_product_offer_availability(): void
    {
        /** Set test values for the availabilities */
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;
        $availabilitySettings = $customSetting->getRichSnippets()->getProduct()->getOffer()->getAvailability();
        $availabilitySettings->setDefaultAvailability('Default');
        $availabilitySettings->setDefaultAvailabilityOutOfStock('Default_OutOfStock');
        $availabilitySettings->setDefaultAvailabilityClearanceSale('ClearanceSale');
        $availabilitySettings->setDefaultAvailabilityClearanceSaleOutOfStock('ClearanceSale_OutOfStock');
        $this->customSettingSaver->save($customSetting);

        /**
         * Test Default
         */

        $this->productRepository->updateByCriteria([
            'isCloseout' => false,
            'stock' => 100
        ], new Criteria([ DemoDataIds::PRODUCT_SW_1007 ]));

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'https://schema.org/Default',
            $ldArray['Product'][0]['offers'][0]['availability']
        );

        /**
         * Test Default_OutOfStock
         */

        $this->productRepository->updateByCriteria([
            'isCloseout' => false,
            'stock' => 0
        ], new Criteria([ DemoDataIds::PRODUCT_SW_1007 ]));

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'https://schema.org/Default_OutOfStock',
            $ldArray['Product'][0]['offers'][0]['availability']
        );

        /**
         * Test ClearanceSale
         */

        $this->productRepository->updateByCriteria([
            'isCloseout' => true,
            'stock' => 100
        ], new Criteria([ DemoDataIds::PRODUCT_SW_1007 ]));

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'https://schema.org/ClearanceSale',
            $ldArray['Product'][0]['offers'][0]['availability']
        );

        /**
         * Test ClearanceSale_OutOfStock
         */

        $this->productRepository->updateByCriteria([
            'isCloseout' => true,
            'stock' => 0
        ], new Criteria([ DemoDataIds::PRODUCT_SW_1007 ]));

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'https://schema.org/ClearanceSale_OutOfStock',
            $ldArray['Product'][0]['offers'][0]['availability']
        );

        /**
         * Test custom field
         */
        /** Set a custom field setting */
        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1007,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__AVAILABILITY,
            AvailabilityStruct::AVAILABILITY__PRE_ORDER
        );

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'https://schema.org/PreOrder',
            $ldArray['Product'][0]['offers'][0]['availability']
        );

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);

        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1007,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__AVAILABILITY,
            ''
        );
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_product_offer_itemCondition(): void
    {
        /** Set test values for the availabilities */
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;
        $itemConditionSettings = $customSetting->getRichSnippets()->getProduct()->getOffer()->getItemCondition();
        $itemConditionSettings->setDefaultItemCondition('DefaultItemCondition');
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'https://schema.org/DefaultItemCondition',
            $ldArray['Product'][0]['offers'][0]['itemCondition']
        );

        /** Set a custom field setting */
        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1007,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__ITEM_CONDITION,
            ItemConditionStruct::ITEM_CONDITION__DAMAGED_CONDITION
        );

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'https://schema.org/DamagedCondition',
            $ldArray['Product'][0]['offers'][0]['itemCondition']
        );

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);

        /** Set a custom field setting */
        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1007,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__ITEM_CONDITION,
            ''
        );
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_product_general_skuCompilation(): void
    {
        /** Set a manufacturer number for the demo product */
        $this->productRepository->update([
            [
                'id' => DemoDataIds::PRODUCT_SW_1007,
                'manufacturerNumber' => 'manufacturerNumber1007'
            ]
        ]);

        /** Set test values for the sku */
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;
        $itemConditionSettings = $customSetting->getRichSnippets()->getProduct()->getGeneral()->setSkuCompilation(
            GeneralStruct::SKU_COMPILATION__PRODUCT_NUMBER
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'SW-1007',
            $ldArray['Product'][0]['sku']
        );

        /** Switch and test again */
        $itemConditionSettings = $customSetting->getRichSnippets()->getProduct()->getGeneral()->setSkuCompilation(
            GeneralStruct::SKU_COMPILATION__MANUFACTURER_NUMBER__OTHERWISE__PRODUCT_NUMBER
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'manufacturerNumber1007',
            $ldArray['Product'][0]['sku']
        );

        /**
         * Test custom value
         */

        /** Set a custom field setting */
        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1007,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__CUSTOM_SKU,
            'MY-CUSTOM-SKU'
        );

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'MY-CUSTOM-SKU',
            $ldArray['Product'][0]['sku']
        );

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);

        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1007,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__CUSTOM_SKU,
            ''
        );
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_product_general_mpnCompilation(): void
    {
        /** Set a manufacturer number for the demo product */
        $this->productRepository->update([
            [
                'id' => DemoDataIds::PRODUCT_SW_1007,
                'manufacturerNumber' => 'manufacturerNumber1007'
            ]
        ]);

        /** Set test values for the mpn */
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;
        $itemConditionSettings = $customSetting->getRichSnippets()->getProduct()->getGeneral()->setMpnCompilation(
            GeneralStruct::MPN_COMPILATION__PRODUCT_NUMBER
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'SW-1007',
            $ldArray['Product'][0]['mpn']
        );

        /** Switch and test again */
        $itemConditionSettings = $customSetting->getRichSnippets()->getProduct()->getGeneral()->setMpnCompilation(
            GeneralStruct::MPN_COMPILATION__MANUFACTURER_NUMBER__OTHERWISE__PRODUCT_NUMBER
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'manufacturerNumber1007',
            $ldArray['Product'][0]['mpn']
        );

        /**
         * Test custom value
         */

        /** Set a custom field setting */
        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1007,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__CUSTOM_MPN,
            'MY-CUSTOM-MPN'
        );

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        $this->assertSame(
            'MY-CUSTOM-MPN',
            $ldArray['Product'][0]['mpn']
        );

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);

        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1007,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__CUSTOM_MPN,
            ''
        );
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_product_general_priceValidUntil(): void
    {
        /** Calculate the date until the offer is valid */
        $date = new \DateTime('now');
        $date->add(new \DateInterval('P7D'));
        $priceValidUntil = $date->format('Y-m-d');

        /** Test: Not display */
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;
        $customSetting->getRichSnippets()->getProduct()->getPriceValidUntil()->setInterval(
            PriceValidUntilStruct::INTERVAL__NOT_DISPLAY
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $this->assertArrayNotHasKey('priceValidUntil', $ldArray['Product'][0]['offers'][0]);

        /** Switch and test again */
        $customSetting->getRichSnippets()->getProduct()->getPriceValidUntil()->setInterval(
            PriceValidUntilStruct::INTERVAL__TODAY
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $date = new \DateTime('now');

        $this->assertSame(
            $date->format('Y-m-d'),
            $ldArray['Product'][0]['offers'][0]['priceValidUntil']
        );

        /** Switch and test again */
        $customSetting->getRichSnippets()->getProduct()->getPriceValidUntil()->setInterval(
            PriceValidUntilStruct::INTERVAL__1_DAY
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $date = new \DateTime('now');
        $date->add(new \DateInterval('P1D'));

        $this->assertSame(
            $date->format('Y-m-d'),
            $ldArray['Product'][0]['offers'][0]['priceValidUntil']
        );

        /** Switch and test again */
        $customSetting->getRichSnippets()->getProduct()->getPriceValidUntil()->setInterval(
            PriceValidUntilStruct::INTERVAL__1_WEEK
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $date = new \DateTime('now');
        $date->add(new \DateInterval('P7D'));

        $this->assertSame(
            $date->format('Y-m-d'),
            $ldArray['Product'][0]['offers'][0]['priceValidUntil']
        );

        /** Switch and test again */
        $customSetting->getRichSnippets()->getProduct()->getPriceValidUntil()->setInterval(
            PriceValidUntilStruct::INTERVAL__2_WEEK
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $date = new \DateTime('now');
        $date->add(new \DateInterval('P14D'));

        $this->assertSame(
            $date->format('Y-m-d'),
            $ldArray['Product'][0]['offers'][0]['priceValidUntil']
        );

        /** Switch and test again */
        $customSetting->getRichSnippets()->getProduct()->getPriceValidUntil()->setInterval(
            PriceValidUntilStruct::INTERVAL__1_MONTH
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $date = new \DateTime('now');
        $date->add(new \DateInterval('P1M'));

        $this->assertSame(
            $date->format('Y-m-d'),
            $ldArray['Product'][0]['offers'][0]['priceValidUntil']
        );

        /** Switch and test again */
        $customSetting->getRichSnippets()->getProduct()->getPriceValidUntil()->setInterval(
            PriceValidUntilStruct::INTERVAL__CUSTOM_DAYS
        );
        $customSetting->getRichSnippets()->getProduct()->getPriceValidUntil()->setCustomDays(
            5
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $date = new \DateTime('now');
        $date->add(new \DateInterval('P5D'));

        $this->assertSame(
            $date->format('Y-m-d'),
            $ldArray['Product'][0]['offers'][0]['priceValidUntil']
        );

        /** Switch and test again */
        $customSetting->getRichSnippets()->getProduct()->getPriceValidUntil()->setInterval(
            PriceValidUntilStruct::INTERVAL__1_WEEK
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $date = new \DateTime('now');
        $date->add(new \DateInterval('P7D'));

        $this->assertSame(
            $date->format('Y-m-d'),
            $ldArray['Product'][0]['offers'][0]['priceValidUntil']
        );

        /**
         * Test custom value
         */

        $date = new \DateTime('now');
        $date->add(new \DateInterval('P50D'));

        /** Set a custom field setting */
        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1006_1,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__PRICE_VALID_UNTIL_DATE,
            $date->format('Y-m-d')
        );

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_1);

        $this->assertSame(
            $date->format('Y-m-d'),
            $ldArray['Product'][0]['offers'][0]['priceValidUntil']
        );

        /** Save a different value for the variant */
        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1006_2,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__PRICE_VALID_UNTIL_DATE,
            '1987-02-28'
        );

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_2);

        $this->assertSame(
            '1987-02-28',
            $ldArray['Product'][0]['offers'][0]['priceValidUntil']
        );

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);

        /** Set a custom field setting */
        $this->setCustomFieldSetting(
            DemoDataIds::PRODUCT_SW_1006_1,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_RICH_SNIPPET__PRICE_VALID_UNTIL_DATE,
            null
        );
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_product_review_authorCompilation(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /** Test: Not display */
        $customSetting->getRichSnippets()->getProduct()->getReview()->getAuthor()->setCompilation(
            AuthorStruct::COMPILATION__NOT_DISPLAY
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1001);
        $this->assertArrayNotHasKey('author', $ldArray['Product'][0]['review'][0]);

        /** Test: Static snippet [de] */
        $customSetting->getRichSnippets()->getProduct()->getReview()->getAuthor()->setCompilation(
            AuthorStruct::COMPILATION__STATIC_SNIPPET
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1001);

        $this->assertContains($ldArray['Product'][0]['review'][0]['author'], [
            'Kunde',
            'Customer'
        ]);

        /** Test: Static snippet [en] */
        $customSetting->getRichSnippets()->getProduct()->getReview()->getAuthor()->setCompilation(
            AuthorStruct::COMPILATION__STATIC_SNIPPET
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/en/detail/' . DemoDataIds::PRODUCT_SW_1001);

        $this->assertContains($ldArray['Product'][0]['review'][0]['author'], [
            'Kunde',
            'Customer'
        ]);

        /** Test: Firstname */
        $customSetting->getRichSnippets()->getProduct()->getReview()->getAuthor()->setCompilation(
            AuthorStruct::COMPILATION__FIRSTNAME
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1001);

        $this->assertSame(
            'Moritz',
            $ldArray['Product'][0]['review'][0]['author']
        );

        /** Test: Firstname and lastname */
        $customSetting->getRichSnippets()->getProduct()->getReview()->getAuthor()->setCompilation(
            AuthorStruct::COMPILATION__FIRSTNAME_AND_LASTNAME
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1001);

        $this->assertSame(
            'Moritz Becker',
            $ldArray['Product'][0]['review'][0]['author']
        );

        /** Test: Firstname and lastname */
        $customSetting->getRichSnippets()->getProduct()->getReview()->getAuthor()->setCompilation(
            AuthorStruct::COMPILATION__FIRSTNAME_AND_FIRST_LETTER_OF_LASTNAME
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1001);

        $this->assertSame(
            'Moritz B.',
            $ldArray['Product'][0]['review'][0]['author']
        );

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_breadcrumb_general(): void
    {
        /** Set test values*/
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;
        $customSetting->getRichSnippets()->getBreadcrumb()->getGeneral()->setActive(false);
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure, that no breadcrumbs will be output */
        $this->assertArrayNotHasKey('BreadcrumbList', $ldArray);

        /**
         * Second test
         */
        $customSetting->getRichSnippets()->getBreadcrumb()->getGeneral()->setActive(true);
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure, that the breadcrumbs will be output */
        $this->assertArrayHasKey('BreadcrumbList', $ldArray);
        $this->assertNotEmpty($ldArray['BreadcrumbList'][0]);
        $this->assertArrayHasKey('itemListElement', $ldArray['BreadcrumbList'][0]);
        $this->assertCount(3, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_breadcrumb_product_showInBreadcrumbMode_notDisplay(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /**
         * Test » Not display
         */
        $customSetting->getRichSnippets()->getBreadcrumb()->getProduct()->setShowInBreadcrumbMode(
            ProductStruct::SHOW_IN_BREADCRUMB_MODE__NOT_DISPLAY
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure there are only two elements */
        $this->assertCount(3, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Make sure that the breadcrumb will NOT display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);
        $this->assertStringNotContainsString('dreisc-seo--product-breadcrumb is-active', $pageResponse);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_breadcrumb_product_showInBreadcrumbMode_onlyJsonLd(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /**
         * Test » Only JSON LD
         */
        $customSetting->getRichSnippets()->getBreadcrumb()->getProduct()->setShowInBreadcrumbMode(
            ProductStruct::SHOW_IN_BREADCRUMB_MODE__ONLY_JSON_LD
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure there are now three elements */
        $this->assertCount(4, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Check the details */
        $this->assertSame('Produkt mit Staffelpreisen', $ldArray['BreadcrumbList'][0]['itemListElement'][3]['name']);
        $this->assertArrayHasKey('item', $ldArray['BreadcrumbList'][0]['itemListElement'][3]);
        $this->assertSame('http://www.shopware-dev.de/Produkt-mit-Staffelpreisen/SW-1007', $ldArray['BreadcrumbList'][0]['itemListElement'][3]['item']);

        /** Make sure that the breadcrumb will NOT display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);
        $this->assertStringNotContainsString('dreisc-seo--product-breadcrumb is-active', $pageResponse);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_breadcrumb_product_showInBreadcrumbMode_onlyShop(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /**
         * Test » Only Shop
         */
        $customSetting->getRichSnippets()->getBreadcrumb()->getProduct()->setShowInBreadcrumbMode(
            ProductStruct::SHOW_IN_BREADCRUMB_MODE__ONLY_SHOP
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure there are only two elements */
        $this->assertCount(3, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Make sure that the breadcrumb will display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);
        $this->assertStringContainsString('dreisc-seo--product-breadcrumb is-active', $pageResponse);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_breadcrumb_product_showInBreadcrumbMode_shopAndJsonLd(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /**
         * Test » Shop and JSON LD
         */
        $customSetting->getRichSnippets()->getBreadcrumb()->getProduct()->setShowInBreadcrumbMode(
            ProductStruct::SHOW_IN_BREADCRUMB_MODE__SHOP_AND_JSON_LD
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure there are now three elements */
        $this->assertCount(4, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Check the details */
        $this->assertSame('Produkt mit Staffelpreisen', $ldArray['BreadcrumbList'][0]['itemListElement'][3]['name']);
        $this->assertArrayHasKey('item', $ldArray['BreadcrumbList'][0]['itemListElement'][3]);
        $this->assertSame('http://www.shopware-dev.de/Produkt-mit-Staffelpreisen/SW-1007', $ldArray['BreadcrumbList'][0]['itemListElement'][3]['item']);

        /** Make sure that the breadcrumb will display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);
        $this->assertStringContainsString('dreisc-seo--product-breadcrumb is-active', $pageResponse);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_breadcrumb_home_showInBreadcrumbMode_notDisplay(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /**
         * Test » Not display
         */
        $customSetting->getRichSnippets()->getBreadcrumb()->getHome()->setShowInBreadcrumbMode(
            HomeStruct::SHOW_IN_BREADCRUMB_MODE__NOT_DISPLAY
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure there are only two elements */
        $this->assertCount(3, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Make sure that the breadcrumb will NOT display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);
        $this->assertStringNotContainsString('dreisc-seo--home-breadcrumb', $pageResponse);

        /**
         * »» Navigation
         */

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        /** Make sure there are only two elements */
        $this->assertCount(2, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Make sure that the breadcrumb will NOT display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);
        $this->assertStringNotContainsString('dreisc-seo--home-breadcrumb', $pageResponse);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_breadcrumb_home_showInBreadcrumbMode_onlyJsonLd(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /**
         * Test » Only JSON LD
         */
        $customSetting->getRichSnippets()->getBreadcrumb()->getHome()->setShowInBreadcrumbMode(
            HomeStruct::SHOW_IN_BREADCRUMB_MODE__ONLY_JSON_LD
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure there are now three elements */
        $this->assertCount(4, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Check the details */
        $this->assertSame('Home', $ldArray['BreadcrumbList'][0]['itemListElement'][0]['name']);
        $this->assertArrayHasKey('item', $ldArray['BreadcrumbList'][0]['itemListElement'][0]);
        $this->assertSame('http://www.shopware-dev.de/', $ldArray['BreadcrumbList'][0]['itemListElement'][0]['item']);

        /** Make sure that the breadcrumb will NOT display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);
        $this->assertStringNotContainsString('dreisc-seo--home-breadcrumb', $pageResponse);

        /**
         * »» Navigation
         */

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        /** Check the details */
        $this->assertSame('Home', $ldArray['BreadcrumbList'][0]['itemListElement'][0]['name']);
        $this->assertArrayHasKey('item', $ldArray['BreadcrumbList'][0]['itemListElement'][0]);
        $this->assertSame('http://www.shopware-dev.de/', $ldArray['BreadcrumbList'][0]['itemListElement'][0]['item']);

        /** Make sure that the breadcrumb will display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES__WITHOUT_DE_TRANSLATION);
        $this->assertStringNotContainsString('dreisc-seo--home-breadcrumb', $pageResponse);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_breadcrumb_home_showInBreadcrumbMode_onlyShop(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /**
         * Test » Only Shop
         */
        $customSetting->getRichSnippets()->getBreadcrumb()->getHome()->setShowInBreadcrumbMode(
            HomeStruct::SHOW_IN_BREADCRUMB_MODE__ONLY_SHOP
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure there are only two elements */
        $this->assertCount(3, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Make sure that the breadcrumb will display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);
        $this->assertStringContainsString('dreisc-seo--home-breadcrumb', $pageResponse);

        /**
         * »» Navigation
         */

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        /** Make sure there are only two elements */
        $this->assertCount(2, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Make sure that the breadcrumb will display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES__WITHOUT_DE_TRANSLATION);
        $this->assertStringContainsString('dreisc-seo--home-breadcrumb', $pageResponse);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_breadcrumb_home_showInBreadcrumbMode_shopAndJsonLd(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /**
         * Test » Shop and JSON LD
         */
        $customSetting->getRichSnippets()->getBreadcrumb()->getHome()->setShowInBreadcrumbMode(
            HomeStruct::SHOW_IN_BREADCRUMB_MODE__SHOP_AND_JSON_LD
        );
        $this->customSettingSaver->save($customSetting);

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure there are now three elements */
        $this->assertCount(4, $ldArray['BreadcrumbList'][0]['itemListElement']);

        /** Check the details */
        $this->assertSame('Home', $ldArray['BreadcrumbList'][0]['itemListElement'][0]['name']);
        $this->assertArrayHasKey('item', $ldArray['BreadcrumbList'][0]['itemListElement'][0]);
        $this->assertSame('http://www.shopware-dev.de/', $ldArray['BreadcrumbList'][0]['itemListElement'][0]['item']);

        /** Make sure that the breadcrumb will display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);
        $this->assertStringContainsString('dreisc-seo--home-breadcrumb', $pageResponse);

        /**
         * »» Navigation
         */

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        /** Check the details */
        $this->assertSame('Home', $ldArray['BreadcrumbList'][0]['itemListElement'][0]['name']);
        $this->assertArrayHasKey('item', $ldArray['BreadcrumbList'][0]['itemListElement'][0]);
        $this->assertSame('http://www.shopware-dev.de/', $ldArray['BreadcrumbList'][0]['itemListElement'][0]['item']);

        /** Make sure that the breadcrumb will display in the shop */
        $pageResponse = $this->fetchUrlResponse('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES__WITHOUT_DE_TRANSLATION);
        $this->assertStringContainsString('dreisc-seo--home-breadcrumb', $pageResponse);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_logo(): void
    {
        $randomMedia = $this->fetchRandomMediaEntity();

        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure that there is NO Organization key */
        $this->assertArrayNotHasKey('Organization', $ldArray);

        /** Set organization test data */
        $customSetting->getRichSnippets()->getLogo()->getGeneral()
            ->setActive(true)
            ->setLogo($randomMedia->getId())
            ->setUrl('http://www.shopware-dev.de/contact');
        $this->customSettingSaver->save($customSetting);

        /** Fetch the data again */
        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure that there is Organization key and has one entry */
        $this->assertArrayHasKey('Organization', $ldArray);
        $this->assertCount(1, $ldArray['Organization']);

        /** Check the details */
        $this->assertSame([
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'logo' => $randomMedia->getUrl(),
            'url' => 'http://www.shopware-dev.de/contact'
        ], $ldArray['Organization'][0]);

        /**
         * »» Navigation
         */

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        /** Make sure that there is Organization key and has one entry */
        $this->assertArrayHasKey('Organization', $ldArray);
        $this->assertCount(1, $ldArray['Organization']);

        /** Check the details */
        $this->assertSame([
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'logo' => $randomMedia->getUrl(),
            'url' => 'http://www.shopware-dev.de/contact'
        ], $ldArray['Organization'][0]);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_logo_differentSalesChannel(): void
    {
        $randomMedia = $this->fetchRandomMediaEntity();

        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /** Set organization test data */
        $customSetting->getRichSnippets()->getLogo()->getGeneral()
            ->setActive(true)
            ->setLogo($randomMedia->getId())
            ->setUrl('http://www.shopware-dev.de/contact');
        $this->customSettingSaver->save($customSetting);

        /** Set data for the gb sales channel */
        $gbCustomSetting = $this->customSettingLoader->load(DemoDataIds::SALES_CHANNEL__GB_SHOP);
        $gbCustomSettingBackup = clone $gbCustomSetting;
        $gbCustomSetting->getRichSnippets()->getLogo()->getGeneral()
            ->setUrl('http://www.shopware-dev.de/gb-shop');
        $this->customSettingSaver->save($gbCustomSetting, DemoDataIds::SALES_CHANNEL__GB_SHOP);

        /** Fetch the data again */
        $ldArray = $this->fetchLdArray('http://gbshop.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure that there is Organization key and has one entry */
        $this->assertArrayHasKey('Organization', $ldArray);
        $this->assertCount(1, $ldArray['Organization']);

        /** Check the details */
        $this->assertSame([
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'logo' => $randomMedia->getUrl(),
            'url' => 'http://www.shopware-dev.de/gb-shop'
        ], $ldArray['Organization'][0]);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
        $this->customSettingSaver->save($gbCustomSettingBackup, DemoDataIds::SALES_CHANNEL__GB_SHOP);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_localBusiness(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure that there is NO Organization key */
        $this->assertArrayNotHasKey('LocalBusiness', $ldArray);

        /** Fetch the country entity for DE */
        /** @var CountryEntity $countryEntity */
        $countryEntity = $this->countryRepository->search(
            (new Criteria())
                ->addFilter(
                    new EqualsFilter('iso', 'DE')
                )
        )->first();
        $this->assertNotNull($countryEntity);

        /** Set organization test data */
        $customSetting->getRichSnippets()->getLocalBusiness()->getGeneral()
            ->setActive(true)
            ->setName('Dreischild GmbH')
            ->setUrl('https://de.dreischild.com')
            ->setTelephone('+49123456789');

        $customSetting->getRichSnippets()->getLocalBusiness()->getAddress()
            ->setStreetAddress('Fasanenweg 35')
            ->setAddressLocality('Saarburg')
            ->setPostalCode('54439')
            ->setAddressCountry($countryEntity->getId());

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getMonday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('10:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getTuesday()
            ->setActive(true)
            ->setOpens('10:00')
            ->setCloses('11:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getWednesday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getThursday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getFriday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getSaturday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getSunday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        /** Define the expected array */
        $expectedResult = [
            '@context' => 'https://schema.org',
            '@type' => 'LocalBusiness',
            'name' => 'Dreischild GmbH',
            'url' => 'https://de.dreischild.com',
            'telephone' => '+49123456789',
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => 'Fasanenweg 35',
                'addressLocality' => 'Saarburg',
                'postalCode' => '54439',
                'addressCountry' => 'DE'
            ],
            'openingHoursSpecification' => [
                [
                    '@type' => 'OpeningHoursSpecification',
                    'dayOfWeek' => [
                        'Monday'
                    ],
                    'opens' => '09:00',
                    'closes' => '10:00'
                ],
                [
                    '@type' => 'OpeningHoursSpecification',
                    'dayOfWeek' => [
                        'Tuesday'
                    ],
                    'opens' => '10:00',
                    'closes' => '11:00'
                ],
                [
                    '@type' => 'OpeningHoursSpecification',
                    'dayOfWeek' => [
                        'Wednesday',
                        'Thursday',
                        'Friday',
                        'Saturday',
                        'Sunday',
                    ],
                    'opens' => '09:00',
                    'closes' => '18:00'
                ]
            ],
            'priceRange' => '€€€'
        ];

        $this->customSettingSaver->save($customSetting);

        /** Fetch the data again */
        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure that there is Organization key and has one entry */
        $this->assertArrayHasKey('LocalBusiness', $ldArray);
        $this->assertCount(1, $ldArray['LocalBusiness']);

        /** Check the details */
        $this->assertSame($expectedResult, $ldArray['LocalBusiness'][0]);

        /**
         * »» Navigation
         */

        $ldArray = $this->fetchLdArray('http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);

        /** Make sure that there is Organization key and has one entry */
        $this->assertArrayHasKey('LocalBusiness', $ldArray);
        $this->assertCount(1, $ldArray['LocalBusiness']);

        /** Check the details */
        $this->assertSame($expectedResult, $ldArray['LocalBusiness'][0]);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_general_differentSalesChannel(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        $customSetting->getRichSnippets()->getGeneral()
            ->setActive(false);

        $this->customSettingSaver->save($customSetting);

        /** Set data for the gb sales channel */
        $gbCustomSetting = $this->customSettingLoader->load(DemoDataIds::SALES_CHANNEL__GB_SHOP);
        $gbCustomSettingBackup = clone $gbCustomSetting;
        $gbCustomSetting->getRichSnippets()->getGeneral()
            ->setActive(true);
        $this->customSettingSaver->save($gbCustomSetting, DemoDataIds::SALES_CHANNEL__GB_SHOP);

        /** We expect no ld data */
        $this->assertNoLdJsonData('http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Fetch the data again */
        $ldArray = $this->fetchLdArray('http://gbshop.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure that the Product item is not empty */
        $this->assertArrayHasKey('Product', $ldArray);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
        $this->customSettingSaver->save($gbCustomSettingBackup, DemoDataIds::SALES_CHANNEL__GB_SHOP);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_localBusiness_differentSalesChannel(): void
    {
        $customSetting = $this->customSettingLoader->load();
        $customSettingBackup = clone $customSetting;

        /** Fetch the country entity for DE */
        /** @var CountryEntity $countryEntity */
        $countryEntity = $this->countryRepository->search(
            (new Criteria())
                ->addFilter(
                    new EqualsFilter('iso', 'DE')
                )
        )->first();
        $this->assertNotNull($countryEntity);

        /** Set organization test data */
        $customSetting->getRichSnippets()->getLocalBusiness()->getGeneral()
            ->setActive(true)
            ->setName('Dreischild GmbH')
            ->setUrl('https://de.dreischild.com')
            ->setTelephone('+49123456789');

        $customSetting->getRichSnippets()->getLocalBusiness()->getAddress()
            ->setStreetAddress('Fasanenweg 35')
            ->setAddressLocality('Saarburg')
            ->setPostalCode('54439')
            ->setAddressCountry($countryEntity->getId());

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getMonday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('10:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getTuesday()
            ->setActive(true)
            ->setOpens('10:00')
            ->setCloses('11:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getWednesday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getThursday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getFriday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getSaturday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        $customSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getSunday()
            ->setActive(true)
            ->setOpens('09:00')
            ->setCloses('18:00');

        $this->customSettingSaver->save($customSetting);

        /** Set data for the gb sales channel */
        $gbCustomSetting = $this->customSettingLoader->load(DemoDataIds::SALES_CHANNEL__GB_SHOP);
        $gbCustomSettingBackup = clone $gbCustomSetting;
        $gbCustomSetting->getRichSnippets()->getLocalBusiness()->getGeneral()
            ->setUrl('http://gbshop.shopware-dev.de/gb-shop')
            ->setTelephone('0255138');
        $gbCustomSetting->getRichSnippets()->getLocalBusiness()->getAddress()
            ->setPostalCode('48565');
        $gbCustomSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()
            ->getMonday()->setActive(false);
        $gbCustomSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()
            ->getTuesday()->setCloses('20:00');
        $gbCustomSetting->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()
            ->getWednesday()->setOpens('06:00');
        $this->customSettingSaver->save($gbCustomSetting, DemoDataIds::SALES_CHANNEL__GB_SHOP);

        /** Define the expected array */
        $expectedResult = [
            '@context' => 'https://schema.org',
            '@type' => 'LocalBusiness',
            'name' => 'Dreischild GmbH',
            'url' => 'http://gbshop.shopware-dev.de/gb-shop',
            'telephone' => '0255138',
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => 'Fasanenweg 35',
                'addressLocality' => 'Saarburg',
                'postalCode' => '48565',
                'addressCountry' => 'DE'
            ],
            'openingHoursSpecification' => [
                [
                    '@type' => 'OpeningHoursSpecification',
                    'dayOfWeek' => [
                        'Tuesday'
                    ],
                    'opens' => '10:00',
                    'closes' => '20:00'
                ],
                [
                    '@type' => 'OpeningHoursSpecification',
                    'dayOfWeek' => [
                        'Wednesday'
                    ],
                    'opens' => '06:00',
                    'closes' => '18:00'
                ],
                [
                    '@type' => 'OpeningHoursSpecification',
                    'dayOfWeek' => [
                        'Thursday',
                        'Friday',
                        'Saturday',
                        'Sunday',
                    ],
                    'opens' => '09:00',
                    'closes' => '18:00'
                ]
            ],
            'priceRange' => '€€€'
        ];

        /** Fetch the data again */
        $ldArray = $this->fetchLdArray('http://gbshop.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1007);

        /** Make sure that there is Organization key and has one entry */
        $this->assertArrayHasKey('LocalBusiness', $ldArray);
        $this->assertCount(1, $ldArray['LocalBusiness']);

        /** Check the details */
        $this->assertSame($expectedResult, $ldArray['LocalBusiness'][0]);

        /** Restore */
        $this->customSettingSaver->save($customSettingBackup);
        $this->customSettingSaver->save($gbCustomSettingBackup, DemoDataIds::SALES_CHANNEL__GB_SHOP);
    }

    private function fetchUrlResponse($url)
    {
        $browser = KernelLifecycleManager::createBrowser($this->getKernel());
        $browser->request(
            'GET',
            $url,
            []
        );

        return $browser->getResponse()->getContent();
    }

    private function fetchLdArray($url)
    {
        $browser = KernelLifecycleManager::createBrowser($this->getKernel());
        $ldResult = [];

        $browser->request(
            'GET',
            $url,
            []
        );

        $response = $browser->getResponse()->getContent();
        preg_match('/<script type="application\/ld\+json">([\s\S]*?)<\/script>/', $response, $ldJsonMatch);

        $this->assertNotEmpty($ldJsonMatch, 'Missing ld+json javascript snippet');

        $ldItems = json_decode($ldJsonMatch[1], true);
        foreach($ldItems as $ldItem) {
            $this->assertNotEmpty($ldItem['@type'], 'Missing @type entry for root element');
            $type = $ldItem['@type'];

            if(empty($ldResult[$type])) {
                $ldResult[$type] = [];
            }

            $ldResult[$type][] = $ldItem;
        }

        return $ldResult;
    }

    private function assertNoLdJsonData($url)
    {
        $ldResult = [];

        $browser = KernelLifecycleManager::createBrowser($this->getKernel());
        $browser->request(
            'GET',
            $url,
            []
        );

        $response = $browser->getResponse()->getContent();
        preg_match('/<script type="application\/ld\+json">([\s\S]*?)<\/script>/', $response, $ldJsonMatch);

        $this->assertEmpty($ldJsonMatch, 'There is a ld+json javascript snippet');
    }

    /**
     * @param string $productId
     * @param string $salesChannelId
     * @param string $customField
     * @param string $customFieldValue
     * @throws InconsistentCriteriaIdsException
     */
    private function setCustomFieldSetting(string $productId, string $salesChannelId, string $customField, ?string $customFieldValue)
    {
        /** Fetch the language id the sales channel */
        /** @var SalesChannelEntity $salesChannel */
        $salesChannel = $this->salesChannelRepository->search(new Criteria([ $salesChannelId ]))->first();
        if (null === $salesChannel) {
            throw new \RuntimeException('Invalid sales channel id: ' . $salesChannelId);
        }

        /** Create the context */
        $context = $this->contextFactory->createContext(
            (new ContextFactory\Struct\ContextStruct())
                ->setLanguageIdChain([ $salesChannel->getLanguageId() ])
        );

        /** Update the product */
        $this->productRepository->upsert([
            [
                'id' => $productId,
                'customFields' => [
                    $customField => $customFieldValue
                ]
            ]
        ], $context);
    }

    /**
     * @return MediaEntity|null
     */
    private function fetchRandomMediaEntity(): ?MediaEntity
    {
        return $this->mediaRepository->search(
            (new Criteria())->setLimit(1)
        )->first();
    }

    /**
     * @param string $seoPathInfo
     * @param string $salesChannelId
     * @param string $languageId
     * @return bool
     */
    private function isUrlSet(string $seoPathInfo, string $salesChannelId, string $languageId): bool
    {
        $entitySearchResult = $this->seoUrlRepository->search(
            (new Criteria())->addFilter(
                new MultiFilter(
                    MultiFilter::CONNECTION_AND,
                    [
                        new EqualsFilter(
                            'seoPathInfo',
                            $seoPathInfo
                        ),
                        new EqualsFilter(
                            'salesChannelId',
                            $salesChannelId
                        ),
                        new EqualsFilter(
                            'languageId',
                            $languageId
                        )
                    ]
                )
            )
        );

        return $entitySearchResult->count() >= 1;
    }
}
