<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Subscriber\Installment\Canonical;

use DreiscSeoPro\Core\Content\Product\ProductEnum;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Content\SalesChannel\SalesChannelRepository;
use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Foundation\Context\ContextFactory;
use DreiscSeoPro\Core\Foundation\Dal\EntityRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\MultiFilter;
use Shopware\Core\Framework\Test\TestCaseBase\AdminApiTestBehaviour;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Subscriber\Installment\Canonical\CanonicalSubscriber;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;

class CanonicalSubscriberTest extends TestCase
{
    use IntegrationTestBehaviour;
    use AdminApiTestBehaviour;

    /**
     * @var CanonicalSubscriber
     */
    private $canonicalSubscriber;

    /**
     * @var SalesChannelRepository
     */
    private $salesChannelRepository;

    /**
     * @var ContextFactory
     */
    private $contextFactory;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    protected function setUp(): void
    {
        $this->canonicalSubscriber = $this->getContainer()->get(CanonicalSubscriber::class);
        $this->salesChannelRepository = $this->getContainer()->get(SalesChannelRepository::class);
        $this->contextFactory = $this->getContainer()->get(ContextFactory::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_default_home(): void
    {
        $this->assertCanonicalLink(
            'http://www.shopware-dev.de',
            'http://www.shopware-dev.de/'
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_default_product(): void
    {
        $this->assertCanonicalLink(
            'http://www.shopware-dev.de/Mehreren-Kategorien-zugewiesen/SW-1004',
            'http://www.shopware-dev.de/Mehreren-Kategorien-zugewiesen/SW-1004'
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_default_category(): void
    {
        if ($this->isUrlSet('Produkte/', DemoDataIds::SALES_CHANNEL__MAIN_SHOP, $this->getDeDeLanguageId())) {
            $this->assertCanonicalLink(
                'http://www.shopware-dev.de/Produkte/',
                'http://www.shopware-dev.de/Produkte/'
            );
        } else {
            $this->assertCanonicalLink(
                'http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS,
                'http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__PRODUCTS
            );
        }
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_default_servicePage(): void
    {
        if ($this->isUrlSet('Shop-Service/Impressum/', DemoDataIds::SALES_CHANNEL__MAIN_SHOP, $this->getDeDeLanguageId())) {
            $this->assertCanonicalLink(
                'http://www.shopware-dev.de/Shop-Service/Impressum/',
                'http://www.shopware-dev.de/Shop-Service/Impressum/'
            );
        } else {
            $this->assertCanonicalLink(
                'http://www.shopware-dev.de/navigation/' . DemoDataIds::FOOTER_CATEGORY__MAIN_SHOP__SHOP_SERVICE__IMPRESSUM,
                'http://www.shopware-dev.de/navigation/' . DemoDataIds::FOOTER_CATEGORY__MAIN_SHOP__SHOP_SERVICE__IMPRESSUM
            );
        }

    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_product_externalUrl(): void
    {
        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1000,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_TYPE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => ProductEnum::CANONICAL_LINK_TYPE__EXTERNAL_URL
            ]
        );

        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1000,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_REFERENCE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => 'http://de.dreischild.com'
            ]
        );

        $this->assertCanonicalLink(
            'http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1000,
            'http://de.dreischild.com'
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_product_externalUrl_languageInherit(): void
    {
        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1001,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdEn(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_TYPE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => ProductEnum::CANONICAL_LINK_TYPE__EXTERNAL_URL
            ]
        );

        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1001,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdEn(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_REFERENCE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => 'http://inherit.from.en'
            ]
        );

        $this->assertCanonicalLink(
            'http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1001,
            'http://inherit.from.en'
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_product_externalUrl_considerInheritance(): void
    {
        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1006,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_TYPE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => ProductEnum::CANONICAL_LINK_TYPE__EXTERNAL_URL
            ]
        );

        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1006,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_REFERENCE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => 'http://inherit.from.main.product'
            ]
        );

        $this->assertCanonicalLink(
            'http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1006_2,
            'http://inherit.from.main.product'
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_product_productUrl(): void
    {
        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1000,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_TYPE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => ProductEnum::CANONICAL_LINK_TYPE__PRODUCT_URL
            ]
        );

        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1000,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_REFERENCE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => DemoDataIds::PRODUCT_SW_1006_2
            ]
        );

        $this->assertCanonicalLink(
            'http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1000,
            'http://www.shopware-dev.de/Varianten-Artikel/SW-1006.2'
        );
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_product_categoryUrl(): void
    {
        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1000,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_TYPE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => ProductEnum::CANONICAL_LINK_TYPE__CATEGORY_URL
            ]
        );

        $this->setCustomFieldSetting(
            $this->productRepository,
            DemoDataIds::PRODUCT_SW_1000,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $this->demoDataRepository->getLanguageIdDe(),
            ProductEnum::CUSTOM_FIELD__DREISC_SEO_CANONICAL_LINK_REFERENCE,
            [
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP => DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES
            ]
        );

        if ($this->isUrlSet('Spezielle-Kategorien/', DemoDataIds::SALES_CHANNEL__MAIN_SHOP, $this->getDeDeLanguageId())) {
            $this->assertCanonicalLink(
                'http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1000,
                'http://www.shopware-dev.de/Spezielle-Kategorien/'
            );
        } else {
            $this->assertCanonicalLink(
                'http://www.shopware-dev.de/detail/' . DemoDataIds::PRODUCT_SW_1000,

                'http://www.shopware-dev.de/navigation/' . DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES
            );
        }

    }

    /**
     * @param $url
     * @param $canonicalLink
     */
    private function assertCanonicalLink($url, $canonicalLink) {
        $this->getBrowser()->request(
            'GET',
            $url,
            []
        );

        $response = $this->getBrowser()->getResponse()->getContent();

        /** Make sure that the canonical link is set */
        $this->assertStringContainsString(
            '<link rel="canonical" href="' . $canonicalLink . '" />',
            $response
        );

        /** Make sure that there is exactly one link */
        preg_match_all(
            '/\<link rel="canonical"/m',
            $response,
            $canonicalLinkMatches
        );

        $this->assertArrayHasKey(0, $canonicalLinkMatches);
        $this->assertCount(1, $canonicalLinkMatches[0]);
    }

    private function setCustomFieldSetting(EntityRepository $entityRepository, string $referenceId, string $salesChannelId, string $languageId, string $customField, $customFieldValue)
    {
        /** Fetch the language id the sales channel */
        /** @var SalesChannelEntity $salesChannel */
        $salesChannel = $this->salesChannelRepository->search(new Criteria([ $salesChannelId ]))->first();
        if (null === $salesChannel) {
            throw new \RuntimeException('Invalid sales channel id: ' . $salesChannelId);
        }

        /** Create the context */
        $context = $this->contextFactory->createContext(
            (new ContextFactory\Struct\ContextStruct())
                ->setLanguageIdChain([ $languageId ])
        );

        /** Update the product */
        $entityRepository->upsert([
            [
                'id' => $referenceId,
                'customFields' => [
                    $customField => $customFieldValue
                ]
            ]
        ], $context);
    }

    /**
     * @param string $seoPathInfo
     * @param string $salesChannelId
     * @param string $languageId
     * @return bool
     */
    private function isUrlSet(string $seoPathInfo, string $salesChannelId, string $languageId): bool
    {
        $entitySearchResult = $this->seoUrlRepository->search(
            (new Criteria())->addFilter(
                new MultiFilter(
                    MultiFilter::CONNECTION_AND,
                    [
                        new EqualsFilter(
                            'seoPathInfo',
                            $seoPathInfo
                        ),
                        new EqualsFilter(
                            'salesChannelId',
                            $salesChannelId
                        ),
                        new EqualsFilter(
                            'languageId',
                            $languageId
                        )
                    ]
                )
            )
        );

        return $entitySearchResult->count() >= 1;
    }
}
