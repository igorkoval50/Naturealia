<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\CustomSetting;

use DreiscSeoPro\Core\CustomSetting\CustomSettingLoader;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\LocalBusiness\OpeningHoursSpecification\SpecificationStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Product\Offer\AvailabilityStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Product\Offer\ItemConditionStruct;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\CustomSetting\CustomSettingSaver;

class CustomSettingSaverTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var CustomSettingSaver
     */
    private $customSettingSaver;

    /**
     * @var CustomSettingLoader
     */
    private $customSettingLoader;

    protected function setUp(): void
    {
        $this->customSettingSaver = $this->getContainer()->get(CustomSettingSaver::class);
        $this->customSettingLoader = $this->getContainer()->get(CustomSettingLoader::class);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_save_customSettingStruct(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();
        $customSettingStructBackup =  clone $customSettingStruct;

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getProduct()->getOffer()->getSeller()->setName('Test company');
        $customSettingStruct->getMetaTags()->getMetaTitle()->getLengthConfig()->setRecommendedLengthEnd(50);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test the results */
        $this->assertSame($customSettingStruct->toArray(), $reloadedCustomSettingStruct->toArray());

        /** Restore */
        $this->customSettingSaver->save($customSettingStructBackup);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_metaTags_metaTitle_lengthConfig(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getMetaTags()->getMetaTitle()->getLengthConfig()->setRecommendedLengthStart(1);
        $customSettingStruct->getMetaTags()->getMetaTitle()->getLengthConfig()->setRecommendedLengthEnd(2);
        $customSettingStruct->getMetaTags()->getMetaTitle()->getLengthConfig()->setMaxLength(3);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'recommendedLengthStart' => 1,
            'recommendedLengthEnd' => 2,
            'maxLength' => 3
        ], $reloadedCustomSettingStruct->getMetaTags()->getMetaTitle()->getLengthConfig()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'metaTags' => [
                'metaTitle' => [
                    'lengthConfig' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'recommendedLengthStart' => 150,
            'recommendedLengthEnd' => 550,
            'maxLength' => 600
        ], $reloadedCustomSettingStruct->getMetaTags()->getMetaTitle()->getLengthConfig()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_metaTags_metaDescription_lengthConfig(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getMetaTags()->getMetaDescription()->getLengthConfig()->setRecommendedLengthStart(1);
        $customSettingStruct->getMetaTags()->getMetaDescription()->getLengthConfig()->setRecommendedLengthEnd(2);
        $customSettingStruct->getMetaTags()->getMetaDescription()->getLengthConfig()->setMaxLength(3);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'recommendedLengthStart' => 1,
            'recommendedLengthEnd' => 2,
            'maxLength' => 3
        ], $reloadedCustomSettingStruct->getMetaTags()->getMetaDescription()->getLengthConfig()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'metaTags' => [
                'metaDescription' => [
                    'lengthConfig' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'recommendedLengthStart' => 35,
            'recommendedLengthEnd' => 130,
            'maxLength' => 160
        ], $reloadedCustomSettingStruct->getMetaTags()->getMetaDescription()->getLengthConfig()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_metaTags_keywords_lengthConfig(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getMetaTags()->getKeywords()->getLengthConfig()->setRecommendedLengthStart(1);
        $customSettingStruct->getMetaTags()->getKeywords()->getLengthConfig()->setRecommendedLengthEnd(2);
        $customSettingStruct->getMetaTags()->getKeywords()->getLengthConfig()->setMaxLength(3);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'recommendedLengthStart' => 1,
            'recommendedLengthEnd' => 2,
            'maxLength' => 3
        ], $reloadedCustomSettingStruct->getMetaTags()->getKeywords()->getLengthConfig()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'metaTags' => [
                'keywords' => [
                    'lengthConfig' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'recommendedLengthStart' => 30,
            'recommendedLengthEnd' => 255,
            'maxLength' => 255
        ], $reloadedCustomSettingStruct->getMetaTags()->getKeywords()->getLengthConfig()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_metaTags_robotsTag(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getMetaTags()->getRobotsTag()
            ->setDefaultRobotsTagProduct('DEFAULT-PRODUCT')
            ->setDefaultRobotsTagCategory('DEFAULT-CATEGORY')
            ->setNoIndexRequestParameterConfig('myParam>40');

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultRobotsTagProduct' => 'DEFAULT-PRODUCT',
            'defaultRobotsTagCategory' => 'DEFAULT-CATEGORY',
            'noIndexRequestParameterConfig' => 'myParam>40'
        ], $reloadedCustomSettingStruct->getMetaTags()->getRobotsTag()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'metaTags' => [
                'robotsTag' => []
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultRobotsTagProduct' => 'index,follow',
            'defaultRobotsTagCategory' => 'index,follow',
            'noIndexRequestParameterConfig' => 'sort!=name-asc; p>1; properties; rating; min-price; max-price; manufacturer'
        ], $reloadedCustomSettingStruct->getMetaTags()->getRobotsTag()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_general(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getGeneral()->setActive(false);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'active' => false
        ], $reloadedCustomSettingStruct->getRichSnippets()->getGeneral()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'general' => []
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'active' => true
        ], $reloadedCustomSettingStruct->getRichSnippets()->getGeneral()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_product_general(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getProduct()->getGeneral()->setSkuCompilation('SKU_DEFAULT');
        $customSettingStruct->getRichSnippets()->getProduct()->getGeneral()->setMpnCompilation('MPN_DEFAULT');

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'skuCompilation' => 'SKU_DEFAULT',
            'mpnCompilation' => 'MPN_DEFAULT'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getGeneral()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'product' => [
                    'general' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'skuCompilation' => 'productNumber',
            'mpnCompilation' => 'manufacturerNumberOtherwiseProductNumber'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getGeneral()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_product_priceValidUntil(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getProduct()->getPriceValidUntil()->setInterval('TEST_INTERVAL');
        $customSettingStruct->getRichSnippets()->getProduct()->getPriceValidUntil()->setCustomDays(10);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'interval' => 'TEST_INTERVAL',
            'customDays' => 10
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getPriceValidUntil()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'product' => [
                    'priceValidUntil' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'interval' => 'today',
            'customDays' => 0
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getPriceValidUntil()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_product_offer_seller(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getProduct()->getOffer()->getSeller()->setName('shopware AG');

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'name' => 'shopware AG'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getOffer()->getSeller()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'product' => [
                    'offer' => [
                        'seller' => []
                    ]
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'name' => ''
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getOffer()->getSeller()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_product_offer_availability(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getProduct()->getOffer()->getAvailability()->setDefaultAvailability(AvailabilityStruct::AVAILABILITY__PRE_SALE);
        $customSettingStruct->getRichSnippets()->getProduct()->getOffer()->getAvailability()->setDefaultAvailabilityClearanceSale(AvailabilityStruct::AVAILABILITY__DISCONTINUED);
        $customSettingStruct->getRichSnippets()->getProduct()->getOffer()->getAvailability()->setDefaultAvailabilityClearanceSaleOutOfStock(AvailabilityStruct::AVAILABILITY__ONLINE_ONLY);
        $customSettingStruct->getRichSnippets()->getProduct()->getOffer()->getAvailability()->setDefaultAvailabilityOutOfStock(AvailabilityStruct::AVAILABILITY__IN_STOCK);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultAvailability' => 'PreSale',
            'defaultAvailabilityOutOfStock' => 'InStock',
            'defaultAvailabilityClearanceSale' => 'Discontinued',
            'defaultAvailabilityClearanceSaleOutOfStock' => 'OnlineOnly'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getOffer()->getAvailability()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'product' => [
                    'offer' => [
                        'availability' => []
                    ]
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultAvailability' => 'InStock',
            'defaultAvailabilityOutOfStock' => 'OutOfStock',
            'defaultAvailabilityClearanceSale' => 'LimitedAvailability',
            'defaultAvailabilityClearanceSaleOutOfStock' => 'SoldOut'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getOffer()->getAvailability()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_product_offer_itemCondition(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getProduct()->getOffer()->getItemCondition()->setDefaultItemCondition(
            ItemConditionStruct::ITEM_CONDITION__REFURBISHED_CONDITION
        );

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultItemCondition' => 'RefurbishedCondition'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getOffer()->getItemCondition()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'product' => [
                    'offer' => [
                        'itemCondition' => []
                    ]
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultItemCondition' => 'NewCondition'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getOffer()->getItemCondition()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_product_review_author(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getProduct()->getReview()->getAuthor()->setCompilation('TEST_COMPILATION');

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'compilation' => 'TEST_COMPILATION'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getReview()->getAuthor()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'product' => [
                    'review' => [
                        'author' => []
                    ]
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'compilation' => 'staticSnippet'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getProduct()->getReview()->getAuthor()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_breadcrumb_general(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getBreadcrumb()->getGeneral()->setActive(false);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'active' => false
        ], $reloadedCustomSettingStruct->getRichSnippets()->getBreadcrumb()->getGeneral()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'breadcrumb' => [
                    'general' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'active' => true
        ], $reloadedCustomSettingStruct->getRichSnippets()->getBreadcrumb()->getGeneral()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_breadcrumb_home(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getBreadcrumb()->getHome()->setShowInBreadcrumbMode('MY-BC-MODE');

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'showInBreadcrumbMode' => 'MY-BC-MODE'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getBreadcrumb()->getHome()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'breadcrumb' => [
                    'home' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'showInBreadcrumbMode' => 'notDisplay'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getBreadcrumb()->getHome()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_breadcrumb_product(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getBreadcrumb()->getProduct()->setShowInBreadcrumbMode('MY-PRODUCT_BC-MODE');

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'showInBreadcrumbMode' => 'MY-PRODUCT_BC-MODE'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getBreadcrumb()->getProduct()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'breadcrumb' => [
                    'product' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'showInBreadcrumbMode' => 'notDisplay'
        ], $reloadedCustomSettingStruct->getRichSnippets()->getBreadcrumb()->getProduct()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_localBusiness(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getLocalBusiness()
            ->getGeneral()
                ->setActive(true)
                ->setName('Dreischild GmbH')
                ->setUrl('https://de.dreischild.com')
                ->setTelephone('+49123456789');

        $customSettingStruct->getRichSnippets()->getLocalBusiness()
            ->getAddress()
                ->setStreetAddress('Fasanenweg 35')
                ->setAddressLocality('Saarburg')
                ->setPostalCode('54439')
                ->setAddressCountry('DE');

        $customSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getMonday()
            ->setActive(true)
            ->setOpens('11:30')
            ->setCloses('18:30');

        $customSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getTuesday()
            ->setActive(true)
            ->setOpens('09:30')
            ->setCloses('18:30');

        $customSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getWednesday()
            ->setActive(true)
            ->setOpens('07:00')
            ->setCloses('15:30');

        $customSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getThursday()
            ->setActive(true)
            ->setOpens('07:00')
            ->setCloses('15:30');

        $customSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getFriday()
            ->setActive(true)
            ->setOpens('07:00')
            ->setCloses('15:30');

        $customSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getSaturday()
            ->setActive(true)
            ->setOpens('07:00')
            ->setCloses('15:30');

        $customSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getSunday()
            ->setActive(true)
            ->setOpens('07:00')
            ->setCloses('15:30');

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'general' => [
                'active' => true,
                'name' => 'Dreischild GmbH',
                'url' => 'https://de.dreischild.com',
                'telephone' => '+49123456789'
            ],
            'address' => [
                'streetAddress' => 'Fasanenweg 35',
                'addressLocality' => 'Saarburg',
                'postalCode' => '54439',
                'addressCountry' => 'DE'
            ],
            'openingHoursSpecification' => [
                'monday' => [
                    'active' => true,
                    'opens' => '11:30',
                    'closes' => '18:30',
                ],
                'tuesday' => [
                    'active' => true,
                    'opens' => '09:30',
                    'closes' => '18:30',
                ],
                'wednesday' => [
                    'active' => true,
                    'opens' => '07:00',
                    'closes' => '15:30',
                ],
                'thursday' => [
                    'active' => true,
                    'opens' => '07:00',
                    'closes' => '15:30'
                ],
                'friday' => [
                    'active' => true,
                    'opens' => '07:00',
                    'closes' => '15:30'
                ],
                'saturday' => [
                    'active' => true,
                    'opens' => '07:00',
                    'closes' => '15:30'
                ],
                'sunday' => [
                    'active' => true,
                    'opens' => '07:00',
                    'closes' => '15:30'
                ]
            ]
        ], $reloadedCustomSettingStruct->getRichSnippets()->getLocalBusiness()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'localBusiness' => [
                    'general' => [],
                    'address' => [],
                    'openingHoursSpecification' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'general' => [
                'active' => false,
                'name' => '',
                'url' => '',
                'telephone' => ''
            ],
            'address' => [
                'streetAddress' => '',
                'addressLocality' => '',
                'postalCode' => '',
                'addressCountry' => ''
            ],
            'openingHoursSpecification' => [
                'monday' => [
                    'active' => false,
                    'opens' => '',
                    'closes' => '',
                ],
                'tuesday' => [
                    'active' => false,
                    'opens' => '',
                    'closes' => '',
                ],
                'wednesday' => [
                    'active' => false,
                    'opens' => '',
                    'closes' => '',
                ],
                'thursday' => [
                    'active' => false,
                    'opens' => '',
                    'closes' => ''
                ],
                'friday' => [
                    'active' => false,
                    'opens' => '',
                    'closes' => ''
                ],
                'saturday' => [
                    'active' => false,
                    'opens' => '',
                    'closes' => ''
                ],
                'sunday' => [
                    'active' => false,
                    'opens' => '',
                    'closes' => ''
                ]
            ]
        ], $reloadedCustomSettingStruct->getRichSnippets()->getLocalBusiness()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_richSnippets_logo(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getRichSnippets()->getLogo()
            ->getGeneral()
                ->setActive(true)
                ->setLogo('https://de.dreischild.com/logo.png')
                ->setUrl('https://de.dreischild.com');

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'general' => [
                'active' => true,
                'logo' => 'https://de.dreischild.com/logo.png',
                'url' => 'https://de.dreischild.com'
            ]
        ], $reloadedCustomSettingStruct->getRichSnippets()->getLogo()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'richSnippets' => [
                'logo' => [
                    'general' => []
                ]
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'general' => [
                'active' => false,
                'logo' => '',
                'url' => ''
            ]
        ], $reloadedCustomSettingStruct->getRichSnippets()->getLogo()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_seoUrl(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getSeoUrl()
            ->setDefaultSalesChannelId(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultSalesChannelId' => 'fe13aa4b47264e049b9bf84bd5e2a38a'
        ], $reloadedCustomSettingStruct->getSeoUrl()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'seoUrl' => []
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultSalesChannelId' => ''
        ], $reloadedCustomSettingStruct->getSeoUrl()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_serp(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Modify some data */
        $customSettingStruct->getSerp()
            ->setDefaultSalesChannelId(DemoDataIds::SALES_CHANNEL__GB_SHOP);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultSalesChannelId' => '4a8f660ce5a44fc9bd18c73ad3727b3b'
        ], $reloadedCustomSettingStruct->getSerp()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'serp' => []
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'defaultSalesChannelId' => ''
        ], $reloadedCustomSettingStruct->getSerp()->toArray());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_bulkGenerator_general(): void
    {
        /** Load the data via custom setting struct */
        $customSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'startGeneratorInTheStorageProcess' => true
        ], $customSettingStruct->getBulkGenerator()->getGeneral()->toArray());

        /** Modify some data */
        $customSettingStruct->getBulkGenerator()->getGeneral()->setStartGeneratorInTheStorageProcess(false);

        /** Save the struct */
        $this->customSettingSaver->save($customSettingStruct);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'startGeneratorInTheStorageProcess' => false
        ], $reloadedCustomSettingStruct->getBulkGenerator()->getGeneral()->toArray());

        /** Reset the data */
        $this->customSettingSaver->save([
            'bulkGenerator' => [
                'general' => []
            ]
        ]);

        /** Load the settings again */
        $reloadedCustomSettingStruct = $this->customSettingLoader->load();

        /** Test data */
        $this->assertSame([
            'startGeneratorInTheStorageProcess' => true
        ], $reloadedCustomSettingStruct->getBulkGenerator()->getGeneral()->toArray());
    }
}
