<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\CustomSetting;

use DreiscSeoPro\Core\CustomSetting\CustomSettingSaver;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\MetaTags\RobotsTagStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSetting\RichSnippets\Product\Offer\AvailabilityStruct;
use DreiscSeoPro\Core\CustomSetting\Struct\CustomSettingStruct;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\CustomSetting\CustomSettingLoader;

class CustomSettingLoaderTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var CustomSettingLoader
     */
    private $customSettingLoader;

    /**
     * @var CustomSettingSaver
     */
    private $customSettingSaver;

    protected function setUp(): void
    {
        $this->customSettingLoader = $this->getContainer()->get(CustomSettingLoader::class);
        $this->customSettingSaver = $this->getContainer()->get(CustomSettingSaver::class);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_load_default(): void
    {
        $customSettingStruct = $this->customSettingLoader->load();

        /** We expect the default values */
        $this->assertSame([
            'metaTags' => [
                'metaTitle' => [
                    'lengthConfig' =>[
                        'recommendedLengthStart' => 150,
                        'recommendedLengthEnd' => 550,
                        'maxLength' => 600
                    ]
                ],
                'metaDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 35,
                        'recommendedLengthEnd' => 130,
                        'maxLength' => 160
                    ]
                ],
                'keywords' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 30,
                        'recommendedLengthEnd' => 255,
                        'maxLength' => 255
                    ]
                ],
                'robotsTag' => [
                    'defaultRobotsTagProduct' => 'index,follow',
                    'defaultRobotsTagCategory' => 'index,follow',
                    'noIndexRequestParameterConfig' => 'sort!=name-asc; p>1; properties; rating; min-price; max-price; manufacturer'
                ]
            ],
            'socialMedia' => [
                'facebookTitle' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 10,
                        'recommendedLengthEnd' => 65,
                        'maxLength' => 70
                    ]
                ],
                'facebookDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 10,
                        'recommendedLengthEnd' => 65,
                        'maxLength' => 70
                    ]
                ],
                'twitterTitle' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 10,
                        'recommendedLengthEnd' => 35,
                        'maxLength' => 40
                    ]
                ],
                'twitterDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 10,
                        'recommendedLengthEnd' => 110,
                        'maxLength' => 120
                    ]
                ]
            ],
            'richSnippets' => [
                'general' => [
                    'active' => true,
                ],
                'product' => [
                    'general' => [
                        'skuCompilation' => 'productNumber',
                        'mpnCompilation' => 'manufacturerNumberOtherwiseProductNumber'
                    ],
                    'offer' => [
                        'seller' => [
                            'name' => ''
                        ],
                        'availability' => [
                            'defaultAvailability' => 'InStock',
                            'defaultAvailabilityOutOfStock' => 'OutOfStock',
                            'defaultAvailabilityClearanceSale' => 'LimitedAvailability',
                            'defaultAvailabilityClearanceSaleOutOfStock' => 'SoldOut'
                        ],
                        'itemCondition' => [
                            'defaultItemCondition' => 'NewCondition'
                        ]
                    ],
                    'priceValidUntil' =>  [
                        'interval' => 'today',
                        'customDays' => 0
                    ],
                    'review' => [
                        'author' => [
                            'compilation' => 'staticSnippet'
                        ]
                    ]
                ],
                'breadcrumb' => [
                    'general' => [
                        'active' => true
                    ],
                    'home' => [
                        'showInBreadcrumbMode' => 'notDisplay'
                    ],
                    'product' => [
                        'showInBreadcrumbMode' => 'notDisplay'
                    ]
                ],
                'logo' => [
                    'general' => [
                        'active' => false,
                        'logo' => '',
                        'url' => ''
                    ]
                ],
                'localBusiness' => [
                    'general' => [
                        'active' => false,
                        'name' => '',
                        'url' => '',
                        'telephone' => ''
                    ],
                    'address' => [
                        'streetAddress' => '',
                        'addressLocality' => '',
                        'postalCode' => '',
                        'addressCountry' => ''
                    ],
                    'openingHoursSpecification' => [
                        'monday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'tuesday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'wednesday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'thursday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'friday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'saturday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'sunday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ]
                    ]
                ]
            ],
            'seoUrl' => [
                'defaultSalesChannelId' => ''
            ],
            'serp' => [
                'defaultSalesChannelId' => ''
            ],
            'bulkGenerator' => [
                'general' => [
                    'startGeneratorInTheStorageProcess' => true
                ]
            ]
        ], $customSettingStruct->toArray());

        /** Test the struct */
        $this->assertSame(600, $customSettingStruct->getMetaTags()->getMetaTitle()->getLengthConfig()->getMaxLength());
        $this->assertTrue($customSettingStruct->getRichSnippets()->getGeneral()->isActive());
        $this->assertSame('', $customSettingStruct->getRichSnippets()->getProduct()->getOffer()->getSeller()->getName());
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_load_salesChannel(): void
    {
        $customSettingStruct = $this->customSettingLoader->load(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        /** We expect the default values */
        $this->assertSame([
            'metaTags' => [
                'metaTitle' => [
                    'lengthConfig' =>[
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'metaDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'keywords' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'robotsTag' => [
                    'defaultRobotsTagProduct' => null,
                    'defaultRobotsTagCategory' => null,
                    'noIndexRequestParameterConfig' => null
                ]
            ],
            'socialMedia' => [
                'facebookTitle' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'facebookDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'twitterTitle' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'twitterDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ]
            ],
            'richSnippets' => [
                'general' => [
                    'active' => null,
                ],
                'product' => [
                    'general' => [
                        'skuCompilation' => null,
                        'mpnCompilation' => null
                    ],
                    'offer' => [
                        'seller' => [
                            'name' => null
                        ],
                        'availability' => [
                            'defaultAvailability' => null,
                            'defaultAvailabilityOutOfStock' => null,
                            'defaultAvailabilityClearanceSale' => null,
                            'defaultAvailabilityClearanceSaleOutOfStock' => null
                        ],
                        'itemCondition' => [
                            'defaultItemCondition' => null
                        ]
                    ],
                    'priceValidUntil' =>  [
                        'interval' => null,
                        'customDays' => null
                    ],
                    'review' => [
                        'author' => [
                            'compilation' => null
                        ]
                    ]
                ],
                'breadcrumb' => [
                    'general' => [
                        'active' => null
                    ],
                    'home' => [
                        'showInBreadcrumbMode' => null
                    ],
                    'product' => [
                        'showInBreadcrumbMode' => null
                    ]
                ],
                'logo' => [
                    'general' => [
                        'active' => null,
                        'logo' => null,
                        'url' => null
                    ]
                ],
                'localBusiness' => [
                    'general' => [
                        'active' => null,
                        'name' => null,
                        'url' => null,
                        'telephone' => null
                    ],
                    'address' => [
                        'streetAddress' => null,
                        'addressLocality' => null,
                        'postalCode' => null,
                        'addressCountry' => null
                    ],
                    'openingHoursSpecification' => [
                        'monday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'tuesday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'wednesday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'thursday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'friday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'saturday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'sunday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ]
                    ]
                ]
            ],
            'seoUrl' => [
                'defaultSalesChannelId' => null
            ],
            'serp' => [
                'defaultSalesChannelId' => null
            ],
            'bulkGenerator' => [
                'general' => [
                    'startGeneratorInTheStorageProcess' => null
                ]
            ]
        ], $customSettingStruct->toArray());

        /** Test the struct */
        $this->assertNull($customSettingStruct->getMetaTags()->getMetaTitle()->getLengthConfig()->getMaxLength());
        $this->assertNull($customSettingStruct->getRichSnippets()->getGeneral()->isActive());
        $this->assertNull($customSettingStruct->getRichSnippets()->getProduct()->getOffer()->getSeller()->getName());
    }


    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     * @throws InconsistentCriteriaIdsException
     */
    public function test_load_salesChannel_merged(): void
    {
        /** Load for default */
        $defaultCustomSettingStruct = $this->customSettingLoader->load();
        $defaultCustomSettingStruct->getRichSnippets()->getLocalBusiness()->getAddress()->setAddressLocality('DEFAULT-Saarburg');
        $defaultCustomSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getMonday()->setActive(true);
        $defaultCustomSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getFriday()->setOpens('10:30');
        $defaultCustomSettingStruct->getRichSnippets()->getProduct()->getOffer()->setAvailability(new AvailabilityStruct(
            null,
            'DEFAULT-AV',
            null,
            null,
            CustomSettingStruct::SETTING_CONTEXT__DEFAULT
        ));
        $defaultCustomSettingStruct->getSocialMedia()->getFacebookTitle()->getLengthConfig()->setMaxLength(1000);
        $defaultCustomSettingStruct->getSocialMedia()->getFacebookDescription()->getLengthConfig()->setMaxLength(100);
        $defaultCustomSettingStruct->getSocialMedia()->getTwitterTitle()->getLengthConfig()->setMaxLength(2000);
        $defaultCustomSettingStruct->getSocialMedia()->getTwitterDescription()->getLengthConfig()->setMaxLength(200);

        /** Save the default changes */
        $this->customSettingSaver->save($defaultCustomSettingStruct);

        /** Load for the sales channel */
        $salesChannelCustomSettingStruct = $this->customSettingLoader->load(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        /** Set same settings for the sales channel */
        $salesChannelCustomSettingStruct->getRichSnippets()->getLocalBusiness()->getAddress()->setPostalCode('SALES-CHANNEL-54439');
        $salesChannelCustomSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getMonday()->setOpens('17:00');
        $salesChannelCustomSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getMonday()->setCloses('22:00');
        $salesChannelCustomSettingStruct->getRichSnippets()->getLocalBusiness()->getOpeningHoursSpecification()->getSaturday()->setActive(true);
        $salesChannelCustomSettingStruct->getRichSnippets()->getProduct()->getOffer()->setAvailability(new AvailabilityStruct(
            'SALES-CHANNEL-AV',
            null,
            null,
            null,
            CustomSettingStruct::SETTING_CONTEXT__DEFAULT
        ));
        $salesChannelCustomSettingStruct->getMetaTags()->getRobotsTag()
            ->setDefaultRobotsTagProduct(RobotsTagStruct::ROBOTS_TAG__NOINDEX_NOFOLLOW);
        $salesChannelCustomSettingStruct->getSeoUrl()
            ->setDefaultSalesChannelId(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);
        $salesChannelCustomSettingStruct->getSerp()
            ->setDefaultSalesChannelId(DemoDataIds::SALES_CHANNEL__GB_SHOP);

        /** Save settings for the sales channel */
        $this->customSettingSaver->save($salesChannelCustomSettingStruct, DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        /** Load the settings for the sales channel again */
        $salesChannelCustomSettingStruct = $this->customSettingLoader->load(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        /** We expect only the sales channel values */
        $this->assertSame([
            'metaTags' => [
                'metaTitle' => [
                    'lengthConfig' =>[
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'metaDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'keywords' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'robotsTag' => [
                    'defaultRobotsTagProduct' => 'noindex,nofollow',
                    'defaultRobotsTagCategory' => null,
                    'noIndexRequestParameterConfig' => null
                ]
            ],
            'socialMedia' => [
                'facebookTitle' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'facebookDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'twitterTitle' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ],
                'twitterDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => null,
                        'recommendedLengthEnd' => null,
                        'maxLength' => null
                    ]
                ]
            ],
            'richSnippets' => [
                'general' => [
                    'active' => null,
                ],
                'product' => [
                    'general' => [
                        'skuCompilation' => null,
                        'mpnCompilation' => null
                    ],
                    'offer' => [
                        'seller' => [
                            'name' => null
                        ],
                        'availability' => [
                            'defaultAvailability' => 'SALES-CHANNEL-AV',
                            'defaultAvailabilityOutOfStock' => null,
                            'defaultAvailabilityClearanceSale' => null,
                            'defaultAvailabilityClearanceSaleOutOfStock' => null
                        ],
                        'itemCondition' => [
                            'defaultItemCondition' => null
                        ]
                    ],
                    'priceValidUntil' =>  [
                        'interval' => null,
                        'customDays' => null
                    ],
                    'review' => [
                        'author' => [
                            'compilation' => null
                        ]
                    ]
                ],
                'breadcrumb' => [
                    'general' => [
                        'active' => null
                    ],
                    'home' => [
                        'showInBreadcrumbMode' => null
                    ],
                    'product' => [
                        'showInBreadcrumbMode' => null
                    ]
                ],
                'logo' => [
                    'general' => [
                        'active' => null,
                        'logo' => null,
                        'url' => null
                    ]
                ],
                'localBusiness' => [
                    'general' => [
                        'active' => null,
                        'name' => null,
                        'url' => null,
                        'telephone' => null
                    ],
                    'address' => [
                        'streetAddress' => null,
                        'addressLocality' => null,
                        'postalCode' => 'SALES-CHANNEL-54439',
                        'addressCountry' => null
                    ],
                    'openingHoursSpecification' => [
                        'monday' => [
                            'active' => null,
                            'opens' => '17:00',
                            'closes' => '22:00'
                        ],
                        'tuesday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'wednesday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'thursday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'friday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ],
                        'saturday' => [
                            'active' => true,
                            'opens' => null,
                            'closes' => null
                        ],
                        'sunday' => [
                            'active' => null,
                            'opens' => null,
                            'closes' => null
                        ]
                    ]
                ]
            ],
            'seoUrl' => [
                'defaultSalesChannelId' => 'fe13aa4b47264e049b9bf84bd5e2a38a'
            ],
            'serp' => [
                'defaultSalesChannelId' => '4a8f660ce5a44fc9bd18c73ad3727b3b'
            ],
            'bulkGenerator' => [
                'general' => [
                    'startGeneratorInTheStorageProcess' => null
                ]
            ]
        ], $salesChannelCustomSettingStruct->toArray());

        /** Load the data again merged */
        $mergedCustomSettingStruct = $this->customSettingLoader->load(DemoDataIds::SALES_CHANNEL__MAIN_SHOP, true);

        /** We expect the default values */
        $this->assertSame([
            'metaTags' => [
                'metaTitle' => [
                    'lengthConfig' =>[
                        'recommendedLengthStart' => 150,
                        'recommendedLengthEnd' => 550,
                        'maxLength' => 600
                    ]
                ],
                'metaDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 35,
                        'recommendedLengthEnd' => 130,
                        'maxLength' => 160
                    ]
                ],
                'keywords' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 30,
                        'recommendedLengthEnd' => 255,
                        'maxLength' => 255
                    ]
                ],
                'robotsTag' => [
                    'defaultRobotsTagProduct' => 'noindex,nofollow',
                    'defaultRobotsTagCategory' => 'index,follow',
                    'noIndexRequestParameterConfig' => 'sort!=name-asc; p>1; properties; rating; min-price; max-price; manufacturer'
                ]
            ],
            'socialMedia' => [
                'facebookTitle' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 10,
                        'recommendedLengthEnd' => 65,
                        'maxLength' => 1000
                    ]
                ],
                'facebookDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 10,
                        'recommendedLengthEnd' => 65,
                        'maxLength' => 100
                    ]
                ],
                'twitterTitle' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 10,
                        'recommendedLengthEnd' => 35,
                        'maxLength' => 2000
                    ]
                ],
                'twitterDescription' => [
                    'lengthConfig' => [
                        'recommendedLengthStart' => 10,
                        'recommendedLengthEnd' => 110,
                        'maxLength' => 200
                    ]
                ]
            ],
            'richSnippets' => [
                'general' => [
                    'active' => true,
                ],
                'product' => [
                    'general' => [
                        'skuCompilation' => 'productNumber',
                        'mpnCompilation' => 'manufacturerNumberOtherwiseProductNumber'
                    ],
                    'offer' => [
                        'seller' => [
                            'name' => ''
                        ],
                        'availability' => [
                            'defaultAvailability' => 'SALES-CHANNEL-AV',
                            'defaultAvailabilityOutOfStock' => 'DEFAULT-AV',
                            'defaultAvailabilityClearanceSale' => 'LimitedAvailability',
                            'defaultAvailabilityClearanceSaleOutOfStock' => 'SoldOut'
                        ],
                        'itemCondition' => [
                            'defaultItemCondition' => 'NewCondition'
                        ]
                    ],
                    'priceValidUntil' =>  [
                        'interval' => 'today',
                        'customDays' => 0
                    ],
                    'review' => [
                        'author' => [
                            'compilation' => 'staticSnippet'
                        ]
                    ]
                ],
                'breadcrumb' => [
                    'general' => [
                        'active' => true
                    ],
                    'home' => [
                        'showInBreadcrumbMode' => 'notDisplay'
                    ],
                    'product' => [
                        'showInBreadcrumbMode' => 'notDisplay'
                    ]
                ],
                'logo' => [
                    'general' => [
                        'active' => false,
                        'logo' => '',
                        'url' => ''
                    ]
                ],
                'localBusiness' => [
                    'general' => [
                        'active' => false,
                        'name' => '',
                        'url' => '',
                        'telephone' => ''
                    ],
                    'address' => [
                        'streetAddress' => '',
                        'addressLocality' => 'DEFAULT-Saarburg',
                        'postalCode' => 'SALES-CHANNEL-54439',
                        'addressCountry' => ''
                    ],
                    'openingHoursSpecification' => [
                        'monday' => [
                            'active' => true,
                            'opens' => '17:00',
                            'closes' => '22:00'
                        ],
                        'tuesday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'wednesday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'thursday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'friday' => [
                            'active' => false,
                            'opens' => '10:30',
                            'closes' => ''
                        ],
                        'saturday' => [
                            'active' => true,
                            'opens' => '',
                            'closes' => ''
                        ],
                        'sunday' => [
                            'active' => false,
                            'opens' => '',
                            'closes' => ''
                        ]
                    ]
                ]
            ],
            'seoUrl' => [
                'defaultSalesChannelId' => 'fe13aa4b47264e049b9bf84bd5e2a38a'
            ],
            'serp' => [
                'defaultSalesChannelId' => '4a8f660ce5a44fc9bd18c73ad3727b3b'
            ],
            'bulkGenerator' => [
                'general' => [
                    'startGeneratorInTheStorageProcess' => true
                ]
            ]
        ], $mergedCustomSettingStruct->toArray());

        /** Test the struct */
        $this->assertNull($salesChannelCustomSettingStruct->getMetaTags()->getMetaTitle()->getLengthConfig()->getMaxLength());
        $this->assertNull($salesChannelCustomSettingStruct->getRichSnippets()->getGeneral()->isActive());
        $this->assertNull($salesChannelCustomSettingStruct->getRichSnippets()->getProduct()->getOffer()->getSeller()->getName());
    }
}
