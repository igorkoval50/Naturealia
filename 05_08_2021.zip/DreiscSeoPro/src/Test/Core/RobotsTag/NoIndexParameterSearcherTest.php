<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\RobotsTag;

use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\RobotsTag\NoIndexParameterSearcher;

class NoIndexParameterSearcherTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var NoIndexParameterSearcher
     */
    private $noIndexParameterSearcher;

    protected function setUp(): void
    {
        $this->noIndexParameterSearcher = $this->getContainer()->get(NoIndexParameterSearcher::class);
    }

    public function test_falseIfEmptyNoIndexParameterConfigString(): void
    {
        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                '',
                [
                    'no-aggregations' => '1',
                    'px' => '1',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_falseIfNoParams(): void
    {
        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p,otherKey',
                []
            )
        );
    }

    public function test_noMatch(): void
    {
        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'px' => '1',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_paramWithoutValue(): void
    {
        /** We test for the 'p' parameter with has also a space */
        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'p' => '1',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_equalInt(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer= 24; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => "24",
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer= 50; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '24',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_equalFloat(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer= 24.34; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '24.34',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer= 24.34; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '24.85',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_equalString(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer= test; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => 'test',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer= test; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => 'TEST',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer= test2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => 'TEST',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_notEqualInt(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer!= 24; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '24',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer!= 50; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '24',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_notEqualFloat(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer!= 24.34; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '24.34',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer!= 24.34; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '24.85',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_notEqualString(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer!= test; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => 'test',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer!= test; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => 'TEST',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer!= test2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => 'TEST',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_largerThanInt(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer > 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '4',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer > 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '2',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_largerThanFloat(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer > 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '2.01',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer > 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '1.95',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_smallerThanInt(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer < 0; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '-5',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer < 0; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '0',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_smallerThanFloat(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer < 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer < 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '40',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_smallerThanEqual(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer <= 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer <= 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '2',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer <= 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '3',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }

    public function test_largerThanEqual(): void
    {
        /** We test for the 'integer' parameter with has also a space */
        $this->assertFalse(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer >= 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer >= 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '2',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );

        $this->assertTrue(
            $this->noIndexParameterSearcher->hasNoIndexParameter(
                'p ;otherKey=test;;integer >= 2; thirtKey>2;',
                [
                    'no-aggregations' => '1',
                    'integer' => '3',
                    'slots' => '9c3d602528d74e1f9b02c56928f928d4',
                    'sort' => 'name-desc'
                ]
            )
        );
    }
}
