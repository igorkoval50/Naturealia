<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\BulkGenerator;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Core\BulkGenerator\TemplateGenerator\Exception\ReferenceEntityNotFoundException;
use DreiscSeoPro\Core\BulkGenerator\TemplateGenerator\Struct\TemplateGeneratorStruct;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\CustomField\Aggregate\CustomFieldSet\CustomFieldSetRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Foundation\Context\ContextFactory;
use DreiscSeoPro\Core\Foundation\Context\LanguageChainFactory;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Seo\SeoDataSaver\CategorySeoDataSaver;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Struct\SeoDataSaverStruct;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\BulkGenerator\CategoryTemplateGenerator;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\CustomField\CustomFieldTypes;

class CategoryTemplateGeneratorTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var CategoryTemplateGenerator
     */
    private $categoryTemplateGenerator;

    /**
     * @var CustomFieldSetRepository
     */
    private $customFieldSetRepository;

    /**
     * @var ContextFactory
     */
    private $contextFactory;

    /**
     * @var LanguageChainFactory
     */
    private $languageChainFactory;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var CategorySeoDataSaver
     */
    private $categorySeoDataSaver;

    protected function setUp(): void
    {
        $this->categoryTemplateGenerator = $this->getContainer()->get(CategoryTemplateGenerator::class);
        $this->customFieldSetRepository = $this->getContainer()->get(CustomFieldSetRepository::class);
        $this->contextFactory = $this->getContainer()->get(ContextFactory::class);
        $this->languageChainFactory = $this->getContainer()->get(LanguageChainFactory::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
        $this->categorySeoDataSaver = $this->getContainer()->get(CategorySeoDataSaver::class);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     */
    public function test_generateTemplate_metaTitle_categoryName(): void
    {
        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy();

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            '> {{ category.translated.name }}'
        );

        $this->assertSame('> Standard-Produkte', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_metaTitle_parent(): void
    {
        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy();

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            '{{ category.translated.name }}»{{ category.parent.translated.name }}'
        );

        $this->assertSame('Standard-Produkte»Produkte', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_metaTitle_parentCategories(): void
    {
        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy();

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            '{{ category.translated.name }}{% for parentCategory in parentCategories %}»{{ parentCategory.translated.name }}{% endfor %}'
        );

        $this->assertSame('Standard-Produkte»Produkte»Hauptnavigation»Mainshop', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_metaTitle_childCategories(): void
    {
        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy();

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            '#{% for childCategory in childCategories %}»{{ childCategory.translated.name }}{% endfor %}'
        );

        $this->assertSame('#', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_metaTitle_childCategories_withValidCategory(): void
    {
        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DemoDataIds::CATEGORY__GBSHOP__PRODUCTS
        );

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            '{% for childCategory in childCategories %}»{{ childCategory.translated.name }}{% endfor %}'
        );

        $this->assertSame('»Standard-Produkte»GB-Produkte', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_metaTitle_categoryNameAndShippingFreeText(): void
    {
        $template = '{% set metaTitle = [] %}
                    {% set metaTitle = metaTitle|merge([category.translated.name]) %}
                    {% if \'de-DE\' == language.locale.code %}
                        {% set metaTitle = metaTitle|merge([\'versandkostenfrei\']) %}
                    {% else %}
                        {% set metaTitle = metaTitle|merge([\'free shipping\']) %}
                    {% endif %}
                    {{ metaTitle|join(\' \') }}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DemoDataIds::CATEGORY__GBSHOP__PRODUCTS
        );

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('Produkte versandkostenfrei', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_metaTitle_customFieldIfExistOtherwiseCategoryName(): void
    {
        $template = '{% if category.customFields.custom_myset_mytestfield is defined %}
                        {{ category.customFields.custom_myset_mytestfield }}
                    {% else %}
                        {{ category.translated.name }}
                    {% endif %}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DemoDataIds::CATEGORY__GBSHOP__PRODUCTS
        );

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('Produkte', $renderedTemplate);

        /** Now we create the field "custom_mytestfield" */
        $this->customFieldSetRepository->upsert([
            [
                'id' => Uuid::randomHex(),
                'name' => 'custom_myset',
                'config' => [
                    'label' => [
                        'en-GB' => 'My test set',
                    ],
                ],
                'relations' => [
                    [
                        'id' => Uuid::randomHex(),
                        'entityName' => 'category'
                    ]
                ],
                'customFields' => [
                    [
                        'id' => Uuid::randomHex(),
                        'name' => 'custom_myset_mytestfield',
                        'type' => CustomFieldTypes::TEXT,
                        'config' => [
                            'componentName' => 'sw-field',
                            'type' => 'text',
                            'customFieldType' => 'text',
                            'label' => [
                                'en-GB' => 'My test field',
                            ],
                            'placeholder' => [
                                'en-GB' => 'Type a text...',
                            ],
                            'customFieldPosition' => 1,
                        ],
                    ]
                ]
            ]
        ]);

        /** Create the "de-DE" context */
        $languageChain = $this->languageChainFactory->getLanguageIdChain($templateGeneratorStruct->getLanguageId());
        $deContext = $this->contextFactory->createContext(
            (new ContextFactory\Struct\ContextStruct())
                ->setLanguageIdChain($languageChain)
        );

        /** Update the custom field of the product */
        $this->categoryRepository->update([
            [
                'id' => $templateGeneratorStruct->getReferenceId(),
                'customFields' => [
                    'custom_myset_mytestfield' => 'This is my custom field value'
                ]
            ]
        ], $deContext);

        /** Run generator again */
        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('This is my custom field value', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_url_parentCategoryUrlAndCategoryName(): void
    {
        $template = '{% set url = [] %}
                    {% if categoryParentSeo is defined and null != categoryParentSeo.url %}
                        {% set categoryParentUrl = categoryParentSeo.url|rtrim(\'/\') %}
                        {% set url = url|merge([categoryParentUrl]) %}
                    {% endif %}
                    {% set url = url|merge([category.translated.name]) %}
                    {{ url|join(\'/\') }}';

        /**
         * At first we test it with a root category
         */

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            null,
            null,
            DreiscSeoBulkEnum::SEO_OPTION__URL
        );

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('hauptnavigation', $renderedTemplate);

        /**
         * Now we test with a category which has a parent category
         */

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES__WITHOUT_DE_TRANSLATION,
            null,
            null,
            DreiscSeoBulkEnum::SEO_OPTION__URL
        );

        /** We set a url for the parent category */
        $this->categorySeoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES,
                DreiscSeoBulkEnum::SEO_OPTION__URL,
                $templateGeneratorStruct->getLanguageId(),
                $templateGeneratorStruct->getSalesChannelId(),
                'test parent url',
                true
            )
        ]);

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('test-parent-url/without-de-translation', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_url_metaTitleIfAvailableOrCategoryName(): void
    {
        $template = '{% if categorySeo.metaTitle %}
                        {{ categorySeo.metaTitle}}
                    {% else %}
                        {{ category.translated.name }}
                    {% endif %}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES,
            null,
            null,
            DreiscSeoBulkEnum::SEO_OPTION__URL
        );

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('spezielle-kategorien', $renderedTemplate);

        /**
         * Now we set a meta title and test again
         */

        /** We set a url for the parent category */
        $this->categorySeoDataSaver->save([
            new SeoDataSaverStruct(
                $templateGeneratorStruct->getArea(),
                $templateGeneratorStruct->getReferenceId(),
                DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                $templateGeneratorStruct->getLanguageId(),
                $templateGeneratorStruct->getSalesChannelId(),
                'Mein Test Meta Titel',
                true
            )
        ]);

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('mein-test-meta-titel', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_metaDescription_trimmedCategoryDescription(): void
    {
        $template = '{% set maxLength = 130 %}
                    {% if category.translated.description|length > maxLength %}
                        {{ category.translated.description|slice(0, maxLength-3) ~ \'...\' }}
                    {% else %}
                        {{ category.translated.description }}
                    {% endif %}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            null,
            DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION
        );

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('Beschreibung der Kategorie: 3fa301fbf6a043d6b90e45d6a28e89d7', $renderedTemplate);

        /** Now we update the description and test again */
        $loremText = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam volu';
        $this->categoryRepository->update([
            [
                'id' => $templateGeneratorStruct->getReferenceId(),
                'description' => [
                    $templateGeneratorStruct->getLanguageId() => $loremText
                ]
            ]
        ]);

        $renderedTemplate = $this->categoryTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** We except the new value */
        $this->assertSame('Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliqu...', $renderedTemplate);
    }

    /**
     * @param string|null $categoryId
     * @param string|null $salesChannelId
     * @param bool|null $spaceless
     * @param string|null $seoOption
     * @return TemplateGeneratorStruct
     */
    private function getTemplateGeneratorStructDummy(string $categoryId = null, string $salesChannelId = null, bool $spaceless = null, string $seoOption = null): TemplateGeneratorStruct
    {
        return new TemplateGeneratorStruct(
            DreiscSeoBulkEnum::AREA__CATEGORY,
            $categoryId ?? DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            $seoOption ?? DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            $this->getDeDeLanguageId(),
            $salesChannelId,
            $spaceless ?? true
        );
    }
}
