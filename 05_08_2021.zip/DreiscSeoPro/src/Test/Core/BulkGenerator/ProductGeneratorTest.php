<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\BulkGenerator;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Core\BulkGenerator\TemplateGenerator\Exception\ReferenceEntityNotFoundException;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkRepository;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Foundation\Context\ContextFactory;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\ProductSeoDataFetcher;
use DreiscSeoPro\Core\Seo\SeoDataSaver;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\BulkGenerator\ProductGenerator;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;
use Shopware\Core\Framework\Uuid\Uuid;
use Symfony\Component\Console\Tester\CommandTester;

class ProductGeneratorTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var ProductGenerator
     */
    private $productGenerator;

    /**
     * @var DreiscSeoBulkRepository
     */
    private $dreiscSeoBulkRepository;

    /**
     * @var DreiscSeoBulkTemplateRepository
     */
    private $dreiscSeoBulkTemplateRepository;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var ProductSeoDataFetcher
     */
    private $productSeoDataFetcher;

    /**
     * @var SeoDataSaver
     */
    private $seoDataSaver;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var ContextFactory
     */
    private $contextFactory;

    protected function setUp(): void
    {
        $this->productGenerator = $this->getContainer()->get(ProductGenerator::class);
        $this->dreiscSeoBulkRepository = $this->getContainer()->get(DreiscSeoBulkRepository::class);
        $this->dreiscSeoBulkTemplateRepository = $this->getContainer()->get(DreiscSeoBulkTemplateRepository::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->productSeoDataFetcher = $this->getContainer()->get(ProductSeoDataFetcher::class);
        $this->seoDataSaver = $this->getContainer()->get(SeoDataSaver::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->contextFactory = $this->getContainer()->get(ContextFactory::class);
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_seoBulkPriority(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $firstCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $secondCategoryId = DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        /** Create the first template */
        $firstDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE)
            ->setName('My Bulk Template')
            ->setTemplate('{{ product.translated.name }} - {{ product.productNumber }} FIRST');

        $this->dreiscSeoBulkTemplateRepository->create([ $firstDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($firstCategoryId)
            ->setPriority(10)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE)
            ->setDreiscSeoBulkTemplateId($firstDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Create the second template */
        $secondDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE)
            ->setName('My Bulk Template')
            ->setTemplate('{{ product.translated.name }} - {{ product.productNumber }} SECOND');

        $this->dreiscSeoBulkTemplateRepository->create([ $secondDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "GB Shop » Products » Standard-Products" */
        $secondDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($secondCategoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE)
            ->setDreiscSeoBulkTemplateId($secondDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $secondDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** We except the first entry, because the priority is 10 */
        $this->assertSame('Standard Produkt 1000 - SW-1000 FIRST', $seoDataFetchResultStruct->getMetaTitle());

        /** Update the priority of the second entity to 20 */
        $this->dreiscSeoBulkRepository->update([
            [
                DreiscSeoBulkEntity::ID__PROPERTY_NAME => $secondDreiscSeoBulkEntity->getId(),
                DreiscSeoBulkEntity::PRIORITY__PROPERTY_NAME => 20
            ]
        ]);

        /** Run the generator again **/
        $this->productGenerator->generate([ $productId ]);

        /** Check the value again */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** Now we except the second entry, because the priority is 20 */
        $this->assertSame('Standard Produkt 1000 - SW-1000 SECOND', $seoDataFetchResultStruct->getMetaTitle());
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_seoBulkPriorityForUrl(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $firstCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $secondCategoryId = DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        /** Create the first template */
        $firstDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__URL)
            ->setName('My Bulk Template')
            ->setTemplate('{{ product.translated.name }} - {{ product.productNumber }} FIRST');

        $this->dreiscSeoBulkTemplateRepository->create([ $firstDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($firstCategoryId)
            ->setPriority(10)
            ->setSalesChannelId(DemoDataIds::SALES_CHANNEL__MAIN_SHOP)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__URL)
            ->setDreiscSeoBulkTemplateId($firstDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Create the second template */
        $secondDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__URL)
            ->setName('My Bulk Template')
            ->setTemplate('{{ product.translated.name }} - {{ product.productNumber }} SECOND');

        $this->dreiscSeoBulkTemplateRepository->create([ $secondDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "GB Shop » Products » Standard-Products" */
        $secondDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($secondCategoryId)
            ->setSalesChannelId(DemoDataIds::SALES_CHANNEL__MAIN_SHOP)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__URL)
            ->setDreiscSeoBulkTemplateId($secondDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $secondDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** We except the first entry, because the priority is 10 */
        $this->assertSame('standard-produkt-1000-sw-1000-first', $seoDataFetchResultStruct->getUrl());

        /** Update the priority of the second entity to 20 */
        $this->dreiscSeoBulkRepository->update([
            [
                DreiscSeoBulkEntity::ID__PROPERTY_NAME => $secondDreiscSeoBulkEntity->getId(),
                DreiscSeoBulkEntity::PRIORITY__PROPERTY_NAME => 20
            ]
        ]);

        /** Run the generator again **/
        $this->productGenerator->generate([ $productId ]);

        /** Check the value again */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Now we except the second entry, because the priority is 20 */
        $this->assertSame('standard-produkt-1000-sw-1000-second', $seoDataFetchResultStruct->getUrl());

        /** Update the sales channel to GB Shop, so that the first bulk should be used */
        $this->dreiscSeoBulkRepository->update([
            [
                DreiscSeoBulkEntity::ID__PROPERTY_NAME => $secondDreiscSeoBulkEntity->getId(),
                DreiscSeoBulkEntity::SALES_CHANNEL_ID__PROPERTY_NAME => DemoDataIds::SALES_CHANNEL__GB_SHOP
            ]
        ]);

        /** Run the generator again **/
        $this->productGenerator->generate([ $productId ]);

        /** Check the value again */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Now we except the second entry, because the priority is 20 */
        $this->assertSame('standard-produkt-1000-sw-1000-first', $seoDataFetchResultStruct->getUrl());
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_specialChars_url(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $firstCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        /** Create the template */
        $firstDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__URL)
            ->setName('My Bulk Template')
            ->setTemplate('{{ product.translated.name }}~test.html');

        $this->dreiscSeoBulkTemplateRepository->create([ $firstDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($firstCategoryId)
            ->setPriority(10)
            ->setSalesChannelId(DemoDataIds::SALES_CHANNEL__MAIN_SHOP)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__URL)
            ->setDreiscSeoBulkTemplateId($firstDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Check for the point and "~" character */
        $this->assertSame('standard-produkt-1000~test.html', $seoDataFetchResultStruct->getUrl());
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_specialChars_metaTitle(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $firstCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        $context = $this->contextFactory->createContext(
            (new ContextFactory\Struct\ContextStruct())
                ->setLanguageIdChain([
                    $this->demoDataRepository->getLanguageIdDe()
                ])
        );

        /** Update product name */
        $this->productRepository->upsert([
            [
                'id' => DemoDataIds::PRODUCT_SW_1000,
                'name' => 'Test & Product\' With  Symbols"'
            ]
        ], $context);

        /** Create the template */
        $firstDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE)
            ->setName('My Bulk Template')
            ->setTemplate('{{ product.translated.name }}');

        $this->dreiscSeoBulkTemplateRepository->create([ $firstDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($firstCategoryId)
            ->setPriority(10)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE)
            ->setDreiscSeoBulkTemplateId($firstDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** Check for the point and "~" character */
        $this->assertSame('Test & Product\' With  Symbols"', $seoDataFetchResultStruct->getMetaTitle());

        /** Restore product name */
        $this->productRepository->upsert([
            [
                'id' => DemoDataIds::PRODUCT_SW_1000,
                'name' => 'Standard Produkt 1000'
            ]
        ], $context);
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_moreThen255Cahrs(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $firstCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        $longText = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.';

        /**
         * Meta Title
         */

        /** Create the template */
        $firstDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE)
            ->setName('My Bulk Template')
            ->setTemplate($longText);

        $this->dreiscSeoBulkTemplateRepository->create([ $firstDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($firstCategoryId)
            ->setPriority(10)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE)
            ->setDreiscSeoBulkTemplateId($firstDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        /**
         * Meta Description
         */

        /** Create the template */
        $firstDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_DESCRIPTION)
            ->setName('My Bulk Template')
            ->setTemplate($longText);

        $this->dreiscSeoBulkTemplateRepository->create([ $firstDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($firstCategoryId)
            ->setPriority(10)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION)
            ->setDreiscSeoBulkTemplateId($firstDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        $this->assertTrue(true);
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_robotsTag(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        /** Create template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__ROBOTS_TAG)
            ->setName('My Bulk Template')
            ->setTemplate('index,follow,template');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__ROBOTS_TAG)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** We except the first entry, because the priority is 10 */
        $this->assertSame('index,follow,template', $seoDataFetchResultStruct->getRobotsTag());
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_facebookTitle(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        /** Create template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__FACEBOOK_TITLE)
            ->setName('My Bulk Template')
            ->setTemplate('FB TITLE');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__FACEBOOK_TITLE)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** We except the first entry, because the priority is 10 */
        $this->assertSame('FB TITLE', $seoDataFetchResultStruct->getFacebookTitle());
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_facebookDescription(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        /** Create template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__FACEBOOK_DESCRIPTION)
            ->setName('My Bulk Template')
            ->setTemplate('FB DESCRIPTION');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__FACEBOOK_DESCRIPTION)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** We except the first entry, because the priority is 10 */
        $this->assertSame('FB DESCRIPTION', $seoDataFetchResultStruct->getFacebookDescription());
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_twitterTitle(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        /** Create template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__TWITTER_TITLE)
            ->setName('My Bulk Template')
            ->setTemplate('TW TITLE');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__TWITTER_TITLE)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** We except the first entry, because the priority is 10 */
        $this->assertSame('TW TITLE', $seoDataFetchResultStruct->getTwitterTitle());
    }

    /**
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_twitterDescription(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $productId = DemoDataIds::PRODUCT_SW_1000;

        /** Create template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__TWITTER_DESCRIPTION)
            ->setName('My Bulk Template')
            ->setTemplate('TW DESCRIPTION');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__TWITTER_DESCRIPTION)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->productGenerator->generate([ $productId ]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** We except the first entry, because the priority is 10 */
        $this->assertSame('TW DESCRIPTION', $seoDataFetchResultStruct->getTwitterDescription());
    }
}
