<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\BulkGenerator;

use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkRepository;
use DreiscSeoPro\Core\Foundation\Context\ContextFactory;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\BulkGenerator\CategoryGenerator;
use Shopware\Core\Framework\Uuid\Uuid;

class CategoryGeneratorTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var CategoryGenerator
     */
    private $categoryGenerator;

    /**
     * @var DreiscSeoBulkRepository
     */
    private $dreiscSeoBulkRepository;

    /**
     * @var DreiscSeoBulkTemplateRepository
     */
    private $dreiscSeoBulkTemplateRepository;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var ContextFactory
     */
    private $contextFactory;

    protected function setUp(): void
    {
        $this->categoryGenerator = $this->getContainer()->get(CategoryGenerator::class);
        $this->dreiscSeoBulkRepository = $this->getContainer()->get(DreiscSeoBulkRepository::class);
        $this->dreiscSeoBulkTemplateRepository = $this->getContainer()->get(DreiscSeoBulkTemplateRepository::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->contextFactory = $this->getContainer()->get(ContextFactory::class);
    }

    public function test_moreThen255Cahrs(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;

        $longText = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.';

        /**
         * Meta Title
         */

        /** Create the template */
        $firstDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE)
            ->setName('My Bulk Template')
            ->setTemplate($longText);

        $this->dreiscSeoBulkTemplateRepository->create([ $firstDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setPriority(10)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE)
            ->setDreiscSeoBulkTemplateId($firstDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->categoryGenerator->generate([ $categoryId ]);

        /**
         * Meta Description
         */

        /** Create the template */
        $firstDreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_DESCRIPTION)
            ->setName('My Bulk Template')
            ->setTemplate($longText);

        $this->dreiscSeoBulkTemplateRepository->create([ $firstDreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $firstDreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setPriority(10)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION)
            ->setDreiscSeoBulkTemplateId($firstDreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $firstDreiscSeoBulkEntity ]);

        /** Run the generator **/
        $this->categoryGenerator->generate([ $categoryId ]);

        $this->assertTrue(true);
    }
}
