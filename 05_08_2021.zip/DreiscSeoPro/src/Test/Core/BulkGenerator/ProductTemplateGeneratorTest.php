<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\BulkGenerator;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Core\BulkGenerator\TemplateGenerator\Exception\ReferenceEntityNotFoundException;
use DreiscSeoPro\Core\BulkGenerator\TemplateGenerator\Struct\TemplateGeneratorStruct;
use DreiscSeoPro\Core\Content\CustomField\Aggregate\CustomFieldSet\CustomFieldSetRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\MainCategory\MainCategoryRepository;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Foundation\Context\ContextFactory;
use DreiscSeoPro\Core\Foundation\Context\LanguageChainFactory;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataSaver\ProductSeoDataSaver;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Struct\SeoDataSaverStruct;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\BulkGenerator\ProductTemplateGenerator;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\CustomField\CustomFieldTypes;

class ProductTemplateGeneratorTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var ProductTemplateGenerator
     */
    private $productTemplateGenerator;

    /**
     * @var ProductSeoDataSaver
     */
    private $productSeoDataSaver;

    /**
     * @var CustomFieldSetRepository
     */
    private $customFieldSetRepository;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var ContextFactory
     */
    private $contextFactory;

    /**
     * @var LanguageChainFactory
     */
    private $languageChainFactory;

    /**
     * @var MainCategoryRepository
     */
    private $mainCategoryRepository;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    protected function setUp(): void
    {
        $this->productTemplateGenerator = $this->getContainer()->get(ProductTemplateGenerator::class);
        $this->productSeoDataSaver = $this->getContainer()->get(ProductSeoDataSaver::class);
        $this->customFieldSetRepository = $this->getContainer()->get(CustomFieldSetRepository::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->contextFactory = $this->getContainer()->get(ContextFactory::class);
        $this->languageChainFactory = $this->getContainer()->get(LanguageChainFactory::class);
        $this->mainCategoryRepository = $this->getContainer()->get(MainCategoryRepository::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_metaTitle_productName(): void
    {
        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy();

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            '> {{ product.translated.name }}'
        );

        $this->assertSame('> Standard Produkt 1001', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_metaTitle_productNameAndShopName(): void
    {
        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy();

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            '{{ product.translated.name }} | ##shopName##'
        );

        $this->assertSame('Standard Produkt 1001 | ##shopName##', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_metaTitle_productNameShippingFreePriceAndShopName(): void
    {
        $template = '{% set metaTitle = [] %}
                {% set metaTitle = metaTitle|merge([product.translated.name]) %}
                {% if true == product.shippingFree %}
                    {% if \'de-DE\' == language.locale.code %}
                        {% set metaTitle = metaTitle|merge([\'versandkostenfrei\']) %}
                    {% else %}
                        {% set metaTitle = metaTitle|merge([\'free shipping\']) %}
                    {% endif %}
                {% endif %}
                {% if \'de-DE\' == language.locale.code %}
                    {% set metaTitle = metaTitle|merge([\'für nur\']) %}
                {% else %}
                    {% set metaTitle = metaTitle|merge([\'for only\']) %}
                {% endif %}
                {% set metaTitle = metaTitle|merge([\'##productPrice##\']) %}
                {% set metaTitle = metaTitle|merge([\'von ##shopName##\']) %}
                {{ metaTitle|join(\' \') }}';

        $templateGeneratorStructDe = $this->getTemplateGeneratorStructDummy();
        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStructDe,
            $template
        );

        $this->assertSame('Standard Produkt 1001 für nur ##productPrice## von ##shopName##', $renderedTemplate);

        /** Run an other test for en-GB */
        $templateGeneratorStructEn = $this->getTemplateGeneratorStructDummy(
            null, null, null,
            $this->demoDataRepository->getLanguageIdEn()
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStructEn,
            $template
        );

        $this->assertSame('Standard Product 1001 for only ##productPrice## von ##shopName##', $renderedTemplate);

        /** Set the product shipping free */
        $this->productRepository->upsert([
            [
                'id' => $templateGeneratorStructDe->getReferenceId(),
                'shippingFree' => true
            ]
        ]);

        /** Test again de-DE */
        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStructDe,
            $template
        );

        $this->assertSame('Standard Produkt 1001 versandkostenfrei für nur ##productPrice## von ##shopName##', $renderedTemplate);

        /** Test again en-GB */
        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStructEn,
            $template
        );

        $this->assertSame('Standard Product 1001 free shipping for only ##productPrice## von ##shopName##', $renderedTemplate);
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_metaTitle_productNameManufacturePriceAndShopName(): void
    {
        $template = '{% set metaTitle = [] %}
                {% set metaTitle = metaTitle|merge([product.translated.name]) %}
                {% if \'de-DE\' == language.locale.code %}
                    {% set metaTitle = metaTitle|merge([\'von\', product.manufacturer.translated.name]) %}
                {% else %}
                    {% set metaTitle = metaTitle|merge([\'(\' ~ product.manufacturer.translated.name ~ \')\']) %}
                {% endif %}
                {% if \'de-DE\' == language.locale.code %}
                    {% set metaTitle = metaTitle|merge([\'für nur\']) %}
                {% else %}
                    {% set metaTitle = metaTitle|merge([\'for only\']) %}
                {% endif %}
                {% set metaTitle = metaTitle|merge([\'##productPrice##\']) %}
                {% set metaTitle = metaTitle|merge([\'von ##shopName##\']) %}
                {{ metaTitle|join(\' \') }}';

        $templateGeneratorStructDe = $this->getTemplateGeneratorStructDummy();
        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStructDe,
            $template
        );

        $this->assertSame('Standard Produkt 1001 von Dreischild für nur ##productPrice## von ##shopName##', $renderedTemplate);

        /** Run an other test for en-GB */
        $templateGeneratorStructEn = $this->getTemplateGeneratorStructDummy(
            null, null, null,
            $this->demoDataRepository->getLanguageIdEn()
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStructEn,
            $template
        );

        $this->assertSame('Standard Product 1001 (Dreischild) for only ##productPrice## von ##shopName##', $renderedTemplate);

        /** Set the product shipping free */
        $this->productRepository->upsert([
            [
                'id' => $templateGeneratorStructDe->getReferenceId(),
                'shippingFree' => true
            ]
        ]);

        /** Test again de-DE */
        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStructDe,
            $template
        );

        $this->assertSame('Standard Produkt 1001 von Dreischild für nur ##productPrice## von ##shopName##', $renderedTemplate);

        /** Test again en-GB */
        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStructEn,
            $template
        );

        $this->assertSame('Standard Product 1001 (Dreischild) for only ##productPrice## von ##shopName##', $renderedTemplate);
    }

    /**
     * @return array
     */
    public function dataProvider_generateTemplate_customFieldOrProductNameAsFallback(): array
    {
        return [
            [ 'metaTitle' ], // » DreiscSeoBulkEnum::SEO_OPTION__META_TITLE
            [ 'metaDescription' ], // » DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION
            [ 'url' ] // » DreiscSeoBulkEnum::SEO_OPTION__URL
        ];
    }

    /**
     * @dataProvider dataProvider_generateTemplate_customFieldOrProductNameAsFallback
     *
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws ReferenceEntityNotFoundException
     */
    public function test_generateTemplate_multiSeoOptions_customFieldOrProductNameAsFallback(string $activeSeoOption): void
    {
        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy($activeSeoOption);
        $template = '{% if product.customFields.custom_myset_mytestfield is defined %}{{ product.customFields.custom_myset_mytestfield }}{% else %}{{ product.translated.name }}{% endif %}';

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** We except the product name */
        if (DreiscSeoBulkEnum::SEO_OPTION__URL === $activeSeoOption) {
            $this->assertSame('standard-produkt-1001', $renderedTemplate);
        } else {
            $this->assertSame('Standard Produkt 1001', $renderedTemplate);
        }

        /** Now we create the field "custom_mytestfield" */
        $this->customFieldSetRepository->upsert([
            [
                'id' => Uuid::randomHex(),
                'name' => 'custom_myset',
                'config' => [
                    'label' => [
                        'en-GB' => 'My test set',
                    ],
                ],
                'relations' => [
                    [
                        'id' => Uuid::randomHex(),
                        'entityName' => 'product'
                    ]
                ],
                'customFields' => [
                    [
                        'id' => Uuid::randomHex(),
                        'name' => 'custom_myset_mytestfield',
                        'type' => CustomFieldTypes::TEXT,
                        'config' => [
                            'componentName' => 'sw-field',
                            'type' => 'text',
                            'customFieldType' => 'text',
                            'label' => [
                                'en-GB' => 'My test field',
                            ],
                            'placeholder' => [
                                'en-GB' => 'Type a text...',
                            ],
                            'customFieldPosition' => 1,
                        ],
                    ]
                ]
            ]
        ]);

        /** Create the "de-DE" context */
        $languageChain = $this->languageChainFactory->getLanguageIdChain($templateGeneratorStruct->getLanguageId());
        $deContext = $this->contextFactory->createContext(
            (new ContextFactory\Struct\ContextStruct())
                ->setLanguageIdChain($languageChain)
        );

        /** Update the custom field of the product */
        $this->productRepository->update([
            [
                'id' => $templateGeneratorStruct->getReferenceId(),
                'customFields' => [
                    'custom_myset_mytestfield' => 'This is my custom field value'
                ]
            ]
        ], $deContext);

        /** Run generator again */
        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** We except the product name */
        if (DreiscSeoBulkEnum::SEO_OPTION__URL === $activeSeoOption) {
            $this->assertSame('this-is-my-custom-field-value', $renderedTemplate);
        } else {
            $this->assertSame('This is my custom field value', $renderedTemplate);
        }
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     */
    public function test_generateTemplate_url_manufacturerAndProductName(): void
    {
        $template = '{{ product.manufacturer.translated.name }}/{{ product.translated.name }}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__URL,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('dreischild/standard-produkt-1001', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     */
    public function test_generateTemplate_url_metaTitleOrProductNameAsFallback(): void
    {
        $template = '{% if productSeo.metaTitle %}{{ productSeo.metaTitle}}{% else %}{{ product.translated.name }}{% endif %}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__URL,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('standard-produkt-1001', $renderedTemplate);

        /** Now we set a meta title */
        $this->productSeoDataSaver->save([
            new SeoDataSaverStruct(
                $templateGeneratorStruct->getArea(),
                $templateGeneratorStruct->getReferenceId(),
                DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                $templateGeneratorStruct->getLanguageId(),
                $templateGeneratorStruct->getSalesChannelId(),
                'This is my meta title',
                true
            )
        ]);

        /** Generate again */
        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('this-is-my-meta-title', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     */
    public function test_generateTemplate_url_parentCategoryUrlAndProductName(): void
    {
        $template = '{% set url = [] %}
                    {% if mainCategorySeo is defined and null != mainCategorySeo.url %}
                        {% set mainCategoryUrl = mainCategorySeo.url|rtrim(\'/\') %}
                        {% set url = url|merge([mainCategoryUrl]) %}
                    {% endif %}

                    {% set url = url|merge([product.translated.name]) %}
                    {{ url|join(\'/\') }}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__URL,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            DemoDataIds::PRODUCT_SW_1004
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** Since no main category is set, we expect "produkte/standard-produkte" as main category url */
        $this->assertSame('produkte/standard-produkte/mehreren-kategorien-zugewiesen', $renderedTemplate);

        /** We create a main category for the product */
        $this->mainCategoryRepository->upsert([
            [
                'productId' => $templateGeneratorStruct->getReferenceId(),
                'categoryId' => DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES__WITHOUT_DE_TRANSLATION,
                'salesChannelId' => $templateGeneratorStruct->getSalesChannelId()
            ]
        ]);

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** Now we expect the url of the set main category */
        $this->assertSame('spezielle-kategorien/without-de-translation/mehreren-kategorien-zugewiesen', $renderedTemplate);

        /**
         * Now we make an other test with the product "Nur im Subshop sichtbar" (SW-1003)
         * This product is only visible in the GB Shop. So we have no main category
         */

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__URL,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            DemoDataIds::PRODUCT_SW_1003
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** We except the url without main category part */
        $this->assertSame('nur-im-subshop-sichtbar', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     */
    public function test_generateTemplate_url_parentCategoryUrlAndProductName_variant(): void
    {
        $template = '{% set url = [] %}
                    {% if mainCategorySeo is defined and null != mainCategorySeo.url %}
                        {% set mainCategoryUrl = mainCategorySeo.url|rtrim(\'/\') %}
                        {% set url = url|merge([mainCategoryUrl]) %}
                    {% endif %}

                    {% set url = url|merge([product.translated.name]) %}
                    {{ url|join(\'/\') }}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__URL,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            DemoDataIds::PRODUCT_SW_1006_2
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** Since no main category is set, we expect "produkte/standard-produkte" as main category url */
        $this->assertSame('produkte/standard-produkte/varianten-artikel', $renderedTemplate);

        /** We create a main category for the product */
        $this->mainCategoryRepository->upsert([
            [
                'productId' => $templateGeneratorStruct->getReferenceId(),
                'categoryId' => DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES__WITHOUT_DE_TRANSLATION,
                'salesChannelId' => $templateGeneratorStruct->getSalesChannelId()
            ]
        ]);

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** Now we expect the url of the set main category */
        $this->assertSame('spezielle-kategorien/without-de-translation/varianten-artikel', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_url_introTextAndProductName(): void
    {
        $template = '{% if \'de-DE\' == language.locale.code %}
                        unsere-topseller/{{ product.translated.name }}
                    {% else %}
                        our-topseller/{{ product.translated.name }}
                    {% endif %}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__URL,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** We except the de-DE value */
        $this->assertSame('unsere-topseller/standard-produkt-1001', $renderedTemplate);

        /** Test again with the en-GB language */
        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__URL,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            null,
            $this->demoDataRepository->getLanguageIdEn()
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** We except the en-GB value */
        $this->assertSame('our-topseller/standard-product-1001', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_metaDescription_trimmedProductDescription(): void
    {
        $template = '{% set maxLength = 130 %}
                    {% if product.translated.description|length > maxLength %}
                        {{ product.translated.description|slice(0, maxLength-3) ~ \'...\' }}
                    {% else %}
                        {{ product.translated.description }}
                    {% endif %}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('Beschreibung 3848d63292714905aa86008fd973693a', $renderedTemplate);

        /** Now we update the description and test again */
        $loremText = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam volu';
        $this->productRepository->update([
            [
                'id' => $templateGeneratorStruct->getReferenceId(),
                'description' => [
                    $templateGeneratorStruct->getLanguageId() => $loremText
                ]
            ]
        ]);

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        /** We except the en-GB value */
        $this->assertSame('Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliqu...', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_robotsTag(): void
    {
        $template = 'index,follow';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__ROBOTS_TAG,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('index,follow', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_robotsTag_basePrice(): void
    {
        $template = 'index,follow';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__ROBOTS_TAG,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );

        $this->assertSame('index,follow', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_variantData(): void
    {
        $template = '{{ product.translated.name }}##{{ product.productNumber }}##{{ product.stock }}##{{ product.weight }}##{{ product.isCloseout }}';

        /** We add data to the main product, so that we can test, if the inheritance works */
        $this->productRepository->update([
            [
                'id' => DemoDataIds::PRODUCT_SW_1006,
                'weight' => 600,
                'isCloseout' => true
            ]
        ]);

        /** Update the instock of the variant */
        $this->productRepository->update([
            [
                'id' => DemoDataIds::PRODUCT_SW_1006_1,
                'stock' => 1137
            ]
        ]);

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            DemoDataIds::PRODUCT_SW_1006_1
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );


        $this->assertSame('Varianten SW-1006.1##SW-1006.1##1137##600##1', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_variantOptions(): void
    {
        $template = '{% set metaTitle = [] %}
                    {% set seperatorBetweenProductNameAndOptions = \'»\' %}
                    {% set seperatorBetweenGroupAndOption = \': \' %}
                    {% set seperatorBetweenOptions = \', \' %}

                    {# Add the product name #}
                    {% set metaTitle = metaTitle|merge([product.translated.name]) %}

                    {# Add the variant options, if it is a variant #}
                    {% if isVariant %}
                        {% if product.options is defined %}
                            {% set metaTitle = metaTitle|merge([seperatorBetweenProductNameAndOptions]) %}

                            {% set optionStrings = [] %}
                            {% for option in product.options %}
                                {% set singleOption = [option.group.translated.name, option.translated.name]|join(seperatorBetweenGroupAndOption) %}
                                {% set optionStrings = optionStrings|merge([singleOption]) %}
                            {% endfor %}

                            {% set optionStringsUrl = optionStrings|join(seperatorBetweenOptions) %}
                            {% set metaTitle = metaTitle|merge([optionStringsUrl]) %}
                        {% endif %}
                    {% endif %}

                    {# Convert the array to an string and output. Seperated by whitespace #}
                    {{ metaTitle|join(\' \') }}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            DemoDataIds::PRODUCT_SW_1006_1
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );


        $this->assertSame('Varianten SW-1006.1 » Color: Red, material: Iron, size: XL', $renderedTemplate);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws ReferenceEntityNotFoundException
     * @throws DBALException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_generateTemplate_systemDefaults(): void
    {
        $template = 'LANGUAGE_SYSTEM:{{ systemDefaults.LANGUAGE_SYSTEM}}|CURRENCY:{{ systemDefaults.CURRENCY}}';

        $templateGeneratorStruct = $this->getTemplateGeneratorStructDummy(
            DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            DemoDataIds::PRODUCT_SW_1006_1
        );

        $renderedTemplate = $this->productTemplateGenerator->generateTemplate(
            $templateGeneratorStruct,
            $template
        );


        $this->assertSame('LANGUAGE_SYSTEM:2fbb5fe2e29a4d70aa5854ce7ce3e20b|CURRENCY:b7d2554b0ce847cd82f3ac9bd1c0dfca', $renderedTemplate);
    }

    /**
     * @param null $seoOption
     * @param null $salesChannelId
     * @param null $productId
     * @return TemplateGeneratorStruct
     */
    private function getTemplateGeneratorStructDummy(string $seoOption = null, string $salesChannelId = null, string $productId = null, string $languageId = null, bool $spaceless = null): TemplateGeneratorStruct
    {
        return new TemplateGeneratorStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            $productId ?? DemoDataIds::PRODUCT_SW_1001,
            $seoOption ?? DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            $languageId ?? $this->getDeDeLanguageId(),
            $salesChannelId,
            $spaceless ?? true
        );
    }
}
