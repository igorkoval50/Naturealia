<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Routing;

use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Content\SeoUrlTemplate\SeoUrlTemplateRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectEntity;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectEnum;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectRepository;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Content\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainRepository;
use DreiscSeoPro\Core\Content\SalesChannel\SalesChannelRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\MultiFilter;
use Shopware\Core\Framework\Test\TestCaseBase\AdminApiTestBehaviour;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Routing\RequestTransformer;
use Shopware\Core\Framework\Test\TestCaseBase\SalesChannelApiTestBehaviour;
use Shopware\Core\Framework\Uuid\Uuid;

class RequestTransformerTest extends TestCase
{
    use IntegrationTestBehaviour;
    use SalesChannelApiTestBehaviour;
    use AdminApiTestBehaviour;

    /**
     * @var RequestTransformer
     */
    private $requestTransformer;

    /**
     * @var DreiscSeoRedirectRepository
     */
    private $dreiscSeoRedirectRepository;

    /**
     * @var SalesChannelRepository
     */
    private $salesChannelRepository;

    /**
     * @var SalesChannelDomainRepository
     */
    private $salesChannelDomainRepository;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var SeoUrlTemplateRepository
     */
    private $seoUrlTemplateRepository;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    protected function setUp(): void
    {
        $this->requestTransformer = $this->getContainer()->get(RequestTransformer::class);
        $this->dreiscSeoRedirectRepository = $this->getContainer()->get(DreiscSeoRedirectRepository::class);
        $this->salesChannelRepository = $this->getContainer()->get(SalesChannelRepository::class);
        $this->salesChannelDomainRepository = $this->getContainer()->get(SalesChannelDomainRepository::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
        $this->seoUrlTemplateRepository = $this->getContainer()->get(SeoUrlTemplateRepository::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
    }

    public function test_redirect_inactive(): void
    {
        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-source-url')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__URL)
                ->setRedirectSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setRedirectPath('my/redirect/url')
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-source-url');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** The response should be null, because the redirect is inactive */
        $this->assertNull($response);
    }

    public function test_redirect_http_status_code_302(): void
    {
        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__302)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-source-url')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__URL)
                ->setRedirectSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setRedirectPath('my/redirect/url')
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-source-url');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNotNull($response, 'It is not a valid json. So no redirect was created');

        /** Check the target */
        $this->assertSame('http://www.shopware-dev.de/my/redirect/url', $response->redirectUrl);
        $this->assertSame(302, $response->statusCode);
    }

    public function test_redirect_url_to_url(): void
    {
        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        $salesChannelDomain_httpGbshopShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_GBSHOP_SHOPWARE_DEV_DE
        );

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-source-url')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__URL)
                ->setRedirectSalesChannelDomainId($salesChannelDomain_httpGbshopShopwareDevDe->getId())
                ->setRedirectPath('my/redirect/url')
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-source-url');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNotNull($response, 'It is not a valid json. So no redirect was created');

        /** Check the target */
        $this->assertSame(rtrim($salesChannelDomain_httpGbshopShopwareDevDe->getUrl(), '/') . '/my/redirect/url', $response->redirectUrl);
        $this->assertSame(301, $response->statusCode);
    }

    public function test_redirect_url_to_externalUrl(): void
    {
        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-source-url')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__EXTERNAL_URL)
                ->setRedirectUrl('https://de.dreischild.de')
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-source-url');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNotNull($response, 'It is not a valid json. So no redirect was created');

        /** Check the target */
        $this->assertSame('https://de.dreischild.de', $response->redirectUrl);
        $this->assertSame(301, $response->statusCode);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_redirect_url_to_product(): void
    {
        $salesChannel = $this->salesChannelRepository->get(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        /** Set the seo url temlplate, so that we can detect the default urls */
        $this->seoUrlTemplateRepository->updateByCriteria([
            'template' => '{{ product.translated.name }}/{{ product.productNumber }}/AUTO-GENERATED'
        ],
            (new Criteria())
                ->addFilter(
                    new EqualsFilter('entityName', 'product')
                )
        );

        /**
         * Fetch a product which has a category mapping to the root category or
         * one of the categories above
         */
        $validProduct = $this->productRepository->search(
            (new Criteria())
                ->setLimit(1)
                ->addFilter(
                    new EqualsFilter('categoryTree', $salesChannel->getNavigationCategoryId())
                )
        )->first();

        /** It fails, if we cannot find a product */
        $this->assertNotNull($validProduct);

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-product-redirect-url')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__PRODUCT)
                ->setRedirectProductId($validProduct->getId())
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-product-redirect-url');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNotNull($response, 'It is not a valid json. So no redirect was created');

        /** Check the target */
        $this->assertSame('http://www.shopware-dev.de/Standard-Produkt-1001/SW-1001', $response->redirectUrl);
        $this->assertSame(301, $response->statusCode);
    }

    /**
     * Redirect to the product SW-1003, which is not available for the main shop.
     * So we check, if there is no redirect
     *
     * @throws InconsistentCriteriaIdsException
     */
    public function test_redirect_url_to_product_which_is_not_available_for_this_shop(): void
    {
        $salesChannel = $this->salesChannelRepository->get(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        /** Fetch the product SW-1003 */
        $validProduct = $this->productRepository->get(DemoDataIds::PRODUCT_SW_1003);

        /** It fails, if we cannot find a product */
        $this->assertNotNull($validProduct);

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-product-redirect-url-product-not-available-for-this-shop')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__PRODUCT)
                ->setRedirectProductId($validProduct->getId())
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-product-redirect-url-product-not-available-for-this-shop');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNull($response, 'It is a valid json. So a redirect was created, while the product is not available for this shop');
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_redirect_url_to_product_with_deviating_redirect_sales_channel_domain(): void
    {
        $salesChannel = $this->salesChannelRepository->get(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        $salesChannelDomain_httpGbshopShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_GBSHOP_SHOPWARE_DEV_DE
        );

        /**
         * Fetch a product which has a category mapping to the root category or
         * one of the categories above
         */
        $validProduct = $this->productRepository->search(
            (new Criteria())
                ->setLimit(1)
                ->addFilter(
                    new EqualsFilter('categoryTree', $salesChannel->getNavigationCategoryId())
                )
        )->first();

        /** It fails, if we cannot find a product */
        $this->assertNotNull($validProduct);

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-product-redirect-url')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__PRODUCT)
                ->setRedirectProductId($validProduct->getId())
                ->setHasDeviatingRedirectSalesChannelDomain(true)
                ->setDeviatingRedirectSalesChannelDomainId($salesChannelDomain_httpGbshopShopwareDevDe->getId())
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-product-redirect-url');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNotNull($response, 'It is not a valid json. So no redirect was created');

        /** Check the target */
        $this->assertSame('http://gbshop.shopware-dev.de/Standard-Product-1001/SW-1001', $response->redirectUrl);
        $this->assertSame(301, $response->statusCode);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_redirect_url_to_category(): void
    {
        $salesChannel = $this->salesChannelRepository->get(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        /**
         * Fetch a category with has the navigation category as a parent
         */
        $validCategory = $this->categoryRepository->search(
            (new Criteria())
                ->setLimit(1)
                ->addFilter(
                    new EqualsFilter('parentId', $salesChannel->getNavigationCategoryId())
                )
        )->first();

        /** It fails, if we cannot find a child category */
        $this->assertNotNull($validCategory);

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-category-redirect-url')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__CATEGORY)
                ->setRedirectCategoryId($validCategory->getId())
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-category-redirect-url');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNotNull($response, 'It is not a valid json. So no redirect was created');

        /** Check the target */
        if ($this->isUrlSet('Produkte/', DemoDataIds::SALES_CHANNEL__MAIN_SHOP, $this->getDeDeLanguageId())) {
            $this->assertSame('http://www.shopware-dev.de/Produkte/', $response->redirectUrl);
        } else {
            $this->assertSame('http://www.shopware-dev.de/navigation/c542db9e9d964fe29a15061440a68730', $response->redirectUrl);
        }

        $this->assertSame(301, $response->statusCode);
    }

    /**
     * In this test we redirect to the category "GB Shop » Products" which is not
     * accessible for the main shop. The redirect should be ignored.
     *
     * @throws InconsistentCriteriaIdsException
     */
    public function test_redirect_url_to_category_which_is_not_available_for_this_shop(): void
    {
        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        /** Fetch the category */
        $category = $this->categoryRepository->get(DemoDataIds::CATEGORY__GBSHOP__PRODUCTS);

        /** It fails, if we cannot find a child category */
        $this->assertNotNull($category);

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-category-redirect-url-which-is-not-available-for-this-shop')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__CATEGORY)
                ->setRedirectCategoryId($category->getId())
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-category-redirect-url-which-is-not-available-for-this-shop');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNull($response, 'It is a valid json. So a redirect was created, while the category is not available for this shop');
    }

    /**
     * Check if the redirect goes to the EN subshop
     *
     * @throws InconsistentCriteriaIdsException
     */
    public function test_redirect_url_to_category_with_deviating_redirect_sales_channel_domain(): void
    {
        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        $salesChannelDomain_httpWwwShopwareDevDeEn = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE_EN
        );

        /** Fetch the category */
        $category = $this->categoryRepository->get(DemoDataIds::CATEGORY__MAIN__PRODUCTS);

        /** It fails, if we cannot find a child category */
        $this->assertNotNull($category);

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-category-redirect-url/deviating-redirect')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__CATEGORY)
                ->setRedirectCategoryId($category->getId())
                ->setHasDeviatingRedirectSalesChannelDomain(true)
                ->setDeviatingRedirectSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDeEn->getId())
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-category-redirect-url/deviating-redirect');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNotNull($response, 'It is not a valid json. So no redirect was created');

        /** Check the target */
        if ($this->isUrlSet('Products/', DemoDataIds::SALES_CHANNEL__MAIN_SHOP, $this->demoDataRepository->getLanguageIdEn())) {
            $this->assertSame('http://www.shopware-dev.de/en/Products/', $response->redirectUrl);
        } else {
            $this->assertSame('http://www.shopware-dev.de/en/navigation/c542db9e9d964fe29a15061440a68730', $response->redirectUrl);
        }

        $this->assertSame(301, $response->statusCode);
    }

    /**
     * We redirect from http://www.shopware-dev.de to a main shop category. Check if the test
     * fail, because this category is not available for the deviating domain.
     *
     * @throws InconsistentCriteriaIdsException
     */
    public function test_redirect_url_to_category_with_deviating_redirect_sales_channel_domain_and_not_available_for_this_shop(): void
    {
        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        $salesChannelDomain_httpGbshopShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_GBSHOP_SHOPWARE_DEV_DE
        );

        /** Fetch the category */
        $category = $this->categoryRepository->get(DemoDataIds::CATEGORY__MAIN__PRODUCTS);

        /** It fails, if we cannot find a child category */
        $this->assertNotNull($category);

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-category-redirect-url/deviating-redirect-and-not-available')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__CATEGORY)
                ->setRedirectCategoryId($category->getId())
                ->setHasDeviatingRedirectSalesChannelDomain(true)
                ->setDeviatingRedirectSalesChannelDomainId($salesChannelDomain_httpGbshopShopwareDevDe->getId())
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-category-redirect-url/deviating-redirect-and-not-available');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNull($response, 'It is a valid json. So a redirect was created, while the category is not available for this shop');
    }

    public function test_redirect_url_to_home(): void
    {
        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        $salesChannelDomain_httpGbshopShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_GBSHOP_SHOPWARE_DEV_DE
        );

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setSourcePath('my-source-url-to-home')
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__URL)
                ->setRedirectSalesChannelDomainId($salesChannelDomain_httpGbshopShopwareDevDe->getId())
                ->setRedirectPath('')
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', 'http://www.shopware-dev.de/my-source-url-to-home');
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNotNull($response, 'It is not a valid json. So no redirect was created');

        /** Check the target */
        $this->assertSame(rtrim($salesChannelDomain_httpGbshopShopwareDevDe->getUrl(), '/') . '/', $response->redirectUrl);
        $this->assertSame(301, $response->statusCode);
    }

    /**
     * In version 6.6.0 the error "ltrim() expects parameter 1 to be string, boolean given"
     * was thrown when using a sales channel with a virtual folder.
     *
     * @throws InconsistentCriteriaIdsException
     */
    public function test_virtual_url_bug(): void
    {
        /** Start request */
        $this->getBrowser()->request(
            'GET',
            'http://www.shopware-dev.de/en',
            []
        );

        $response = $this->getBrowser()->getResponse()->getContent();

        $this->assertStringContainsString('header-logo-main', $response);
    }

    /**
     * @param string $seoPathInfo
     * @param string $salesChannelId
     * @param string $languageId
     * @return bool
     */
    private function isUrlSet(string $seoPathInfo, string $salesChannelId, string $languageId): bool
    {
        $entitySearchResult = $this->seoUrlRepository->search(
            (new Criteria())->addFilter(
                new MultiFilter(
                    MultiFilter::CONNECTION_AND,
                    [
                        new EqualsFilter(
                            'seoPathInfo',
                            $seoPathInfo
                        ),
                        new EqualsFilter(
                            'salesChannelId',
                            $salesChannelId
                        ),
                        new EqualsFilter(
                            'languageId',
                            $languageId
                        )
                    ]
                )
            )
        );

        return $entitySearchResult->count() >= 1;
    }
}
