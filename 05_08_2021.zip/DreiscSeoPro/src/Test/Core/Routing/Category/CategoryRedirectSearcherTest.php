<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Routing\Category;

use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectEntity;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectEnum;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectRepository;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Content\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainRepository;
use DreiscSeoPro\Core\Content\SalesChannel\SalesChannelRepository;
use DreiscSeoPro\Core\Foundation\Seo\SeoUrlAssembler;
use Shopware\Core\Content\Category\CategoryEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use Shopware\Core\Framework\Test\TestCaseBase\SalesChannelApiTestBehaviour;
use Shopware\Core\Framework\Uuid\Uuid;

class CategoryRedirectSearcherTest extends TestCase
{
    use IntegrationTestBehaviour;
    use SalesChannelApiTestBehaviour;

    /**
     * @var DreiscSeoRedirectRepository
     */
    private $dreiscSeoRedirectRepository;

    /**
     * @var SalesChannelRepository
     */
    private $salesChannelRepository;

    /**
     * @var SalesChannelDomainRepository
     */
    private $salesChannelDomainRepository;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var SeoUrlAssembler
     */
    private $seoUrlAssembler;

    protected function setUp(): void
    {
        $this->dreiscSeoRedirectRepository = $this->getContainer()->get(DreiscSeoRedirectRepository::class);
        $this->salesChannelRepository = $this->getContainer()->get(SalesChannelRepository::class);
        $this->salesChannelDomainRepository = $this->getContainer()->get(SalesChannelDomainRepository::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
        $this->seoUrlAssembler = $this->getContainer()->get(SeoUrlAssembler::class);
    }

    /**
     * Test a redirect of a category to an url
     *
     * @throws InconsistentCriteriaIdsException
     */
    public function test_redirect_category_to_url(): void
    {
        $salesChannel = $this->salesChannelRepository->get(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        /** Fetch a category with has the navigation category as a parent */
        /** @var CategoryEntity $validCategory */
        $validCategory = $this->categoryRepository->search(
            (new Criteria())
                ->setLimit(1)
                ->addFilter(
                    new EqualsFilter('parentId', $salesChannel->getNavigationCategoryId())
                )
        )->first();

        /** It fails, if we cannot find a child category */
        $this->assertNotNull($validCategory);

        /** Determine the url of the product */
        $categoryUrlInfo = $this->seoUrlAssembler->assemble(
            $validCategory,
            $salesChannel->getId(),
            $salesChannelDomain_httpWwwShopwareDevDe->getLanguageId()
        );

        $this->assertNotEmpty($categoryUrlInfo[SeoUrlAssembler::ABSOLUTE_PATHS]);
        $this->assertNotEmpty($categoryUrlInfo[SeoUrlAssembler::ABSOLUTE_PATHS][$salesChannelDomain_httpWwwShopwareDevDe->getId()]);
        $categoryUrl = $categoryUrlInfo[SeoUrlAssembler::ABSOLUTE_PATHS][$salesChannelDomain_httpWwwShopwareDevDe->getId()];

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__302)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__CATEGORY)
                ->setSourceCategoryId($validCategory->getId())
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__URL)
                ->setRedirectSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setRedirectPath('category/redirect/target-url')
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', $categoryUrl);
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNotNull($response, 'It is not a valid json. So no redirect was created');

        /** Check the target */
        $this->assertSame(rtrim($salesChannelDomain_httpWwwShopwareDevDe->getUrl(), '/') . '/category/redirect/target-url', $response->redirectUrl);
        $this->assertSame(302, $response->statusCode);
    }

    /**
     * Test a redirect with a sales channel domain restriction
     * The redirect must be fail, because the redirect is only for
     * http://gbshop.shopware-dev.de and not for http://www.shopware-dev.de
     *
     * @throws InconsistentCriteriaIdsException
     */
    public function test_redirect_category_with_sales_channel_domain_restriction_to_url(): void
    {
        $salesChannel = $this->salesChannelRepository->get(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);

        $salesChannelDomain_httpWwwShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
        );

        $salesChannelDomain_httpGbshopShopwareDevDe = $this->salesChannelDomainRepository->get(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_GBSHOP_SHOPWARE_DEV_DE
        );

        /** Fetch a category with has the navigation category as a parent */
        /** @var CategoryEntity $validCategory */
        $validCategory = $this->categoryRepository->search(
            (new Criteria())
                ->setLimit(1)
                ->addFilter(
                    new EqualsFilter('parentId', $salesChannel->getNavigationCategoryId())
                )
        )->first();

        /** It fails, if we cannot find a child category */
        $this->assertNotNull($validCategory);

        /** Determine the url of the product */
        $categoryUrlInfo = $this->seoUrlAssembler->assemble(
            $validCategory,
            $salesChannel->getId(),
            $salesChannelDomain_httpWwwShopwareDevDe->getLanguageId()
        );

        $this->assertNotEmpty($categoryUrlInfo[SeoUrlAssembler::ABSOLUTE_PATHS]);
        $this->assertNotEmpty($categoryUrlInfo[SeoUrlAssembler::ABSOLUTE_PATHS][$salesChannelDomain_httpWwwShopwareDevDe->getId()]);
        $categoryUrl = $categoryUrlInfo[SeoUrlAssembler::ABSOLUTE_PATHS][$salesChannelDomain_httpWwwShopwareDevDe->getId()];

        $dreiscSeoRedirectId = Uuid::randomHex();
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__302)
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__CATEGORY)
                ->setSourceCategoryId($validCategory->getId())
                ->setHasSourceSalesChannelDomainRestriction(true)
                ->setSourceSalesChannelDomainRestrictionIds([
                    $salesChannelDomain_httpGbshopShopwareDevDe->getId()
                ])
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__URL)
                ->setRedirectSalesChannelDomainId($salesChannelDomain_httpWwwShopwareDevDe->getId())
                ->setRedirectPath('category/redirect/target-url')
        ]);

        $client = $this->createSalesChannelBrowser(null, true);
        $client->setServerParameter('IS_PHP_UNIT_TEST', 1);

        /** Start request */
        ob_start();
        $client->request('GET', $categoryUrl);
        $response = json_decode(ob_get_contents());
        ob_end_clean();

        /** Check, if it is valid JSON */
        $this->assertNull($response, 'It is a valid json. So a redirect was created, while a domain restriction is set');
    }
}
