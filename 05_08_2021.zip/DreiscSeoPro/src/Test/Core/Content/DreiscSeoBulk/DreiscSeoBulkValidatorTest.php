<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Content\DreiscSeoBulk;

use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Framework\DataAbstractionLayer\Write\WriteException;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkValidator;
use Shopware\Core\Framework\Uuid\Uuid;

class DreiscSeoBulkValidatorTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var DreiscSeoBulkValidator
     */
    private $dreiscSeoBulkValidator;

    /**
     * @var DreiscSeoBulkRepository
     */
    private $dreiscSeoBulkRepository;

    protected function setUp(): void
    {
        $this->dreiscSeoBulkValidator = $this->getContainer()->get(DreiscSeoBulkValidator::class);
        $this->dreiscSeoBulkRepository = $this->getContainer()->get(DreiscSeoBulkRepository::class);
    }

    public function test_invalid_area(): void
    {
        $dreiscSeoBulkEntity = $this->getDummySeoBulkEntity();
        $dreiscSeoBulkEntity->setArea('invalidValue');

        try {
            $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);
            $this->assertTrue(false, 'No exception was thrown although there is an invalid value');
        } catch (WriteException $exception) {
            $this->assertStringContainsString('Invalid value for the field "area"', $exception->getMessage());
        }

    }

    public function test_invalid_seo_option(): void
    {
        $dreiscSeoBulkEntity = $this->getDummySeoBulkEntity();
        $dreiscSeoBulkEntity->setSeoOption('invalidValue');

        try {
            $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);
            $this->assertTrue(false, 'No exception was thrown although there is an invalid value');
        } catch (WriteException $exception) {
            $this->assertStringContainsString('Invalid value for the field "seo_option"', $exception->getMessage());
        }
    }

    public function test_unique_entiy_insert(): void
    {
        $firstEntity = $this->getDummySeoBulkEntity();
        $duplicatedEntity = $this->getDummySeoBulkEntity();

        /** Initial insert */
        $firstEntity->setInherit(true);
        $this->dreiscSeoBulkRepository->create([ $firstEntity ]);

        /** Make an update */
        $firstEntity->setOverwrite(true);
        $this->dreiscSeoBulkRepository->upsert([
            $firstEntity
        ]);

        /** Insert duplicate */
        try {
            $this->dreiscSeoBulkRepository->create([ $duplicatedEntity ]);
            $this->assertTrue(false, 'No exception was thrown although this is a duplicate');
        } catch (WriteException $exception) {
            $this->assertStringContainsString('There is already an entity with the unique field values for "seo_option, area, category_id, sales_channel_id, language_id"', $exception->getMessage());
        }
    }

    public function test_unique_entiy_update(): void
    {
        $firstEntity = $this->getDummySeoBulkEntity();
        $duplicatedEntity = $this->getDummySeoBulkEntity();

        /** Initial insert */
        $firstEntity->setInherit(true);
        $this->dreiscSeoBulkRepository->create([ $firstEntity ]);

        /** Make an update */
        $firstEntity->setOverwrite(true);
        $this->dreiscSeoBulkRepository->upsert([
            $firstEntity
        ]);

        /** Change the category, so that the insert not fails */
        $duplicatedEntity->setCategoryId(DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS);

        /** Insert duplicate */
        $this->dreiscSeoBulkRepository->create([ $duplicatedEntity ]);

        /** Change the category back for the update, so that the update fails */
        $duplicatedEntity->setCategoryId($firstEntity->getCategoryId());

        /** Update the entity to an existing unique */
        try {
            $this->dreiscSeoBulkRepository->update([ $duplicatedEntity ]);
            $this->assertTrue(false, 'No exception was thrown although this is a duplicate');
        } catch (WriteException $exception) {
            $this->assertStringContainsString('There is already an entity with the unique field values for "seo_option, area, category_id, sales_channel_id, language_id"', $exception->getMessage());
        }
    }

    private function getDummySeoBulkEntity(): DreiscSeoBulkEntity
    {
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId(DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS)
            ->setLanguageId($this->getDeDeLanguageId())
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE);

        return $dreiscSeoBulkEntity;
    }
}
