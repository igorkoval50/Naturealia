<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Content\DreiscSeoBulk;

use DreiscSeoPro\Core\Content\Category\CategoryExtension;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkCollection;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\Language\LanguageRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Content\Category\CategoryEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkRepository;
use Shopware\Core\Framework\Uuid\Uuid;

class DreiscSeoBulkRepositoryTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var DreiscSeoBulkRepository
     */
    private $dreiscSeoBulkRepository;

    /**
     * @var DreiscSeoBulkTemplateRepository
     */
    private $dreiscSeoBulkTemplateRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    protected function setUp(): void
    {
        $this->dreiscSeoBulkRepository = $this->getContainer()->get(DreiscSeoBulkRepository::class);
        $this->dreiscSeoBulkTemplateRepository = $this->getContainer()->get(DreiscSeoBulkTemplateRepository::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_dreisc_seo_bulk(): void
    {
        /** Create a bulk template */
        $dreiscSeoBulkTemplateEntity = $this->getDummyBulkTemplateEntity();
        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create a bulk setting */
        $dreiscSeoBulkEntity = $this->getDummyBulkEntity();
        $dreiscSeoBulkEntity->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId());
        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Check, if the entity was saved */
        $loadedDreiscSeoBulkEntity = $this->dreiscSeoBulkRepository->get($dreiscSeoBulkEntity->getId(), [
            DreiscSeoBulkEntity::DREISC_SEO_BULK_TEMPLATE__PROPERTY_NAME
        ]);

        /** Check basic fields */
        $this->assertSame($dreiscSeoBulkEntity->getId(), $loadedDreiscSeoBulkEntity->getId());
        $this->assertSame(DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS, $loadedDreiscSeoBulkEntity->getCategoryId());
        $this->assertSame($this->getDeDeLanguageId(), $loadedDreiscSeoBulkEntity->getLanguageId());
        $this->assertSame(DreiscSeoBulkEnum::AREA__PRODUCT, $loadedDreiscSeoBulkEntity->getArea());
        $this->assertSame(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE, $loadedDreiscSeoBulkEntity->getSeoOption());

        /** Check bulk template association */
        $loadedDreiscSeoBulkTemplate = $loadedDreiscSeoBulkEntity->getDreiscSeoBulkTemplate();
        $this->assertNotNull($loadedDreiscSeoBulkTemplate);
        $this->assertSame($dreiscSeoBulkTemplateEntity->getId(), $loadedDreiscSeoBulkTemplate->getId());
        $this->assertSame($dreiscSeoBulkTemplateEntity->getName(), $loadedDreiscSeoBulkTemplate->getName());
    }

    public function test_dreisc_seo_bulk_category_association(): void
    {
        /** Create a bulk setting */
        $dreiscSeoBulkEntity = $this->getDummyBulkEntity();
        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Check if the bulk is available from the category side */
        $searchResult = $this->categoryRepository->search(
            (new Criteria([ $dreiscSeoBulkEntity->getCategoryId() ]))
                ->addAssociation(CategoryExtension::DREISC_SEO_BULK_ASSOCIATION)
        );

        /** @var CategoryEntity $categoryEntity */
        $categoryEntity = $searchResult->first();
        /** @var DreiscSeoBulkCollection $dreiscSeoBulks */
        $dreiscSeoBulks = $categoryEntity->getExtension(CategoryExtension::DREISC_SEO_BULK_ASSOCIATION);

        $this->assertInstanceOf(DreiscSeoBulkCollection::class, $dreiscSeoBulks);
        $this->assertSame($dreiscSeoBulkEntity->getId(), $dreiscSeoBulks->first()->getId());
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_getResponsibleSeoBulk_noResult(): void {
        $dreiscSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleSeoBulk(
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            DreiscSeoBulkEnum::AREA__PRODUCT,
            DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            $this->getDeDeLanguageId(),
            null
        );

        $this->assertNull($dreiscSeoBulkEntity);
    }

    public function test_getResponsibleSeoBulk_sameCategoryMatch(): void {
        /** Create a bulk template */
        $dreiscSeoBulkTemplateEntity = $this->getDummyBulkTemplateEntity();
        $dreiscSeoBulkEntity = $this->getDummyBulkEntity();
        $dreiscSeoBulkEntity->setDreiscSeoBulkTemplate($dreiscSeoBulkTemplateEntity);
        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        $responsibleSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleSeoBulk(
            $dreiscSeoBulkEntity->getCategoryId(),
            $dreiscSeoBulkEntity->getArea(),
            $dreiscSeoBulkEntity->getSeoOption(),
            $dreiscSeoBulkEntity->getLanguageId(),
            $dreiscSeoBulkEntity->getSalesChannelId()
        );

        $this->assertNotNull($responsibleSeoBulkEntity);
        $this->assertSame($dreiscSeoBulkEntity->getCategoryId(), $responsibleSeoBulkEntity->getCategoryId());
        $this->assertNotNull($responsibleSeoBulkEntity->getDreiscSeoBulkTemplate());
        $this->assertSame($dreiscSeoBulkTemplateEntity->getName(), $responsibleSeoBulkEntity->getDreiscSeoBulkTemplate()->getName());

        /**
         * Now we update the seo bulk configuration and activate the inheritance
         * It was a bug, that in this case no seo bulk is available
         */

        $this->dreiscSeoBulkRepository->update([[
            DreiscSeoBulkEntity::ID__PROPERTY_NAME => $dreiscSeoBulkEntity->getId(),
            DreiscSeoBulkEntity::INHERIT__PROPERTY_NAME => true
        ]]);

        /** Fetch the responsible seo bulk again */
        $responsibleSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleSeoBulk(
            $dreiscSeoBulkEntity->getCategoryId(),
            $dreiscSeoBulkEntity->getArea(),
            $dreiscSeoBulkEntity->getSeoOption(),
            $dreiscSeoBulkEntity->getLanguageId(),
            $dreiscSeoBulkEntity->getSalesChannelId()
        );

        /** Test if it still not null */
        $this->assertNotNull($responsibleSeoBulkEntity);
        $this->assertSame($dreiscSeoBulkEntity->getCategoryId(), $responsibleSeoBulkEntity->getCategoryId());
    }

    public function test_getResponsibleSeoBulk_parentCategoryMatch(): void {
        /** Create a bulk template */
        $dreiscSeoBulkTemplateEntity = $this->getDummyBulkTemplateEntity();
        $dreiscSeoBulkEntity = $this->getDummyBulkEntity();
        $dreiscSeoBulkEntity->setCategoryId(DemoDataIds::ROOT_CATEGORY__MAIN_SHOP);
        $dreiscSeoBulkEntity->setDreiscSeoBulkTemplate($dreiscSeoBulkTemplateEntity);
        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        $responsibleSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleSeoBulk(
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            $dreiscSeoBulkEntity->getArea(),
            $dreiscSeoBulkEntity->getSeoOption(),
            $dreiscSeoBulkEntity->getLanguageId(),
            $dreiscSeoBulkEntity->getSalesChannelId()
        );

        /** It should be null, because the parent seo bulk does not inherit the template yet */
        $this->assertNull($responsibleSeoBulkEntity);

        /** Let`s activate the inheritance */
        $dreiscSeoBulkEntity->setInherit(true);
        $this->dreiscSeoBulkRepository->update([[
            DreiscSeoBulkEntity::ID__PROPERTY_NAME => $dreiscSeoBulkEntity->getId(),
            DreiscSeoBulkEntity::INHERIT__PROPERTY_NAME => true
        ]]);

        /** Fetch the responsible seo bulk again */
        $responsibleSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleSeoBulk(
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            $dreiscSeoBulkEntity->getArea(),
            $dreiscSeoBulkEntity->getSeoOption(),
            $dreiscSeoBulkEntity->getLanguageId(),
            $dreiscSeoBulkEntity->getSalesChannelId()
        );

        $this->assertNotNull($responsibleSeoBulkEntity);
        $this->assertSame(DemoDataIds::ROOT_CATEGORY__MAIN_SHOP, $responsibleSeoBulkEntity->getCategoryId());
        $this->assertNotNull($responsibleSeoBulkEntity->getDreiscSeoBulkTemplate());
        $this->assertSame($dreiscSeoBulkTemplateEntity->getName(), $responsibleSeoBulkEntity->getDreiscSeoBulkTemplate()->getName());

        /**
         * Now we have a inheritance from the root category to the products » standard-products category
         * Next we make sure, that the inheritance even not breaks, if the products category has its own template
         * which has *no* inheritance
         */

        /** Add a seo bulk configuration for the category in the middle without inheritance */
        $middleCategoryDreiscSeoBulkEntity = $this->getDummyBulkEntity();
        $middleCategoryDreiscSeoBulkEntity->setCategoryId(DemoDataIds::CATEGORY__MAIN__PRODUCTS);
        $middleCategoryDreiscSeoBulkEntity->setInherit(false);
        $middleCategoryDreiscSeoBulkEntity->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId());
        $this->dreiscSeoBulkRepository->create([ $middleCategoryDreiscSeoBulkEntity ]);

        /** Fetch the responsible seo bulk again */
        $responsibleSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleSeoBulk(
            DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
            $dreiscSeoBulkEntity->getArea(),
            $dreiscSeoBulkEntity->getSeoOption(),
            $dreiscSeoBulkEntity->getLanguageId(),
            $dreiscSeoBulkEntity->getSalesChannelId()
        );

        $this->assertNotNull($responsibleSeoBulkEntity);
        $this->assertSame(DemoDataIds::ROOT_CATEGORY__MAIN_SHOP, $responsibleSeoBulkEntity->getCategoryId());
    }

    /**
     * We test whether multiple bulk templates for a product are selected with the highest priority.
     * We use the product SW-1004 for this because it is assigned to the two categories used in the test.
     *
     * @throws InconsistentCriteriaIdsException
     */
    public function test_getResponsibleProductSeoBulkRespectPriority(): void
    {
        /** Create a bulk template */
        $dreiscSeoBulkTemplateEntity = $this->getDummyBulkTemplateEntity();

        $dreiscSeoBulkEntityFirst = $this->getDummyBulkEntity();
        $dreiscSeoBulkEntityFirst->setPriority(0);
        $dreiscSeoBulkEntityFirst->setCategoryId(DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS);
        $dreiscSeoBulkEntityFirst->setDreiscSeoBulkTemplate($dreiscSeoBulkTemplateEntity);
        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntityFirst ]);

        $dreiscSeoBulkEntitySecond = $this->getDummyBulkEntity();
        $dreiscSeoBulkEntitySecond->setPriority(10);
        $dreiscSeoBulkEntitySecond->setCategoryId(DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES__WITHOUT_DE_TRANSLATION);
        $dreiscSeoBulkEntitySecond->setDreiscSeoBulkTemplate($dreiscSeoBulkTemplateEntity);
        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntitySecond ]);

        $responsibleSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleProductSeoBulkRespectPriority(
            DemoDataIds::PRODUCT_SW_1004,
            $dreiscSeoBulkEntityFirst->getSeoOption(),
            $dreiscSeoBulkEntityFirst->getLanguageId(),
            $dreiscSeoBulkEntityFirst->getSalesChannelId()
        );

        $this->assertNotNull($responsibleSeoBulkEntity);
        $this->assertSame($dreiscSeoBulkEntitySecond->getId(), $responsibleSeoBulkEntity->getId());
        $this->assertNotNull($responsibleSeoBulkEntity->getDreiscSeoBulkTemplate());
        $this->assertSame($dreiscSeoBulkTemplateEntity->getName(), $responsibleSeoBulkEntity->getDreiscSeoBulkTemplate()->getName());

        /** Now we update the priority */
        $dreiscSeoBulkEntityFirst->setPriority(20);
        $this->dreiscSeoBulkRepository->upsert([
            $dreiscSeoBulkEntityFirst
        ]);

        $responsibleSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleProductSeoBulkRespectPriority(
            DemoDataIds::PRODUCT_SW_1004,
            $dreiscSeoBulkEntityFirst->getSeoOption(),
            $dreiscSeoBulkEntityFirst->getLanguageId(),
            $dreiscSeoBulkEntityFirst->getSalesChannelId()
        );

        $this->assertNotNull($responsibleSeoBulkEntity);
        $this->assertSame($dreiscSeoBulkEntityFirst->getId(), $responsibleSeoBulkEntity->getId());
    }

    private function getDummyBulkEntity(): DreiscSeoBulkEntity
    {
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId(DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS)
            ->setLanguageId($this->getDeDeLanguageId())
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE);

        return $dreiscSeoBulkEntity;
    }

    private function getDummyBulkTemplateEntity(): DreiscSeoBulkTemplateEntity
    {
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE)
            ->setName('My Bulk Template');

        return $dreiscSeoBulkTemplateEntity;
    }
}
