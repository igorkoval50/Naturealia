<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate;

use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Write\WriteException;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateValidator;
use Shopware\Core\Framework\Uuid\Uuid;

class DreiscSeoBulkTemplateValidatorTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var DreiscSeoBulkTemplateValidator
     */
    private $dreiscSeoBulkTemplateValidator;

    /**
     * @var DreiscSeoBulkTemplateRepository
     */
    private $dreiscSeoBulkTemplateRepository;

    protected function setUp(): void
    {
        $this->dreiscSeoBulkTemplateValidator = $this->getContainer()->get(DreiscSeoBulkTemplateValidator::class);
        $this->dreiscSeoBulkTemplateRepository = $this->getContainer()->get(DreiscSeoBulkTemplateRepository::class);
    }

    public function test_invalid_area(): void
    {
        $dreiscSeoBulkTemplateEntity = $this->getDummySeoBulkTemplateEntity();
        $dreiscSeoBulkTemplateEntity->setArea('invalidValue');

        try {
            $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);
            $this->assertTrue(false, 'No exception was thrown although there is an invalid value');
        } catch (WriteException $exception) {
            $this->assertStringContainsString('Invalid value for the field "area"', $exception->getMessage());
        }

    }

    public function test_invalid_seo_option(): void
    {
        $dreiscSeoBulkTemplateEntity = $this->getDummySeoBulkTemplateEntity();
        $dreiscSeoBulkTemplateEntity->setSeoOption('invalidValue');

        try {
            $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);
            $this->assertTrue(false, 'No exception was thrown although there is an invalid value');
        } catch (WriteException $exception) {
            $this->assertStringContainsString('Invalid value for the field "seo_option"', $exception->getMessage());
        }
    }

    private function getDummySeoBulkTemplateEntity(): DreiscSeoBulkTemplateEntity
    {
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE)
            ->setName('My Bulk Template');

        return $dreiscSeoBulkTemplateEntity;
    }
}
