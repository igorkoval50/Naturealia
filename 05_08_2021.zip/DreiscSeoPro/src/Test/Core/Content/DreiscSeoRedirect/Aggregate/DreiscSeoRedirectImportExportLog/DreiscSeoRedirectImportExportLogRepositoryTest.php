<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportLog;

use DreiscSeoPro\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportFile\Import\RowImporter;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportLog\DreiscSeoRedirectImportExportLogRepository;

class DreiscSeoRedirectImportExportLogRepositoryTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var DreiscSeoRedirectImportExportLogRepository
     */
    private $dreiscSeoRedirectImportExportLogRepository;

    /**
     * @var RowImporter
     */
    private $rowImporter;

    protected function setUp(): void
    {
        $this->dreiscSeoRedirectImportExportLogRepository = $this->getContainer()->get(DreiscSeoRedirectImportExportLogRepository::class);
        $this->rowImporter = $this->getContainer()->get(RowImporter::class);
    }

    public function test_getResult(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_ID => DemoDataIds::PRODUCT_SW_1000,
            RowImporter::HEADER__TARGET_PRODUCT_ID => DemoDataIds::PRODUCT_SW_1001
        ], 1);

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_ID => DemoDataIds::PRODUCT_SW_1001,
            RowImporter::HEADER__TARGET_PRODUCT_ID => DemoDataIds::PRODUCT_SW_1002
        ], 2);

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_ID => 'INVALID UUID',
            RowImporter::HEADER__TARGET_PRODUCT_ID => DemoDataIds::PRODUCT_SW_1002
        ], 3);

        $result = $this->dreiscSeoRedirectImportExportLogRepository->getResult();

        $this->assertSame(3, $result['total']);
        $this->assertSame(1, $result['errors']);
    }
}
