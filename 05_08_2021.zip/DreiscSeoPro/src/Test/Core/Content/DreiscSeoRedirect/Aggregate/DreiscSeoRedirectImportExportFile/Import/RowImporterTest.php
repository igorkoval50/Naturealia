<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportFile\Import;

use DreiscSeoPro\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportLog\DreiscSeoRedirectImportExportLogEntity;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportLog\DreiscSeoRedirectImportExportLogRepository;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectEnum;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportFile\Import\RowImporter;
use Shopware\Core\Framework\Uuid\Uuid;

class RowImporterTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var RowImporter
     */
    private $rowImporter;

    /**
     * @var DreiscSeoRedirectImportExportLogRepository
     */
    private $dreiscSeoRedirectImportExportLogRepository;

    protected function setUp(): void
    {
        $this->rowImporter = $this->getContainer()->get(RowImporter::class);
        $this->dreiscSeoRedirectImportExportLogRepository = $this->getContainer()->get(DreiscSeoRedirectImportExportLogRepository::class);

        $this->dreiscSeoRedirectImportExportLogRepository->truncate();
    }

    public function test_noHeadlineException(): void
    {
        $this->expectExceptionMessage('MISSING_HEADER');
        $this->rowImporter->import([
            'test' => '1'
        ], 1);
    }

    /**
     * Check if the default values of the redirect are set
     */
    public function test_defaults(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $dreiscSeoRedirect = $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect();
        $this->assertTrue($dreiscSeoRedirect->getActive());
        $this->assertSame('301', $dreiscSeoRedirect->getRedirectHttpStatusCode());
    }

    /**
     * Check if the can override the default values
     */
    public function test_deviant_defaults(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
            RowImporter::HEADER__ACTIVE => '0',
            RowImporter::HEADER__HTTP_STATUS_CODE => '302',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $dreiscSeoRedirect = $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect();
        $this->assertFalse($dreiscSeoRedirect->getActive());
        $this->assertSame('302', $dreiscSeoRedirect->getRedirectHttpStatusCode());
    }

    /**
     * Check for invalid http status code error
     */
    public function test_302_http_status_code(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
            RowImporter::HEADER__ACTIVE => '0',
            RowImporter::HEADER__HTTP_STATUS_CODE => '302',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            '302',
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectHttpStatusCode()
        );
    }

    /**
     * Check for invalid http status code error
     */
    public function test_invalid_http_status_code(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
            RowImporter::HEADER__ACTIVE => '0',
            RowImporter::HEADER__HTTP_STATUS_CODE => '404',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_HTTP_STATUS_CODE,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            '404',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['httpStatusCode']
        );
    }

    /**
     * Check the error, if no source is defined
     */
    public function test_missing_source(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__MISSING_SOURCE,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );
    }

    /**
     * Check the error, if no target is defined
     */
    public function test_missing_target(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1001',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__MISSING_TARGET,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );
    }

    /**
     * Check error for invalid product numbers
     */
    public function test_invalid_source_product_number(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'INVALID_ID',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001'
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_SOURCE_PRODUCT_NUMBER,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            'INVALID_ID',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['productNumber']
        );
    }

    /**
     * Check error for invalid product numbers
     */
    public function test_invalid_target_product_number(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1001',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'INVALID_ID'
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_TARGET_PRODUCT_NUMBER,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            'INVALID_ID',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['productNumber']
        );
    }

    public function test_source_internal_url(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_INTERNAL_URL => 'http://www.shopware-dev.de/redirect-test',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $dreiscSeoRedirect = $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect();

        $this->assertSame('url', $dreiscSeoRedirect->getSourceType());
    }

    public function test_source_internal_url_redirect_home(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_INTERNAL_URL => 'http://www.shopware-dev.de',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_SOURCE_INTERNAL_URL_EMPTY_BASE_URL,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            'http://www.shopware-dev.de',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['url']
        );
    }

    public function test_source_internal_url_redirect_invalid(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_INTERNAL_URL => 'http://de.invalid.de/this-is-a-test',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_SOURCE_INTERNAL_URL,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            'http://de.invalid.de/this-is-a-test',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['url']
        );
    }

    public function test_source_category(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_CATEGORY_ID => DemoDataIds::CATEGORY__MAIN__PRODUCTS,
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            'category',
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceType()
        );

        $this->assertSame(
            DemoDataIds::CATEGORY__MAIN__PRODUCTS,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceCategoryId()
        );
    }

    public function test_invalid_source_category(): void
    {
        $invalidCategoryId = Uuid::randomHex();

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_CATEGORY_ID => $invalidCategoryId,
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1001',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_SOURCE_CATEGORY_ID__NOT_FOUND,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            $invalidCategoryId,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['categoryId']
        );
    }

    public function test_target_internal_url(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1004',
            RowImporter::HEADER__TARGET_INTERNAL_URL => 'http://www.shopware-dev.de/en/Products',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $dreiscSeoRedirect = $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect();

        $this->assertSame('url', $dreiscSeoRedirect->getRedirectType());
        $this->assertSame('Products', $dreiscSeoRedirect->getRedirectPath());
    }

    public function test_target_internal_url_home(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1004',
            RowImporter::HEADER__TARGET_INTERNAL_URL => 'http://www.shopware-dev.de/en/',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            DreiscSeoRedirectEnum::REDIRECT_TYPE__URL,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectType()
        );

        $this->assertSame(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE_EN,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectSalesChannelDomainId()
        );

        $this->assertNull(
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectPath()
        );
    }

    public function test_target_internal_url_invalid(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1004',
            RowImporter::HEADER__TARGET_INTERNAL_URL => 'http://de.dreischild.de/test-url',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_TARGET_INTERNAL_URL,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            'http://de.dreischild.de/test-url',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['url']
        );
    }

    public function test_target_category(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1001',
            RowImporter::HEADER__TARGET_CATEGORY_ID => DemoDataIds::CATEGORY__MAIN__PRODUCTS,
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            'category',
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectType()
        );

        $this->assertSame(
            DemoDataIds::CATEGORY__MAIN__PRODUCTS,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectCategoryId()
        );
    }

    public function test_invalid_target_category(): void
    {
        $invalidCategoryId = Uuid::randomHex();

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1001',
            RowImporter::HEADER__TARGET_CATEGORY_ID => $invalidCategoryId,
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_TARGET_CATEGORY_ID__NOT_FOUND,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            $invalidCategoryId,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['categoryId']
        );
    }

    public function test_target_external_url(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1001',
            RowImporter::HEADER__TARGET_EXTERNAL_URL => 'http://de.dreischild.com',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            'externalUrl',
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectType()
        );

        $this->assertSame(
            'http://de.dreischild.com',
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectUrl()
        );
    }

    public function test_source_productId(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_ID => DemoDataIds::PRODUCT_SW_1000,
            RowImporter::HEADER__TARGET_EXTERNAL_URL => 'http://de.dreischild.com',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            'product',
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceType()
        );

        $this->assertSame(
            DemoDataIds::PRODUCT_SW_1000,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceProductId()
        );
    }

    public function test_source_productId__not_found(): void
    {
        $notFoundUuid = Uuid::randomHex();

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_ID => $notFoundUuid,
            RowImporter::HEADER__TARGET_EXTERNAL_URL => 'http://de.dreischild.com',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            RowImporter::ERROR__INVALID_SOURCE_PRODUCT_ID__NOT_FOUND,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            $notFoundUuid,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['productId']
        );
    }

    public function test_source_productId__invalid_uuid(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_ID => 'INVALID UUID',
            RowImporter::HEADER__TARGET_EXTERNAL_URL => 'http://de.dreischild.com',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            RowImporter::ERROR__INVALID_SOURCE_PRODUCT_ID__UUID_FORMAT,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            'invalid uuid',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['productId']
        );
    }

    public function test_target_productId(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_ID => DemoDataIds::PRODUCT_SW_1006_2,
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            'product',
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectType()
        );

        $this->assertSame(
            DemoDataIds::PRODUCT_SW_1006_2,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectProductId()
        );
    }

    public function test_target_productId__not_found(): void
    {
        $notFoundUuid = Uuid::randomHex();

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_ID => $notFoundUuid,
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            RowImporter::ERROR__INVALID_TARGET_PRODUCT_ID__NOT_FOUND,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            $notFoundUuid,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['productId']
        );
    }

    public function test_target_productId__invalid_uuid(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_ID => 'INVALID UUID',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            RowImporter::ERROR__INVALID_TARGET_PRODUCT_ID__UUID_FORMAT,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            'invalid uuid',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['productId']
        );
    }

    public function test_multi_errors(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__HTTP_STATUS_CODE => '404',
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1001-INVALD',
            RowImporter::HEADER__TARGET_INTERNAL_URL => 'http://de.dreischild.com',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        /** Check if there a three errors */
        $this->assertCount(3, $dreiscSeoRedirectImportExportLogEntity->getErrors());
    }

    public function test_invalid_source_category_id(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_CATEGORY_ID => 'INVALID SOURCE CATEGORY UUID',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1000',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_SOURCE_CATEGORY_ID__UUID_FORMAT,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );
    }

    public function test_invalid_target_category_id(): void
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_CATEGORY_ID => 'INVALID SOURCE CATEGORY UUID',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            RowImporter::ERROR__INVALID_TARGET_CATEGORY_ID__UUID_FORMAT,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );
    }

    public function test_source_same_columns()
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_CATEGORY_ID => DemoDataIds::CATEGORY__MAIN__PRODUCTS,
        ], 1);

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_CATEGORY_ID => DemoDataIds::CATEGORY__MAIN__PRODUCTS,
        ], 2);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(2);

        $this->assertSame(
            RowImporter::ERROR__SOURCE_ALREADY_EXISTS,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

    }

    public function test_source_already_exists()
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_CATEGORY_ID => DemoDataIds::CATEGORY__MAIN__PRODUCTS,
        ], 1);
        $dreiscSeoRedirectImportExportLogEntityFirst = $this->getLogByRowIndex(1);

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_CATEGORY_ID => DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
        ], 2);
        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(2);

        $this->assertSame(
            RowImporter::ERROR__SOURCE_ALREADY_EXISTS,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            $dreiscSeoRedirectImportExportLogEntityFirst->getDreiscSeoRedirect()->getId(),
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['dreiscSeoRedirectId']
        );
    }

    public function test_target_deviating_product()
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1004',
            RowImporter::HEADER__TARGET_DEVIATING_DOMAIN => 'http://www.shopware-dev.de/en'
        ], 1);
        $dreiscSeoRedirectImportExportLogEntityFirst = $this->getLogByRowIndex(1);

        $this->assertSame(
            DemoDataIds::PRODUCT_SW_1000,
            $dreiscSeoRedirectImportExportLogEntityFirst->getDreiscSeoRedirect()->getSourceProductId()
        );

        $this->assertSame(
            DemoDataIds::PRODUCT_SW_1004,
            $dreiscSeoRedirectImportExportLogEntityFirst->getDreiscSeoRedirect()->getRedirectProductId()
        );

        $this->assertSame(
            true,
            $dreiscSeoRedirectImportExportLogEntityFirst->getDreiscSeoRedirect()->getHasDeviatingRedirectSalesChannelDomain()
        );

        $this->assertSame(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE_EN,
            $dreiscSeoRedirectImportExportLogEntityFirst->getDreiscSeoRedirect()->getDeviatingRedirectSalesChannelDomainId()
        );
    }

    public function test_target_deviating_category()
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_CATEGORY_ID => DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS,
            RowImporter::HEADER__TARGET_DEVIATING_DOMAIN => 'http://www.shopware-dev.de/en'
        ], 1);
        $dreiscSeoRedirectImportExportLogEntityFirst = $this->getLogByRowIndex(1);

        $this->assertSame(
            DemoDataIds::PRODUCT_SW_1000,
            $dreiscSeoRedirectImportExportLogEntityFirst->getDreiscSeoRedirect()->getSourceProductId()
        );

        $this->assertSame(
            DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS,
            $dreiscSeoRedirectImportExportLogEntityFirst->getDreiscSeoRedirect()->getRedirectCategoryId()
        );

        $this->assertSame(
            true,
            $dreiscSeoRedirectImportExportLogEntityFirst->getDreiscSeoRedirect()->getHasDeviatingRedirectSalesChannelDomain()
        );

        $this->assertSame(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE_EN,
            $dreiscSeoRedirectImportExportLogEntityFirst->getDreiscSeoRedirect()->getDeviatingRedirectSalesChannelDomainId()
        );
    }

    public function test_target_invalid_deviating_product()
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1004',
            RowImporter::HEADER__TARGET_DEVIATING_DOMAIN => 'http://de.dreischild.com/en'
        ], 1);
        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            RowImporter::ERROR__INVALID_DEVIATING_DOMAIN,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            'http://de.dreischild.com/en',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['deviatingDomain']
        );
    }

    public function test_source_restriction_ids_product()
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1006',
            RowImporter::HEADER__SOURCE_RESTRICTION_DOMAINS => 'http://www.shopware-dev.de|http://www.shopware-dev.de/en'
        ], 1);
        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            DemoDataIds::PRODUCT_SW_1000,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceProductId()
        );

        $this->assertSame(
            DemoDataIds::PRODUCT_SW_1006,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectProductId()
        );

        $this->assertTrue(
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getHasSourceSalesChannelDomainRestriction()
        );

        $this->assertIsArray(
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceSalesChannelDomainRestrictionIds()
        );

        /** Check restriction ids */
        $restrictionDomainIds = $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceSalesChannelDomainRestrictionIds();
        $this->assertCount(2, $restrictionDomainIds);

        $this->assertContains(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE, $restrictionDomainIds
        );

        $this->assertContains(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE_EN, $restrictionDomainIds
        );
    }

    public function test_source_restriction_ids_category()
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_CATEGORY_ID => DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS,
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1006',
            RowImporter::HEADER__SOURCE_RESTRICTION_DOMAINS => 'http://www.shopware-dev.de|http://www.shopware-dev.de/en'
        ], 1);
        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceCategoryId()
        );

        $this->assertSame(
            DemoDataIds::PRODUCT_SW_1006,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectProductId()
        );

        $this->assertTrue(
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getHasSourceSalesChannelDomainRestriction()
        );

        $this->assertIsArray(
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceSalesChannelDomainRestrictionIds()
        );

        /** Check restriction ids */
        $restrictionDomainIds = $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceSalesChannelDomainRestrictionIds();
        $this->assertCount(2, $restrictionDomainIds);

        $this->assertContains(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE, $restrictionDomainIds
        );

        $this->assertContains(
            DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE_EN, $restrictionDomainIds
        );
    }

    public function test_source_invalid_restriction_ids_product()
    {
        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1006',
            RowImporter::HEADER__SOURCE_RESTRICTION_DOMAINS => 'http://www.shopware-dev.de|http://de.dreischild.com/en'
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);

        $this->assertSame(
            RowImporter::ERROR__INVALID_RESTRICTION_DOMAIN,
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['error']
        );

        $this->assertSame(
            'http://de.dreischild.com/en',
            $dreiscSeoRedirectImportExportLogEntity->getErrors()[0]['params']['restrictionDomain']
        );
    }

    public function test_whitespaces()
    {
        $this->rowImporter->import([
            '  ' . RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000 ',
            '  ' . RowImporter::HEADER__TARGET_INTERNAL_URL => '  http://www.shopware-dev.de/test-it',
        ], 1);

        $dreiscSeoRedirectImportExportLogEntity = $this->getLogByRowIndex(1);
        $this->assertNotNull($dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect());

        $this->assertSame(
            DemoDataIds::PRODUCT_SW_1000,
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getSourceProductId()
        );

        $this->assertSame(
            'test-it',
            $dreiscSeoRedirectImportExportLogEntity->getDreiscSeoRedirect()->getRedirectPath()
        );
    }

    /**
     * @param int $rowIndex
     * @return DreiscSeoRedirectImportExportLogEntity
     */
    private function getLogByRowIndex(int $rowIndex): DreiscSeoRedirectImportExportLogEntity
    {
        $dreiscSeoRedirectImportExportLogEntity = $this->dreiscSeoRedirectImportExportLogRepository
            ->getByRowIndex($rowIndex);

        $this->assertNotNull($dreiscSeoRedirectImportExportLogEntity);

        return $dreiscSeoRedirectImportExportLogEntity;
    }
}
