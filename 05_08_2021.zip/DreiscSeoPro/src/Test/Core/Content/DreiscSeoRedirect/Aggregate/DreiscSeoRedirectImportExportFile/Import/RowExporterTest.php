<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportFile\Import;

use DreiscSeoPro\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportFile\Import\RowImporter;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Content\ImportExport\Struct\Progress;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportFile\Import\RowExporter;
use Shopware\Core\Framework\Uuid\Uuid;

class RowExporterTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var RowExporter
     */
    private $rowExporter;

    /**
     * @var RowImporter
     */
    private $rowImporter;

    protected function setUp(): void
    {
        $this->rowExporter = $this->getContainer()->get(RowExporter::class);
        $this->rowImporter = $this->getContainer()->get(RowImporter::class);
    }

    public function test_row_exporter(): void
    {
        $this->generateDummyRedirects();
        $fileId = Uuid::randomHex();

        $progress = new Progress(
            $fileId,
            Progress::STATE_PROGRESS
        );

        $rowExportResultStructs = $this->rowExporter->export(
            $progress,
            0,
            25
        );

        /** Check total value */
        $this->assertCount(4, $rowExportResultStructs);

        /** Active */
        $this->assertSame('0', $rowExportResultStructs[0]->getActive());
        $this->assertSame('1', $rowExportResultStructs[1]->getActive());

        /** HttpStatusCode */
        $this->assertSame('302', $rowExportResultStructs[0]->getHttpStatusCode());
        $this->assertSame('301', $rowExportResultStructs[1]->getHttpStatusCode());

        /** Source product number */
        $this->assertSame('SW-1000', $rowExportResultStructs[0]->getSourceProductNumber());

        /** Source category id */
        $this->assertSame(DemoDataIds::CATEGORY__MAIN__PRODUCTS, $rowExportResultStructs[3]->getSourceCategoryId());

        /** Source internal url */
        $this->assertSame('http://www.shopware-dev.de/meine-url', $rowExportResultStructs[2]->getSourceInternalUrl());

        /** Target product number */
        $this->assertSame('SW-1004', $rowExportResultStructs[0]->getTargetProductNumber());

        /** Target category number */
        $this->assertSame(DemoDataIds::CATEGORY__MAIN__PRODUCTS, $rowExportResultStructs[1]->getTargetCategoryId());

        /** Target internal url */
        $this->assertSame('http://www.shopware-dev.de/meine-url-target', $rowExportResultStructs[3]->getTargetInternalUrl());

        /** Target external url */
        $this->assertSame('http://de.dreischild.com', $rowExportResultStructs[2]->getTargetExternalUrl());

        /** Deviating domain */
        $this->assertSame('http://www.shopware-dev.de',$rowExportResultStructs[0]->getTargetDeviatingDomain());

        /** Restriction domains */
        $this->assertSame('http://www.shopware-dev.de|http://www.shopware-dev.de/en',$rowExportResultStructs[1]->getSourceRestrictionDomains());
    }

    private function generateDummyRedirects()
    {
        $this->rowImporter->import([
            RowImporter::HEADER__ACTIVE => 0,
            RowImporter::HEADER__HTTP_STATUS_CODE => '302',
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1000',
            RowImporter::HEADER__TARGET_PRODUCT_NUMBER => 'SW-1004',
            RowImporter::HEADER__TARGET_DEVIATING_DOMAIN => 'http://www.shopware-dev.de'
        ], 0);

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_PRODUCT_NUMBER => 'SW-1001',
            RowImporter::HEADER__SOURCE_RESTRICTION_DOMAINS => 'http://www.shopware-dev.de|http://www.shopware-dev.de/en',
            RowImporter::HEADER__TARGET_CATEGORY_ID => DemoDataIds::CATEGORY__MAIN__PRODUCTS
        ], 1);

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_INTERNAL_URL => 'http://www.shopware-dev.de/meine-url',
            RowImporter::HEADER__TARGET_EXTERNAL_URL => 'http://de.dreischild.com'
        ], 2);

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_CATEGORY_ID => DemoDataIds::CATEGORY__MAIN__PRODUCTS,
            RowImporter::HEADER__TARGET_INTERNAL_URL => 'http://www.shopware-dev.de/meine-url-target'
        ], 3);
    }
}
