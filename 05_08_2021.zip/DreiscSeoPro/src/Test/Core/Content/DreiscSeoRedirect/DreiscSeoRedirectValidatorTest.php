<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Content\DreiscSeoRedirect;

use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectEntity;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectEnum;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectRepository;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectValidator;
use DreiscSeoPro\Core\Content\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Write\WriteException;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\Framework\Validation\WriteConstraintViolationException;
use Shopware\Core\System\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainEntity;

class DreiscSeoRedirectValidatorTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var DreiscSeoRedirectRepository
     */
    private $dreiscSeoRedirectRepository;

    /**
     * @var SalesChannelDomainRepository
     */
    private $salesChannelDomainRepository;

    protected function setUp(): void
    {
        $this->dreiscSeoRedirectRepository = $this->getContainer()->get(DreiscSeoRedirectRepository::class);
        $this->salesChannelDomainRepository = $this->getContainer()->get(SalesChannelDomainRepository::class);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_validation(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Create a redirect with the dummy data */
        $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);

        $dreiscSeoRedirectSearchResult = $this->dreiscSeoRedirectRepository->search(
            new Criteria([ $dummySeoRedirectEntity->getId() ])
        );

        $this->assertSame(
            $dummySeoRedirectEntity->getId(),
            $dreiscSeoRedirectSearchResult->getEntities()->first()->getId()
        );
    }

    /**
     * Check if the source type is defined
     * @throws InconsistentCriteriaIdsException
     */
    public function test_missing_source_type(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Remove the source type to check if an exception will be thrown */
        $dummySeoRedirectEntity->setSourceType('');

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_SHOULD_NOT_BE_BLANK,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * Check if the redirect type is defined
     * @throws InconsistentCriteriaIdsException
     */
    public function test_missing_redirect_type(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Remove the redirect type to check if an exception will be thrown */
        $dummySeoRedirectEntity->setRedirectType('');

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_SHOULD_NOT_BE_BLANK,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * Check if the redirect type is defined
     * @throws InconsistentCriteriaIdsException
     */
    public function test_missing_redirect_http_status_code(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Remove the redirect type to check if an exception will be thrown */
        $dummySeoRedirectEntity->setRedirectHttpStatusCode('');

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_SHOULD_NOT_BE_BLANK,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * Check if the source type validation works
     * @throws InconsistentCriteriaIdsException
     */
    public function test_invalid_source_type(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Remove the source type to check if an exception will be thrown */
        $dummySeoRedirectEntity->setSourceType('invalidType');

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_INVALID_VALUE_FOR_THE_FIELD,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * Check if the redirect type validation works
     * @throws InconsistentCriteriaIdsException
     */
    public function test_invalid_redirect_type(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Remove the redirect type to check if an exception will be thrown */
        $dummySeoRedirectEntity->setRedirectType('invalidType');

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_INVALID_VALUE_FOR_THE_FIELD,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * Check if the fields for the source type "url" are set
     * @throws InconsistentCriteriaIdsException
     */
    public function test_check_field_for_source_type_url(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Remove the source path to check if an exception will be thrown */
        $dummySeoRedirectEntity->setSourcePath('');

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_HAS_SPECIAL_VALUE_AND_OTHER_FIELDS_ARE_REQUIRED,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * Check if the fields for the redirect type "externalUrl"
     * @throws InconsistentCriteriaIdsException
     */
    public function test_check_field_for_redirect_type_external_url(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Set the redirect type */
        $dummySeoRedirectEntity->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__EXTERNAL_URL);

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_HAS_SPECIAL_VALUE_AND_OTHER_FIELDS_ARE_REQUIRED,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * Check if the fields for the redirect type "product"
     * @throws InconsistentCriteriaIdsException
     */
    public function test_check_field_for_redirect_type_product(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Set the redirect type */
        $dummySeoRedirectEntity->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__PRODUCT);

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_HAS_SPECIAL_VALUE_AND_OTHER_FIELDS_ARE_REQUIRED,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * Check if the fields for the source type "product"
     * @throws InconsistentCriteriaIdsException
     */
    public function test_check_field_for_source_type_product(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Set the source type */
        $dummySeoRedirectEntity->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__PRODUCT);

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_HAS_SPECIAL_VALUE_AND_OTHER_FIELDS_ARE_REQUIRED,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * Check if the fields for the redirect type "category"
     * @throws InconsistentCriteriaIdsException
     */
    public function test_check_field_for_redirect_type_category(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Set the redirect type */
        $dummySeoRedirectEntity->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__CATEGORY);

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_HAS_SPECIAL_VALUE_AND_OTHER_FIELDS_ARE_REQUIRED,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    public function test_check_field_for_source_type_category(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Set the source type */
        $dummySeoRedirectEntity->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__CATEGORY);

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_HAS_SPECIAL_VALUE_AND_OTHER_FIELDS_ARE_REQUIRED,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_check_field_for_source_restriction(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Set hasSourceSalesChannelDomainRestriction to true */
        $dummySeoRedirectEntity->setHasSourceSalesChannelDomainRestriction(true);

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_HAS_SPECIAL_VALUE_AND_OTHER_FIELDS_ARE_REQUIRED,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_check_field_for_deviation_redirect_sales_channel_domain(): void
    {
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        /** Set hasSourceSalesChannelDomainRestriction to true */
        $dummySeoRedirectEntity->setHasDeviatingRedirectSalesChannelDomain(true);

        try {
            $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_FIELD_HAS_SPECIAL_VALUE_AND_OTHER_FIELDS_ARE_REQUIRED,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    public function test_source_path_slash(): void
    {
        $validSourcePath = 'my/redirect';
        $invalidSourcePath = '/my/redirect';
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        $dummySeoRedirectEntity->setSourcePath($validSourcePath);
        $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);

        try {
            $dummySeoRedirectEntity->setSourcePath($invalidSourcePath);
            $this->dreiscSeoRedirectRepository->update([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_SOURCE_PATH_SHOULD_NOT_START_WITH_SLASH,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    public function test_redirect_path_slash(): void
    {
        $validRedirectPath = 'my/redirect';
        $invalidRedirectPath = '/my/redirect';
        $dummySeoRedirectEntity = $this->getDummySeoRedirectEntity();

        $dummySeoRedirectEntity->setRedirectPath($validRedirectPath);
        $this->dreiscSeoRedirectRepository->create([ $dummySeoRedirectEntity ]);

        try {
            $dummySeoRedirectEntity->setRedirectPath($invalidRedirectPath);
            $this->dreiscSeoRedirectRepository->update([ $dummySeoRedirectEntity ]);
            $this->assertTrue(false, 'Test failed, because the write exception was not thrown');
        } catch (WriteException $writeException) {
            /** @var WriteConstraintViolationException $writeConstraintViolationException */
            $writeConstraintViolationException = current($writeException->getExceptions());

            $this->assertSame(
                DreiscSeoRedirectValidator::VIOLATION_REDIRECT_PATH_SHOULD_NOT_START_WITH_SLASH,
                $writeConstraintViolationException->getViolations()->get(0)->getCode()
            );
        }
    }

    /**
     * @return SalesChannelDomainEntity|null
     * @throws InconsistentCriteriaIdsException
     */
    private function getRandomSalesChannelDomain(): ?SalesChannelDomainEntity
    {
        $searchResult = $this->salesChannelDomainRepository->search(
            (new Criteria())->setLimit(1)
        );

        return $searchResult->getEntities()->first();
    }

    /**
     * Creates a valid redirect entity
     *
     * @return DreiscSeoRedirectEntity
     * @throws InconsistentCriteriaIdsException
     */
    private function getDummySeoRedirectEntity(): DreiscSeoRedirectEntity
    {
        $randomSalesChannelDomain = $this->getRandomSalesChannelDomain();

        return (new DreiscSeoRedirectEntity())
            ->setId(Uuid::randomHex())
            ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
            ->setActive(true)

            ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
            ->setSourceSalesChannelDomainId($randomSalesChannelDomain->getId())
            ->setSourcePath('my/source/path')

            ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__URL)
            ->setRedirectSalesChannelDomainId($randomSalesChannelDomain->getId())
            ->setRedirectPath('my/redirect/path');
    }
}
