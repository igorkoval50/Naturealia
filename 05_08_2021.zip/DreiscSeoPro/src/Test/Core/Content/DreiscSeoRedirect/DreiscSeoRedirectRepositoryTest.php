<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Content\DreiscSeoRedirect;

use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportFile\Import\RowImporter;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\Aggregate\DreiscSeoRedirectImportExportLog\DreiscSeoRedirectImportExportLogRepository;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectCollection;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectEntity;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectEnum;
use DreiscSeoPro\Core\Content\Product\ProductExtension;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Content\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainExtension;
use DreiscSeoPro\Core\Content\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\MultiFilter;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Content\DreiscSeoRedirect\DreiscSeoRedirectRepository;
use Shopware\Core\Framework\Uuid\Uuid;

class DreiscSeoRedirectRepositoryTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var DreiscSeoRedirectRepository
     */
    private $dreiscSeoRedirectRepository;

    /**
     * @var SalesChannelDomainRepository
     */
    private $salesChannelDomainRepository;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var RowImporter
     */
    private $rowImporter;

    /**
     * @var DreiscSeoRedirectImportExportLogRepository
     */
    private $dreiscSeoRedirectImportExportLogRepository;

    protected function setUp(): void
    {
        $this->dreiscSeoRedirectRepository = $this->getContainer()->get(DreiscSeoRedirectRepository::class);
        $this->salesChannelDomainRepository = $this->getContainer()->get(SalesChannelDomainRepository::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
        $this->rowImporter = $this->getContainer()->get(RowImporter::class);
        $this->dreiscSeoRedirectImportExportLogRepository = $this->getContainer()->get(DreiscSeoRedirectImportExportLogRepository::class);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_dreisc_seo_redirect_repository(): void
    {
        /** Test data */
        $testSourceUrl = 'my-redirect';
        $dreiscSeoRedirectId = Uuid::randomHex();

        /** Fetch the first sales channel domain, which we can get */
        $salesChannelDomainSearchResult = $this->salesChannelDomainRepository->search(
            (new Criteria())->setLimit(1)
        );

        $salesChannelDomain = $salesChannelDomainSearchResult->getEntities()->first();

        /** Create a new redirect */
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourcePath($testSourceUrl)
                ->setRedirectPath('my-redirect')
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain->getId())
                ->setRedirectSalesChannelDomainId($salesChannelDomain->getId())
        ]);

        /** Search for the id */
        $searchResult = $this->dreiscSeoRedirectRepository->search(
            new Criteria([ $dreiscSeoRedirectId ])
        );

        /** Check if the source url is set */
        $dreiscSeoRedirectEntity = $searchResult->getEntities()->first();
        $this->assertSame($testSourceUrl, $dreiscSeoRedirectEntity->getSourcePath());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_sales_channel_domain_association(): void
    {
        /** Test data */
        $testSourcePath = 'my-redirect';
        $dreiscSeoRedirectId = Uuid::randomHex();

        /** Fetch the first sales channel domain, which we can get */
        $salesChannelDomainSearchResult = $this->salesChannelDomainRepository->search(
            (new Criteria())->setLimit(1)
        );

        $salesChannelDomain = $salesChannelDomainSearchResult->getEntities()->first();

        /** Create a new redirect */
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($dreiscSeoRedirectId)
                ->setRedirectHttpStatusCode(DreiscSeoRedirectEnum::REDIRECT_HTTP_STATUS_CODE__301)
                ->setSourcePath($testSourcePath)
                ->setRedirectPath('my-redirect')
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__URL)
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__URL)
                ->setSourceSalesChannelDomainId($salesChannelDomain->getId())
                ->setRedirectSalesChannelDomainId($salesChannelDomain->getId())
        ]);

        /** Now we want to fetch the redirects from the domain association (extension) */
        $criteria = new Criteria();
        $criteria
            ->getAssociation(SalesChannelDomainExtension::DREISC_SEO_REDIRECTS_SOURCE_ASSOCIATION)
            ->addFilter(
                new EqualsFilter(
                    DreiscSeoRedirectEntity::SOURCE_PATH__PROPERTY_NAME,
                    $testSourcePath
                )
            );

        $salesChannelDomainSearchResult = $this->salesChannelDomainRepository->search(
            $criteria
        );

        /** Check the value */
        $salesChannelDomainEntity = $salesChannelDomainSearchResult->getEntities()->first();

        /** @var DreiscSeoRedirectCollection $dreiscSeoRedirectCollection */
        $dreiscSeoRedirectCollection = $salesChannelDomainEntity->getExtension(
            SalesChannelDomainExtension::DREISC_SEO_REDIRECTS_SOURCE_ASSOCIATION
        );

        $this->assertSame($testSourcePath, $dreiscSeoRedirectCollection->first()->getSourcePath());
    }

    /**
     * Test if the can read the source and redirect products from product side
     *
     * @throws InconsistentCriteriaIdsException
     */
    public function test_source_and_redirect_product_associations(): void
    {
        $redirectId = Uuid::randomHex();

        /** Fetch the first two products we can fetch */
        $productSearchResult = $this->productRepository->search(
            (new Criteria())->setLimit(2)
        );

        $testSourceProduct = null;
        $testRedirectProduct = null;
        foreach ($productSearchResult->getEntities() as $product) {
            if(null === $testSourceProduct) {
                $testSourceProduct = $product;
            } else {
                $testRedirectProduct = $product;
            }
        }

        /** Create the redirect */
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($redirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode('301')
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__PRODUCT)
                ->setSourceProductId($testSourceProduct->getId())
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__PRODUCT)
                ->setRedirectProductId($testRedirectProduct->getId())
        ]);

        /** Check the redirect entry */
        $redirectSearchResult = $this->dreiscSeoRedirectRepository->search(
            (new Criteria([ $redirectId ]))
                ->addAssociation(DreiscSeoRedirectEntity::SOURCE_PRODUCT__PROPERTY_NAME)
                ->addAssociation(DreiscSeoRedirectEntity::REDIRECT_PRODUCT__PROPERTY_NAME)
        );

        $redirect = $redirectSearchResult->getEntities()->first();

        /** Assert the tests */
        $this->assertSame($testSourceProduct->getId(), $redirect->getSourceProduct()->getId());
        $this->assertSame($testRedirectProduct->getId(), $redirect->getRedirectProduct()->getId());

        /**
         * Check the "source product from the product side
         */
        $productSearchResult = $this->productRepository->search(
            (new Criteria([ $testSourceProduct->getId() ]))
                ->addAssociation(ProductExtension::DREISC_SEO_REDIRECTS_SOURCE_ASSOCIATION)
        );

        $product = $productSearchResult->getEntities()->first();

        /** Check if the redirect is available */
        /** @var DreiscSeoRedirectCollection $redirectCollection */
        $redirectCollection = $product->getExtension(ProductExtension::DREISC_SEO_REDIRECTS_SOURCE_ASSOCIATION);

        $idFound = false;
        foreach($redirectCollection as $redirectCollectionItem) {
            if($redirectId === $redirectCollectionItem->getId()) {
                $idFound = true;
            }
        }
        $this->assertTrue($idFound);

        /**
         * Check the "source product from the product side
         */
        $productSearchResult = $this->productRepository->search(
            (new Criteria([ $testRedirectProduct->getId() ]))
                ->addAssociation(ProductExtension::DREISC_SEO_REDIRECTS_REDIRECT_ASSOCIATION)
        );

        $product = $productSearchResult->getEntities()->first();

        /** Check if the redirect is available */
        /** @var DreiscSeoRedirectCollection $redirectCollection */
        $redirectCollection = $product->getExtension(ProductExtension::DREISC_SEO_REDIRECTS_REDIRECT_ASSOCIATION);
        $this->assertSame($redirectId, $redirectCollection->first()->getId());
    }

    public function test_ifWeCanDeleteProductWithRedirect(): void
    {
        $redirectId = Uuid::randomHex();

        /** Create the redirect */
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($redirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode('301')
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__PRODUCT)
                ->setSourceProductId(DemoDataIds::PRODUCT_SW_1000)
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__PRODUCT)
                ->setRedirectProductId(DemoDataIds::PRODUCT_SW_1001)
        ]);

        /** Check, if the entry is set */
        $checkDreiscSeoRedirectEntity = $this->dreiscSeoRedirectRepository->get($redirectId);
        $this->assertNotNull($checkDreiscSeoRedirectEntity);
        $this->assertSame($redirectId, $checkDreiscSeoRedirectEntity->getId());

        /** Delete the product */
        $this->productRepository->deleteById(DemoDataIds::PRODUCT_SW_1000);

        /** Check, if the product was deleted */
        $productEntity = $this->productRepository->get(DemoDataIds::PRODUCT_SW_1000);
        $this->assertNull($productEntity);
    }

    public function test_ifWeCanDeleteCategoryWithRedirect(): void
    {
        $redirectId = Uuid::randomHex();

        /** Create the redirect */
        $this->dreiscSeoRedirectRepository->create([
            (new DreiscSeoRedirectEntity())
                ->setId($redirectId)
                ->setActive(true)
                ->setRedirectHttpStatusCode('301')
                ->setSourceType(DreiscSeoRedirectEnum::SOURCE_TYPE__CATEGORY)
                ->setSourceCategoryId(DemoDataIds::CATEGORY__MAIN__PRODUCTS)
                ->setRedirectType(DreiscSeoRedirectEnum::REDIRECT_TYPE__CATEGORY)
                ->setRedirectCategoryId(DemoDataIds::CATEGORY__GBSHOP__PRODUCTS)
        ]);

        /** Check, if the entry is set */
        $checkDreiscSeoRedirectEntity = $this->dreiscSeoRedirectRepository->get($redirectId);
        $this->assertNotNull($checkDreiscSeoRedirectEntity);
        $this->assertSame($redirectId, $checkDreiscSeoRedirectEntity->getId());

        /** Delete the product */
        $this->categoryRepository->deleteById(DemoDataIds::CATEGORY__MAIN__PRODUCTS);

        /** Check, if the category was deleted */
        $categoryEntity = $this->categoryRepository->get(DemoDataIds::CATEGORY__MAIN__PRODUCTS);
        $this->assertNull($categoryEntity);
    }

    public function test_isDeletableIfARedirectLogReferenceThRedirect(): void
    {
        $sourcePath = 'http://www.shopware-dev.de/my-internal-id';

        $this->rowImporter->import([
            RowImporter::HEADER__SOURCE_INTERNAL_URL => $sourcePath,
            RowImporter::HEADER__TARGET_CATEGORY_ID => DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS,
        ], 1000);

        $dreiscSeoRedirectImportExportLog = $this->dreiscSeoRedirectImportExportLogRepository->getByRowIndex(1000);
        $this->assertNotNull($dreiscSeoRedirectImportExportLog->getDreiscSeoRedirect());

        /** Try to remove */
        $this->dreiscSeoRedirectRepository->plainDeleteById(
            $dreiscSeoRedirectImportExportLog->getDreiscSeoRedirect()->getId()
        );

        /** Done. There was no DAL FK exception */
        $this->assertTrue(true);
    }
}
