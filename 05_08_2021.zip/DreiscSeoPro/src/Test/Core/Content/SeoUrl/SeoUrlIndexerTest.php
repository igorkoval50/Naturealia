<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Content\SeoUrl;

use DreiscSeoPro\Core\Content\Category\CategoryIndexer;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkRepository;
use DreiscSeoPro\Core\Content\Product\ProductIndexer;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Content\SeoUrlTemplate\SeoUrlTemplateRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\CategorySeoDataFetcher;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\ProductSeoDataFetcher;
use DreiscSeoPro\Core\Seo\SeoDataSaver;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;
use Shopware\Core\Framework\Uuid\Uuid;

class SeoUrlIndexerTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var DreiscSeoBulkRepository
     */
    private $dreiscSeoBulkRepository;

    /**
     * @var DreiscSeoBulkTemplateRepository
     */
    private $dreiscSeoBulkTemplateRepository;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var ProductSeoDataFetcher
     */
    private $productSeoDataFetcher;

    /**
     * @var CategorySeoDataFetcher
     */
    private $categorySeoDataFetcher;

    /**
     * @var SeoDataSaver
     */
    private $seoDataSaver;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    /**
     * @var SeoUrlTemplateRepository
     */
    private $seoUrlTemplateRepository;

    protected function setUp(): void
    {
        $this->dreiscSeoBulkRepository = $this->getContainer()->get(DreiscSeoBulkRepository::class);
        $this->dreiscSeoBulkTemplateRepository = $this->getContainer()->get(DreiscSeoBulkTemplateRepository::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->productSeoDataFetcher = $this->getContainer()->get(ProductSeoDataFetcher::class);
        $this->categorySeoDataFetcher = $this->getContainer()->get(CategorySeoDataFetcher::class);
        $this->seoDataSaver = $this->getContainer()->get(SeoDataSaver::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
        $this->seoUrlTemplateRepository = $this->getContainer()->get(SeoUrlTemplateRepository::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
    }

    /**
     * Tests if the url will be changed by the indexer after saving the product
     *
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws \Exception
     */
    public function test_indexRefresh_url_product(): void
    {
        $randomInt = random_int(10, 100000);
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $productId = DemoDataIds::PRODUCT_SW_1000;
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;

        /** Create a template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__URL)
            ->setName('My Bulk Template')
            ->setTemplate('REFRESH-URL - {{ product.productNumber }}-' . $randomInt);

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setSalesChannelId(DemoDataIds::SALES_CHANNEL__MAIN_SHOP)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__URL)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Update the product to trigger the refresh progress */
        $this->productRepository->update([
            [
                'id' => $productId,
                'stock' => random_int(500, 9999)
            ]
        ]);

        /** Check, if the new url was set by indexer */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Check the url */
        $this->assertSame('refresh-url-sw-1000-' . $randomInt, $seoDataFetchResultStruct->getUrl());
    }

    /**
     * Tests if the url will be changed by the indexer after saving the category
     *
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws \Exception
     */
    public function test_indexRefresh_url_category(): void
    {
        $randomInt = random_int(10, 100000);
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;

        /** Create a template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__URL)
            ->setName('My Bulk Template')
            ->setTemplate('REFRESH-URL - {{ category.id }}-' . $randomInt);

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setSalesChannelId(DemoDataIds::SALES_CHANNEL__MAIN_SHOP)
            ->setArea(DreiscSeoBulkEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__URL)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit(true)
            ->setOverwrite(true);

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Update the category to trigger the refresh progress */
        $this->categoryRepository->update([
            [
                'id' => $categoryId,
                'stock' => random_int(500, 9999)
            ]
        ]);

        /** Check, if the new url was set by indexer */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            $categoryId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Check the url */
        $expectedUrl = sprintf('refresh-url-%s-%d', $categoryId, $randomInt);
        $this->assertSame($expectedUrl, $seoDataFetchResultStruct->getUrl());
    }
}
