<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Canonical;

use DreiscSeoPro\Core\Canonical\CanonicalFetcherStruct;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Canonical\CanonicalFetcher;
use Shopware\Core\Framework\Uuid\Uuid;

class CanonicalFetcherTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var CanonicalFetcher
     */
    private $canonicalFetcher;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    protected function setUp(): void
    {
        $this->canonicalFetcher = $this->getContainer()->get(CanonicalFetcher::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
    }

    public function testFetcherForNotExistingProduct(): void
    {
        $canonicalFetchResult = $this->canonicalFetcher->fetch(
            new CanonicalFetcherStruct(
                'product',
                Uuid::randomHex(),
                $this->demoDataRepository->getLanguageIdDe(),
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
                DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
            )
        );

        $this->assertNull($canonicalFetchResult);
    }

    public function testFetcherForNotExistingCategory(): void
    {
        $canonicalFetchResult = $this->canonicalFetcher->fetch(
            new CanonicalFetcherStruct(
                'category',
                Uuid::randomHex(),
                $this->demoDataRepository->getLanguageIdDe(),
                DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
                DemoDataIds::SALES_CHANNEL_DOMAIN__HTTP_WWW_SHOPWARE_DEV_DE
            )
        );

        $this->assertNull($canonicalFetchResult);
    }
}
