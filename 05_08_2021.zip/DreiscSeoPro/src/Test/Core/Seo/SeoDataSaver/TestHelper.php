<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Seo\SeoDataSaver;

use Doctrine\DBAL\Connection;
use Shopware\Core\Content\Category\Aggregate\CategoryTranslation\CategoryTranslationDefinition;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Uuid;

class TestHelper
{
    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @param string $categoryId
     * @param string $languageId
     * @return array
     * @throws InvalidUuidException
     */
    public function fetchCategoryTranslations(string $categoryId, string $languageId)
    {
        $result = $this->connection->createQueryBuilder()
            ->from(CategoryTranslationDefinition::ENTITY_NAME)
            ->select([
                CategoryTranslationDefinition::ENTITY_NAME . '.meta_title as metaTitle',
                CategoryTranslationDefinition::ENTITY_NAME . '.meta_description as metaDescription'
            ])
            ->where(CategoryTranslationDefinition::ENTITY_NAME . '.category_id = :categoryId')
            ->setParameter('categoryId', Uuid::fromHexToBytes($categoryId))
            ->andWhere(CategoryTranslationDefinition::ENTITY_NAME . '.language_id = :languageId')
            ->setParameter('languageId', Uuid::fromHexToBytes($languageId))
            ->execute()
            ->fetch();

        return $result;
    }
}
