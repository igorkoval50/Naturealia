<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Seo\SeoDataSaver\Saver\Category;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\CategorySeoDataFetcher;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\Struct\SeoDataFetchResultStruct;
use DreiscSeoPro\Core\Seo\SeoDataSaver;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Struct\SeoDataSaverStruct;
use DreiscSeoPro\Test\Core\Seo\SeoDataSaver\TestHelper;
use Shopware\Core\Content\Seo\SeoUrl\SeoUrlEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Saver\Category\UrlSaver;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;

class UrlSaverTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var UrlSaver
     */
    private $urlSaver;

    /**
     * @var SeoDataSaver
     */
    private $seoDataSaver;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var TestHelper
     */
    private $testHelper;

    /**
     * @var CategorySeoDataFetcher
     */
    private $categorySeoDataFetcher;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    protected function setUp(): void
    {
        $this->urlSaver = $this->getContainer()->get(UrlSaver::class);
        $this->seoDataSaver = $this->getContainer()->get(SeoDataSaver::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->testHelper = $this->getContainer()->get(TestHelper::class);
        $this->categorySeoDataFetcher = $this->getContainer()->get(CategorySeoDataFetcher::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
    }

    /**
     * @throws SeoDataSaver\Exception\UnknownAreaException
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_saver(): void
    {
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $secondCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;
        $salesChannelId = DemoDataIds::SALES_CHANNEL__MAIN_SHOP;
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Make sure, that there is no seo url for the current category */
        $this->seoUrlRepository->deleteByCriteria(
            (new Criteria())
                ->addFilter(
                    new EqualsFilter('routeName', SeoUrlRepository::ROUTE_NAME__FRONTEND_NAVIGATION_PAGE),
                    new EqualsFilter('foreignKey', $categoryId),
                    new EqualsFilter('salesChannelId', $salesChannelId)
                )
        );

        /** Check initial value */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch($categoryId, $languageIdDe, $salesChannelId);
        $this->assertNull($seoDataFetchResultStruct->getUrl());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedUrl());

        /** Set an url for "Deutsch" */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__URL,
                $languageIdDe,
                $salesChannelId,
                'Meine neuer URL',
                false
            )
        ]);

        /** Check, if the url is set */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch($categoryId, $languageIdDe, $salesChannelId);
        $this->assertSame('meine-neuer-url', $seoDataFetchResultStruct->getUrl());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedUrl());

        /** Set an url for "Deutsch" again » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__URL,
                $languageIdDe,
                $salesChannelId,
                'Meine neuer URL 2',
                false
            )
        ]);

        /** Check, if the value set */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch($categoryId, $languageIdDe, $salesChannelId);
        $this->assertSame('meine-neuer-url', $seoDataFetchResultStruct->getUrl());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedUrl());

        /** Set an url for "Deutsch" again » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__URL,
                $languageIdDe,
                $salesChannelId,
                'Meine neuer URL 2',
                true
            )
        ]);

        /** Check, if the value set */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch($categoryId, $languageIdDe, $salesChannelId);
        $this->assertSame('meine-neuer-url-2', $seoDataFetchResultStruct->getUrl());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedUrl());

        /** Check if the isCanonical = NULL Url still exists */
        $nonCanonicalSeoUrlSearchResult = $this->seoUrlRepository->getByContext(
            $languageIdDe,
            $salesChannelId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_NAVIGATION_PAGE,
            $categoryId,
            [ SeoUrlRepository::SEO_FILTER__IS_CANONICAL => null ]
        );

        $this->assertNotNull($nonCanonicalSeoUrlSearchResult);

        /** Check, if the old url is still there */
        /** @var SeoUrlEntity $nonCanonicalSeoUrlEntity */
        $oldUrlFound = false;
        foreach($nonCanonicalSeoUrlSearchResult as $nonCanonicalSeoUrlEntity) {
            $this->assertNull($nonCanonicalSeoUrlEntity->getIsCanonical());

            if('meine-neuer-url' === $nonCanonicalSeoUrlEntity->getSeoPathInfo()) {
                $oldUrlFound = true;
            }
        }

        /** Check if the entry was found */
        $this->assertTrue($oldUrlFound);

        /** Check that the url can not be set for another page */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $secondCategoryId, //<--- Here is the difference
                DreiscSeoBulkEnum::SEO_OPTION__URL,
                $languageIdDe,
                $salesChannelId,
                'Meine neuer URL 2',
                true
            )
        ]);

        /** Check, if the postfix is set */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch($secondCategoryId, $languageIdDe, $salesChannelId);
        $this->assertSame('meine-neuer-url-2-' . $secondCategoryId, $seoDataFetchResultStruct->getUrl());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedUrl());
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     */
    public function test_urlWithPostfixAlreadySet(): void
    {
        $baseCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $secondCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;
        $thirdCategoryId = DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES__WITHOUT_DE_TRANSLATION;
        $salesChannelId = DemoDataIds::SALES_CHANNEL__MAIN_SHOP;
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Set for the second category "my test url" */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $secondCategoryId,
                DreiscSeoBulkEnum::SEO_OPTION__URL,
                $languageIdDe,
                $salesChannelId,
                'my test url',
                true
            )
        ]);

        /** Set for the third category "my test url" + baseCategoryId */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $thirdCategoryId,
                DreiscSeoBulkEnum::SEO_OPTION__URL,
                $languageIdDe,
                $salesChannelId,
                'my test url-' . $baseCategoryId,
                true
            )
        ]);

        /** Set for the base category "my test url" */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $baseCategoryId,
                DreiscSeoBulkEnum::SEO_OPTION__URL,
                $languageIdDe,
                $salesChannelId,
                'my test url',
                true
            )
        ]);

        /** Check, the value » We except: my-test-url-[baseCategoryId]-[baseCategoryId] */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch($baseCategoryId, $languageIdDe, $salesChannelId);
        $expectedUrl = sprintf('my-test-url-%s-%s', $baseCategoryId, $baseCategoryId);
        $this->assertSame($expectedUrl, $seoDataFetchResultStruct->getUrl());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedUrl());
    }
}
