<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Seo\SeoDataSaver\Saver\Category;

use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataSaver;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Struct\SeoDataSaverStruct;
use DreiscSeoPro\Test\Core\Seo\SeoDataSaver\TestHelper;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Saver\Category\MetaTitleSaver;

class MetaTitleSaverTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var MetaTitleSaver
     */
    private $metaTitleSaver;

    /**
     * @var SeoDataSaver
     */
    private $seoDataSaver;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var TestHelper
     */
    private $testHelper;

    protected function setUp(): void
    {
        $this->metaTitleSaver = $this->getContainer()->get(MetaTitleSaver::class);
        $this->seoDataSaver = $this->getContainer()->get(SeoDataSaver::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->testHelper = $this->getContainer()->get(TestHelper::class);
    }

    public function test_saver(): void
    {
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /**
         * DE
         */

        /** Check, if the value is empty at the start */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdDe);
        $this->assertNull($categoryTranslations['metaTitle']);

        /** Set value for "Deutsch" */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                $languageIdDe,
                null,
                'Mein neuer Titel',
                false
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdDe);
        $this->assertSame('Mein neuer Titel', $categoryTranslations['metaTitle']);

        /** Set value for "Deutsch" » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                $languageIdDe,
                null,
                'Mein neuer Titel 2',
                false
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdDe);
        $this->assertSame('Mein neuer Titel', $categoryTranslations['metaTitle']);

        /** Set value for "Deutsch" » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                $languageIdDe,
                null,
                'Mein neuer Titel 2',
                true
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdDe);
        $this->assertSame('Mein neuer Titel 2', $categoryTranslations['metaTitle']);

        /**
         * EN
         */

        /** Check, if the value is empty at the start */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdEn);
        $this->assertNull($categoryTranslations['metaTitle']);

        /** Set value for "English" */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                $languageIdEn,
                null,
                'My new title',
                false
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdEn);
        $this->assertSame('My new title', $categoryTranslations['metaTitle']);

        /** Set value for "English" » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                $languageIdEn,
                null,
                'My new title 2',
                false
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdEn);
        $this->assertSame('My new title', $categoryTranslations['metaTitle']);

        /** Set value for "English" » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                $languageIdEn,
                null,
                'My new title 2',
                true
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdEn);
        $this->assertSame('My new title 2', $categoryTranslations['metaTitle']);
    }
}
