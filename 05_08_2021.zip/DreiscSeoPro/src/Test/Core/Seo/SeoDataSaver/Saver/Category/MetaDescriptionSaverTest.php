<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Seo\SeoDataSaver\Saver\Category;

use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataSaver;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Struct\SeoDataSaverStruct;
use DreiscSeoPro\Test\Core\Seo\SeoDataSaver\TestHelper;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Saver\Category\MetaDescriptionSaver;

class MetaDescriptionSaverTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var MetaDescriptionSaver
     */
    private $metaDescriptionSaver;

    /**
     * @var SeoDataSaver
     */
    private $seoDataSaver;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var TestHelper
     */
    private $testHelper;

    protected function setUp(): void
    {
        $this->metaDescriptionSaver = $this->getContainer()->get(MetaDescriptionSaver::class);
        $this->seoDataSaver = $this->getContainer()->get(SeoDataSaver::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->testHelper = $this->getContainer()->get(TestHelper::class);
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_saver(): void
    {
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /**
         * DE
         */

        /** Check, if the value is empty at the start */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdDe);
        $this->assertNull($categoryTranslations['metaDescription']);

        /** Set value for "Deutsch" */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
                $languageIdDe,
                null,
                'Meine neue Beschreibung',
                false
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdDe);
        $this->assertSame('Meine neue Beschreibung', $categoryTranslations['metaDescription']);

        /** Set value for "Deutsch" » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
                $languageIdDe,
                null,
                'Meine neue Beschreibung 2',
                false
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdDe);
        $this->assertSame('Meine neue Beschreibung', $categoryTranslations['metaDescription']);

        /** Set value for "Deutsch" » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
                $languageIdDe,
                null,
                'Meine neue Beschreibung 2',
                true
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdDe);
        $this->assertSame('Meine neue Beschreibung 2', $categoryTranslations['metaDescription']);

        /**
         * EN
         */

        /** Check, if the value is empty at the start */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdEn);
        $this->assertNull($categoryTranslations['metaDescription']);

        /** Set value for "English" */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
                $languageIdEn,
                null,
                'My new description',
                false
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdEn);
        $this->assertSame('My new description', $categoryTranslations['metaDescription']);

        /** Set value for "English" » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
                $languageIdEn,
                null,
                'My new description 2',
                false
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdEn);
        $this->assertSame('My new description', $categoryTranslations['metaDescription']);

        /** Set value for "English" » Check override protection */
        $this->seoDataSaver->save([
            new SeoDataSaverStruct(
                DreiscSeoBulkEnum::AREA__CATEGORY,
                $categoryId,
                DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
                $languageIdEn,
                null,
                'My new description 2',
                true
            )
        ]);

        /** Check, if the value set */
        $categoryTranslations = $this->testHelper->fetchCategoryTranslations($categoryId, $languageIdEn);
        $this->assertSame('My new description 2', $categoryTranslations['metaDescription']);
    }
}
