<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Seo\SeoUrl;

use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Seo\SeoUrl\SeoUrlSaver;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;
use Shopware\Core\Framework\Uuid\Uuid;

class SeoUrlSaverTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var SeoUrlSaver
     */
    private $seoUrlSaver;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    protected function setUp(): void
    {
        $this->seoUrlSaver = $this->getContainer()->get(SeoUrlSaver::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_category_base(): void
    {
        $newCategoryId = Uuid::randomHex();
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Create the url */
        $generatedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newCategoryId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_NAVIGATION_PAGE,
            'This is my test url'

        );

        /** Check the generated values */
        $this->assertSame(DemoDataIds::SALES_CHANNEL__MAIN_SHOP, $generatedSeoUrlEntity->getSalesChannelId());
        $this->assertSame($languageIdDe, $generatedSeoUrlEntity->getLanguageId());
        $this->assertSame('frontend.navigation.page', $generatedSeoUrlEntity->getRouteName());
        $this->assertSame($newCategoryId, $generatedSeoUrlEntity->getForeignKey());
        $this->assertSame('/navigation/' . $newCategoryId, $generatedSeoUrlEntity->getPathInfo());
        $this->assertSame('this-is-my-test-url', $generatedSeoUrlEntity->getSeoPathInfo());
        $this->assertTrue($generatedSeoUrlEntity->getIsCanonical());
        $this->assertTrue($generatedSeoUrlEntity->getIsModified());
        $this->assertFalse($generatedSeoUrlEntity->getIsDeleted());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_product_base(): void
    {
        $newProductId = Uuid::randomHex();
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Create the url */
        $generatedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my test url'

        );

        /** Check the generated values */
        $this->assertSame(DemoDataIds::SALES_CHANNEL__MAIN_SHOP, $generatedSeoUrlEntity->getSalesChannelId());
        $this->assertSame($languageIdDe, $generatedSeoUrlEntity->getLanguageId());
        $this->assertSame('frontend.detail.page', $generatedSeoUrlEntity->getRouteName());
        $this->assertSame($newProductId, $generatedSeoUrlEntity->getForeignKey());
        $this->assertSame('/detail/' . $newProductId, $generatedSeoUrlEntity->getPathInfo());
        $this->assertSame('this-is-my-test-url', $generatedSeoUrlEntity->getSeoPathInfo());
        $this->assertTrue($generatedSeoUrlEntity->getIsCanonical());
        $this->assertTrue($generatedSeoUrlEntity->getIsModified());
        $this->assertFalse($generatedSeoUrlEntity->getIsDeleted());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_saveItemsWithTheSameUrl(): void
    {
        $firstNewProductId = Uuid::randomHex();
        $secondNewProductId = Uuid::randomHex();
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Save the first product */
        $generatedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $firstNewProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my product'

        );

        $this->assertSame('this-is-my-product', $generatedSeoUrlEntity->getSeoPathInfo());

        /** Save the second product with the same url */
        $generatedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $secondNewProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my product'

        );

        $this->assertSame('this-is-my-product-' . $secondNewProductId, $generatedSeoUrlEntity->getSeoPathInfo());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_saveItemTwoTimes(): void
    {
        $newProductId = Uuid::randomHex();
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Save the product */
        $generatedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my product'
        );

        $this->assertSame('this-is-my-product', $generatedSeoUrlEntity->getSeoPathInfo());

        /** Save the product */
        $generatedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my product'
        );

        $this->assertSame('this-is-my-product', $generatedSeoUrlEntity->getSeoPathInfo());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_checkCanonicalFlagUpdate(): void
    {
        $newProductId = Uuid::randomHex();
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Save the product */
        $generatedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my product',
            false
        );

        $this->assertSame('this-is-my-product', $generatedSeoUrlEntity->getSeoPathInfo());
        $this->assertFalse($generatedSeoUrlEntity->getIsCanonical());

        /** Save the product */
        $generatedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my product'
        );

        $this->assertSame('this-is-my-product', $generatedSeoUrlEntity->getSeoPathInfo());
        $this->assertTrue($generatedSeoUrlEntity->getIsCanonical());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_checkAutoCanonicalFlagUpdateByNewUrl(): void
    {
        $newProductId = Uuid::randomHex();
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Save the product */
        $firstGeneratedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my product'
        );

        $this->assertSame('this-is-my-product', $firstGeneratedSeoUrlEntity->getSeoPathInfo());
        $this->assertTrue($firstGeneratedSeoUrlEntity->getIsCanonical());

        /** Update the url */
        $secondGeneratedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my new product'
        );

        $this->assertSame('this-is-my-new-product', $secondGeneratedSeoUrlEntity->getSeoPathInfo());
        $this->assertTrue($secondGeneratedSeoUrlEntity->getIsCanonical());

        /** Check the first entry again. It should be isCanonical = false */
        $firstGeneratedSeoUrlEntity = $this->seoUrlRepository->get($firstGeneratedSeoUrlEntity->getId(), null, null, false);
        $this->assertNull($firstGeneratedSeoUrlEntity->getIsCanonical());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_checkAutoCanonicalFlagUpdateByNewUrlWithoutCanonicalFlag(): void
    {
        $newProductId = Uuid::randomHex();
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Save the product */
        $firstGeneratedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my product'
        );

        $this->assertSame('this-is-my-product', $firstGeneratedSeoUrlEntity->getSeoPathInfo());
        $this->assertTrue($firstGeneratedSeoUrlEntity->getIsCanonical());

        /** Update the url as isCanonical = false */
        $secondGeneratedSeoUrlEntity = $this->seoUrlSaver->save(
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            $newProductId,
            SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE,
            'This is my new product',
            false
        );

        $this->assertSame('this-is-my-new-product', $secondGeneratedSeoUrlEntity->getSeoPathInfo());
        $this->assertFalse($secondGeneratedSeoUrlEntity->getIsCanonical());

        /** Check the first entry again. It should be still isCanonical = true */
        $firstGeneratedSeoUrlEntity = $this->seoUrlRepository->get($firstGeneratedSeoUrlEntity->getId());
        $this->assertTrue($firstGeneratedSeoUrlEntity->getIsCanonical());
    }
}
