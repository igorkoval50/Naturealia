<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Seo\LiveTemplate;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Content\SystemConfig\SystemConfigRepository;
use DreiscSeoPro\Core\Foundation\Context\ContextFactory;
use DreiscSeoPro\Core\Foundation\Context\LanguageChainFactory;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use Shopware\Core\Content\Category\CategoryEntity;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\Api\Context\SalesChannelApiSource;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\MultiFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\NotFilter;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Seo\LiveTemplate\LiveTemplateConverter;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\SystemConfig\SystemConfigService;

class LiveTemplateConverterTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var LiveTemplateConverter
     */
    private $liveTemplateConverter;

    /**
     * @var ContextFactory
     */
    private $contextFactory;

    /**
     * @var SystemConfigRepository
     */
    private $systemConfigRepository;

    /**
     * @var SystemConfigService
     */
    private $systemConfigService;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var LanguageChainFactory
     */
    private $languageChainFactory;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    protected function setUp(): void
    {
        $this->liveTemplateConverter = $this->getContainer()->get(LiveTemplateConverter::class);
        $this->contextFactory = $this->getContainer()->get(ContextFactory::class);
        $this->systemConfigRepository = $this->getContainer()->get(SystemConfigRepository::class);
        $this->systemConfigService = $this->getContainer()->get(SystemConfigService::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
        $this->languageChainFactory = $this->getContainer()->get(LanguageChainFactory::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
    }

    /**
     * The live template should not be converted if there is a system source
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_translateProductEntity_checkForSystemSource(): void
    {
        $systemSourceContext = $this->contextFactory->createContext(
            new ContextFactory\Struct\ContextStruct()
        );

        $productEntity = $this->createProductEntity('##shopName##');

        $this->liveTemplateConverter->translateProductEntity($productEntity, $systemSourceContext);

        /** The live template should not be converted  */
        $this->assertSame('meta title ##shopName##', $productEntity->getMetaTitle());
        $this->assertSame('meta description ##shopName##', $productEntity->getMetaDescription());
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_translateProductEntity_checkShopName(): void
    {
        /** Set the default shop name to "My demo store" */
        $this->systemConfigService->set(
            'core.basicInformation.shopName',
            'My demo store'
        );

        /** Set the main shop name to "Mainshop" */
        $this->systemConfigService->set(
            'core.basicInformation.shopName',
            'Mainshop',
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Test GB Shop */
        $productEntity = $this->createProductEntity('##shopName##');
        $salesChannelContext = $this->createSalesChannelContext(DemoDataIds::SALES_CHANNEL__GB_SHOP);

        $this->liveTemplateConverter->translateProductEntity($productEntity, $salesChannelContext);

        /** Since we have not defined a value, we except the default value "Demostore" */
        $this->assertSame('meta title My demo store', $productEntity->getMetaTitle());
        $this->assertSame('meta description My demo store', $productEntity->getMetaDescription());

        /** Test Main shop */
        $productEntity = $this->createProductEntity('##shopName##');
        $salesChannelContext = $this->createSalesChannelContext(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);
        $this->liveTemplateConverter->translateProductEntity($productEntity, $salesChannelContext);

        /** Since we have not defined a value, we except the default value "Demostore" */
        $this->assertSame('meta title Mainshop', $productEntity->getMetaTitle());
        $this->assertSame('meta description Mainshop', $productEntity->getMetaDescription());
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_translateCategoryEntity_checkShopName(): void
    {
        /** Set the default shop name to "My demo store" */
        $this->systemConfigService->set(
            'core.basicInformation.shopName',
            'My demo store'
        );

        /** Set the main shop name to "Mainshop" */
        $this->systemConfigService->set(
            'core.basicInformation.shopName',
            'Mainshop',
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Test GB Shop */
        $categoryEntity = $this->createCategoryEntity('##shopName##');

        $salesChannelContext = $this->createSalesChannelContext(DemoDataIds::SALES_CHANNEL__GB_SHOP);

        $this->liveTemplateConverter->translateCategoryEntity($categoryEntity, $salesChannelContext);

        /** Since we have not defined a value, we except the default value "Demostore" */
        $this->assertSame('meta title My demo store', $categoryEntity->getMetaTitle());
        $this->assertSame('meta description My demo store', $categoryEntity->getMetaDescription());

        /** Test Main shop */
        $categoryEntity = $this->createProductEntity('##shopName##');
        $salesChannelContext = $this->createSalesChannelContext(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);
        $this->liveTemplateConverter->translateProductEntity($categoryEntity, $salesChannelContext);

        /** Since we have not defined a value, we except the default value "Demostore" */
        $this->assertSame('meta title Mainshop', $categoryEntity->getMetaTitle());
        $this->assertSame('meta description Mainshop', $categoryEntity->getMetaDescription());
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    public function test_translateProductEntity_checkProductPrice(): void
    {
        $salesChannelContext = $this->createSalesChannelContext(DemoDataIds::SALES_CHANNEL__GB_SHOP);
        $productEntity = $this->createProductEntity('##productPrice##', $salesChannelContext);

        $this->liveTemplateConverter->translateProductEntity($productEntity, $salesChannelContext);

        /** Since we have not defined a value, we except the default value "Demostore" */
        $this->assertSame('meta title €119.00', $productEntity->getMetaTitle());
        $this->assertSame('meta description €119.00', $productEntity->getMetaDescription());

        /** Test Main shop */
        $productEntity = $this->createProductEntity('##productPrice##');
        $salesChannelContext = $this->createSalesChannelContext(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);
        $this->liveTemplateConverter->translateProductEntity($productEntity, $salesChannelContext);

        /** Since we have not defined a value, we except the default value "Demostore" */
        $this->assertSame('meta title 119,00 €', $productEntity->getMetaTitle());
        $this->assertSame('meta description 119,00 €', $productEntity->getMetaDescription());
    }

    /**
     * @param string $template
     * @param Context|null $context
     * @return ProductEntity
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    private function createProductEntity(string $template, Context $context = null): ProductEntity
    {
        if (null === $context) {
            $context = $this->createSalesChannelContext(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);
        }

        $productEntity = $this->productRepository->get(DemoDataIds::PRODUCT_SW_1000, null, $context);

        $productEntity->setMetaTitle('meta title ' . $template);
        $productEntity->setMetaDescription('meta description ' . $template);

        return $productEntity;
    }

    private function createCategoryEntity(string $template, Context $context = null): CategoryEntity
    {
        if (null === $context) {
            $context = $this->createSalesChannelContext(DemoDataIds::SALES_CHANNEL__MAIN_SHOP);
        }

        $categoryEntity = $this->categoryRepository->get(DemoDataIds::CATEGORY__MAIN__PRODUCTS, null, $context);

        $categoryEntity->setMetaTitle('meta title ' . $template);
        $categoryEntity->setMetaDescription('meta description ' . $template);

        return $categoryEntity;
    }

    /**
     * @param string $salesChannelId
     * @return Context
     * @throws DBALException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     */
    private function createSalesChannelContext(string $salesChannelId): Context
    {
        if(DemoDataIds::SALES_CHANNEL__MAIN_SHOP === $salesChannelId) {
            $languageChain = $this->languageChainFactory->getLanguageIdChain(
                $this->demoDataRepository->getLanguageIdDe()
            );
        } else {
            $languageChain = $this->languageChainFactory->getLanguageIdChain(
                $this->demoDataRepository->getLanguageIdEn()
            );
        }

        return $this->contextFactory->createContext(
            (new ContextFactory\Struct\ContextStruct())
                ->setContextSource(new SalesChannelApiSource($salesChannelId))
                ->setLanguageIdChain($languageChain)
        );
    }
}
