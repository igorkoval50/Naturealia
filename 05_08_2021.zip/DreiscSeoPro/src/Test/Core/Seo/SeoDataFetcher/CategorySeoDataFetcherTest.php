<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Seo\SeoDataFetcher;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataSaver;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Exception\UnknownAreaException;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\MultiFilter;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\CategorySeoDataFetcher;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;

class CategorySeoDataFetcherTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var CategorySeoDataFetcher
     */
    private $categorySeoDataFetcher;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    /**
     * @var SeoDataSaver
     */
    private $seoDataSaver;

    protected function setUp(): void
    {
        $this->categorySeoDataFetcher = $this->getContainer()->get(CategorySeoDataFetcher::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
        $this->seoDataSaver = $this->getContainer()->get(SeoDataSaver::class);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws DBALException
     * @throws UnknownAreaException
     */
    public function test_fetch_metaTitleDe(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /** Fetch the seo data for "Deutsch" */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            $languageIdDe,
            null
        );

        /** Check the default values */
        $this->assertNull($seoDataFetchResultStruct->getMetaTitle());
        $this->assertNull($seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());

        /** Update the meta title for "English" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__CATEGORY,
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            $languageIdEn,
            null,
            'My new title',
            false
        )]);

        /** Fetch the seo data for "Deutsch" again */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            $languageIdDe,
            null
        );

        /** Check, if the meta title is now available as inherit */
        $this->assertSame('My new title', $seoDataFetchResultStruct->getMetaTitle());
        $this->assertTrue($seoDataFetchResultStruct->isInheritedMetaTitle());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());

        /** Update the meta title for "Deutsch" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__CATEGORY,
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            $languageIdDe,
            null,
            'Mein neuer Titel',
            false
        )]);

        /** Fetch the seo data for "Deutsch" again */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            $languageIdDe,
            null
        );

        /** Check, if the meta title is now available without inheritance */
        $this->assertSame('Mein neuer Titel', $seoDataFetchResultStruct->getMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws DBALException
     * @throws UnknownAreaException
     */
    public function test_fetch_metaTitleEn(): void
    {
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /** Fetch the seo data for "English" */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            $languageIdEn,
            null
        );

        /** Check the default values */
        $this->assertNull($seoDataFetchResultStruct->getMetaTitle());
        $this->assertNull($seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());

        /** Update the meta title for "English" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__CATEGORY,
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            $languageIdEn,
            null,
            'My new title',
            false
        )]);

        /** Fetch the seo data for "English" again */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            $languageIdEn,
            null
        );

        /** Check, if the meta title is now available as inherit */
        $this->assertSame('My new title', $seoDataFetchResultStruct->getMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws DBALException
     * @throws UnknownAreaException
     */
    public function test_fetch_metaDescription(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /** Update the meta description for "English" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__CATEGORY,
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
            $languageIdEn,
            null,
            'My new description',
            false
        )]);

        /** Fetch the seo data for "Deutsch" */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            $languageIdDe,
            null
        );

        /** Check, if the meta description is now available as inherit */
        $this->assertSame('My new description', $seoDataFetchResultStruct->getMetaDescription());
        $this->assertTrue($seoDataFetchResultStruct->isInheritedMetaDescription());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());

        /** Update the meta description for "Deutsch" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__CATEGORY,
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
            $languageIdDe,
            null,
            'Meine neue Beschreibung',
            false
        )]);

        /** Fetch the seo data for "Deutsch" again */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            $languageIdDe,
            null
        );

        /** Check, if the meta title is now available without inheritance */
        $this->assertSame('Meine neue Beschreibung', $seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws UnknownAreaException
     */
    public function test_fetch_url(): void
    {
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Make sure, that there is no url for the category */
        $this->seoUrlRepository->deleteByCriteria(
            (new Criteria())
                ->addFilter(
                    new MultiFilter(
                        MultiFilter::CONNECTION_AND,
                        [
                            new EqualsFilter('routeName', SeoUrlRepository::ROUTE_NAME__FRONTEND_NAVIGATION_PAGE),
                            new EqualsFilter('foreignKey', $categoryId)
                        ]
                    )
                )
        );

        /** Fetch the seo data */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            $categoryId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Check if the default seo was set */
        $this->assertNull($seoDataFetchResultStruct->getUrl());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedUrl());

        /** Set a  url */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__CATEGORY,
            $categoryId,
            DreiscSeoBulkEnum::SEO_OPTION__URL,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
            '/my/category/inherit url',
            true
        )]);

        /** Fetch the seo data again */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            $categoryId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Check the url */
        $this->assertSame('/my/category/inherit-url', $seoDataFetchResultStruct->getUrl());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedUrl());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws DBALException
     * @throws UnknownAreaException
     */
    public function test_fetch_robotsTag(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /** Update the robots tag for "English" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__CATEGORY,
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            DreiscSeoBulkEnum::SEO_OPTION__ROBOTS_TAG,
            $languageIdEn,
            null,
            'robot,cat,en',
            false
        )]);

        /** Fetch the seo data for "Deutsch" */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            $languageIdDe,
            null
        );

        /** Check, if the robots tag is now available as inherit */
        $this->assertSame('robot,cat,en', $seoDataFetchResultStruct->getRobotsTag());
        $this->assertTrue($seoDataFetchResultStruct->isInheritedRobotsTag());

        /** Update the robots tag for "Deutsch" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__CATEGORY,
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            DreiscSeoBulkEnum::SEO_OPTION__ROBOTS_TAG,
            $languageIdDe,
            null,
            'robot,cat,de',
            false
        )]);

        /** Fetch the seo data for "Deutsch" again */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            DemoDataIds::ROOT_CATEGORY__MAIN_SHOP,
            $languageIdDe,
            null
        );

        /** Check, if the robots tag is now available without inheritance */
        $this->assertSame('robot,cat,de', $seoDataFetchResultStruct->getRobotsTag());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedRobotsTag());
    }
}
