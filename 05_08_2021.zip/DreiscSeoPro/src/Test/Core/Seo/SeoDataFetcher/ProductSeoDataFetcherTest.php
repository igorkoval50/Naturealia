<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Core\Seo\SeoDataFetcher;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataSaver;
use DreiscSeoPro\Core\Seo\SeoDataSaver\Exception\UnknownAreaException;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\ProductSeoDataFetcher;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;

class ProductSeoDataFetcherTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var ProductSeoDataFetcher
     */
    private $productSeoDataFetcher;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var SeoDataSaver
     */
    private $seoDataSaver;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    protected function setUp(): void
    {
        $this->productSeoDataFetcher = $this->getContainer()->get(ProductSeoDataFetcher::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->seoDataSaver = $this->getContainer()->get(SeoDataSaver::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws DBALException
     * @throws UnknownAreaException
     */
    public function test_fetch_metaTitleDe(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /** Fetch the seo data for "Deutsch" */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1000,
            $languageIdDe,
            null
        );

        /** Check the default values */
        $this->assertNull($seoDataFetchResultStruct->getMetaTitle());
        $this->assertNull($seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());

        /** Update the meta title for "English" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            DemoDataIds::PRODUCT_SW_1000,
            DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            $languageIdEn,
            null,
            'My new title',
            false
        )]);

        /** Fetch the seo data for "Deutsch" again */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1000,
            $languageIdDe,
            null
        );

        /** Check, if the meta title is now available as inherit */
        $this->assertSame('My new title', $seoDataFetchResultStruct->getMetaTitle());
        $this->assertTrue($seoDataFetchResultStruct->isInheritedMetaTitle());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());

        /** Update the meta title for "Deutsch" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            DemoDataIds::PRODUCT_SW_1000,
            DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            $languageIdDe,
            null,
            'Mein neuer Titel',
            false
        )]);

        /** Fetch the seo data for "Deutsch" again */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1000,
            $languageIdDe,
            null
        );

        /** Check, if the meta title is now available without inheritance */
        $this->assertSame('Mein neuer Titel', $seoDataFetchResultStruct->getMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws UnknownAreaException
     */
    public function test_fetch_metaTitle_considerInheritance(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /** Update the meta title for "English" » Main product */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            DemoDataIds::PRODUCT_SW_1006,
            DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
            $languageIdEn,
            null,
            'MAIN TITLE',
            false
        )]);

        /** Fetch the seo data for "Deutsch" » Variant */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1006_1,
            $languageIdDe,
            null
        );

        /** We expect null, because the consider inheritance flag was not set */
        $this->assertNull($seoDataFetchResultStruct->getMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());

        /** We fetch again, which the flag */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1006_1,
            $languageIdDe,
            null,
            true
        );

        /** Now we expect the value of the main product */
        $this->assertSame('MAIN TITLE', $seoDataFetchResultStruct->getMetaTitle());
        $this->assertTrue($seoDataFetchResultStruct->isInheritedMetaTitle());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws DBALException
     * @throws UnknownAreaException
     */
    public function test_fetch_metaDescription(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /** Update the meta description for "English" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            DemoDataIds::PRODUCT_SW_1000,
            DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
            $languageIdEn,
            null,
            'My new description',
            false
        )]);

        /** Fetch the seo data for "Deutsch" */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1000,
            $languageIdDe,
            null
        );

        /** Check, if the meta description is now available as inherit */
        $this->assertSame('My new description', $seoDataFetchResultStruct->getMetaDescription());
        $this->assertTrue($seoDataFetchResultStruct->isInheritedMetaDescription());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());

        /** Update the meta description for "Deutsch" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            DemoDataIds::PRODUCT_SW_1000,
            DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
            $languageIdDe,
            null,
            'Meine neue Beschreibung',
            false
        )]);

        /** Fetch the seo data for "Deutsch" again */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1000,
            $languageIdDe,
            null
        );

        /** Check, if the meta title is now available without inheritance */
        $this->assertSame('Meine neue Beschreibung', $seoDataFetchResultStruct->getMetaDescription());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaDescription());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());
    }

    /**
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws UnknownAreaException
     */
    public function test_fetch_url(): void
    {
        $productId = DemoDataIds::PRODUCT_SW_1000;
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();

        /** Make sure, that there is no url for the category */
        $this->seoUrlRepository->deleteByCriteria(
            (new Criteria())
                ->addFilter(
                    new EqualsFilter('routeName', SeoUrlRepository::ROUTE_NAME__FRONTEND_DETAIL_PAGE),
                    new EqualsFilter('foreignKey', $productId)
                )
        );

        /** Fetch the seo data */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Check if the values are empty */
        $this->assertNull($seoDataFetchResultStruct->getUrl());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedUrl());

        /** Set a inherit url */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            $productId,
            DreiscSeoBulkEnum::SEO_OPTION__URL,
            $languageIdDe,
            null,
            '/my/category/inherit url',
            false
        )]);

        /** Fetch the seo data again */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Check the inherit url */
        $this->assertSame('/my/category/inherit-url', $seoDataFetchResultStruct->getUrl());
        $this->assertTrue($seoDataFetchResultStruct->isInheritedUrl());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws DBALException
     * @throws UnknownAreaException
     */
    public function test_fetch_robotsTag(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /** Update the robots tag for "English" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            DemoDataIds::PRODUCT_SW_1000,
            DreiscSeoBulkEnum::SEO_OPTION__ROBOTS_TAG,
            $languageIdEn,
            null,
            'robots,tag,en',
            false
        )]);

        /** Fetch the seo data for "Deutsch" */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1000,
            $languageIdDe,
            null
        );

        /** Check, if the robots tag is now available as inherit */
        $this->assertSame('robots,tag,en', $seoDataFetchResultStruct->getRobotsTag());
        $this->assertTrue($seoDataFetchResultStruct->isInheritedRobotsTag());

        /** Update the robots tag for "Deutsch" */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            DemoDataIds::PRODUCT_SW_1000,
            DreiscSeoBulkEnum::SEO_OPTION__ROBOTS_TAG,
            $languageIdDe,
            null,
            'robots,tag,de',
            false
        )]);

        /** Fetch the seo data for "Deutsch" again */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1000,
            $languageIdDe,
            null
        );

        /** Check, if the meta title is now available without inheritance */
        $this->assertSame('robots,tag,de', $seoDataFetchResultStruct->getRobotsTag());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedRobotsTag());

        /** Make sure the other values have stayed that way */
        $this->assertNull($seoDataFetchResultStruct->getMetaTitle());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedMetaTitle());
    }

    /**
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws DBALException
     * @throws UnknownAreaException
     */
    public function test_fetch_robotsTag_considerInheritance(): void
    {
        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $languageIdEn = $this->demoDataRepository->getLanguageIdEn();

        /** Update the robots tag for "English" » Main product */
        $this->seoDataSaver->save([ new SeoDataSaver\Struct\SeoDataSaverStruct(
            DreiscSeoBulkEnum::AREA__PRODUCT,
            DemoDataIds::PRODUCT_SW_1006,
            DreiscSeoBulkEnum::SEO_OPTION__ROBOTS_TAG,
            $languageIdEn,
            null,
            'robots,tag,en,main',
            false
        )]);

        /** Fetch the seo data for "Deutsch" » Variant */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1006_1,
            $languageIdDe,
            null
        );

        /** We expect null, because the consider inheritance flag was not set */
        $this->assertNull($seoDataFetchResultStruct->getRobotsTag());
        $this->assertFalse($seoDataFetchResultStruct->isInheritedRobotsTag());

        /** We fetch again, with the flag */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            DemoDataIds::PRODUCT_SW_1006_1,
            $languageIdDe,
            null,
            true
        );

        /** Now we expect the value of the main product */
        $this->assertSame('robots,tag,en,main', $seoDataFetchResultStruct->getRobotsTag());
//        $this->assertTrue($seoDataFetchResultStruct->isInheritedRobotsTag());
    }
}
