<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Administration\Controller;

use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Administration\Controller\DreiscSeoCustomConfigController;
use Shopware\Core\PlatformRequest;
use Shopware\Core\Framework\Test\TestCaseBase\AdminApiTestBehaviour;

class DreiscSeoCustomConfigControllerTest extends TestCase
{
    use IntegrationTestBehaviour;
    use AdminApiTestBehaviour;

    /**
     * @var DreiscSeoCustomConfigController
     */
    private $dreiscSeoCustomConfigController;

    protected function setUp(): void
    {
        $this->dreiscSeoCustomConfigController = $this->getContainer()->get(DreiscSeoCustomConfigController::class);
    }

    public function test_loadCustomConfig(): void
    {
        $payload = [];
        $this->getBrowser()->request(
            'GET',
            '/api/dreisc.seo/dreisc.seo.custom.config/loadCustomConfig',
            $payload
        );

        $response = $this->getBrowser()->getResponse()->getContent();
        $response = json_decode($response, true);

        /** Test "success" field */
        $this->assertNotEmpty($response['success']);
        $this->assertTrue($response['success']);

        /** Check the pixel table */
        $this->assertNotEmpty($response['defaultCustomSettings']['pixelTable']);
        $this->assertSame(12, $response['defaultCustomSettings']['pixelTable']['default']);
        $this->assertSame(11.125, $response['defaultCustomSettings']['pixelTable'][50]);

        /** Test "maxLength" fields */
        $this->assertIsInt($response['defaultCustomSettings']['metaTags']['metaTitle']['lengthConfig']['maxLength']);
        $this->assertIsInt($response['defaultCustomSettings']['metaTags']['metaDescription']['lengthConfig']['maxLength']);
        $this->assertIsInt($response['defaultCustomSettings']['metaTags']['keywords']['lengthConfig']['maxLength']);

        /** Test sales channel "maxLength" fields */
        $this->assertNull($response['salesChannelCustomSettings'][DemoDataIds::SALES_CHANNEL__MAIN_SHOP]['metaTags']['metaTitle']['lengthConfig']['maxLength']);
        $this->assertNull($response['salesChannelCustomSettings'][DemoDataIds::SALES_CHANNEL__MAIN_SHOP]['metaTags']['metaDescription']['lengthConfig']['maxLength']);
        $this->assertNull($response['salesChannelCustomSettings'][DemoDataIds::SALES_CHANNEL__MAIN_SHOP]['metaTags']['keywords']['lengthConfig']['maxLength']);
    }
}
