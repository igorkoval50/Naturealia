<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Administration\Controller;

use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkRepository;
use DreiscSeoPro\Core\Content\Product\ProductRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Administration\Controller\DreiscSeoBulkController;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\PlatformRequest;
use Shopware\Core\Framework\Test\TestCaseBase\AdminApiTestBehaviour;

class DreiscSeoBulkControllerTest extends TestCase
{
    use IntegrationTestBehaviour;
    use AdminApiTestBehaviour;

    /**
     * @var DreiscSeoBulkController
     */
    private $dreiscSeoBulkController;

    /**
     * @var DreiscSeoBulkRepository
     */
    private $dreiscSeoBulkRepository;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    protected function setUp(): void
    {
        $this->dreiscSeoBulkController = $this->getContainer()->get(DreiscSeoBulkController::class);
        $this->dreiscSeoBulkRepository = $this->getContainer()->get(DreiscSeoBulkRepository::class);
        $this->productRepository = $this->getContainer()->get(ProductRepository::class);
        $this->categoryRepository = $this->getContainer()->get(CategoryRepository::class);
    }

    public function test_getResponsibleSeoBulk(): void
    {
        /** Setup a bulk configuration for the demo category */
        $dreiscSeoBulkTemplate = $this->getDummyDreiscSeoBulkTemplateEntity();
        $dreiscSeoBulk = $this->getDummyDreiscSeoBulkEntity($dreiscSeoBulkTemplate);
        $templateName = $dreiscSeoBulkTemplate->getName();

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulk ]);

        $payload = [
            'area' => $dreiscSeoBulk->getArea(),
            'seoOption' => $dreiscSeoBulk->getSeoOption(),
            'languageId' => $dreiscSeoBulk->getLanguageId(),
            'categoryIds' => [
                DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS
            ]
        ];

        $response = $this->getBrowserResponse('/dreisc.seo/dreisc.seo.bulk/getResponsibleSeoBulk', $payload);

        $this->assertNotEmpty($response[0]);
        $this->assertSame(DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS, $response[0]['categoryId']);
        $this->assertNotEmpty($response[0]['seoBulkEntity']);
        $this->assertNotEmpty($response[0]['seoBulkEntity']['dreiscSeoBulkTemplate']);
        $this->assertSame($templateName, $response[0]['seoBulkEntity']['dreiscSeoBulkTemplate']['name']);
    }

    public function test_getResponsibleProductSeoBulkRespectPriority(): void
    {
        /** Setup a bulk configuration for the demo category */
        $dreiscSeoBulkTemplate = $this->getDummyDreiscSeoBulkTemplateEntity();
        $dreiscSeoBulk = $this->getDummyDreiscSeoBulkEntity($dreiscSeoBulkTemplate);
        $templateName = $dreiscSeoBulkTemplate->getName();

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulk ]);

        $payload = [
            'productId' => DemoDataIds::PRODUCT_SW_1004,
            'seoOption' => $dreiscSeoBulk->getSeoOption(),
            'languageId' => $dreiscSeoBulk->getLanguageId()
        ];

        $response = $this->getBrowserResponse('/dreisc.seo/dreisc.seo.bulk/getResponsibleProductSeoBulkRespectPriority', $payload);

        $this->assertNotEmpty($response);
        $this->assertNotEmpty($response['dreiscSeoBulkTemplate']);
        $this->assertSame($dreiscSeoBulk->getId(), $response['id']);
        $this->assertSame($dreiscSeoBulkTemplate->getId(), $response['dreiscSeoBulkTemplate']['id']);
    }

    /**
     * Test if the method also works for variants
     */
    public function test_getResponsibleProductSeoBulkRespectPriority_testVariant(): void
    {
        /** Setup a bulk configuration for the demo category */
        $dreiscSeoBulkTemplate = $this->getDummyDreiscSeoBulkTemplateEntity();
        $dreiscSeoBulk = $this->getDummyDreiscSeoBulkEntity($dreiscSeoBulkTemplate);
        $dreiscSeoBulk->setCategoryId(DemoDataIds::ROOT_CATEGORY__MAIN_SHOP);
        $dreiscSeoBulk->setInherit(true);

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulk ]);

        $payload = [
            'productId' => DemoDataIds::PRODUCT_SW_1006_1,
            'seoOption' => $dreiscSeoBulk->getSeoOption(),
            'languageId' => $dreiscSeoBulk->getLanguageId()
        ];

        $response = $this->getBrowserResponse('/dreisc.seo/dreisc.seo.bulk/getResponsibleProductSeoBulkRespectPriority', $payload);

        $this->assertNotEmpty($response);
        $this->assertNotEmpty($response['dreiscSeoBulkTemplate']);
        $this->assertSame($dreiscSeoBulk->getId(), $response['id']);
        $this->assertSame($dreiscSeoBulkTemplate->getId(), $response['dreiscSeoBulkTemplate']['id']);
    }

    /**
     * @throws InconsistentCriteriaIdsException
     */
    public function test_deleteBulkTemplate(): void
    {
        /** Setup a bulk configuration for the demo category */
        $dreiscSeoBulkTemplate = $this->getDummyDreiscSeoBulkTemplateEntity();
        $dreiscSeoBulk = $this->getDummyDreiscSeoBulkEntity($dreiscSeoBulkTemplate);
        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulk ]);

        /** Check if seo settings available */
        $checkDreiscSeoBulk = $this->dreiscSeoBulkRepository->get($dreiscSeoBulk->getId());
        $this->assertSame($dreiscSeoBulk->getId(), $checkDreiscSeoBulk->getId());
        $this->assertSame($dreiscSeoBulkTemplate->getId(), $checkDreiscSeoBulk->getDreiscSeoBulkTemplateId());

        /** Try to delete the template over the controller */
        $response = $this->getBrowserResponse('/dreisc.seo/dreisc.seo.bulk/deleteBulkTemplate', [
            'seoBulkTemplateId' => $dreiscSeoBulkTemplate->getId()
        ]);

        /** We expect that the request failed because the template in in use */
        $this->assertFalse($response['success']);
        $this->assertSame($dreiscSeoBulkTemplate->getId(), $response['seoBulkTemplateEntity']['id']);
        $this->assertCount(1, $response['seoBulkEntriesWithCurrentTemplate']);
        $this->assertSame($dreiscSeoBulk->getId(), $response['seoBulkEntriesWithCurrentTemplate'][0]['id']);
        $this->assertSame(1, $response['seoBulkEntriesWithCurrentTemplateTotal']);

        /** Try again to delete the template over the controller. In this run with the deleteSeoBulkWhichUseTemplate param */
        $response = $this->getBrowserResponse('/dreisc.seo/dreisc.seo.bulk/deleteBulkTemplate', [
            'seoBulkTemplateId' => $dreiscSeoBulkTemplate->getId(),
            'deleteSeoBulkWhichUseTemplate' => true
        ]);

        /** We expect that the call was successful */
        $this->assertTrue($response['success']);

        /** Double check */
        $checkDreiscSeoBulk = $this->dreiscSeoBulkRepository->get($dreiscSeoBulk->getId());
        $this->assertNull($checkDreiscSeoBulk);
    }

    public function dataProvider_getTemplatePreview_category_metaDescription(): array
    {
        return [
            [ true ],
            [ false ]
        ];
    }

    /**
     * @dataProvider dataProvider_getTemplatePreview_category_metaDescription
     * @param bool $spaceless
     */
    public function test_getTemplatePreview_category_metaDescription(bool $spaceless): void
    {
        $response = $this->getBrowserResponse('/dreisc.seo/dreisc.seo.bulk/getTemplatePreview', [
            'area' => DreiscSeoBulkEnum::AREA__CATEGORY,
            'activeItemId' => DemoDataIds::CATEGORY__MAIN__SPECIAL_CATEGORIES__WITHOUT_DE_TRANSLATION,
            'seoOption' => DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
            'languageId' => $this->getDeDeLanguageId(),
            'template' => ' {{ category.translated.name }} ',
            'spaceless' => $spaceless
        ]);

        $this->assertTrue($response['success']);

        if (true === $spaceless) {
            $this->assertSame('Without DE translation', $response['renderedTemplate']);
        } else {
            $this->assertSame(' Without DE translation ', $response['renderedTemplate']);
        }
    }

    public function test_prepareBulkGenerator_product(): void
    {
        $productIdSearchResult = $this->productRepository->searchIds(new Criteria());
        $response = $this->getBrowserResponse('/dreisc.seo/dreisc.seo.bulk/prepareBulkGenerator', [
            'area' => DreiscSeoBulkEnum::AREA__PRODUCT
        ]);

        /** Check, if the response was successful */
        $this->assertNotEmpty($response);
        $this->assertNotEmpty($response['success']);
        $this->assertTrue($response['success']);

        /** Check if the total value match with the dal value */
        $this->assertSame($productIdSearchResult->getTotal(), $response['total']);
    }

    public function test_prepareBulkGenerator_category(): void
    {
        $categoryIdSearchResult = $this->categoryRepository->searchIds(new Criteria());
        $response = $this->getBrowserResponse('/dreisc.seo/dreisc.seo.bulk/prepareBulkGenerator', [
            'area' => DreiscSeoBulkEnum::AREA__CATEGORY
        ]);

        /** Check, if the response was successful */
        $this->assertNotEmpty($response);
        $this->assertNotEmpty($response['success']);
        $this->assertTrue($response['success']);

        /** Check if the total value match with the dal value */
        $this->assertSame($categoryIdSearchResult->getTotal(), $response['total']);
    }

    public function test_runBulkGeneratorThread_product(): void
    {
        $productIdSearchResult = $this->productRepository->searchIds(new Criteria());
        $response = $this->getBrowserResponse('/dreisc.seo/dreisc.seo.bulk/runBulkGeneratorThread', [
            'area' => DreiscSeoBulkEnum::AREA__PRODUCT,
            'offset' => 5,
            'limit' => 2
        ]);

        /** Check, if the response was successful */
        $this->assertNotEmpty($response);
        $this->assertNotEmpty($response['success']);
        $this->assertTrue($response['success']);
    }

    /**
     * @param DreiscSeoBulkTemplateEntity|null $dreiscSeoBulkTemplate
     * @return DreiscSeoBulkEntity
     */
    private function getDummyDreiscSeoBulkEntity(DreiscSeoBulkTemplateEntity $dreiscSeoBulkTemplate = null)
    {
        $dreiscSeoBulkId = Uuid::randomHex();

        $dreiscSeoBulk = (new DreiscSeoBulkEntity())
            ->setId($dreiscSeoBulkId)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE)
            ->setCategoryId(DemoDataIds::CATEGORY__GBSHOP__PRODUCTS__STANDARD_PRODUCTS)
            ->setLanguageId($this->getDeDeLanguageId());

        if (null !== $dreiscSeoBulkTemplate) {
            $dreiscSeoBulk->setDreiscSeoBulkTemplate($dreiscSeoBulkTemplate);
        }

        return $dreiscSeoBulk;
    }

    /**
     * @return DreiscSeoBulkTemplateEntity
     */
    private function getDummyDreiscSeoBulkTemplateEntity()
    {
        $dreiscSeoBulkTemplateId = Uuid::randomHex();

        return (new DreiscSeoBulkTemplateEntity())
            ->setId($dreiscSeoBulkTemplateId)
            ->setName('Test Template')
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE);
    }

    /**
     * @param string $url
     * @param array $payload
     * @return mixed
     */
    private function getBrowserResponse(string $url, array $payload)
    {
        $this->getBrowser()->request(
            'GET',
            '/api' . $url,
            $payload
        );

        $response = $this->getBrowser()->getResponse()->getContent();
        return json_decode($response, true);
    }
}
