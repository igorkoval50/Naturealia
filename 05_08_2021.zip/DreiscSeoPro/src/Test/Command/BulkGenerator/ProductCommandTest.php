<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Command\BulkGenerator;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkRepository;
use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Content\SeoUrlTemplate\SeoUrlTemplateRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\ProductSeoDataFetcher;
use DreiscSeoPro\Core\Seo\SeoDataSaver;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use DreiscSeoPro\Command\BulkGenerator\ProductCommand;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;
use Shopware\Core\Framework\Uuid\Uuid;
use Symfony\Component\Console\Tester\CommandTester;

class ProductCommandTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var ProductCommand
     */
    private $productCommand;

    /**
     * @var DreiscSeoBulkRepository
     */
    private $dreiscSeoBulkRepository;

    /**
     * @var DreiscSeoBulkTemplateRepository
     */
    private $dreiscSeoBulkTemplateRepository;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var ProductSeoDataFetcher
     */
    private $productSeoDataFetcher;

    /**
     * @var SeoDataSaver
     */
    private $seoDataSaver;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    /**
     * @var SeoUrlTemplateRepository
     */
    private $seoUrlTemplateRepository;

    protected function setUp(): void
    {
        $this->productCommand = $this->getContainer()->get(ProductCommand::class);
        $this->dreiscSeoBulkRepository = $this->getContainer()->get(DreiscSeoBulkRepository::class);
        $this->dreiscSeoBulkTemplateRepository = $this->getContainer()->get(DreiscSeoBulkTemplateRepository::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->productSeoDataFetcher = $this->getContainer()->get(ProductSeoDataFetcher::class);
        $this->seoDataSaver = $this->getContainer()->get(SeoDataSaver::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
        $this->seoUrlTemplateRepository = $this->getContainer()->get(SeoUrlTemplateRepository::class);
    }

    /**
    * @return array
    */
    public function dataProvider_initialInheritOverride(): array
    {
        return [
            [ true, false, false, false ],
            [ true, false, false, true ],
            [ true, false, true, true ],
            [ true, false, true, false ],
            [ true, true, false, false ],
            [ true, true, false, true ],
            [ true, true, true, true ],
            [ true, true, true, false ],

            [ false, false, false, false ],
            [ false, false, false, true ],
            [ false, false, true, true ],
            [ false, false, true, false ],
            [ false, true, false, false ],
            [ false, true, false, true ],
            [ false, true, true, true ],
            [ false, true, true, false ]
        ];
    }

    /**
     * @dataProvider dataProvider_initialInheritOverride
     *
     * @param bool $isParentCategoryId
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     */
    public function test_metaTitle(bool $isParentCategoryId, bool $initialValueSet, bool $inherit, bool $override): void
    {
        /** Make sure there are no cached seo bulks */
        DreiscSeoBulkRepository::resetCache();

        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $productId = DemoDataIds::PRODUCT_SW_1000;

        if (true === $isParentCategoryId) {
            $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;
        } else {
            $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        }

        /** Set initial value to check the override value */
        if (true === $initialValueSet) {
            $this->seoDataSaver->save([
                new SeoDataSaver\Struct\SeoDataSaverStruct(
                    DreiscSeoBulkEnum::AREA__PRODUCT,
                    $productId,
                    DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                    $languageIdDe,
                    null,
                    'Initial value product',
                    true
                )
            ]);
        }

        /** Create a template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE)
            ->setName('My Bulk Template')
            ->setTemplate('{{ product.translated.name }} - {{ product.productNumber }}');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit($inherit)
            ->setOverwrite($override);

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Create a command tester **/
        $commandTester = new CommandTester($this->productCommand);
        $commandTester->execute([]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** Check the value of the child */
        $value = $seoDataFetchResultStruct->getMetaTitle();
        if (true === $isParentCategoryId) {
            if (false === $initialValueSet && false === $inherit && false === $override) {
                $this->assertNull($value);
            } elseif (false === $initialValueSet && false === $inherit && true === $override) {
                $this->assertNull($value);
            } elseif (true === $initialValueSet && false === $inherit && false === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (true === $initialValueSet && false === $inherit && true === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (true === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (false === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (false === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (true === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            }
        } else {
            if (false === $initialValueSet && false === $inherit && false === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (false === $initialValueSet && false === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (true === $initialValueSet && false === $inherit && false === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (true === $initialValueSet && false === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (true === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (false === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (false === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (true === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            }
        }
    }

    /**
     * @dataProvider dataProvider_initialInheritOverride
     *
     * @param bool $isParentCategoryId
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     */
    public function test_metaDescription(bool $isParentCategoryId, bool $initialValueSet, bool $inherit, bool $override): void
    {
        /** Make sure there are no cached seo bulks */
        DreiscSeoBulkRepository::resetCache();

        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $productId = DemoDataIds::PRODUCT_SW_1000;

        if (true === $isParentCategoryId) {
            $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;
        } else {
            $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        }

        /** Set initial value to check the override value */
        if (true === $initialValueSet) {
            $this->seoDataSaver->save([
                new SeoDataSaver\Struct\SeoDataSaverStruct(
                    DreiscSeoBulkEnum::AREA__PRODUCT,
                    $productId,
                    DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
                    $languageIdDe,
                    null,
                    'Initial value product',
                    true
                )
            ]);
        }

        /** Create a template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_DESCRIPTION)
            ->setName('My Bulk Template')
            ->setTemplate('{{ product.translated.name }} - {{ product.productNumber }}');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit($inherit)
            ->setOverwrite($override);

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Create a command tester **/
        $commandTester = new CommandTester($this->productCommand);
        $commandTester->execute([]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            null
        );

        /** Check the value of the child */
        $value = $seoDataFetchResultStruct->getMetaDescription();
        if (true === $isParentCategoryId) {
            if (false === $initialValueSet && false === $inherit && false === $override) {
                $this->assertNull($value);
            } elseif (false === $initialValueSet && false === $inherit && true === $override) {
                $this->assertNull($value);
            } elseif (true === $initialValueSet && false === $inherit && false === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (true === $initialValueSet && false === $inherit && true === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (true === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (false === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (false === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (true === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            }
        } else {
            if (false === $initialValueSet && false === $inherit && false === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (false === $initialValueSet && false === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (true === $initialValueSet && false === $inherit && false === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (true === $initialValueSet && false === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (true === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('Initial value product', $value);
            } elseif (false === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (false === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            } elseif (true === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('Standard Produkt 1000 - SW-1000', $value);
            }
        }
    }

    /**
     * @dataProvider dataProvider_initialInheritOverride
     *
     * @param bool $isParentCategoryId
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     */
    public function test_url(bool $isParentCategoryId, bool $initialValueSet, bool $inherit, bool $override): void
    {
        /** Make sure there are no cached seo bulks */
        DreiscSeoBulkRepository::resetCache();

        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $productId = DemoDataIds::PRODUCT_SW_1000;

        /** Set the seo url temlplate, so that we can detect the default urls */
        $this->seoUrlTemplateRepository->updateByCriteria([
            'template' => '{{ product.translated.name }}/{{ product.productNumber }}/AUTO-GENERATED'
        ],
            (new Criteria())
                ->addFilter(
                    new EqualsFilter('entityName', 'product')
                )
        );

        if (true === $isParentCategoryId) {
            $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;
        } else {
            $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        }

        /** Make sure, that the urls are reset */
        $this->seoUrlRepository->deleteByCriteria(
            (new Criteria())
                ->addFilter(
                    new EqualsFilter('foreignKey', $productId)
                )
        );

        /** Set initial value to check the override value */
        if (true === $initialValueSet) {
            $this->seoDataSaver->save([
                new SeoDataSaver\Struct\SeoDataSaverStruct(
                    DreiscSeoBulkEnum::AREA__PRODUCT,
                    $productId,
                    DreiscSeoBulkEnum::SEO_OPTION__URL,
                    $languageIdDe,
                    DemoDataIds::SALES_CHANNEL__MAIN_SHOP,
                    'Initial value product',
                    true
                )
            ]);
        }

        /** Create a template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__URL)
            ->setName('My Bulk Template')
            ->setTemplate('{{ product.translated.name }} - {{ product.productNumber }}');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products » Standard-Products" */
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setSalesChannelId(DemoDataIds::SALES_CHANNEL__MAIN_SHOP)
            ->setArea(DreiscSeoBulkEnum::AREA__PRODUCT)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__URL)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit($inherit)
            ->setOverwrite($override);

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Create a command tester **/
        $commandTester = new CommandTester($this->productCommand);
        $commandTester->execute([]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->productSeoDataFetcher->fetch(
            $productId,
            $languageIdDe,
            DemoDataIds::SALES_CHANNEL__MAIN_SHOP
        );

        /** Check the value of the child */
        $childValue = $seoDataFetchResultStruct->getUrl();
        if (true === $isParentCategoryId) {
            if (false === $initialValueSet && false === $inherit && false === $override) {
                $this->assertNull($childValue);
            } elseif (false === $initialValueSet && false === $inherit && true === $override) {
                $this->assertNull($childValue);
            } elseif (true === $initialValueSet && false === $inherit && false === $override) {
                $this->assertSame('initial-value-product', $childValue);
            } elseif (true === $initialValueSet && false === $inherit && true === $override) {
                $this->assertSame('initial-value-product', $childValue);
            } elseif (true === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('initial-value-product', $childValue);
            } elseif (false === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('standard-produkt-1000-sw-1000', $childValue);
            } elseif (false === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('standard-produkt-1000-sw-1000', $childValue);
            } elseif (true === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('standard-produkt-1000-sw-1000', $childValue);
            }
        } else {
            if (false === $initialValueSet && false === $inherit && false === $override) {
                $this->assertSame('standard-produkt-1000-sw-1000', $childValue);
            } elseif (false === $initialValueSet && false === $inherit && true === $override) {
                $this->assertSame('standard-produkt-1000-sw-1000', $childValue);
            } elseif (true === $initialValueSet && false === $inherit && false === $override) {
                $this->assertSame('initial-value-product', $childValue);
            } elseif (true === $initialValueSet && false === $inherit && true === $override) {
                $this->assertSame('standard-produkt-1000-sw-1000', $childValue);
            } elseif (true === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('initial-value-product', $childValue);
            } elseif (false === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('standard-produkt-1000-sw-1000', $childValue);
            } elseif (false === $initialValueSet && true === $inherit && false === $override) {
                $this->assertSame('standard-produkt-1000-sw-1000', $childValue);
            } elseif (true === $initialValueSet && true === $inherit && true === $override) {
                $this->assertSame('standard-produkt-1000-sw-1000', $childValue);
            }
        }
    }
}
