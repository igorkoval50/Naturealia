<?php declare(strict_types=1);

namespace DreiscSeoPro\Test\Command\BulkGenerator;

use Doctrine\DBAL\DBALException;
use DreiscSeoPro\Command\BulkGenerator\CategoryCommand;
use DreiscSeoPro\Core\Content\Category\CategoryRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEntity;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkRepository;
use DreiscSeoPro\Core\Content\SeoUrl\SeoUrlRepository;
use DreiscSeoPro\Core\Content\SeoUrlTemplate\SeoUrlTemplateRepository;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataIds;
use DreiscSeoPro\Core\Foundation\DemoData\DemoDataRepository;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\CategorySeoDataFetcher;
use DreiscSeoPro\Core\Seo\SeoDataFetcher\Struct\SeoDataFetchResultStruct;
use DreiscSeoPro\Core\Seo\SeoDataSaver;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Test\TestCaseBase\IntegrationTestBehaviour;
use PHPUnit\Framework\TestCase;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidLengthException;
use Shopware\Core\Framework\Uuid\Uuid;
use Symfony\Component\Console\Tester\CommandTester;

class CategoryCommandTest extends TestCase
{
    use IntegrationTestBehaviour;

    /**
     * @var CategoryCommand
     */
    private $categoryCommand;

    /**
     * @var DreiscSeoBulkRepository
     */
    private $dreiscSeoBulkRepository;

    /**
     * @var DreiscSeoBulkTemplateRepository
     */
    private $dreiscSeoBulkTemplateRepository;

    /**
     * @var DemoDataRepository
     */
    private $demoDataRepository;

    /**
     * @var CategorySeoDataFetcher
     */
    private $categorySeoDataFetcher;

    /**
     * @var SeoDataSaver
     */
    private $seoDataSaver;

    /**
     * @var SeoUrlRepository
     */
    private $seoUrlRepository;

    /**
     * @var SeoUrlTemplateRepository
     */
    private $seoUrlTemplateRepository;

    protected function setUp(): void
    {
        $this->categoryCommand = $this->getContainer()->get(CategoryCommand::class);
        $this->dreiscSeoBulkRepository = $this->getContainer()->get(DreiscSeoBulkRepository::class);
        $this->dreiscSeoBulkTemplateRepository = $this->getContainer()->get(DreiscSeoBulkTemplateRepository::class);
        $this->demoDataRepository = $this->getContainer()->get(DemoDataRepository::class);
        $this->categorySeoDataFetcher = $this->getContainer()->get(CategorySeoDataFetcher::class);
        $this->seoDataSaver = $this->getContainer()->get(SeoDataSaver::class);
        $this->seoUrlRepository = $this->getContainer()->get(SeoUrlRepository::class);
        $this->seoUrlTemplateRepository = $this->getContainer()->get(SeoUrlTemplateRepository::class);
    }

    /**
     * @return array
     */
    public function dataProvider_initialInheritOverride(): array
    {
        return [
            [ false, false, false ],
            [ false, false, true ],
            [ false, true, true ],
            [ false, true, false ],
            [ true, false, false ],
            [ true, false, true ],
            [ true, true, true ],
            [ true, true, false ],
        ];
    }

    /**
     * @dataProvider dataProvider_initialInheritOverride
     *
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     */
    public function test_metaTitle(bool $initialValueSet, bool $inherit, bool $override): void
    {
        /** Make sure there are no cached seo bulks */
        DreiscSeoBulkRepository::resetCache();

        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;
        $childCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;

        /** Set initial value to check the override value */
        if (true === $initialValueSet) {
            $this->seoDataSaver->save([
                new SeoDataSaver\Struct\SeoDataSaverStruct(
                    DreiscSeoBulkEnum::AREA__CATEGORY,
                    $categoryId,
                    DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                    $languageIdDe,
                    null,
                    'Initial value category',
                    true
                ),
                new SeoDataSaver\Struct\SeoDataSaverStruct(
                    DreiscSeoBulkEnum::AREA__CATEGORY,
                    $childCategoryId,
                    DreiscSeoBulkEnum::SEO_OPTION__META_TITLE,
                    $languageIdDe,
                    null,
                    'Initial value child category',
                    true
                )
            ]);
        }

        /** Create a template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_TITLE)
            ->setName('My Bulk Template')
            ->setTemplate('Kategorie: {% if null != category.parent %}{{ category.parent.translated.name }} » {% endif %}{{ category.translated.name }}');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products" */
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_TITLE)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit($inherit)
            ->setOverwrite($override);

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Create a command tester **/
        $commandTester = new CommandTester($this->categoryCommand);
        $commandTester->execute([]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            $categoryId,
            $languageIdDe,
            null
        );

        /** Check the value of the child */
        $value = $seoDataFetchResultStruct->getMetaTitle();
        if (true === $initialValueSet && false === $override) {
            $this->assertSame('Initial value category', $value);
        } else{
            $this->assertSame('Kategorie: Hauptnavigation » Produkte', $value);
        }

        /** Check, the child category */
        $childSeoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            $childCategoryId,
            $languageIdDe,
            null
        );

        /** Check the value of the child */
        $childValue = $childSeoDataFetchResultStruct->getMetaTitle();
        if (false === $initialValueSet && false === $inherit) {
            $this->assertNull($childValue);
        } elseif (true === $initialValueSet && false === $inherit) {
            $this->assertSame('Initial value child category', $childValue);
        } elseif (true === $initialValueSet && true === $inherit && false === $override) {
            $this->assertSame('Initial value child category', $childValue);
        } elseif (false === $initialValueSet && true === $inherit) {
            $this->assertSame('Kategorie: Produkte » Standard-Produkte', $childValue);
        } elseif (true === $initialValueSet && true === $inherit && true === $override) {
            $this->assertSame('Kategorie: Produkte » Standard-Produkte', $childValue);
        }
    }

    /**
     * @dataProvider dataProvider_initialInheritOverride
     *
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     */
    public function test_metaDescription(bool $initialValueSet, bool $inherit, bool $override): void
    {
        /** Make sure there are no cached seo bulks */
        DreiscSeoBulkRepository::resetCache();

        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;
        $childCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;

        /** Set initial value to check the override value */
        if (true === $initialValueSet) {
            $this->seoDataSaver->save([
                new SeoDataSaver\Struct\SeoDataSaverStruct(
                    DreiscSeoBulkEnum::AREA__CATEGORY,
                    $categoryId,
                    DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
                    $languageIdDe,
                    null,
                    'Initial value category',
                    true
                ),
                new SeoDataSaver\Struct\SeoDataSaverStruct(
                    DreiscSeoBulkEnum::AREA__CATEGORY,
                    $childCategoryId,
                    DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION,
                    $languageIdDe,
                    null,
                    'Initial value child category',
                    true
                )
            ]);
        }

        /** Create a template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__META_DESCRIPTION)
            ->setName('My Bulk Template')
            ->setTemplate('Kategorie: {% if null != category.parent %}{{ category.parent.translated.name }} » {% endif %}{{ category.translated.name }}');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products" */
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setArea(DreiscSeoBulkEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__META_DESCRIPTION)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit($inherit)
            ->setOverwrite($override);

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Create a command tester **/
        $commandTester = new CommandTester($this->categoryCommand);
        $commandTester->execute([]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            $categoryId,
            $languageIdDe,
            null
        );

        /** Check the value of the child */
        $value = $seoDataFetchResultStruct->getMetaDescription();
        if (true === $initialValueSet && false === $override) {
            $this->assertSame('Initial value category', $value);
        } else{
            $this->assertSame('Kategorie: Hauptnavigation » Produkte', $value);
        }

        /** Check, the child category */
        $childSeoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            $childCategoryId,
            $languageIdDe,
            null
        );

        /** Check the value of the child */
        $childValue = $childSeoDataFetchResultStruct->getMetaDescription();
        if (false === $initialValueSet && false === $inherit) {
            $this->assertNull($childValue);
        } elseif (true === $initialValueSet && false === $inherit) {
            $this->assertSame('Initial value child category', $childValue);
        } elseif (true === $initialValueSet && true === $inherit && false === $override) {
            $this->assertSame('Initial value child category', $childValue);
        } elseif (false === $initialValueSet && true === $inherit) {
            $this->assertSame('Kategorie: Produkte » Standard-Produkte', $childValue);
        } elseif (true === $initialValueSet && true === $inherit && true === $override) {
            $this->assertSame('Kategorie: Produkte » Standard-Produkte', $childValue);
        }
    }

    /**
     * @dataProvider dataProvider_initialInheritOverride
     *
     * @param bool $initialValueSet
     * @param bool $inherit
     * @param bool $override
     * @throws DBALException
     * @throws InconsistentCriteriaIdsException
     * @throws InvalidUuidException
     * @throws InvalidUuidLengthException
     * @throws SeoDataSaver\Exception\UnknownAreaException
     */
    public function test_url(bool $initialValueSet, bool $inherit, bool $override): void
    {
        /** Make sure there are no cached seo bulks */
        DreiscSeoBulkRepository::resetCache();

        $languageIdDe = $this->demoDataRepository->getLanguageIdDe();
        $categoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS;
        $childCategoryId = DemoDataIds::CATEGORY__MAIN__PRODUCTS__STANDARD_PRODUCTS;
        $salesChannelId = DemoDataIds::SALES_CHANNEL__MAIN_SHOP;

        /** Set the seo url temlplate, so that we can detect the default urls */
        $this->seoUrlTemplateRepository->updateByCriteria([
            'template' => '{% for part in category.seoBreadcrumb %}{{ part }}{% endfor %}/AUTO-GENERATED'
        ],
            (new Criteria())
                ->addFilter(
                    new EqualsFilter('entityName', 'category')
                )
        );

        /** Make sure that there is no url set for the ids */
        foreach([$categoryId, $childCategoryId] as $usedId) {
            $this->seoUrlRepository->deleteByCriteria(
                (new Criteria())
                    ->addFilter(
                        new EqualsFilter('routeName', SeoUrlRepository::ROUTE_NAME__FRONTEND_NAVIGATION_PAGE),
                        new EqualsFilter('foreignKey', $usedId)
                    )
            );
        }

        /** Set initial value to check the override value */
        if (true === $initialValueSet) {
            $this->seoDataSaver->save([
                new SeoDataSaver\Struct\SeoDataSaverStruct(
                    DreiscSeoBulkEnum::AREA__CATEGORY,
                    $categoryId,
                    DreiscSeoBulkEnum::SEO_OPTION__URL,
                    $languageIdDe,
                    $salesChannelId,
                    'Initial value category',
                    true
                ),
                new SeoDataSaver\Struct\SeoDataSaverStruct(
                    DreiscSeoBulkEnum::AREA__CATEGORY,
                    $childCategoryId,
                    DreiscSeoBulkEnum::SEO_OPTION__URL,
                    $languageIdDe,
                    $salesChannelId,
                    'Initial value child category',
                    true
                )
            ]);
        }

        /** Create a template */
        $dreiscSeoBulkTemplateEntity = (new DreiscSeoBulkTemplateEntity())
            ->setId(Uuid::randomHex())
            ->setArea(DreiscSeoBulkTemplateEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkTemplateEnum::SEO_OPTION__URL)
            ->setName('My Bulk Template')
            ->setTemplate('Kategorie: {% if null != category.parent %}{{ category.parent.translated.name }} » {% endif %}{{ category.translated.name }}');

        $this->dreiscSeoBulkTemplateRepository->create([ $dreiscSeoBulkTemplateEntity ]);

        /** Create the bulk setting for the category "Mainshop » Products" */
        $dreiscSeoBulkEntity = (new DreiscSeoBulkEntity())
            ->setId(Uuid::randomHex())
            ->setCategoryId($categoryId)
            ->setLanguageId($languageIdDe)
            ->setSalesChannelId($salesChannelId)
            ->setArea(DreiscSeoBulkEnum::AREA__CATEGORY)
            ->setSeoOption(DreiscSeoBulkEnum::SEO_OPTION__URL)
            ->setDreiscSeoBulkTemplateId($dreiscSeoBulkTemplateEntity->getId())
            ->setInherit($inherit)
            ->setOverwrite($override);

        $this->dreiscSeoBulkRepository->create([ $dreiscSeoBulkEntity ]);

        /** Create a command tester **/
        $commandTester = new CommandTester($this->categoryCommand);
        $commandTester->execute([]);

        /** Check, if the value is set */
        $seoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            $categoryId,
            $languageIdDe,
            $salesChannelId
        );

        /** Check the value of the child */
        $value = $seoDataFetchResultStruct->getUrl();
        if (true === $initialValueSet && false === $override) {
            $this->assertSame('initial-value-category', $value);
        } else{
            $this->assertSame('kategorie-hauptnavigation-produkte', $value);
        }

        /** Check, the child category */
        $childSeoDataFetchResultStruct = $this->categorySeoDataFetcher->fetch(
            $childCategoryId,
            $languageIdDe,
            $salesChannelId
        );

        /** Check the value of the child */
        $childValue = $childSeoDataFetchResultStruct->getUrl();
        if (false === $initialValueSet && false === $inherit) {
            /** Url was not generated from our tool, because there is no inherit */
            $this->assertNull($childValue);
        } elseif (true === $initialValueSet && false === $inherit) {
            $this->assertSame('initial-value-child-category', $childValue);
        } elseif (true === $initialValueSet && true === $inherit && false === $override) {
            $this->assertSame('initial-value-child-category', $childValue);
        } elseif (false === $initialValueSet && true === $inherit) {
            $this->assertSame('kategorie-produkte-standard-produkte', $childValue);
        } elseif (true === $initialValueSet && true === $inherit && true === $override) {
            $this->assertSame('kategorie-produkte-standard-produkte', $childValue);
        }
    }
}
