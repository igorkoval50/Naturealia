<?php declare(strict_types=1);

namespace DreiscSeoPro\Administration\Controller;

use DreiscSeoPro\Command\BulkGenerator\CategoryCommand;
use DreiscSeoPro\Command\BulkGenerator\ProductCommand;
use DreiscSeoPro\Core\BulkGenerator\CategoryGenerator;
use DreiscSeoPro\Core\BulkGenerator\CategoryTemplateGenerator;
use DreiscSeoPro\Core\BulkGenerator\Generator\AbstractGenerator;
use DreiscSeoPro\Core\BulkGenerator\ProductGenerator;
use DreiscSeoPro\Core\BulkGenerator\ProductTemplateGenerator;
use DreiscSeoPro\Core\BulkGenerator\TemplateGenerator\Struct\TemplateGeneratorStruct;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\Aggregate\DreiscSeoBulkTemplate\DreiscSeoBulkTemplateRepository;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkEnum;
use DreiscSeoPro\Core\Content\DreiscSeoBulk\DreiscSeoBulkRepository;
use DreiscSeoPro\Core\Foundation\Dal\Iterator\IteratorFactory;
use RuntimeException;
use Shopware\Core\Content\Category\CategoryDefinition;
use Shopware\Core\Content\Product\ProductDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\Uuid\Uuid;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Shopware\Core\Framework\Routing\Annotation\RouteScope;

class DreiscSeoBulkController extends AbstractController
{
    /**
     * @var DreiscSeoBulkRepository
     */
    private $dreiscSeoBulkRepository;

    /**
     * @var DreiscSeoBulkTemplateRepository
     */
    private $dreiscSeoBulkTemplateRepository;

    /**
     * @var CategoryTemplateGenerator
     */
    private $categoryBulkGenerator;

    /**
     * @var ProductTemplateGenerator
     */
    private $productBulkGenerator;

    /**
     * @var IteratorFactory
     */
    private $iteratorFactory;

    /**
     * @var CategoryGenerator
     */
    private $categoryGenerator;

    /**
     * @var ProductGenerator
     */
    private $productGenerator;

    /**
     * @param DreiscSeoBulkRepository $dreiscSeoBulkRepository
     * @param DreiscSeoBulkTemplateRepository $dreiscSeoBulkTemplateRepository
     * @param CategoryTemplateGenerator $categoryBulkGenerator
     * @param ProductTemplateGenerator $productBulkGenerator
     * @param IteratorFactory $iteratorFactory
     * @param CategoryGenerator $categoryGenerator
     * @param ProductGenerator $productGenerator
     */
    public function __construct(DreiscSeoBulkRepository $dreiscSeoBulkRepository, DreiscSeoBulkTemplateRepository $dreiscSeoBulkTemplateRepository, CategoryTemplateGenerator $categoryBulkGenerator, ProductTemplateGenerator $productBulkGenerator, IteratorFactory $iteratorFactory, CategoryGenerator $categoryGenerator, ProductGenerator $productGenerator)
    {
        $this->dreiscSeoBulkRepository = $dreiscSeoBulkRepository;
        $this->dreiscSeoBulkTemplateRepository = $dreiscSeoBulkTemplateRepository;
        $this->categoryBulkGenerator = $categoryBulkGenerator;
        $this->productBulkGenerator = $productBulkGenerator;
        $this->iteratorFactory = $iteratorFactory;
        $this->categoryGenerator = $categoryGenerator;
        $this->productGenerator = $productGenerator;
    }

    /**
     * @RouteScope(scopes={"api"})
     * @Route("/api/dreisc.seo/dreisc.seo.bulk/getResponsibleSeoBulk", defaults={"auth_required"=true})
     * @throws InconsistentCriteriaIdsException
     */
    public function getResponsibleSeoBulk(Request $request): JsonResponse
    {
        $bulkTemplateInformation = [];

        /** Check the required parameters */
        $categoryIds = $request->get('categoryIds');
        if (empty($categoryIds)) {
            throw new RuntimeException('Missing parameter: categoryIds');
        }

        $area = $request->get('area');
        if (empty($area)) {
            throw new RuntimeException('Missing parameter: area');
        }

        $seoOption = $request->get('seoOption');
        if (empty($seoOption)) {
            throw new RuntimeException('Missing parameter: seoOption');
        }

        $languageId = $request->get('languageId');
        if (empty($languageId)) {
            throw new RuntimeException('Missing parameter: languageId');
        }

        $salesChannelId = $request->get('salesChannelId');
        if (empty($salesChannelId)) {
            $salesChannelId = null;
        }

        foreach($categoryIds as $categoryId) {
            /** Load the responsible seo bulk configuration */
            $dreiscSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleSeoBulk(
                $categoryId,
                $area,
                $seoOption,
                $languageId,
                $salesChannelId
            );

            $bulkTemplateInformation[] = [
                'categoryId' => $categoryId,
                'seoBulkEntity' => $dreiscSeoBulkEntity
            ];
        }

        return new JsonResponse($bulkTemplateInformation);
    }

    /**
     * @RouteScope(scopes={"api"})
     * @Route("/api/dreisc.seo/dreisc.seo.bulk/getResponsibleProductSeoBulkRespectPriority", defaults={"auth_required"=true})
     * @throws InconsistentCriteriaIdsException
     */
    public function getResponsibleProductSeoBulkRespectPriority(Request $request): JsonResponse
    {
        /** Check the required parameters */
        $productId = $request->get('productId');
        if (empty($productId)) {
            throw new RuntimeException('Missing parameter: productId');
        }

        $seoOption = $request->get('seoOption');
        if (empty($seoOption)) {
            throw new RuntimeException('Missing parameter: seoOption');
        }

        $languageId = $request->get('languageId');
        if (empty($languageId)) {
            throw new RuntimeException('Missing parameter: languageId');
        }

        $salesChannelId = $request->get('salesChannelId');
        if (empty($salesChannelId)) {
            $salesChannelId = null;
        }

        /** Load the responsible seo bulk configuration */
        $dreiscSeoBulkEntity = $this->dreiscSeoBulkRepository->getResponsibleProductSeoBulkRespectPriority(
            $productId,
            $seoOption,
            $languageId,
            $salesChannelId
        );

        return new JsonResponse($dreiscSeoBulkEntity);
    }

    /**
     * @RouteScope(scopes={"api"})
     * @Route("/api/dreisc.seo/dreisc.seo.bulk/deleteBulkTemplate", defaults={"auth_required"=true})
     * @throws InconsistentCriteriaIdsException
     */
    public function deleteBulkTemplate(Request $request): JsonResponse
    {
        $bulkTemplateInformation = [];
        $limit = 5;

        /** Check the required parameters */
        $seoBulkTemplateId = $request->get('seoBulkTemplateId');
        if (empty($seoBulkTemplateId)) {
            throw new RuntimeException('Missing parameter: seoBulkTemplateId');
        }

        $deleteSeoBulkWhichUseTemplate = $request->get('deleteSeoBulkWhichUseTemplate');

        /** Fetch the details of the current bulk template */
        $seoBulkTemplateEntity = $this->dreiscSeoBulkTemplateRepository->get($seoBulkTemplateId);

        /** Fetch seo bulks which use the template */
        $seoBulkSearchResult = $this->dreiscSeoBulkRepository->getSeoBulkListBySeoBulkTemplateId($seoBulkTemplateId, $limit);
        if ($seoBulkSearchResult->getTotal() > 0) {
            if (true === $deleteSeoBulkWhichUseTemplate) {
                $this->dreiscSeoBulkRepository->deleteBySeoBulkTemplateId($seoBulkTemplateId);
            } else {
                return new JsonResponse([
                    'success' => false,
                    'seoBulkTemplateEntity' => $seoBulkTemplateEntity,
                    'seoBulkEntriesWithCurrentTemplate' => $seoBulkSearchResult->getEntities(),
                    'seoBulkEntriesWithCurrentTemplateTotal' => $seoBulkSearchResult->getTotal()
                ]);
            }
        }

        /** Delete the bulk template */
        $this->dreiscSeoBulkTemplateRepository->delete([
            [ 'id' => $seoBulkTemplateId ]
        ]);

        return new JsonResponse([
            'success' => true
        ]);
    }

    /**
     * @RouteScope(scopes={"api"})
     * @Route("/api/dreisc.seo/dreisc.seo.bulk/getTemplatePreview", defaults={"auth_required"=true})
     * @throws InconsistentCriteriaIdsException
     */
    public function getTemplatePreview(Request $request): JsonResponse
    {
        $area = $request->get('area');
        $activeItemId = $request->get('activeItemId');
        $seoOption = $request->get('seoOption');
        $languageId = $request->get('languageId');
        $salesChannelId = $request->get('salesChannelId');
        $template = $request->get('template');
        $spaceless = $request->get('spaceless');

        /** Abort if the template is null or empty */
        if(empty($template)) {
            return new JsonResponse([
                'success' => true,
                'renderedTemplate' => ''
            ]);
        }

        try {
            if (DreiscSeoBulkEnum::AREA__CATEGORY === $area) {
                $renderedTemplate = $this->categoryBulkGenerator->generateTemplate(
                    new TemplateGeneratorStruct(
                        $area,
                        $activeItemId,
                        $seoOption,
                        $languageId,
                        $salesChannelId,
                        $spaceless
                    ),
                    $template
                );
            } elseif (DreiscSeoBulkEnum::AREA__PRODUCT === $area) {
                $renderedTemplate = $this->productBulkGenerator->generateTemplate(
                    new TemplateGeneratorStruct(
                        $area,
                        $activeItemId,
                        $seoOption,
                        $languageId,
                        $salesChannelId,
                        $spaceless
                    ),
                    $template
                );
            } else {
                throw new RuntimeException(sprintf(
                    'Invalid area "%s"',
                    $area
                ));
            }

            return new JsonResponse([
                'success' => true,
                'renderedTemplate' => $renderedTemplate
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * @RouteScope(scopes={"api"})
     * @Route("/api/dreisc.seo/dreisc.seo.bulk/prepareBulkGenerator", defaults={"auth_required"=true})
     * @param Request $request
     * @return JsonResponse
     */
    public function prepareBulkGenerator(Request $request): JsonResponse
    {
        $area = $request->get('area');
        if (empty($area)) {
            throw new RuntimeException('Missing parameter: area');
        }

        $bulkIterator = $this->createBulkIterator($area, 0, 1);

        return new JsonResponse([
            'success' => true,
            'total' => $bulkIterator->fetchCount()
        ]);
    }

    /**
     * @RouteScope(scopes={"api"})
     * @Route("/api/dreisc.seo/dreisc.seo.bulk/runBulkGeneratorThread", defaults={"auth_required"=true})
     * @param Request $request
     * @return JsonResponse
     */
    public function runBulkGeneratorThread(Request $request): JsonResponse
    {
        $area = $request->get('area');
        if (empty($area)) {
            throw new RuntimeException('Missing parameter: area');
        }

        $offset = (int) $request->get('offset');
        $limit = (int) $request->get('limit');
        if (empty($limit)) {
            throw new RuntimeException('Missing parameter: limit');
        }

        if (DreiscSeoBulkEnum::AREA__PRODUCT === $area) {
            /** @var AbstractGenerator $generator */
            $generator = $this->productGenerator;
        } elseif (DreiscSeoBulkEnum::AREA__CATEGORY === $area) {
            /** @var AbstractGenerator $generator */
            $generator = $this->categoryGenerator;
        } else {
            throw new RuntimeException('Invalid area: ' . $area);
        }

        $bulkIterator = $this->createBulkIterator($area, $offset, $limit);
        $ids = $bulkIterator->fetch();
        $generator->generate($ids);

        return new JsonResponse([
            'success' => true,
            'generatedCount' => count($ids)
        ]);
    }

    private function createBulkIterator(string $area, int $offset, int $limit)
    {
        switch ($area) {
            case DreiscSeoBulkEnum::AREA__CATEGORY:
                $entityDefinition = CategoryDefinition::class;
                $orderByStructs = CategoryCommand::createOrderByStructs();
                break;

            case DreiscSeoBulkEnum::AREA__PRODUCT:
                $entityDefinition = ProductDefinition::class;
                $orderByStructs = ProductCommand::createOrderByStructs();
                break;

            default:
                throw new RuntimeException('Invalid area: ' . $area);
        }

        return $this->iteratorFactory->createIdIterator(
            new IteratorFactory\Struct\IteratorFactoryStruct(
                $entityDefinition,
                $offset,
                $limit,
                $orderByStructs
            )
        );
    }
}
