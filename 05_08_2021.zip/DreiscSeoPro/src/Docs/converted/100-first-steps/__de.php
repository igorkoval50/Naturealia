<?php return array (
  'DE' => 
  array (
    'path' => 'de_100-first-steps',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional/first-steps',
    'title' => 'Erste Schritte',
    'menuTitle' => 'Erste Schritte',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Erste Schritte</h1>
<a name="installation"></a>
<h2>Installation</h2>
<p>SEO Professional kann ausschließlich über den Shopware Store erworben werden. Stelle sicher, dass du das Plugin installiert und aktiviert hast. </p>
<p>Weitere Informationen hierzu findest du in der <a href="https://docs.shopware.com/de/shopware-6-de/einstellungen/plugins?category=shopware-6-de/einstellungen/plugins-menue"><strong>Shopware 6 Dokumentation</strong></a></p>
<a name="seo-professional-adminstration"></a>
<h2>SEO Professional Adminstration</h2>
<p>Nachdem das Plugin installiert und aktiviert wurde, ist die Adminstration im Hauptmenü zu finden.</p>
<p><img src="wiki/dreisc_seo_pro/100-first-steps/img/seo-professional-menue.png" alt="SEO Professional Hauptmenü in der Shopware Administration" /></p>
<p>Alle weiteren Informationen zu den einzelnen Modulen findest du unter dem Menüpunkt <a href="docs/seo-professional/modules"><strong>Module</strong></a>.</p>
<a name="deine-naechsten-schritte"></a>
<h2>Deine nächsten Schritte</h2>
<p>Nachdem die Installation abgeschlossen ist, macht es Sinn sich mit den SEO Einstellungen zu beschäftigen, die SEO Professional für die verschiedenen Shopware Module bereitstellt. Einen Guide hierzu findet du unter <a href="docs/seo-professional/seo-settings"><strong>SEO Einstellungen</strong></a>.</p>
<p>Darüber hinaus bietet SEO Professional verschiedene Module an, die dich in deinem SEO Alltag unterstützen können. Beschreibungen dieser Module findest du unter <a href="docs/seo-professional/modules"><strong>SEO Professional Module</strong></a></p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_100-first-steps',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional/first-steps',
    'title' => 'Erste Schritte',
    'menuTitle' => 'Erste Schritte',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Erste Schritte</h1>
<a name="installation"></a>
<h2>Installation</h2>
<p>SEO Professional kann ausschließlich über den Shopware Store erworben werden. Stelle sicher, dass du das Plugin installiert und aktiviert hast. </p>
<p>Weitere Informationen hierzu findest du in der <a href="https://docs.shopware.com/de/shopware-6-de/einstellungen/plugins?category=shopware-6-de/einstellungen/plugins-menue"><strong>Shopware 6 Dokumentation</strong></a></p>
<a name="seo-professional-adminstration"></a>
<h2>SEO Professional Adminstration</h2>
<p>Nachdem das Plugin installiert und aktiviert wurde, ist die Adminstration im Hauptmenü zu finden.</p>
<p><img src="wiki/dreisc_seo_pro/100-first-steps/img/seo-professional-menue.png" alt="SEO Professional Hauptmenü in der Shopware Administration" /></p>
<p>Alle weiteren Informationen zu den einzelnen Modulen findest du unter dem Menüpunkt <a href="docs/seo-professional/modules"><strong>Module</strong></a>.</p>
<a name="deine-naechsten-schritte"></a>
<h2>Deine nächsten Schritte</h2>
<p>Nachdem die Installation abgeschlossen ist, macht es Sinn sich mit den SEO Einstellungen zu beschäftigen, die SEO Professional für die verschiedenen Shopware Module bereitstellt. Einen Guide hierzu findet du unter <a href="docs/seo-professional/seo-settings"><strong>SEO Einstellungen</strong></a>.</p>
<p>Darüber hinaus bietet SEO Professional verschiedene Module an, die dich in deinem SEO Alltag unterstützen können. Beschreibungen dieser Module findest du unter <a href="docs/seo-professional/modules"><strong>SEO Professional Module</strong></a></p>
<p></p>',
  ),
);