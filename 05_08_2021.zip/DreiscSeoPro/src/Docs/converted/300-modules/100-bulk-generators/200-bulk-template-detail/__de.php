<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/100-bulk-generators/200-bulk-template-detail',
    'parent' => 'de_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/bulk-template-detail',
    'title' => 'Eigene Bulk Templates erstellen und bestehende bearbeiten',
    'menuTitle' => 'Eigene Bulk Templates erstellen und bestehende bearbeiten',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Eigene Bulk Templates erstellen und bestehende bearbeiten</h1>
<p>In diesem Abschnitt der Anleitung beschreiben wir, wie man eigene Templates erstellt sowie bestehende Templates bearbeitet.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#voraussetzung">Voraussetzung</a></li><li class="headline-level2"><a href="#einstellungen-der-bulk-templates">Einstellungen der Bulk Templates</a></li><li class="headline-level2"><a href="#allgemeine-informationen-zu-dem-template-code">Allgemeine Informationen zu dem Template-Code</a></li><li class="headline-level2"><a href="#verfuegbare-variablen-fuer-das-template">Verfügbare Variablen für das Template</a></li><li class="headline-level3"><a href="#live-template-variablen-und-autoload-variablen">Live Template Variablen und Autoload-Variablen</a></li><li class="headline-level3"><a href="#variablen-fuer-produkte">Variablen für Produkte</a></li><li class="headline-level3"><a href="#variablen-fuer-kategorien">Variablen für Kategorien</a></li><li class="headline-level3"><a href="#allgemeine-variablen">Allgemeine Variablen</a></li><li class="headline-level2"><a href="#beispiel-produktname--ausgewaehlte-eigenschaft-ausgeben">Beispiel: Produktname + ausgewählte Eigenschaft ausgeben</a></li></ul></div></p>
<a name="voraussetzung"></a>
<h2>Voraussetzung</h2>
<p>Als Voraussetzung für diese Anleitung solltest du dir zunächst einmal die <a href="docs/seo-professional/modules/bulk-generators/general-info">Allgemeine Informationen zu den Bulk Generatoren sowie die Erste Schritte</a> anschauen. Hier wird u.a. auch beschrieben, wie du in die Konfigurationsoberfläche gelangst.</p>
<a name="einstellungen-der-bulk-templates"></a>
<h2>Einstellungen der Bulk Templates</h2>
<p>Bei der Konfiguration der Templates stehen die folgenden Einstellung zur Verfügung:</p>
<ul>
<li>
<p><strong>Name</strong><br>Definiert den internen Namen für das Template. Bei den von uns vorinstallierten Templates findest du hier Bezeichnungen wie <code>dreiscSeoBulkProduct.defaultTemplates.metaTitle.productName</code>. Hierbei handelt es sich lediglich um ein Textbaustein, sodass wir den Namen mehrsprachig zur Verfügung stellen können. Legst du eigene Templates an, so kann hier eine ganz normale Bezeichnung als Name hinterlegt werden.</p>
</li>
<li>
<p><strong>Vorschau-Produkt</strong><br>Hierbei handelt es sich um eine Auswahl, die ausschließlich für den <code>Produkt Bulk Generator</code> zur Verfügung steht. Erst wenn du hier ein Produkt ausgewählt hast, wird unten die entsprechende Vorschau des Templates angezeigt. Die Auswahl des Vorschau-Produkts wird nicht gespeichert. D.h., dass entsprechend bei jeder Bearbeitung des Templates ein Produkt ausgewählt werden muss, wenn eine Vorschau erwünscht ist.</p>
</li>
<li>
<p><strong>Leerzeichen zwischen HTML-Tags entfernen</strong><br>Ist diese Option aktiv, so werden Leerzeichen zwischen den HTML Tags entsprechend entfernt. Hierbei wird der Twig Filter spaceless auf das gesamte Template angewandt.<br><br>Weitere Informationen zu diesem Filter findest du unter:<br><a href="https://twig.symfony.com/doc/3.x/filters/spaceless.html">https://twig.symfony.com/doc/3.x/filters/spaceless.html</a></p>
</li>
<li>
<p><strong>Template</strong><br>Diese Option beherbergt das eigentiche Template.</p>
</li>
<li>
<p><strong>Vorschau</strong><br>In diesem Bereich wird die Vorschau des Templates angezeigt. Diese wird aktualisiert, sobald du eine Anpassung an dem Template durchführst. (Beachte bei dem Produkt Bulk Generator hierbei die Option <code>Vorschau-Produkt</code>)</p>
</li>
</ul>
<p><a data-dreisccmslightbox="images-253078" data-title="Einstellungen der Bulk Templates" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/200-bulk-template-detail/lightbox/einstellungen-der-bulk-templates.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/200-bulk-template-detail/lightbox/einstellungen-der-bulk-templates.png" alt="Einstellungen der Bulk Templates">
                        </a></p>
<a name="allgemeine-informationen-zu-dem-template-code"></a>
<h2>Allgemeine Informationen zu dem Template-Code</h2>
<p>Um eine maximale Flexibilität bei Generierung der Template zu gewährleisten, haben wir uns dazu entschieden, die Templates auf Basis von Twig zu gestalten. Hierbei handelt es sich um die Template Engine, die auch bei der Gestaltung der Storefront Themes zum Einsatz kommt. Um also eigene Templates zu erstellen, ist es erforderlich, dass du zumindest die Grundlagen dieser Engine erlernst oder aber entsprechend deine Shopware Agentur mit der Erstellung beauftragst.</p>
<p>Solltest du dich dazu entscheiden hier einen Einstieg zu finden und dich selbst ans Werk zu machen, so legen wir dir den folgenden Getting started Guide ans Herz:</p>
<p><a href="https://twig.symfony.com/doc/3.x/templates.html">https://twig.symfony.com/doc/3.x/templates.html</a></p>
<p>Des Weiteren findest du in unserer Dokumentation einen <a href="docs/seo-professional/modules/bulk-generators/exkurs-die-wichtigsten-code-snippets">Exkurs für die wichtigsten Code Snippets</a> sowie einen <a href="docs/seo-professional/modules/bulk-generators/exkurs-custom-fields">Exkurs für die Verwendung von Zusatzfeldern in Bulk Templates</a></p>
<a name="verfuegbare-variablen-fuer-das-template"></a>
<h2>Verfügbare Variablen für das Template</h2>
<p>Zur Gestaltung der Templates stehen dir eine Reihe von Variablen zur Verfügung, die du innerhalb der Templates nutzen kannst. (Eine genauere Auflistung findest du unten) Um diese komfortabel nutzen zu können, kannst du dir diese mit einem Klick auf die Auswahlbox <code>Variable hinzufügen</code> anzeigen und mit einem weiteren Klick auf die jeweilige Variable entsprechend im Template einfügen.</p>
<p><a data-dreisccmslightbox="images-253078" data-title="Variable hinzufügen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/200-bulk-template-detail/lightbox/variable-hinzufuegen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/200-bulk-template-detail/lightbox/variable-hinzufuegen.png" alt="Variable hinzufügen">
                        </a></p>
<a name="live-template-variablen-und-autoload-variablen"></a>
<h3>Live Template Variablen und Autoload-Variablen</h3>
<p>Neben den normalen Variablen existieren auch sogenannte Live Template Variablen. Diese erkennst du daran, dass sie am Anfang sowie am Ende jeweils zwei Rautezeichen aufweisen, wie bspw. <code>##shopName##</code>. Diese Variablen werden erst in der Storefront aufgelöst, da erst hier der Context feststeht. Im Fall des Shopnamens also der Verkaufskanal über den die Seite aufgerufen wurde. Ein weiteres Beispiel für eine Live Template Variable wäre bspw. der Preis eines Produkts. Dieser kann pro Kunde, Shop, Rabatt usw. ganz unterschiedlich sein. Für die Adminstration heißt das, dass hier nach der Generierung noch <code>##VARIABLEN_NAME##</code> zu sehen ist.</p>
<p>In der Auswahl der verfügbaren Variablen findest du teilweise Variablen mit einem <code>[↯]</code>-Zeichem im Pfad wie bspw. <code>(product.manufacturer[↯].translated.name)</code>. Dies kennzeichnet lediglich, dass der Teil dieser Variable nur dann geladen wird, wenn dieser im Template definiert wurde. Nutzt du im o.g. Beispiel also <code>product.manufacturer</code> im Template, so werden auch alle Herstellerinformationen des Produkts geladen.</p>
<a name="variablen-fuer-produkte"></a>
<h3>Variablen für Produkte</h3>
<p>Für den <code>Produkt Bulk Generator</code> stehen die folgenden Variablen zur Auswahl:</p>
<ul>
<li><strong>isVariant</strong> » Gibt an, ob es sich um eine Variante handelt</li>
<li><strong>product</strong> » Beinhaltet die Daten des aktuellen Produkts (ProductEntity)
<ul>
<li><strong>product.id</strong> » Id des Produkts</li>
<li><strong>product.translated.name</strong> » Name des Produkts</li>
<li><strong>product.translated.description</strong> » Beschreibung des Produkts</li>
<li><strong>product.translated.keywords</strong> » Keywords / Schlüsselwörter</li>
<li><strong>product.productNumber</strong> » Produktnummer</li>
<li><strong>product.manufacturerNumber</strong> » Herstellernummer</li>
<li><strong>product.manufacturer.id</strong> » Id des Herstellers</li>
<li><strong>product.manufacturer[↯].translated.name</strong> » Name des Herstellers</li>
<li><strong>product.manufacturer[↯].translated.description</strong> » Beschreibung des Herstellers</li>
<li><strong>product.ean</strong> » EAN Nummer</li>
<li><strong>product.restockTime</strong> » Wiederauffüllzeit in Tagen</li>
<li><strong>product.deliveryTime[↯].translated.name</strong> » Lieferzeit</li>
<li><strong>product.markAsTopseller</strong> » Produkt hervorheben [if-Beispiel]</li>
<li><strong>product.isCloseout</strong> » Abverkauf [if-Beispiel]</li>
<li><strong>product.shippingFree</strong> » Versandkostenfrei [if-Beispiel]</li>
<li><strong>product.stock</strong> » Lagerbestand</li>
<li><strong>product.availableStock</strong> » Verfügbarer Bestand</li>
<li><strong>product.minPurchase</strong> » Mindestabnahme</li>
<li><strong>product.maxPurchase</strong> » Maximalabnahme</li>
<li><strong>product.purchaseSteps</strong> » Staffelung</li>
<li><strong>product.packUnit</strong> » Verpackungseinheit</li>
<li><strong>product.purchaseUnit</strong> » Verkaufseinheit</li>
<li><strong>product.referenceUnit</strong> » Grundeinheit</li>
<li><strong>product.weight</strong> » Gewicht</li>
<li><strong>product.width</strong> » Breite</li>
<li><strong>product.height</strong> » Höhe</li>
<li><strong>product.length</strong> » Länge</li>
<li><strong>product.releaseDate.date</strong> » Erscheinungsdatum</li>
<li><strong>product.properties[↯]</strong> » Eigenschaften des Produkts [if-Beispiel]
<ul>
<li><em>Beispiel für eine Implementierung unter &quot;Produktname + Ausgabe der Produkteigenschaften&quot; (Meta Beschreibung)</em></li>
<li><strong>product.properties[n].translated.name</strong> » Name der Eigenschaft (bspw.: Grün)</li>
<li><strong>product.properties[n].groupId</strong> » Id der Eigenschaftsgruppe</li>
<li><strong>product.properties[n].group.translated.name</strong> » Name der Eigenschaftsgruppe (bspw. Farbe)</li>
</ul></li>
<li><strong>product.options[↯]</strong> » Varianten-Eigenschaften [if-Beispiel]
<ul>
<li>*Beispiel für eine Implementierung unter &quot;Produktname [+ Variantenoptionen bei Varianten]&quot; (Meta Titel)</li>
<li><strong>product.options[n].translated.name</strong> » Name der Varianteneigenschaft (bspw.: M)</li>
<li><strong>product.options[n].group.translated.name</strong> » Name der Gruppe der Varianteneigenschaft (bspw.: Größe)</li>
</ul></li>
<li><strong>product.tax.taxRate</strong> » Steuersatz des Produkts</li>
</ul></li>
<li><strong>productSeo</strong> » Beinhaltet die aufbereiteten SEO Einstellungen des 
<ul>
<li><strong>productSeo.metaTitle</strong> » Meta Titel des Produkts</li>
<li><strong>productSeo.isInheritedMetaTitle</strong> » Meta Titel des Produkts wurde vererbt [if-Beispiel]</li>
<li><strong>productSeo.metaDescription</strong> » Meta Beschreibung des Produkts</li>
<li><strong>productSeo.isInheritedMetaDescription</strong> » Meta Beschreibung des Produkts wurde vererbt [if-Beispiel]</li>
<li><strong>productSeo.url</strong> » URL des Produkts</li>
<li><strong>productSeo.isInheritedUrl</strong> » URL des Produkts wurde vererbt [if-Beispiel]</li>
</ul></li>
<li><strong>mainCategory</strong> »Beinhaltet die Daten der Hauptkategorie des Produkts*¹ (CategoryEntity)<br>(Bitte beachten: Diese Variable steht nur bei der SEO Einstellung SEO-URL zur Verfügung)
<ul>
<li><strong>mainCategory.id</strong> » Id der Hauptkategorie des Produkts</li>
<li><strong>mainCategory.translated.name</strong> » Name der Hauptkategorie des Produkts</li>
<li><strong>mainCategory.translated.description</strong> » Beschreibung der Hauptkategorie des Produkts</li>
<li><strong>mainCategory.translated.breadcrumb</strong> » Breadcrumb der Hauptkategorie des Produkts</li>
<li><strong>mainCategory.type</strong> » Kategory-Typ der Hauptkategorie des Produkts</li>
</ul></li>
<li><strong>mainCategorySeo</strong> » Beinhaltet die aufbereiteten SEO Einstellungen der Hauptkategorie des Produkts*¹<br>(Bitte beachten: Diese Variable steht nur bei der SEO Einstellung SEO-URL zur Verfügung)
<ul>
<li><strong>mainCategorySeo.metaTitle</strong> » Meta Titel der Hauptkategorie</li>
<li><strong>mainCategorySeo.isInheritedMetaTitle</strong> » Meta Titel der Hauptkategorie wurde vererbt [if-Beispiel]</li>
<li><strong>mainCategorySeo.metaDescription</strong> » Meta Beschreibung der Hauptkategorie</li>
<li><strong>mainCategorySeo.isInheritedMetaDescription</strong> » Meta Beschreibung der Hauptkategorie wurde vererbt [if-Beispiel]</li>
<li><strong>mainCategorySeo.url</strong> » URL der Hauptkategorie</li>
<li><strong>mainCategorySeo.isInheritedUrl</strong> » URL der Hauptkategorie wurde vererbt</li>
</ul></li>
<li><strong>##productPrice##</strong> » Diese Live Template Variable gibt den aktuellen Preis an. (Kann nicht für die SEO Einstellung SEO-URL verwendet werden)</li>
</ul>
<p><code>*¹ Hauptkategorie des Produkts: Hauptkategorie, die in den Artikelstammdaten unter "Canonical Urls" für den jeweiligen Vertriebskanal ausgewählt wurde.</code></p>
<a name="variablen-fuer-kategorien"></a>
<h3>Variablen für Kategorien</h3>
<p>Für den <code>Kategorie Bulk Generator</code> stehen die folgenden Variablen zur Auswahl:</p>
<ul>
<li><strong>category</strong> » Beinhaltet die Daten der Kategorie (CategoryEntity)
<ul>
<li><strong>category.id</strong> » Id der Kategorie des Produkts</li>
<li><strong>category.translated.name</strong> » Name der Kategorie</li>
<li><strong>category.translated.description</strong> » Beschreibung der Kategorie</li>
<li><strong>category.translated.breadcrumb</strong> » Breadcrumb der Kategorie</li>
</ul></li>
<li><strong>categorySeo</strong> » Beinhaltet die aufbereiteten SEO Einstellungen der Kategorie
<ul>
<li><strong>categorySeo.metaTitle</strong> » Meta Titel der Kategorie</li>
<li><strong>categorySeo.isInheritedMetaTitle</strong> » Meta Titel der Kategorie wurde vererbt [if-Beispiel]</li>
<li><strong>categorySeo.metaDescription</strong> » Meta Beschreibung der Kategorie</li>
<li><strong>categorySeo.isInheritedMetaDescription</strong> » Meta Beschreibung der Kategorie wurde vererbt [if-Beispiel]</li>
<li><strong>categorySeo.url</strong> » URL der Kategorie</li>
<li><strong>categorySeo.isInheritedUrl</strong> » URL der Kategorie wurde vererbt</li>
</ul></li>
<li><strong>categoryParentSeo</strong> » Beinhaltet die aufbereiteten SEO Einstellungen der direkten Eltern-Kategorie (category.parent)
<ul>
<li><strong>categoryParentSeo.metaTitle</strong> » Meta Titel der Eltern-Kategorie</li>
<li><strong>categoryParentSeo.isInheritedMetaTitle</strong> » Meta Titel der Eltern-Kategorie wurde vererbt [if-Beispiel]</li>
<li><strong>categoryParentSeo.metaDescription</strong> » Meta Beschreibung der Eltern-Kategorie</li>
<li><strong>categoryParentSeo.isInheritedMetaDescription</strong> » Meta Beschreibung der Eltern-Kategorie wurde vererbt [if-Beispiel]</li>
<li><strong>categoryParentSeo.url</strong> » URL der Eltern-Kategorie</li>
<li><strong>categoryParentSeo.isInheritedUrl</strong> » URL der Eltern-Kategorie wurde vererbt</li>
</ul></li>
<li><strong>parentCategories</strong> » Beinhaltet die Daten der Eltern-Kategorien der aktuellen Kategory (CategoryEntity[])</li>
<li><strong>childCategories</strong> » Beinhaltet die Daten der Kind-Kategorien der aktuellen Kategory (CategoryEntity[])</li>
</ul>
<a name="allgemeine-variablen"></a>
<h3>Allgemeine Variablen</h3>
<p>Die folgenden Variablen stehen sowohl beim <code>Produkt Bulk Generator</code> als auch beim <code>Kategorie Bulk Generator</code> zur Auswahl:</p>
<ul>
<li><strong>language</strong> » Beinhaltet das LanguageEntity des aktuellen Generators
<ul>
<li><strong>language.locale.code</strong> » Locale Code der Sprache (bspw.: de-DE)</li>
</ul></li>
<li><strong>systemDefaults</strong>
<ul>
<li><strong>systemDefaults.LANGUAGE_SYSTEM</strong> » Id der Standard-Sprache des Shops</li>
<li><strong>systemDefaults.CURRENCY</strong> » Id der Standard-Währung des Shops</li>
</ul></li>
<li><strong>##shopName##</strong> » Diese Live Template Variable gibt den Shopname des aktuellen Context an. (Kann nicht für die SEO Einstellung SEO-URL verwendet werden)</li>
</ul>
<a name="beispiel-produktname--ausgewaehlte-eigenschaft-ausgeben"></a>
<h2>Beispiel: Produktname + ausgewählte Eigenschaft ausgeben</h2>
<p>In dem folgenden Template Beispiel werden die Produkt Eigenschaft iteriert und nach der Eigenschaft Farbe gesucht. </p>
<pre><code class="language-twig">{# Set the variables initial #}
{% set value = [] %}
{% set color = \'\' %}

{# Add the product properties #}
{% set groupNames = [] %}
{% set propertiesGroupedByProperties = [] %}
{# Iterate the product properties and try to find the group name "Farbe" #}
{% if product.properties is defined %}
    {% for property in product.properties %}
        {% set groupId = property.groupId %} 
        {% set groupName = property.group.translated.name %} 
        {% set propertyName = property.translated.name %}

        {% if \'Farbe\' == groupName %}
            {% set color = propertyName %}
        {% endif %}

    {% endfor %}
{% endif %}

{% set value = value|merge([product.translated.name]) %}

{% if color is not empty %}
    {% set value = value|merge(["in der Farbe"]) %}
    {% set value = value|merge([color]) %}
{% endif %}

{{ value|join(\' \') }}</code></pre>
<p>Ergebnis:</p>
<pre><code class="language-html">[Produktname] in der Farbe [Farbwert]</code></pre>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/100-bulk-generators/200-bulk-template-detail',
    'parent' => 'en_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/bulk-template-detail',
    'title' => 'Eigene Bulk Templates erstellen und bestehende bearbeiten',
    'menuTitle' => 'Eigene Bulk Templates erstellen und bestehende bearbeiten',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Eigene Bulk Templates erstellen und bestehende bearbeiten</h1>
<p>In diesem Abschnitt der Anleitung beschreiben wir, wie man eigene Templates erstellt sowie bestehende Templates bearbeitet.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#voraussetzung">Voraussetzung</a></li><li class="headline-level2"><a href="#einstellungen-der-bulk-templates">Einstellungen der Bulk Templates</a></li><li class="headline-level2"><a href="#allgemeine-informationen-zu-dem-template-code">Allgemeine Informationen zu dem Template-Code</a></li><li class="headline-level2"><a href="#verfuegbare-variablen-fuer-das-template">Verfügbare Variablen für das Template</a></li><li class="headline-level3"><a href="#live-template-variablen-und-autoload-variablen">Live Template Variablen und Autoload-Variablen</a></li><li class="headline-level3"><a href="#variablen-fuer-produkte">Variablen für Produkte</a></li><li class="headline-level3"><a href="#variablen-fuer-kategorien">Variablen für Kategorien</a></li><li class="headline-level3"><a href="#allgemeine-variablen">Allgemeine Variablen</a></li><li class="headline-level2"><a href="#beispiel-produktname--ausgewaehlte-eigenschaft-ausgeben">Beispiel: Produktname + ausgewählte Eigenschaft ausgeben</a></li></ul></div></p>
<a name="voraussetzung"></a>
<h2>Voraussetzung</h2>
<p>Als Voraussetzung für diese Anleitung solltest du dir zunächst einmal die <a href="docs/seo-professional/modules/bulk-generators/general-info">Allgemeine Informationen zu den Bulk Generatoren sowie die Erste Schritte</a> anschauen. Hier wird u.a. auch beschrieben, wie du in die Konfigurationsoberfläche gelangst.</p>
<a name="einstellungen-der-bulk-templates"></a>
<h2>Einstellungen der Bulk Templates</h2>
<p>Bei der Konfiguration der Templates stehen die folgenden Einstellung zur Verfügung:</p>
<ul>
<li>
<p><strong>Name</strong><br>Definiert den internen Namen für das Template. Bei den von uns vorinstallierten Templates findest du hier Bezeichnungen wie <code>dreiscSeoBulkProduct.defaultTemplates.metaTitle.productName</code>. Hierbei handelt es sich lediglich um ein Textbaustein, sodass wir den Namen mehrsprachig zur Verfügung stellen können. Legst du eigene Templates an, so kann hier eine ganz normale Bezeichnung als Name hinterlegt werden.</p>
</li>
<li>
<p><strong>Vorschau-Produkt</strong><br>Hierbei handelt es sich um eine Auswahl, die ausschließlich für den <code>Produkt Bulk Generator</code> zur Verfügung steht. Erst wenn du hier ein Produkt ausgewählt hast, wird unten die entsprechende Vorschau des Templates angezeigt. Die Auswahl des Vorschau-Produkts wird nicht gespeichert. D.h., dass entsprechend bei jeder Bearbeitung des Templates ein Produkt ausgewählt werden muss, wenn eine Vorschau erwünscht ist.</p>
</li>
<li>
<p><strong>Leerzeichen zwischen HTML-Tags entfernen</strong><br>Ist diese Option aktiv, so werden Leerzeichen zwischen den HTML Tags entsprechend entfernt. Hierbei wird der Twig Filter spaceless auf das gesamte Template angewandt.<br><br>Weitere Informationen zu diesem Filter findest du unter:<br><a href="https://twig.symfony.com/doc/3.x/filters/spaceless.html">https://twig.symfony.com/doc/3.x/filters/spaceless.html</a></p>
</li>
<li>
<p><strong>Template</strong><br>Diese Option beherbergt das eigentiche Template.</p>
</li>
<li>
<p><strong>Vorschau</strong><br>In diesem Bereich wird die Vorschau des Templates angezeigt. Diese wird aktualisiert, sobald du eine Anpassung an dem Template durchführst. (Beachte bei dem Produkt Bulk Generator hierbei die Option <code>Vorschau-Produkt</code>)</p>
</li>
</ul>
<p><a data-dreisccmslightbox="images-203070" data-title="Einstellungen der Bulk Templates" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/200-bulk-template-detail/lightbox/einstellungen-der-bulk-templates.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/200-bulk-template-detail/lightbox/einstellungen-der-bulk-templates.png" alt="Einstellungen der Bulk Templates">
                        </a></p>
<a name="allgemeine-informationen-zu-dem-template-code"></a>
<h2>Allgemeine Informationen zu dem Template-Code</h2>
<p>Um eine maximale Flexibilität bei Generierung der Template zu gewährleisten, haben wir uns dazu entschieden, die Templates auf Basis von Twig zu gestalten. Hierbei handelt es sich um die Template Engine, die auch bei der Gestaltung der Storefront Themes zum Einsatz kommt. Um also eigene Templates zu erstellen, ist es erforderlich, dass du zumindest die Grundlagen dieser Engine erlernst oder aber entsprechend deine Shopware Agentur mit der Erstellung beauftragst.</p>
<p>Solltest du dich dazu entscheiden hier einen Einstieg zu finden und dich selbst ans Werk zu machen, so legen wir dir den folgenden Getting started Guide ans Herz:</p>
<p><a href="https://twig.symfony.com/doc/3.x/templates.html">https://twig.symfony.com/doc/3.x/templates.html</a></p>
<p>Des Weiteren findest du in unserer Dokumentation einen <a href="docs/seo-professional/modules/bulk-generators/exkurs-die-wichtigsten-code-snippets">Exkurs für die wichtigsten Code Snippets</a> sowie einen <a href="docs/seo-professional/modules/bulk-generators/exkurs-custom-fields">Exkurs für die Verwendung von Zusatzfeldern in Bulk Templates</a></p>
<a name="verfuegbare-variablen-fuer-das-template"></a>
<h2>Verfügbare Variablen für das Template</h2>
<p>Zur Gestaltung der Templates stehen dir eine Reihe von Variablen zur Verfügung, die du innerhalb der Templates nutzen kannst. (Eine genauere Auflistung findest du unten) Um diese komfortabel nutzen zu können, kannst du dir diese mit einem Klick auf die Auswahlbox <code>Variable hinzufügen</code> anzeigen und mit einem weiteren Klick auf die jeweilige Variable entsprechend im Template einfügen.</p>
<p><a data-dreisccmslightbox="images-203070" data-title="Variable hinzufügen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/200-bulk-template-detail/lightbox/variable-hinzufuegen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/200-bulk-template-detail/lightbox/variable-hinzufuegen.png" alt="Variable hinzufügen">
                        </a></p>
<a name="live-template-variablen-und-autoload-variablen"></a>
<h3>Live Template Variablen und Autoload-Variablen</h3>
<p>Neben den normalen Variablen existieren auch sogenannte Live Template Variablen. Diese erkennst du daran, dass sie am Anfang sowie am Ende jeweils zwei Rautezeichen aufweisen, wie bspw. <code>##shopName##</code>. Diese Variablen werden erst in der Storefront aufgelöst, da erst hier der Context feststeht. Im Fall des Shopnamens also der Verkaufskanal über den die Seite aufgerufen wurde. Ein weiteres Beispiel für eine Live Template Variable wäre bspw. der Preis eines Produkts. Dieser kann pro Kunde, Shop, Rabatt usw. ganz unterschiedlich sein. Für die Adminstration heißt das, dass hier nach der Generierung noch <code>##VARIABLEN_NAME##</code> zu sehen ist.</p>
<p>In der Auswahl der verfügbaren Variablen findest du teilweise Variablen mit einem <code>[↯]</code>-Zeichem im Pfad wie bspw. <code>(product.manufacturer[↯].translated.name)</code>. Dies kennzeichnet lediglich, dass der Teil dieser Variable nur dann geladen wird, wenn dieser im Template definiert wurde. Nutzt du im o.g. Beispiel also <code>product.manufacturer</code> im Template, so werden auch alle Herstellerinformationen des Produkts geladen.</p>
<a name="variablen-fuer-produkte"></a>
<h3>Variablen für Produkte</h3>
<p>Für den <code>Produkt Bulk Generator</code> stehen die folgenden Variablen zur Auswahl:</p>
<ul>
<li><strong>isVariant</strong> » Gibt an, ob es sich um eine Variante handelt</li>
<li><strong>product</strong> » Beinhaltet die Daten des aktuellen Produkts (ProductEntity)
<ul>
<li><strong>product.id</strong> » Id des Produkts</li>
<li><strong>product.translated.name</strong> » Name des Produkts</li>
<li><strong>product.translated.description</strong> » Beschreibung des Produkts</li>
<li><strong>product.translated.keywords</strong> » Keywords / Schlüsselwörter</li>
<li><strong>product.productNumber</strong> » Produktnummer</li>
<li><strong>product.manufacturerNumber</strong> » Herstellernummer</li>
<li><strong>product.manufacturer.id</strong> » Id des Herstellers</li>
<li><strong>product.manufacturer[↯].translated.name</strong> » Name des Herstellers</li>
<li><strong>product.manufacturer[↯].translated.description</strong> » Beschreibung des Herstellers</li>
<li><strong>product.ean</strong> » EAN Nummer</li>
<li><strong>product.restockTime</strong> » Wiederauffüllzeit in Tagen</li>
<li><strong>product.deliveryTime[↯].translated.name</strong> » Lieferzeit</li>
<li><strong>product.markAsTopseller</strong> » Produkt hervorheben [if-Beispiel]</li>
<li><strong>product.isCloseout</strong> » Abverkauf [if-Beispiel]</li>
<li><strong>product.shippingFree</strong> » Versandkostenfrei [if-Beispiel]</li>
<li><strong>product.stock</strong> » Lagerbestand</li>
<li><strong>product.availableStock</strong> » Verfügbarer Bestand</li>
<li><strong>product.minPurchase</strong> » Mindestabnahme</li>
<li><strong>product.maxPurchase</strong> » Maximalabnahme</li>
<li><strong>product.purchaseSteps</strong> » Staffelung</li>
<li><strong>product.packUnit</strong> » Verpackungseinheit</li>
<li><strong>product.purchaseUnit</strong> » Verkaufseinheit</li>
<li><strong>product.referenceUnit</strong> » Grundeinheit</li>
<li><strong>product.weight</strong> » Gewicht</li>
<li><strong>product.width</strong> » Breite</li>
<li><strong>product.height</strong> » Höhe</li>
<li><strong>product.length</strong> » Länge</li>
<li><strong>product.releaseDate.date</strong> » Erscheinungsdatum</li>
<li><strong>product.properties[↯]</strong> » Eigenschaften des Produkts [if-Beispiel]
<ul>
<li><em>Beispiel für eine Implementierung unter &quot;Produktname + Ausgabe der Produkteigenschaften&quot; (Meta Beschreibung)</em></li>
<li><strong>product.properties[n].translated.name</strong> » Name der Eigenschaft (bspw.: Grün)</li>
<li><strong>product.properties[n].groupId</strong> » Id der Eigenschaftsgruppe</li>
<li><strong>product.properties[n].group.translated.name</strong> » Name der Eigenschaftsgruppe (bspw. Farbe)</li>
</ul></li>
<li><strong>product.options[↯]</strong> » Varianten-Eigenschaften [if-Beispiel]
<ul>
<li>*Beispiel für eine Implementierung unter &quot;Produktname [+ Variantenoptionen bei Varianten]&quot; (Meta Titel)</li>
<li><strong>product.options[n].translated.name</strong> » Name der Varianteneigenschaft (bspw.: M)</li>
<li><strong>product.options[n].group.translated.name</strong> » Name der Gruppe der Varianteneigenschaft (bspw.: Größe)</li>
</ul></li>
<li><strong>product.tax.taxRate</strong> » Steuersatz des Produkts</li>
</ul></li>
<li><strong>productSeo</strong> » Beinhaltet die aufbereiteten SEO Einstellungen des 
<ul>
<li><strong>productSeo.metaTitle</strong> » Meta Titel des Produkts</li>
<li><strong>productSeo.isInheritedMetaTitle</strong> » Meta Titel des Produkts wurde vererbt [if-Beispiel]</li>
<li><strong>productSeo.metaDescription</strong> » Meta Beschreibung des Produkts</li>
<li><strong>productSeo.isInheritedMetaDescription</strong> » Meta Beschreibung des Produkts wurde vererbt [if-Beispiel]</li>
<li><strong>productSeo.url</strong> » URL des Produkts</li>
<li><strong>productSeo.isInheritedUrl</strong> » URL des Produkts wurde vererbt [if-Beispiel]</li>
</ul></li>
<li><strong>mainCategory</strong> »Beinhaltet die Daten der Hauptkategorie des Produkts*¹ (CategoryEntity)<br>(Bitte beachten: Diese Variable steht nur bei der SEO Einstellung SEO-URL zur Verfügung)
<ul>
<li><strong>mainCategory.id</strong> » Id der Hauptkategorie des Produkts</li>
<li><strong>mainCategory.translated.name</strong> » Name der Hauptkategorie des Produkts</li>
<li><strong>mainCategory.translated.description</strong> » Beschreibung der Hauptkategorie des Produkts</li>
<li><strong>mainCategory.translated.breadcrumb</strong> » Breadcrumb der Hauptkategorie des Produkts</li>
<li><strong>mainCategory.type</strong> » Kategory-Typ der Hauptkategorie des Produkts</li>
</ul></li>
<li><strong>mainCategorySeo</strong> » Beinhaltet die aufbereiteten SEO Einstellungen der Hauptkategorie des Produkts*¹<br>(Bitte beachten: Diese Variable steht nur bei der SEO Einstellung SEO-URL zur Verfügung)
<ul>
<li><strong>mainCategorySeo.metaTitle</strong> » Meta Titel der Hauptkategorie</li>
<li><strong>mainCategorySeo.isInheritedMetaTitle</strong> » Meta Titel der Hauptkategorie wurde vererbt [if-Beispiel]</li>
<li><strong>mainCategorySeo.metaDescription</strong> » Meta Beschreibung der Hauptkategorie</li>
<li><strong>mainCategorySeo.isInheritedMetaDescription</strong> » Meta Beschreibung der Hauptkategorie wurde vererbt [if-Beispiel]</li>
<li><strong>mainCategorySeo.url</strong> » URL der Hauptkategorie</li>
<li><strong>mainCategorySeo.isInheritedUrl</strong> » URL der Hauptkategorie wurde vererbt</li>
</ul></li>
<li><strong>##productPrice##</strong> » Diese Live Template Variable gibt den aktuellen Preis an. (Kann nicht für die SEO Einstellung SEO-URL verwendet werden)</li>
</ul>
<p><code>*¹ Hauptkategorie des Produkts: Hauptkategorie, die in den Artikelstammdaten unter "Canonical Urls" für den jeweiligen Vertriebskanal ausgewählt wurde.</code></p>
<a name="variablen-fuer-kategorien"></a>
<h3>Variablen für Kategorien</h3>
<p>Für den <code>Kategorie Bulk Generator</code> stehen die folgenden Variablen zur Auswahl:</p>
<ul>
<li><strong>category</strong> » Beinhaltet die Daten der Kategorie (CategoryEntity)
<ul>
<li><strong>category.id</strong> » Id der Kategorie des Produkts</li>
<li><strong>category.translated.name</strong> » Name der Kategorie</li>
<li><strong>category.translated.description</strong> » Beschreibung der Kategorie</li>
<li><strong>category.translated.breadcrumb</strong> » Breadcrumb der Kategorie</li>
</ul></li>
<li><strong>categorySeo</strong> » Beinhaltet die aufbereiteten SEO Einstellungen der Kategorie
<ul>
<li><strong>categorySeo.metaTitle</strong> » Meta Titel der Kategorie</li>
<li><strong>categorySeo.isInheritedMetaTitle</strong> » Meta Titel der Kategorie wurde vererbt [if-Beispiel]</li>
<li><strong>categorySeo.metaDescription</strong> » Meta Beschreibung der Kategorie</li>
<li><strong>categorySeo.isInheritedMetaDescription</strong> » Meta Beschreibung der Kategorie wurde vererbt [if-Beispiel]</li>
<li><strong>categorySeo.url</strong> » URL der Kategorie</li>
<li><strong>categorySeo.isInheritedUrl</strong> » URL der Kategorie wurde vererbt</li>
</ul></li>
<li><strong>categoryParentSeo</strong> » Beinhaltet die aufbereiteten SEO Einstellungen der direkten Eltern-Kategorie (category.parent)
<ul>
<li><strong>categoryParentSeo.metaTitle</strong> » Meta Titel der Eltern-Kategorie</li>
<li><strong>categoryParentSeo.isInheritedMetaTitle</strong> » Meta Titel der Eltern-Kategorie wurde vererbt [if-Beispiel]</li>
<li><strong>categoryParentSeo.metaDescription</strong> » Meta Beschreibung der Eltern-Kategorie</li>
<li><strong>categoryParentSeo.isInheritedMetaDescription</strong> » Meta Beschreibung der Eltern-Kategorie wurde vererbt [if-Beispiel]</li>
<li><strong>categoryParentSeo.url</strong> » URL der Eltern-Kategorie</li>
<li><strong>categoryParentSeo.isInheritedUrl</strong> » URL der Eltern-Kategorie wurde vererbt</li>
</ul></li>
<li><strong>parentCategories</strong> » Beinhaltet die Daten der Eltern-Kategorien der aktuellen Kategory (CategoryEntity[])</li>
<li><strong>childCategories</strong> » Beinhaltet die Daten der Kind-Kategorien der aktuellen Kategory (CategoryEntity[])</li>
</ul>
<a name="allgemeine-variablen"></a>
<h3>Allgemeine Variablen</h3>
<p>Die folgenden Variablen stehen sowohl beim <code>Produkt Bulk Generator</code> als auch beim <code>Kategorie Bulk Generator</code> zur Auswahl:</p>
<ul>
<li><strong>language</strong> » Beinhaltet das LanguageEntity des aktuellen Generators
<ul>
<li><strong>language.locale.code</strong> » Locale Code der Sprache (bspw.: de-DE)</li>
</ul></li>
<li><strong>systemDefaults</strong>
<ul>
<li><strong>systemDefaults.LANGUAGE_SYSTEM</strong> » Id der Standard-Sprache des Shops</li>
<li><strong>systemDefaults.CURRENCY</strong> » Id der Standard-Währung des Shops</li>
</ul></li>
<li><strong>##shopName##</strong> » Diese Live Template Variable gibt den Shopname des aktuellen Context an. (Kann nicht für die SEO Einstellung SEO-URL verwendet werden)</li>
</ul>
<a name="beispiel-produktname--ausgewaehlte-eigenschaft-ausgeben"></a>
<h2>Beispiel: Produktname + ausgewählte Eigenschaft ausgeben</h2>
<p>In dem folgenden Template Beispiel werden die Produkt Eigenschaft iteriert und nach der Eigenschaft Farbe gesucht. </p>
<pre><code class="language-twig">{# Set the variables initial #}
{% set value = [] %}
{% set color = \'\' %}

{# Add the product properties #}
{% set groupNames = [] %}
{% set propertiesGroupedByProperties = [] %}
{# Iterate the product properties and try to find the group name "Farbe" #}
{% if product.properties is defined %}
    {% for property in product.properties %}
        {% set groupId = property.groupId %} 
        {% set groupName = property.group.translated.name %} 
        {% set propertyName = property.translated.name %}

        {% if \'Farbe\' == groupName %}
            {% set color = propertyName %}
        {% endif %}

    {% endfor %}
{% endif %}

{% set value = value|merge([product.translated.name]) %}

{% if color is not empty %}
    {% set value = value|merge(["in der Farbe"]) %}
    {% set value = value|merge([color]) %}
{% endif %}

{{ value|join(\' \') }}</code></pre>
<p>Ergebnis:</p>
<pre><code class="language-html">[Produktname] in der Farbe [Farbwert]</code></pre>
<p></p>',
  ),
);