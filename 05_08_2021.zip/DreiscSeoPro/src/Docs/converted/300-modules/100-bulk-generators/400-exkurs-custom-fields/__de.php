<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/100-bulk-generators/400-exkurs-custom-fields',
    'parent' => 'de_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/exkurs-custom-fields',
    'title' => 'Exkurs: Zusatzfelder in Bulk Templates einbinden',
    'menuTitle' => 'Exkurs: Zusatzfelder in Bulk Templates einbinden',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Exkurs: Zusatzfelder in Bulk Templates einbinden</h1>
<p>In diesem Exkurs erklären wir dir, wie du Zusatzfelder in Bulk Templates nutzen kannst.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#einleitung">Einleitung</a></li><li class="headline-level2"><a href="#konfiguration-der-zusatzfelder-oeffnen">Konfiguration der Zusatzfelder öffnen</a></li><li class="headline-level2"><a href="#set-auswaehlen--neu-erstellen">Set auswählen / neu erstellen</a></li><li class="headline-level2"><a href="#set-und-felder-konfigurieren">Set und Felder konfigurieren</a></li></ul></div></p>
<a name="einleitung"></a>
<h2>Einleitung</h2>
<p>Unter den Standard Bulk Templates, die bereits mit SEO Professional vorinstalliert sind, findest du Templates wie <code>Eigenes Zusatzfeld falls vorhanden, ansonsten Kategoriename</code>. Bei diesen Templates handelt es sich um Beispiele, die so nicht direkt eingesetzt werden können, da diese auf individuelle Zusatzfelder aufbauen, die zunächst angelegt werden müssen.</p>
<p>So wird in dem o.g. Beispiel Template exemplarisch die Variable <code>product.customFields.custom_myfield</code> verwendet. Welche Schritte notwendig sind, um diese einzurichten, wird Thema dieses Exkurses sein.</p>
<pre><code class="language-twig">{# HINWEIS: Ersetzen Sie **custom_myfield** durch den technischen Namen Ihres Zusatzfeldes #}
{# NOTE: Replace **custom_myfield** with the technical name of your free text field #}
{% if product.customFields.custom_myfield is defined %}
    {{ product.customFields.custom_myfield }}
{% else %}
    {{ product.translated.name }}
{% endif %}</code></pre>
<a name="konfiguration-der-zusatzfelder-oeffnen"></a>
<h2>Konfiguration der Zusatzfelder öffnen</h2>
<p>Die Konfiguration der Zusatzfelder finden Sie unter <code>Einstellungen » System » Zusatzfelder</code>
<a data-dreisccmslightbox="images-229618" data-title="Konfiguration der Zusatzfelder" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/weg-zur-zusatzfeld-konfiguration.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/weg-zur-zusatzfeld-konfiguration.png" alt="Konfiguration der Zusatzfelder">
                        </a></p>
<a name="set-auswaehlen--neu-erstellen"></a>
<h2>Set auswählen / neu erstellen</h2>
<p>Als nächstes muss entsprechend ein neues Set erstellt werden. Klicken Sie hierzu auf <code>Set anlegen</code> (Es kann hier später natürlich ein beliebiges Set genutzt werden)</p>
<p><a data-dreisccmslightbox="images-229618" data-title="Neues Set erstellen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/neues-set-anlegen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/neues-set-anlegen.png" alt="Neues Set erstellen">
                        </a></p>
<a name="set-und-felder-konfigurieren"></a>
<h2>Set und Felder konfigurieren</h2>
<p>Schauen wir uns den Namen der oben verwendeten Variable an (<code>custom_myfield</code>), so sehen wir, dass diese mit einem Unterstrich getrennt ist. Der Teil vor dem Unterstrich entspricht dem technischen Namen des Sets. Der Teil nach dem Unterstrich entspricht dem Namen des Zusatzfeldes. </p>
<p>Entsprechend konfigurieren wir das Set wie folgt und klicken anschließend auf <code>Speichern</code>.</p>
<p><a data-dreisccmslightbox="images-229618" data-title="Set konfigurieren" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/set-konfiguration.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/set-konfiguration.png" alt="Set konfigurieren">
                        </a> </p>
<p>Im unteren Bereich findet die Konfiguration der Felder statt. Hier klicken wir entsprechend auf <code>Neues Zusatzfeld</code>.</p>
<p><a data-dreisccmslightbox="images-229618" data-title="Neues Zusatzfeld erstellen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/neues-feld-hinzufuegen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/neues-feld-hinzufuegen.png" alt="Neues Zusatzfeld erstellen">
                        </a></p>
<p>Als Konfiguration definieren wir hier die folgenden Werte. <br><strong>Achtung: Stellen Sie hier sicher, dass zwischen <code>custom</code> und <code>myfield</code> nur ein Unterstrich ist!</strong></p>
<p>Abschließend speichern wir die Einstellung über <code>Hinzufügen</code> und <strong>müssen auch noch einmal das Set speichern!</strong></p>
<p><a data-dreisccmslightbox="images-229618" data-title="Beispiel Feld erstellen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/beispiel-feld.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/beispiel-feld.png" alt="Beispiel Feld erstellen">
                        </a></p>
<p>Rufen wir nun die Details eines Produkts auf, so lässt sich ein Wert für das neue Feld hinterlegen.</p>
<p><a data-dreisccmslightbox="images-229618" data-title="Beispiel Feld erstellen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/testfeld.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/testfeld.png" alt="Beispiel Feld erstellen">
                        </a></p>
<p>Führen wir nun ein Test des Bulk Templates durch, so sehen wir in der Vorschau, dass der Wert des neuen Zusatzfeldes entsprechend übernommen wird.</p>
<p><a data-dreisccmslightbox="images-229618" data-title="Zusatzfeld in Bulk Template" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/zusatzfeld-wird-vom-bulk-template-uebernommen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/zusatzfeld-wird-vom-bulk-template-uebernommen.png" alt="Zusatzfeld in Bulk Template">
                        </a></p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/100-bulk-generators/400-exkurs-custom-fields',
    'parent' => 'en_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/exkurs-custom-fields',
    'title' => 'Exkurs: Zusatzfelder in Bulk Templates einbinden',
    'menuTitle' => 'Exkurs: Zusatzfelder in Bulk Templates einbinden',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Exkurs: Zusatzfelder in Bulk Templates einbinden</h1>
<p>In diesem Exkurs erklären wir dir, wie du Zusatzfelder in Bulk Templates nutzen kannst.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#einleitung">Einleitung</a></li><li class="headline-level2"><a href="#konfiguration-der-zusatzfelder-oeffnen">Konfiguration der Zusatzfelder öffnen</a></li><li class="headline-level2"><a href="#set-auswaehlen--neu-erstellen">Set auswählen / neu erstellen</a></li><li class="headline-level2"><a href="#set-und-felder-konfigurieren">Set und Felder konfigurieren</a></li></ul></div></p>
<a name="einleitung"></a>
<h2>Einleitung</h2>
<p>Unter den Standard Bulk Templates, die bereits mit SEO Professional vorinstalliert sind, findest du Templates wie <code>Eigenes Zusatzfeld falls vorhanden, ansonsten Kategoriename</code>. Bei diesen Templates handelt es sich um Beispiele, die so nicht direkt eingesetzt werden können, da diese auf individuelle Zusatzfelder aufbauen, die zunächst angelegt werden müssen.</p>
<p>So wird in dem o.g. Beispiel Template exemplarisch die Variable <code>product.customFields.custom_myfield</code> verwendet. Welche Schritte notwendig sind, um diese einzurichten, wird Thema dieses Exkurses sein.</p>
<pre><code class="language-twig">{# HINWEIS: Ersetzen Sie **custom_myfield** durch den technischen Namen Ihres Zusatzfeldes #}
{# NOTE: Replace **custom_myfield** with the technical name of your free text field #}
{% if product.customFields.custom_myfield is defined %}
    {{ product.customFields.custom_myfield }}
{% else %}
    {{ product.translated.name }}
{% endif %}</code></pre>
<a name="konfiguration-der-zusatzfelder-oeffnen"></a>
<h2>Konfiguration der Zusatzfelder öffnen</h2>
<p>Die Konfiguration der Zusatzfelder finden Sie unter <code>Einstellungen » System » Zusatzfelder</code>
<a data-dreisccmslightbox="images-198041" data-title="Konfiguration der Zusatzfelder" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/weg-zur-zusatzfeld-konfiguration.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/weg-zur-zusatzfeld-konfiguration.png" alt="Konfiguration der Zusatzfelder">
                        </a></p>
<a name="set-auswaehlen--neu-erstellen"></a>
<h2>Set auswählen / neu erstellen</h2>
<p>Als nächstes muss entsprechend ein neues Set erstellt werden. Klicken Sie hierzu auf <code>Set anlegen</code> (Es kann hier später natürlich ein beliebiges Set genutzt werden)</p>
<p><a data-dreisccmslightbox="images-198041" data-title="Neues Set erstellen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/neues-set-anlegen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/neues-set-anlegen.png" alt="Neues Set erstellen">
                        </a></p>
<a name="set-und-felder-konfigurieren"></a>
<h2>Set und Felder konfigurieren</h2>
<p>Schauen wir uns den Namen der oben verwendeten Variable an (<code>custom_myfield</code>), so sehen wir, dass diese mit einem Unterstrich getrennt ist. Der Teil vor dem Unterstrich entspricht dem technischen Namen des Sets. Der Teil nach dem Unterstrich entspricht dem Namen des Zusatzfeldes. </p>
<p>Entsprechend konfigurieren wir das Set wie folgt und klicken anschließend auf <code>Speichern</code>.</p>
<p><a data-dreisccmslightbox="images-198041" data-title="Set konfigurieren" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/set-konfiguration.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/set-konfiguration.png" alt="Set konfigurieren">
                        </a> </p>
<p>Im unteren Bereich findet die Konfiguration der Felder statt. Hier klicken wir entsprechend auf <code>Neues Zusatzfeld</code>.</p>
<p><a data-dreisccmslightbox="images-198041" data-title="Neues Zusatzfeld erstellen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/neues-feld-hinzufuegen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/neues-feld-hinzufuegen.png" alt="Neues Zusatzfeld erstellen">
                        </a></p>
<p>Als Konfiguration definieren wir hier die folgenden Werte. <br><strong>Achtung: Stellen Sie hier sicher, dass zwischen <code>custom</code> und <code>myfield</code> nur ein Unterstrich ist!</strong></p>
<p>Abschließend speichern wir die Einstellung über <code>Hinzufügen</code> und <strong>müssen auch noch einmal das Set speichern!</strong></p>
<p><a data-dreisccmslightbox="images-198041" data-title="Beispiel Feld erstellen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/beispiel-feld.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/beispiel-feld.png" alt="Beispiel Feld erstellen">
                        </a></p>
<p>Rufen wir nun die Details eines Produkts auf, so lässt sich ein Wert für das neue Feld hinterlegen.</p>
<p><a data-dreisccmslightbox="images-198041" data-title="Beispiel Feld erstellen" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/testfeld.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/testfeld.png" alt="Beispiel Feld erstellen">
                        </a></p>
<p>Führen wir nun ein Test des Bulk Templates durch, so sehen wir in der Vorschau, dass der Wert des neuen Zusatzfeldes entsprechend übernommen wird.</p>
<p><a data-dreisccmslightbox="images-198041" data-title="Zusatzfeld in Bulk Template" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/zusatzfeld-wird-vom-bulk-template-uebernommen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/400-exkurs-custom-fields/lightbox/zusatzfeld-wird-vom-bulk-template-uebernommen.png" alt="Zusatzfeld in Bulk Template">
                        </a></p>
<p></p>',
  ),
);