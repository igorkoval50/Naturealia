<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/100-bulk-generators/300-exkurs-die-wichtigsten-code-snippets',
    'parent' => 'de_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/exkurs-die-wichtigsten-code-snippets',
    'title' => 'Exkurs: Die wichtigsten Code Snippets',
    'menuTitle' => 'Exkurs: Die wichtigsten Code Snippets',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Exkurs: Die wichtigsten Code Snippets</h1>
<p>Wie bereits in dem Artikel <a href="docs/seo-professional/modules/bulk-generators/bulk-template-detail">Eigene Bulk Templates erstellen und bestehende bearbeiten</a> beschrieben, werden Grundkenntnisse in Twig vorausgesetzt, um bestehende Templates zu bearbeiten bzw. eigene zu erstellen.</p>
<p>Eine Übersicht der wichtigsten Code Snippets für Bulk Templates finden Sie in diesem Exkurs</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#verwendung-von-variablen">Verwendung von Variablen</a></li><li class="headline-level2"><a href="#bedingungen-in-templates">Bedingungen in Templates</a></li><li class="headline-level2"><a href="#elemente-sammeln-und-anschlieend-gemeinsam-ausgeben">Elemente sammeln und anschließend gemeinsam ausgeben</a></li><li class="headline-level2"><a href="#weiche-fuer-sprachvarianten">Weiche für Sprachvarianten</a></li><li class="headline-level2"><a href="#weiche-fuer-varianten">Weiche für Varianten</a></li></ul></div></p>
<a name="verwendung-von-variablen"></a>
<h2>Verwendung von Variablen</h2>
<p>Die Ausgabe der Variablen erfolgt immer in eckigen Klammern. Willst du bei einem Produkt Bulk Template also bspw. den Produktnamen ausgeben, so reicht folgendes Snippet:</p>
<pre><code class="language-twig">{{ product.translated.name }}</code></pre>
<a name="bedingungen-in-templates"></a>
<h2>Bedingungen in Templates</h2>
<p>Bedingungen werden durch <code>if</code>-Anweisungen geprüft. Wir definieren also einen Code, der nur ausgeführt wird, wenn die Bedingung erfüllt wird. In dem u.g. Fall prüfen wir bspw., ob das definierte Zusatzfeld definiert ist.</p>
<pre><code class="language-twig">{% if product.customFields.custom_myfield is defined %}
    {{ product.customFields.custom_myfield }}
{% endif %}</code></pre>
<p>Optional kann an dieser Stelle auch eine <code>else</code>-Anweisung hinzugefügt werden, die den Code definiert, der ausgeführt wird, wenn die Bedingung nicht zutrifft. In dem u.g. Fall die Ausgabe des Zusatzfeldes, wenn definiert, ansonsten die Ausgabe des Produktnamens.</p>
<pre><code class="language-twig">{% if product.customFields.custom_myfield is defined %}
    {{ product.customFields.custom_myfield }}
{% else %}
    {{ product.translated.name }}
{% endif %}</code></pre>
<a name="elemente-sammeln-und-anschlieend-gemeinsam-ausgeben"></a>
<h2>Elemente sammeln und anschließend gemeinsam ausgeben</h2>
<p>In manchen Fällen macht es Sinn eine Variable aus mehreren Werten zusammenzusetzen und diese anschließend gesammelt auszugeben.</p>
<p>Dies ist bspw. bei dem Standard-Template <code>Name des Hersteller + Produktname [+ Produktnummer bei Varianten]</code> für die SEO Einstellung <code>SEO-URL</code> der Fall. Hier werden die Bestandteile der URL zunächst gesammelt und anschließend mit einem Slash getrennt ausgegeben.</p>
<pre><code class="language-twig">{% set url = [] %}

{# Add the manufacturer name #}
{% if product.manufacturer is defined %}
    {% set url = url|merge([product.manufacturer.translated.name]) %}
{% endif %}

{# Add the product name #}
{% set url = url|merge([product.translated.name]) %}

{# Add the product number, if it is a variant #}
{% if isVariant %}
    {% set url = url|merge([product.productNumber]) %}
{% endif %}

{# Convert the array to an string and output. Seperated by slashes #}
{{ url|join(\'/\') }}</code></pre>
<p>Hierbei definieren wir zunächst ein <code>Array</code>, der all unsere Elemente halten soll.</p>
<pre><code class="language-twig">{% set url = [] %}</code></pre>
<p>Die einzelnen Elemente werden mit dem <code>merge</code>-Filter nach und nach hinzugefügt.</p>
<pre><code class="language-twig">{% set url = url|merge([product.manufacturer.translated.name]) %}</code></pre>
<pre><code class="language-twig">{% set url = url|merge([product.translated.name]) %}</code></pre>
<pre><code class="language-twig">{% set url = url|merge([product.productNumber]) %}</code></pre>
<p>Zur Ausgabe wandeln wir den <code>Array</code> in mit dem <code>join</code>-Filter in eine Zeichenkette um und geben diese aus.</p>
<pre><code class="language-twig">{{ url|join(\'/\') }}</code></pre>
<a name="weiche-fuer-sprachvarianten"></a>
<h2>Weiche für Sprachvarianten</h2>
<p>Ein Template kann in der Regel für alle Sprachen verwendet werden. Um trotzdem jeweilige Sprache des aktuellen Context reagieren zu können, kann diese entsprechend abgefragt werden:</p>
<pre><code class="language-twig">{% if \'de-DE\' == language.locale.code %}
    {% set url = url|merge([\'unsere-topseller\']) %}
{% else %}
    {% set url = url|merge([\'our-topseller\']) %}
{% endif %}</code></pre>
<a name="weiche-fuer-varianten"></a>
<h2>Weiche für Varianten</h2>
<p>Soll bei dem <code>Produkt Bulk Generator</code> eine abweichende Logik für Varianten definiert werden, so kann die Variable <code>isVariant</code> verwendet werden:</p>
<pre><code class="language-twig">{% if isVariant %}
{# Enter your code here ... #}
{% endif %}</code></pre>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/100-bulk-generators/300-exkurs-die-wichtigsten-code-snippets',
    'parent' => 'en_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/exkurs-die-wichtigsten-code-snippets',
    'title' => 'Exkurs: Die wichtigsten Code Snippets',
    'menuTitle' => 'Exkurs: Die wichtigsten Code Snippets',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Exkurs: Die wichtigsten Code Snippets</h1>
<p>Wie bereits in dem Artikel <a href="docs/seo-professional/modules/bulk-generators/bulk-template-detail">Eigene Bulk Templates erstellen und bestehende bearbeiten</a> beschrieben, werden Grundkenntnisse in Twig vorausgesetzt, um bestehende Templates zu bearbeiten bzw. eigene zu erstellen.</p>
<p>Eine Übersicht der wichtigsten Code Snippets für Bulk Templates finden Sie in diesem Exkurs</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#verwendung-von-variablen">Verwendung von Variablen</a></li><li class="headline-level2"><a href="#bedingungen-in-templates">Bedingungen in Templates</a></li><li class="headline-level2"><a href="#elemente-sammeln-und-anschlieend-gemeinsam-ausgeben">Elemente sammeln und anschließend gemeinsam ausgeben</a></li><li class="headline-level2"><a href="#weiche-fuer-sprachvarianten">Weiche für Sprachvarianten</a></li><li class="headline-level2"><a href="#weiche-fuer-varianten">Weiche für Varianten</a></li></ul></div></p>
<a name="verwendung-von-variablen"></a>
<h2>Verwendung von Variablen</h2>
<p>Die Ausgabe der Variablen erfolgt immer in eckigen Klammern. Willst du bei einem Produkt Bulk Template also bspw. den Produktnamen ausgeben, so reicht folgendes Snippet:</p>
<pre><code class="language-twig">{{ product.translated.name }}</code></pre>
<a name="bedingungen-in-templates"></a>
<h2>Bedingungen in Templates</h2>
<p>Bedingungen werden durch <code>if</code>-Anweisungen geprüft. Wir definieren also einen Code, der nur ausgeführt wird, wenn die Bedingung erfüllt wird. In dem u.g. Fall prüfen wir bspw., ob das definierte Zusatzfeld definiert ist.</p>
<pre><code class="language-twig">{% if product.customFields.custom_myfield is defined %}
    {{ product.customFields.custom_myfield }}
{% endif %}</code></pre>
<p>Optional kann an dieser Stelle auch eine <code>else</code>-Anweisung hinzugefügt werden, die den Code definiert, der ausgeführt wird, wenn die Bedingung nicht zutrifft. In dem u.g. Fall die Ausgabe des Zusatzfeldes, wenn definiert, ansonsten die Ausgabe des Produktnamens.</p>
<pre><code class="language-twig">{% if product.customFields.custom_myfield is defined %}
    {{ product.customFields.custom_myfield }}
{% else %}
    {{ product.translated.name }}
{% endif %}</code></pre>
<a name="elemente-sammeln-und-anschlieend-gemeinsam-ausgeben"></a>
<h2>Elemente sammeln und anschließend gemeinsam ausgeben</h2>
<p>In manchen Fällen macht es Sinn eine Variable aus mehreren Werten zusammenzusetzen und diese anschließend gesammelt auszugeben.</p>
<p>Dies ist bspw. bei dem Standard-Template <code>Name des Hersteller + Produktname [+ Produktnummer bei Varianten]</code> für die SEO Einstellung <code>SEO-URL</code> der Fall. Hier werden die Bestandteile der URL zunächst gesammelt und anschließend mit einem Slash getrennt ausgegeben.</p>
<pre><code class="language-twig">{% set url = [] %}

{# Add the manufacturer name #}
{% if product.manufacturer is defined %}
    {% set url = url|merge([product.manufacturer.translated.name]) %}
{% endif %}

{# Add the product name #}
{% set url = url|merge([product.translated.name]) %}

{# Add the product number, if it is a variant #}
{% if isVariant %}
    {% set url = url|merge([product.productNumber]) %}
{% endif %}

{# Convert the array to an string and output. Seperated by slashes #}
{{ url|join(\'/\') }}</code></pre>
<p>Hierbei definieren wir zunächst ein <code>Array</code>, der all unsere Elemente halten soll.</p>
<pre><code class="language-twig">{% set url = [] %}</code></pre>
<p>Die einzelnen Elemente werden mit dem <code>merge</code>-Filter nach und nach hinzugefügt.</p>
<pre><code class="language-twig">{% set url = url|merge([product.manufacturer.translated.name]) %}</code></pre>
<pre><code class="language-twig">{% set url = url|merge([product.translated.name]) %}</code></pre>
<pre><code class="language-twig">{% set url = url|merge([product.productNumber]) %}</code></pre>
<p>Zur Ausgabe wandeln wir den <code>Array</code> in mit dem <code>join</code>-Filter in eine Zeichenkette um und geben diese aus.</p>
<pre><code class="language-twig">{{ url|join(\'/\') }}</code></pre>
<a name="weiche-fuer-sprachvarianten"></a>
<h2>Weiche für Sprachvarianten</h2>
<p>Ein Template kann in der Regel für alle Sprachen verwendet werden. Um trotzdem jeweilige Sprache des aktuellen Context reagieren zu können, kann diese entsprechend abgefragt werden:</p>
<pre><code class="language-twig">{% if \'de-DE\' == language.locale.code %}
    {% set url = url|merge([\'unsere-topseller\']) %}
{% else %}
    {% set url = url|merge([\'our-topseller\']) %}
{% endif %}</code></pre>
<a name="weiche-fuer-varianten"></a>
<h2>Weiche für Varianten</h2>
<p>Soll bei dem <code>Produkt Bulk Generator</code> eine abweichende Logik für Varianten definiert werden, so kann die Variable <code>isVariant</code> verwendet werden:</p>
<pre><code class="language-twig">{% if isVariant %}
{# Enter your code here ... #}
{% endif %}</code></pre>
<p></p>',
  ),
);