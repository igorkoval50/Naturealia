<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/100-bulk-generators',
    'parent' => 'de_300-modules',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators',
    'title' => 'Produkt- und Kategorie Bulk Generator',
    'menuTitle' => 'Produkt- und Kategorie Bulk Generator',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Produkt- und Kategorie Bulk Generator</h1>
<p>Über die SEO Bulk Generatoren bist du in der Lage die Shopware SEO Einstellungen der Produkte sowie der Kategorien per Template automatisch zu generieren. Die Templates zum Generieren der SEO Einstellungen können hierbei pro Kategorie definiert werden.</p>
<p>Neben bereits vorbereiteten Beispiel-Templates, können eigene individuelle Templates über die Einstellungen des Moduls erstellt werden. Über die Template Vorschau Funktion können diese während der Erstellung direkt getestet werden, um die Funktionsfähigkeit sicherzustellen.</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/general-info" class="nav--link link--entry">Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/bulk-template-detail" class="nav--link link--entry">Eigene Bulk Templates erstellen und bestehende bearbeiten</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/execute-bulk-generator" class="nav--link link--entry">Bulk Generator ausführen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/exkurs-die-wichtigsten-code-snippets" class="nav--link link--entry">Exkurs: Die wichtigsten Code Snippets</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/exkurs-custom-fields" class="nav--link link--entry">Exkurs: Zusatzfelder in Bulk Templates einbinden</a></li></ul></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/100-bulk-generators',
    'parent' => 'en_300-modules',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators',
    'title' => 'Produkt- und Kategorie Bulk Generator',
    'menuTitle' => 'Produkt- und Kategorie Bulk Generator',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Produkt- und Kategorie Bulk Generator</h1>
<p>Über die SEO Bulk Generatoren bist du in der Lage die Shopware SEO Einstellungen der Produkte sowie der Kategorien per Template automatisch zu generieren. Die Templates zum Generieren der SEO Einstellungen können hierbei pro Kategorie definiert werden.</p>
<p>Neben bereits vorbereiteten Beispiel-Templates, können eigene individuelle Templates über die Einstellungen des Moduls erstellt werden. Über die Template Vorschau Funktion können diese während der Erstellung direkt getestet werden, um die Funktionsfähigkeit sicherzustellen.</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/general-info" class="nav--link link--entry">Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/bulk-template-detail" class="nav--link link--entry">Eigene Bulk Templates erstellen und bestehende bearbeiten</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/execute-bulk-generator" class="nav--link link--entry">Bulk Generator ausführen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/exkurs-die-wichtigsten-code-snippets" class="nav--link link--entry">Exkurs: Die wichtigsten Code Snippets</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators/exkurs-custom-fields" class="nav--link link--entry">Exkurs: Zusatzfelder in Bulk Templates einbinden</a></li></ul></p>',
  ),
);