<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/100-bulk-generators/250-execute-bulk-generator',
    'parent' => 'de_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/execute-bulk-generator',
    'title' => 'Bulk Generator ausführen',
    'menuTitle' => 'Bulk Generator ausführen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Bulk Generator ausführen</h1>
<p>In diesem Guide beschreiben wir dir, wie du den Bulk Generator startest bzw. dieser automatisch gestartet wird.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#1-moeglichkeit-automatische-generierung-durch-speicherung">1. Möglichkeit: Automatische Generierung durch Speicherung</a></li><li class="headline-level2"><a href="#2-moeglichkeit-bulk-generatoren-ueber-die-administration-starten">2. Möglichkeit: Bulk Generatoren über die Administration starten</a></li><li class="headline-level2"><a href="#3-moeglichkeit-bulk-generatoren-per-shopware-cli-starten">3. Möglichkeit: Bulk Generatoren per Shopware CLI starten</a></li></ul></div></p>
<a name="1-moeglichkeit-automatische-generierung-durch-speicherung"></a>
<h2>1. Möglichkeit: Automatische Generierung durch Speicherung</h2>
<p>Standardmäßig werden die Bulk Generatoren immer dann ausgeführt, wenn ein neues Produkt, Kategorie usw. angelegt oder aber Anpassungen an diesem vorgenommen werden. In diesem Fall wird nach der eigentlichen Speicherung geschaut, ob ein Bulk Template für das jeweilige Element definiert ist und anschließend in diesem Fall ausgeführt.</p>
<p>Ist diese automatische Generierung nicht gewünscht, so kann diese in den Einstellungen abgeschaltet werden. Weitere Informationen hierzu findest du unter <a href="docs/seo-professional/modules/settings/seo-settings#bulk-generatoren-beim-speicherprozess-starten">SEO Professional » Weitere Einstellungen » SEO Einstellungen</a></p>
<p><strong>Wichtiger Hinweis</strong>: Der Prozess wird nicht ausgeführt, wenn bei bestehenden Elementen lediglich die &quot;Speichern&quot;-Schaltfläche betätigt wird, da der Shopware Speicherprozess erst angestoßen wird, wenn sich ein Wert verändert hat.</p>
<a name="2-moeglichkeit-bulk-generatoren-ueber-die-administration-starten"></a>
<h2>2. Möglichkeit: Bulk Generatoren über die Administration starten</h2>
<p>Sowohl im Produkt- als auch im Kategorie Bulk Generator Modul findest du oben in der Smart Bar die Schaltfläche <code>Generator starten</code>. Hierüber ist es möglich den Bulk Generator für alle Produkte bzw. alle Kategorien direkt aus der Adminstration heraus zu starten.</p>
<p><a data-dreisccmslightbox="images-275499" data-title="Generator starten Schaltfläche" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/250-execute-bulk-generator/lightbox/generator-starten-button.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/250-execute-bulk-generator/lightbox/generator-starten-button.png" alt="Generator starten Schaltfläche">
                        </a></p>
<a name="3-moeglichkeit-bulk-generatoren-per-shopware-cli-starten"></a>
<h2>3. Möglichkeit: Bulk Generatoren per Shopware CLI starten</h2>
<p>Um die Bulk Generatoren für alle Produkte, Kategorien usw. per Shopware CLI durchlaufen zu lassen, werden die folgenden Shopware CLI Befehle bereitgestellt, die per Shell ausgeführt werden können:</p>
<pre><code class="language-bash">#Produkt Bulk Generator starten
bin/console dreisc-seo:bulk-generator:product</code></pre>
<pre><code class="language-bash">#Kategorie Bulk Generator starten
bin/console dreisc-seo:bulk-generator:category</code></pre>
<p>Diese Befehle können bei Bedarf - wie jeder andere Shopware CLI Befehl auch - in den Server Cronjobs mit aufgenommen werden.</p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/100-bulk-generators/250-execute-bulk-generator',
    'parent' => 'en_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/execute-bulk-generator',
    'title' => 'Bulk Generator ausführen',
    'menuTitle' => 'Bulk Generator ausführen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Bulk Generator ausführen</h1>
<p>In diesem Guide beschreiben wir dir, wie du den Bulk Generator startest bzw. dieser automatisch gestartet wird.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#1-moeglichkeit-automatische-generierung-durch-speicherung">1. Möglichkeit: Automatische Generierung durch Speicherung</a></li><li class="headline-level2"><a href="#2-moeglichkeit-bulk-generatoren-ueber-die-administration-starten">2. Möglichkeit: Bulk Generatoren über die Administration starten</a></li><li class="headline-level2"><a href="#3-moeglichkeit-bulk-generatoren-per-shopware-cli-starten">3. Möglichkeit: Bulk Generatoren per Shopware CLI starten</a></li></ul></div></p>
<a name="1-moeglichkeit-automatische-generierung-durch-speicherung"></a>
<h2>1. Möglichkeit: Automatische Generierung durch Speicherung</h2>
<p>Standardmäßig werden die Bulk Generatoren immer dann ausgeführt, wenn ein neues Produkt, Kategorie usw. angelegt oder aber Anpassungen an diesem vorgenommen werden. In diesem Fall wird nach der eigentlichen Speicherung geschaut, ob ein Bulk Template für das jeweilige Element definiert ist und anschließend in diesem Fall ausgeführt.</p>
<p>Ist diese automatische Generierung nicht gewünscht, so kann diese in den Einstellungen abgeschaltet werden. Weitere Informationen hierzu findest du unter <a href="docs/seo-professional/modules/settings/seo-settings#bulk-generatoren-beim-speicherprozess-starten">SEO Professional » Weitere Einstellungen » SEO Einstellungen</a></p>
<p><strong>Wichtiger Hinweis</strong>: Der Prozess wird nicht ausgeführt, wenn bei bestehenden Elementen lediglich die &quot;Speichern&quot;-Schaltfläche betätigt wird, da der Shopware Speicherprozess erst angestoßen wird, wenn sich ein Wert verändert hat.</p>
<a name="2-moeglichkeit-bulk-generatoren-ueber-die-administration-starten"></a>
<h2>2. Möglichkeit: Bulk Generatoren über die Administration starten</h2>
<p>Sowohl im Produkt- als auch im Kategorie Bulk Generator Modul findest du oben in der Smart Bar die Schaltfläche <code>Generator starten</code>. Hierüber ist es möglich den Bulk Generator für alle Produkte bzw. alle Kategorien direkt aus der Adminstration heraus zu starten.</p>
<p><a data-dreisccmslightbox="images-466016" data-title="Generator starten Schaltfläche" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/250-execute-bulk-generator/lightbox/generator-starten-button.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/250-execute-bulk-generator/lightbox/generator-starten-button.png" alt="Generator starten Schaltfläche">
                        </a></p>
<a name="3-moeglichkeit-bulk-generatoren-per-shopware-cli-starten"></a>
<h2>3. Möglichkeit: Bulk Generatoren per Shopware CLI starten</h2>
<p>Um die Bulk Generatoren für alle Produkte, Kategorien usw. per Shopware CLI durchlaufen zu lassen, werden die folgenden Shopware CLI Befehle bereitgestellt, die per Shell ausgeführt werden können:</p>
<pre><code class="language-bash">#Produkt Bulk Generator starten
bin/console dreisc-seo:bulk-generator:product</code></pre>
<pre><code class="language-bash">#Kategorie Bulk Generator starten
bin/console dreisc-seo:bulk-generator:category</code></pre>
<p>Diese Befehle können bei Bedarf - wie jeder andere Shopware CLI Befehl auch - in den Server Cronjobs mit aufgenommen werden.</p>
<p></p>',
  ),
);