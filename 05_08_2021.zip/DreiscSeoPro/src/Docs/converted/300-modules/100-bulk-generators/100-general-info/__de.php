<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/100-bulk-generators/100-general-info',
    'parent' => 'de_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/general-info',
    'title' => 'Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte',
    'menuTitle' => 'Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte</h1>
<p>In diesem Abschnitt der Anleitung werden die ersten Schritte mit den Bulk Generatoren, sowie wichtige allgemeine Informationen beschrieben.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#allgemeine-funktionsweise-der-bulk-generatoren">Allgemeine Funktionsweise der Bulk Generatoren</a></li><li class="headline-level2"><a href="#vorbereitung">Vorbereitung</a></li><li class="headline-level2"><a href="#bersicht-der-adminstration">Übersicht der Adminstration</a></li><li class="headline-level2"><a href="#bulk-generator-template-hinterlegen">Bulk Generator Template hinterlegen</a></li><li class="headline-level2"><a href="#bulk-einstellungen">Bulk Einstellungen</a></li><li class="headline-level2"><a href="#verfuegbare-bulk-templates">Verfügbare Bulk Templates</a></li><li class="headline-level2"><a href="#bulk-templates-erstellen-und-bearbeiten">Bulk Templates erstellen und bearbeiten</a></li><li class="headline-level2"><a href="#bulk-generator-ausfuehren">Bulk Generator ausführen</a></li></ul></div></p>
<a name="allgemeine-funktionsweise-der-bulk-generatoren"></a>
<h2>Allgemeine Funktionsweise der Bulk Generatoren</h2>
<p>Die grundsätzliche Idee hinter den Bulk Generatoren ist, dass auf Kategoriebasis Templates hinterlegt werden können, die bestimmen, wie sich SEO Einstellungen wie die URL oder aber der Meta Titel eines Produkts bzw. Kategorie zusammensetzt.</p>
<p>Hierbei ist es möglich eine Vererbung an die jeweiligen Unterkategorien zu aktivieren. So wird das jeweilige Template auch für die Unterkategorien bzw. Produkte der Unterkategorien angewand. Diese Vererbung wird erst dann unterbrochen, wenn für eine bestimmte Unterkategorie ein eigenes Template hinterlegt wird.</p>
<a name="vorbereitung"></a>
<h2>Vorbereitung</h2>
<p>Öffne zur Administration der Bulk Generatoren das Produkt- bzw. Kategorie Bulk Generator Modul. Dieses findest du unter dem Menüpunkt <code>SEO Professional » Produkt Bulk Generator</code> bzw. <code>SEO Professional » Kategorie Bulk Generator</code>.</p>
<p><img src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/img/bulk-module-shopware-admin.png" alt="Bulk Generator Module im Admin" /></p>
<a name="bersicht-der-adminstration"></a>
<h2>Übersicht der Adminstration</h2>
<p>Die Adminstration der jeweiligen Module ist wie folgt aufgebaut:</p>
<ul>
<li>
<p><strong>Bereich A (In der Abbildung blau markiert)</strong><br>In diesem Bereich des Moduls findet die Auswahl der SEO Einstellung statt, für die ein Generator Template hinterlegt werden soll. Die Auswahl des <code>Verkaufskanals</code> steht hierbei nur in Verbindung mit der SEO Einstellung <code>SEO-URL</code> zur Verfügung, da diese im Gegensatz zu bspw. dem Meta Titel pro Verkaufskanal gespeichert wird.</p>
</li>
<li>
<p><strong>Bereich B (In der Abbildung rot markiert)</strong><br>Dieser Bereich dient nur Auswahl der Kategorie, für die ein neues Bulk Generator Template hinterlegt bzw. ein bestehendes bearbeitet werden soll. </p>
</li>
<li>
<p><strong>Bereich C (In der Abbildung grün markiert)</strong><br>Nachdem die Auswahl der Bereiche A und B abgeschlossen ist, wird die Detailansicht der Auswahl geladen. Da zu Beginn noch keine Template hinterlegt sind, wird hier zunächst nur ein Hinweis ausgegeben. </p>
</li>
</ul>
<p><a data-dreisccmslightbox="images-215274" data-title="Übersicht der Adminstration" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/lightbox/bereiche-der-administration.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/lightbox/bereiche-der-administration.png" alt="Übersicht der Adminstration">
                        </a></p>
<a name="bulk-generator-template-hinterlegen"></a>
<h2>Bulk Generator Template hinterlegen</h2>
<p>Nachdem, wie oben beschrieben, die gewünschte SEO Einstellung sowie Kategorie ausgewählt wurde, kann das eigene Template hinterlegt werden. Klicken Sie hierzu zunächst auf die Schaltfläche <code>Bulk Template hinterlegen</code>.</p>
<p><img src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/img/bulk-template-hinterlegen.png" alt="Bulk Template hinterlegen" /></p>
<a name="bulk-einstellungen"></a>
<h2>Bulk Einstellungen</h2>
<p>Zur Einstellung des jeweiligen Bulk Generators stehen die folgenden Optionen zur Verfügung:</p>
<ul>
<li>
<p><strong>Wert überschreiben</strong><br>Standardmäßig werden die SEO Einstellung durch den Bulk Generator nur dann hinterlegt, wenn die jeweilige SEO Einstellung leer ist. Ist diese Option aktiv, so greift das Bulk Template immer, sodass bestehende Werte entsprechend überschrieben werden.<br><br><code>Sonderfall SEO-URL:</code> Bei den URLs ist zu beachten, dass die durch den Shopware Standard generierten URLs ebenfalls als &quot;leere Einstellung&quot; angesehen werden. Die Standard SEO Urls werden also entsprechend auch dann überschrieben, wenn diese Option nicht aktiv ist.</p>
</li>
<li>
<p><strong>Template vererben</strong><br>Standardmäßig wird ein Template immer nur für die aktuelle Kategorie hinterlegt. Somit greift ein Template immer nur für die Kategorie bzw. bei dem Produkt Bulk Generator für alle Produkte der jeweiligen Kategorie. Ist diese Option aktiv, so wird das Template auch an die Unterkategorien weitervererbt, sodass das jeweilige Template auch für diese Kategorien greift.</p>
</li>
<li>
<p><strong>Bulk Template</strong><br>Diese Option bestimmt, welches Template für die aktuell Kategorie genutzt werden soll. Weitere Informationen zu den Template finden Sie weiter unten.</p>
</li>
<li>
<p><strong>Priorität</strong><br>Diese Option steht ausschließlich für den <code>Produkt Bulk Generator</code> zur Verfügung und ist nur dann relevant, wenn ein Produkt mehreren Katgorien zugewiesen ist und diesen jeweils Bulk Generator Templates über dieses Tool zugewiesen wurden. In diesem Fall entscheidet die Höhe des Prioritätswerts, welche Bulk Generator Konfiguration für das jeweilige Produkt verwendet werden soll. Hierbei gilt: Es wird die Bulk Konfiguration verwendet, bei dem der Wert des Feldes <code>Priorität</code> am höchsten ist. </p>
</li>
</ul>
<p><img src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/img/bulk-einstellungen.png" alt="Bulk Einstellungen" /></p>
<a name="verfuegbare-bulk-templates"></a>
<h2>Verfügbare Bulk Templates</h2>
<p>In diesem Bereich kannst du neue Templates erstellen sowie bestehende Templates bearbeiten oder löschen. Klicke zum Hinzufügen eines neuen Templates auf <code>Neues Bulk Template erstellen</code>. Zum Bearbeiten eines Templates reicht es, wenn du auf den Beschreibungstext klickst oder aber über das Contextmenü den Eintrag <code>Editieren</code> nutzt. Möchtest du ein Template löschen, so funktioniert dies ebenfalls über das Contextmenü unter <code>Löschen</code>. Alternativ können mehrere links angehakt und über das <code>Mülleimer-Icon</code> oben rechts zusammen gelöscht werden.</p>
<p><img src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/img/verfuegbare-bulk-templates.png" alt="Verfügbare Bulk Templates" /></p>
<a name="bulk-templates-erstellen-und-bearbeiten"></a>
<h2>Bulk Templates erstellen und bearbeiten</h2>
<p>Um mit den Bulk Generatoren richtig durchzustarten, solltest du dich damit beschäftigen, wie man bestehende Templates bearbeitet sowie neue Templates erstellen kann.</p>
<p>Eine Guide hierzu findest du unter:<br>
<a href="docs/seo-professional/modules/bulk-generators/bulk-template-detail">Eigene Bulk Templates erstellen und bestehende bearbeiten</a></p>
<a name="bulk-generator-ausfuehren"></a>
<h2>Bulk Generator ausführen</h2>
<p>Nachdem du die Bulk Templates nach deinen Wünschen definiert hat, muss der Bulk Generator Prozess gestartet werden, sodass die SEO Einstellungen entsprechend hinterlegt werden. </p>
<p>Wie dies funktioniert erfährst du unter: <br>
<a href="docs/seo-professional/modules/bulk-generators/execute-bulk-generator">Bulk Generator ausführen</a></p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/100-bulk-generators/100-general-info',
    'parent' => 'en_300-modules/100-bulk-generators',
    'seoUrl' => 'docs/seo-professional/modules/bulk-generators/general-info',
    'title' => 'Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte',
    'menuTitle' => 'Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte</h1>
<p>In diesem Abschnitt der Anleitung werden die ersten Schritte mit den Bulk Generatoren, sowie wichtige allgemeine Informationen beschrieben.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#allgemeine-funktionsweise-der-bulk-generatoren">Allgemeine Funktionsweise der Bulk Generatoren</a></li><li class="headline-level2"><a href="#vorbereitung">Vorbereitung</a></li><li class="headline-level2"><a href="#bersicht-der-adminstration">Übersicht der Adminstration</a></li><li class="headline-level2"><a href="#bulk-generator-template-hinterlegen">Bulk Generator Template hinterlegen</a></li><li class="headline-level2"><a href="#bulk-einstellungen">Bulk Einstellungen</a></li><li class="headline-level2"><a href="#verfuegbare-bulk-templates">Verfügbare Bulk Templates</a></li><li class="headline-level2"><a href="#bulk-templates-erstellen-und-bearbeiten">Bulk Templates erstellen und bearbeiten</a></li><li class="headline-level2"><a href="#bulk-generator-ausfuehren">Bulk Generator ausführen</a></li></ul></div></p>
<a name="allgemeine-funktionsweise-der-bulk-generatoren"></a>
<h2>Allgemeine Funktionsweise der Bulk Generatoren</h2>
<p>Die grundsätzliche Idee hinter den Bulk Generatoren ist, dass auf Kategoriebasis Templates hinterlegt werden können, die bestimmen, wie sich SEO Einstellungen wie die URL oder aber der Meta Titel eines Produkts bzw. Kategorie zusammensetzt.</p>
<p>Hierbei ist es möglich eine Vererbung an die jeweiligen Unterkategorien zu aktivieren. So wird das jeweilige Template auch für die Unterkategorien bzw. Produkte der Unterkategorien angewand. Diese Vererbung wird erst dann unterbrochen, wenn für eine bestimmte Unterkategorie ein eigenes Template hinterlegt wird.</p>
<a name="vorbereitung"></a>
<h2>Vorbereitung</h2>
<p>Öffne zur Administration der Bulk Generatoren das Produkt- bzw. Kategorie Bulk Generator Modul. Dieses findest du unter dem Menüpunkt <code>SEO Professional » Produkt Bulk Generator</code> bzw. <code>SEO Professional » Kategorie Bulk Generator</code>.</p>
<p><img src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/img/bulk-module-shopware-admin.png" alt="Bulk Generator Module im Admin" /></p>
<a name="bersicht-der-adminstration"></a>
<h2>Übersicht der Adminstration</h2>
<p>Die Adminstration der jeweiligen Module ist wie folgt aufgebaut:</p>
<ul>
<li>
<p><strong>Bereich A (In der Abbildung blau markiert)</strong><br>In diesem Bereich des Moduls findet die Auswahl der SEO Einstellung statt, für die ein Generator Template hinterlegt werden soll. Die Auswahl des <code>Verkaufskanals</code> steht hierbei nur in Verbindung mit der SEO Einstellung <code>SEO-URL</code> zur Verfügung, da diese im Gegensatz zu bspw. dem Meta Titel pro Verkaufskanal gespeichert wird.</p>
</li>
<li>
<p><strong>Bereich B (In der Abbildung rot markiert)</strong><br>Dieser Bereich dient nur Auswahl der Kategorie, für die ein neues Bulk Generator Template hinterlegt bzw. ein bestehendes bearbeitet werden soll. </p>
</li>
<li>
<p><strong>Bereich C (In der Abbildung grün markiert)</strong><br>Nachdem die Auswahl der Bereiche A und B abgeschlossen ist, wird die Detailansicht der Auswahl geladen. Da zu Beginn noch keine Template hinterlegt sind, wird hier zunächst nur ein Hinweis ausgegeben. </p>
</li>
</ul>
<p><a data-dreisccmslightbox="images-446689" data-title="Übersicht der Adminstration" href="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/lightbox/bereiche-der-administration.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/lightbox/bereiche-der-administration.png" alt="Übersicht der Adminstration">
                        </a></p>
<a name="bulk-generator-template-hinterlegen"></a>
<h2>Bulk Generator Template hinterlegen</h2>
<p>Nachdem, wie oben beschrieben, die gewünschte SEO Einstellung sowie Kategorie ausgewählt wurde, kann das eigene Template hinterlegt werden. Klicken Sie hierzu zunächst auf die Schaltfläche <code>Bulk Template hinterlegen</code>.</p>
<p><img src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/img/bulk-template-hinterlegen.png" alt="Bulk Template hinterlegen" /></p>
<a name="bulk-einstellungen"></a>
<h2>Bulk Einstellungen</h2>
<p>Zur Einstellung des jeweiligen Bulk Generators stehen die folgenden Optionen zur Verfügung:</p>
<ul>
<li>
<p><strong>Wert überschreiben</strong><br>Standardmäßig werden die SEO Einstellung durch den Bulk Generator nur dann hinterlegt, wenn die jeweilige SEO Einstellung leer ist. Ist diese Option aktiv, so greift das Bulk Template immer, sodass bestehende Werte entsprechend überschrieben werden.<br><br><code>Sonderfall SEO-URL:</code> Bei den URLs ist zu beachten, dass die durch den Shopware Standard generierten URLs ebenfalls als &quot;leere Einstellung&quot; angesehen werden. Die Standard SEO Urls werden also entsprechend auch dann überschrieben, wenn diese Option nicht aktiv ist.</p>
</li>
<li>
<p><strong>Template vererben</strong><br>Standardmäßig wird ein Template immer nur für die aktuelle Kategorie hinterlegt. Somit greift ein Template immer nur für die Kategorie bzw. bei dem Produkt Bulk Generator für alle Produkte der jeweiligen Kategorie. Ist diese Option aktiv, so wird das Template auch an die Unterkategorien weitervererbt, sodass das jeweilige Template auch für diese Kategorien greift.</p>
</li>
<li>
<p><strong>Bulk Template</strong><br>Diese Option bestimmt, welches Template für die aktuell Kategorie genutzt werden soll. Weitere Informationen zu den Template finden Sie weiter unten.</p>
</li>
<li>
<p><strong>Priorität</strong><br>Diese Option steht ausschließlich für den <code>Produkt Bulk Generator</code> zur Verfügung und ist nur dann relevant, wenn ein Produkt mehreren Katgorien zugewiesen ist und diesen jeweils Bulk Generator Templates über dieses Tool zugewiesen wurden. In diesem Fall entscheidet die Höhe des Prioritätswerts, welche Bulk Generator Konfiguration für das jeweilige Produkt verwendet werden soll. Hierbei gilt: Es wird die Bulk Konfiguration verwendet, bei dem der Wert des Feldes <code>Priorität</code> am höchsten ist. </p>
</li>
</ul>
<p><img src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/img/bulk-einstellungen.png" alt="Bulk Einstellungen" /></p>
<a name="verfuegbare-bulk-templates"></a>
<h2>Verfügbare Bulk Templates</h2>
<p>In diesem Bereich kannst du neue Templates erstellen sowie bestehende Templates bearbeiten oder löschen. Klicke zum Hinzufügen eines neuen Templates auf <code>Neues Bulk Template erstellen</code>. Zum Bearbeiten eines Templates reicht es, wenn du auf den Beschreibungstext klickst oder aber über das Contextmenü den Eintrag <code>Editieren</code> nutzt. Möchtest du ein Template löschen, so funktioniert dies ebenfalls über das Contextmenü unter <code>Löschen</code>. Alternativ können mehrere links angehakt und über das <code>Mülleimer-Icon</code> oben rechts zusammen gelöscht werden.</p>
<p><img src="wiki/dreisc_seo_pro/300-modules/100-bulk-generators/100-general-info/img/verfuegbare-bulk-templates.png" alt="Verfügbare Bulk Templates" /></p>
<a name="bulk-templates-erstellen-und-bearbeiten"></a>
<h2>Bulk Templates erstellen und bearbeiten</h2>
<p>Um mit den Bulk Generatoren richtig durchzustarten, solltest du dich damit beschäftigen, wie man bestehende Templates bearbeitet sowie neue Templates erstellen kann.</p>
<p>Eine Guide hierzu findest du unter:<br>
<a href="docs/seo-professional/modules/bulk-generators/bulk-template-detail">Eigene Bulk Templates erstellen und bestehende bearbeiten</a></p>
<a name="bulk-generator-ausfuehren"></a>
<h2>Bulk Generator ausführen</h2>
<p>Nachdem du die Bulk Templates nach deinen Wünschen definiert hat, muss der Bulk Generator Prozess gestartet werden, sodass die SEO Einstellungen entsprechend hinterlegt werden. </p>
<p>Wie dies funktioniert erfährst du unter: <br>
<a href="docs/seo-professional/modules/bulk-generators/execute-bulk-generator">Bulk Generator ausführen</a></p>
<p></p>',
  ),
);