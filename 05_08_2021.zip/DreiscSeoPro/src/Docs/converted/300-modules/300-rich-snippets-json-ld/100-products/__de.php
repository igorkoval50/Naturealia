<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/300-rich-snippets-json-ld/100-products',
    'parent' => 'de_300-modules/300-rich-snippets-json-ld',
    'seoUrl' => 'docs/seo-professional/modules/rich-snippets-json-ld/products',
    'title' => 'Produkte',
    'menuTitle' => 'Produkte',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Produkte</h1>
<p>Wenn du deine Produktseiten mit Rich Snippet Markup auszeichnest, kann Google ausführliche Produktinformationen anzeigen. Nutzer sehen dann Preis, Verfügbarkeit, Bewertungsergebnisse usw. direkt in den Suchergebnissen.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#zustand-der-produkte">Zustand der Produkte</a></li><li class="headline-level2"><a href="#verfuegbarkeit-der-produkte">Verfügbarkeit der Produkte</a></li><li class="headline-level2"><a href="#haendlerspezifische-kennung">Händlerspezifische Kennung</a></li><li class="headline-level2"><a href="#herstellerteile-nummer">Herstellerteile-Nummer</a></li><li class="headline-level2"><a href="#preis-gueltig-bis-datum">Preis gültig bis Datum</a></li><li class="headline-level2"><a href="#bewertungen">Bewertungen</a></li><li class="headline-level2"><a href="#weitere-produkt-einstellungen">Weitere Produkt-Einstellungen</a></li><li class="headline-level3"><a href="#name-des-verkaeufers">Name des Verkäufers</a></li></ul></div></p>
<a name="zustand-der-produkte"></a>
<h2>Zustand der Produkte</h2>
<p>Über diese Konfiguration kannst du einen <code>Standardwert für den Zustand der Produkte</code> definieren. Hierbei stehen die folgenden Werte als Auswahl zur Verfügung: </p>
<ul>
<li>Neu</li>
<li>Gebraucht</li>
<li>Generalüberholt</li>
<li>Beschädigt</li>
</ul>
<p>Der hier ausgewählte Standardwert wird für alle Produkte übergeben, bei denen kein <code>abweichender Produktzustand</code> definiert wurde. Wie du einen abweichenden Zustand für ein Produkt hinterlegen kannst, erfährst du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="verfuegbarkeit-der-produkte"></a>
<h2>Verfügbarkeit der Produkte</h2>
<p>In diesem Bereich der Konfiguration kannst du Standardwerte für die Verfügbarkeit der Produkte definieren. Hierbei unterscheiden wir zwischen normalen Produkten sowie Produkten, die für den Abverkauf definiert wurden. Hier unterteilen wir anschließend noch, ob diese Lagerbestand aufweisen oder nicht. Hierdurch ergeben sich die folgenden Standardwerte die definiert werden können:</p>
<ul>
<li>Standardwert für die Verfügbarkeit von normalen Produkten</li>
<li>Standardwert für die Verfügbarkeit von normalen Produkten ohne Lagerbestand </li>
<li>Standardwert für die Verfügbarkeit von Abverkauf-Produkten </li>
<li>Standardwert für die Verfügbarkeit von Abverkauf-Produkten ohne Lagerbestand </li>
</ul>
<p>Die hier ausgewählten Standardwerte werden für alle Produkte übergeben, bei denen keine <code>abweichende Verfügbarkeit</code> definiert wurde. Wie du eine abweichende Verfügbarkeit für ein Produkt hinterlegen kannst, erfährst du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="haendlerspezifische-kennung"></a>
<h2>Händlerspezifische Kennung</h2>
<p>Unter <code>Standardwert für Händlerspezifische Kennung</code> kannst du den Wert definieren, der standardmäßig als SKU Wert übergeben werden soll. Wir empfehlen hier die Produktnummer zu übergeben. Alternativ kann hier per Konfiguration bestimmt werden, dass die Herstellernummer übergeben wird, falls vorhanden.</p>
<p>Der hier ausgewählte Standardwert wird für alle Produkte übergeben, bei denen keine <code>abweichende händlerspezifische Kennung</code> definiert wurde. Wie du eine abweichende händlerspezifische Kennung für ein Produkt hinterlegen kannst, erfährst du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="herstellerteile-nummer"></a>
<h2>Herstellerteile-Nummer</h2>
<p>Unter <code>Standardwert für Herstellerteile-Nummer</code> kannst du den Wert definieren, der standardmäßig als MPN Wert übergeben werden soll. Wir empfehlen hier die Übergabe der Herstellernummer, falls vorhanden. Alternativ kann hier per Konfiguration bestimmt werden, dass die Produktnummer übergeben wird.</p>
<p>Der hier ausgewählte Standardwert wird für alle Produkte übergeben, bei denen keine <code>abweichende Herstellerteile-Nummer</code> definiert wurde. Wie du eine abweichende Herstellerteile-Nummer für ein Produkt hinterlegen kannst, erfährst du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="preis-gueltig-bis-datum"></a>
<h2>Preis gültig bis Datum</h2>
<p>Die Konfiguration <code>Preis gültig bis Datum</code> setzt das Rich Snippet Feld <code>priceValidUntil</code>. Hierbei handelt es sich um ein von Google empfohlendes Feld, dass angibt, wie lange der aktuelle Preis gültig ist.</p>
<p>Über <code>Standardwert für das Feld "Preis gültig bis Datum" (priceValidUntil)</code> kann ein Standardwert konfiguriert werden, der für die Produkte verwendet werden soll. Neben der Einstellung, dass das Feld gar nicht ausgegeben werden soll, kann das aktuelle Datum oder das aktuelle Datum + [Zeitraum] ausgewählt werden. Zusätzlich steht die Option <code>Aktuelles Datum + eigene Anzahl an Tagen</code> zur Verfügung. Wählst du diese Option aus, so erscheint das Feld <code>Anzahl an Tagen</code>, was in diesem Fall ebenfalls ausgefüllt werden muss.</p>
<p>Möchtest du für ein spezifisches Produkt ein festes Datum für diesen Wert setzen, so ist über das Feld <code>Abweichendes "Preis gültig bis"-Datum</code> möglich. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="bewertungen"></a>
<h2>Bewertungen</h2>
<p>Werden Produktbewertungen an Google übergeben, so muss auch ein Autor der Bewertung übergeben werden. Wird dies nicht gemacht, so quittiert Google dies mit einer Fehlermeldung.</p>
<p>Über die Konfiguration <code>Autor der Bewertung</code> kann entsprechend definiert werden, welcher Wert als Autor übergeben werden soll. Hierbei stehen die folgenden Optionen zur Auswahl:</p>
<ul>
<li><strong>Dieses Feld standardmäßig nicht ausgeben</strong><br>Wird nicht empfohlen, da Google die Bewertung dann als nicht vollständig bewertet.</li>
<li><strong>Statischen Wert übergeben (Textbaustein)</strong><br>Ist diese Option aktiv, so wird ein als Textbaustein definierter Wert als Autor übergeben. Der Textbaustein kann über die Schaltfläche <code>Textbaustein Konfiguration in neuem Fenster öffnen</code> bearbeitet werden, sobald die Option ausgewählt wurde.</li>
<li><strong>Vorname des Kunden übergeben</strong><br>Ist diese Option aktiv, so wird der Vorname des Kunden übergeben: <code>Beispiel: Max</code></li>
<li><strong>Vorname + Anfangsbuchstabe des Nachnamen des Kunden übergeben (empfohlen)</strong><br>Ist diese Option aktiv, so wird der Vorname sowie der Anfangsbuchstabe des Nachnamen des Kunden übergeben: <code>Beispiel: Max M.</code></li>
<li><strong>Vorname + Nachname des Kunden übergeben (Einverständnis der Kunden vorausgesetzt!)</strong><br>Ist diese Option aktiv, so wird der Vor- sowie Nachnamen des Kunden übergeben: <code>Beispiel: Max Müller</code><br><br><strong><em>Wichtiger Hinweis:</em></strong> Wählen Sie diese Option nur dann, wenn Sie rechtlich geprüft haben, dass Sie Vor- und Nachname des Kunden an dieser Stelle ausgeben dürfen!</li>
</ul>
<a name="weitere-produkt-einstellungen"></a>
<h2>Weitere Produkt-Einstellungen</h2>
<a name="name-des-verkaeufers"></a>
<h3>Name des Verkäufers</h3>
<p>Über das Feld <code>Name des Verkäufers</code> ist es möglich den Namen des Verkäufers zu hinterlegen. In den Rich Snippets wird dieser Wert als <code>@type: Organization » seller</code> ausgegeben. Wir empfehlen hier den Namen Ihrer Firma zu hinterlegen.</p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/300-rich-snippets-json-ld/100-products',
    'parent' => 'en_300-modules/300-rich-snippets-json-ld',
    'seoUrl' => 'docs/seo-professional/modules/rich-snippets-json-ld/products',
    'title' => 'Produkte',
    'menuTitle' => 'Produkte',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Produkte</h1>
<p>Wenn du deine Produktseiten mit Rich Snippet Markup auszeichnest, kann Google ausführliche Produktinformationen anzeigen. Nutzer sehen dann Preis, Verfügbarkeit, Bewertungsergebnisse usw. direkt in den Suchergebnissen.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#zustand-der-produkte">Zustand der Produkte</a></li><li class="headline-level2"><a href="#verfuegbarkeit-der-produkte">Verfügbarkeit der Produkte</a></li><li class="headline-level2"><a href="#haendlerspezifische-kennung">Händlerspezifische Kennung</a></li><li class="headline-level2"><a href="#herstellerteile-nummer">Herstellerteile-Nummer</a></li><li class="headline-level2"><a href="#preis-gueltig-bis-datum">Preis gültig bis Datum</a></li><li class="headline-level2"><a href="#bewertungen">Bewertungen</a></li><li class="headline-level2"><a href="#weitere-produkt-einstellungen">Weitere Produkt-Einstellungen</a></li><li class="headline-level3"><a href="#name-des-verkaeufers">Name des Verkäufers</a></li></ul></div></p>
<a name="zustand-der-produkte"></a>
<h2>Zustand der Produkte</h2>
<p>Über diese Konfiguration kannst du einen <code>Standardwert für den Zustand der Produkte</code> definieren. Hierbei stehen die folgenden Werte als Auswahl zur Verfügung: </p>
<ul>
<li>Neu</li>
<li>Gebraucht</li>
<li>Generalüberholt</li>
<li>Beschädigt</li>
</ul>
<p>Der hier ausgewählte Standardwert wird für alle Produkte übergeben, bei denen kein <code>abweichender Produktzustand</code> definiert wurde. Wie du einen abweichenden Zustand für ein Produkt hinterlegen kannst, erfährst du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="verfuegbarkeit-der-produkte"></a>
<h2>Verfügbarkeit der Produkte</h2>
<p>In diesem Bereich der Konfiguration kannst du Standardwerte für die Verfügbarkeit der Produkte definieren. Hierbei unterscheiden wir zwischen normalen Produkten sowie Produkten, die für den Abverkauf definiert wurden. Hier unterteilen wir anschließend noch, ob diese Lagerbestand aufweisen oder nicht. Hierdurch ergeben sich die folgenden Standardwerte die definiert werden können:</p>
<ul>
<li>Standardwert für die Verfügbarkeit von normalen Produkten</li>
<li>Standardwert für die Verfügbarkeit von normalen Produkten ohne Lagerbestand </li>
<li>Standardwert für die Verfügbarkeit von Abverkauf-Produkten </li>
<li>Standardwert für die Verfügbarkeit von Abverkauf-Produkten ohne Lagerbestand </li>
</ul>
<p>Die hier ausgewählten Standardwerte werden für alle Produkte übergeben, bei denen keine <code>abweichende Verfügbarkeit</code> definiert wurde. Wie du eine abweichende Verfügbarkeit für ein Produkt hinterlegen kannst, erfährst du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="haendlerspezifische-kennung"></a>
<h2>Händlerspezifische Kennung</h2>
<p>Unter <code>Standardwert für Händlerspezifische Kennung</code> kannst du den Wert definieren, der standardmäßig als SKU Wert übergeben werden soll. Wir empfehlen hier die Produktnummer zu übergeben. Alternativ kann hier per Konfiguration bestimmt werden, dass die Herstellernummer übergeben wird, falls vorhanden.</p>
<p>Der hier ausgewählte Standardwert wird für alle Produkte übergeben, bei denen keine <code>abweichende händlerspezifische Kennung</code> definiert wurde. Wie du eine abweichende händlerspezifische Kennung für ein Produkt hinterlegen kannst, erfährst du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="herstellerteile-nummer"></a>
<h2>Herstellerteile-Nummer</h2>
<p>Unter <code>Standardwert für Herstellerteile-Nummer</code> kannst du den Wert definieren, der standardmäßig als MPN Wert übergeben werden soll. Wir empfehlen hier die Übergabe der Herstellernummer, falls vorhanden. Alternativ kann hier per Konfiguration bestimmt werden, dass die Produktnummer übergeben wird.</p>
<p>Der hier ausgewählte Standardwert wird für alle Produkte übergeben, bei denen keine <code>abweichende Herstellerteile-Nummer</code> definiert wurde. Wie du eine abweichende Herstellerteile-Nummer für ein Produkt hinterlegen kannst, erfährst du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="preis-gueltig-bis-datum"></a>
<h2>Preis gültig bis Datum</h2>
<p>Die Konfiguration <code>Preis gültig bis Datum</code> setzt das Rich Snippet Feld <code>priceValidUntil</code>. Hierbei handelt es sich um ein von Google empfohlendes Feld, dass angibt, wie lange der aktuelle Preis gültig ist.</p>
<p>Über <code>Standardwert für das Feld "Preis gültig bis Datum" (priceValidUntil)</code> kann ein Standardwert konfiguriert werden, der für die Produkte verwendet werden soll. Neben der Einstellung, dass das Feld gar nicht ausgegeben werden soll, kann das aktuelle Datum oder das aktuelle Datum + [Zeitraum] ausgewählt werden. Zusätzlich steht die Option <code>Aktuelles Datum + eigene Anzahl an Tagen</code> zur Verfügung. Wählst du diese Option aus, so erscheint das Feld <code>Anzahl an Tagen</code>, was in diesem Fall ebenfalls ausgefüllt werden muss.</p>
<p>Möchtest du für ein spezifisches Produkt ein festes Datum für diesen Wert setzen, so ist über das Feld <code>Abweichendes "Preis gültig bis"-Datum</code> möglich. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a></p>
<a name="bewertungen"></a>
<h2>Bewertungen</h2>
<p>Werden Produktbewertungen an Google übergeben, so muss auch ein Autor der Bewertung übergeben werden. Wird dies nicht gemacht, so quittiert Google dies mit einer Fehlermeldung.</p>
<p>Über die Konfiguration <code>Autor der Bewertung</code> kann entsprechend definiert werden, welcher Wert als Autor übergeben werden soll. Hierbei stehen die folgenden Optionen zur Auswahl:</p>
<ul>
<li><strong>Dieses Feld standardmäßig nicht ausgeben</strong><br>Wird nicht empfohlen, da Google die Bewertung dann als nicht vollständig bewertet.</li>
<li><strong>Statischen Wert übergeben (Textbaustein)</strong><br>Ist diese Option aktiv, so wird ein als Textbaustein definierter Wert als Autor übergeben. Der Textbaustein kann über die Schaltfläche <code>Textbaustein Konfiguration in neuem Fenster öffnen</code> bearbeitet werden, sobald die Option ausgewählt wurde.</li>
<li><strong>Vorname des Kunden übergeben</strong><br>Ist diese Option aktiv, so wird der Vorname des Kunden übergeben: <code>Beispiel: Max</code></li>
<li><strong>Vorname + Anfangsbuchstabe des Nachnamen des Kunden übergeben (empfohlen)</strong><br>Ist diese Option aktiv, so wird der Vorname sowie der Anfangsbuchstabe des Nachnamen des Kunden übergeben: <code>Beispiel: Max M.</code></li>
<li><strong>Vorname + Nachname des Kunden übergeben (Einverständnis der Kunden vorausgesetzt!)</strong><br>Ist diese Option aktiv, so wird der Vor- sowie Nachnamen des Kunden übergeben: <code>Beispiel: Max Müller</code><br><br><strong><em>Wichtiger Hinweis:</em></strong> Wählen Sie diese Option nur dann, wenn Sie rechtlich geprüft haben, dass Sie Vor- und Nachname des Kunden an dieser Stelle ausgeben dürfen!</li>
</ul>
<a name="weitere-produkt-einstellungen"></a>
<h2>Weitere Produkt-Einstellungen</h2>
<a name="name-des-verkaeufers"></a>
<h3>Name des Verkäufers</h3>
<p>Über das Feld <code>Name des Verkäufers</code> ist es möglich den Namen des Verkäufers zu hinterlegen. In den Rich Snippets wird dieser Wert als <code>@type: Organization » seller</code> ausgegeben. Wir empfehlen hier den Namen Ihrer Firma zu hinterlegen.</p>
<p></p>',
  ),
);