<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/300-rich-snippets-json-ld/200-breadcrumb',
    'parent' => 'de_300-modules/300-rich-snippets-json-ld',
    'seoUrl' => 'docs/seo-professional/modules/rich-snippets-json-ld/breadcrumb',
    'title' => 'Breadcrumb',
    'menuTitle' => 'Breadcrumb',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Breadcrumb</h1>
<p>Wenn du die Breadcrumb Daten übergibst, kann Google die Struktur der Seite optimal erfassen und sich ein besser Bild deiner Seitenstruktur verschaffen.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#allgemein">Allgemein</a></li><li class="headline-level2"><a href="#startseite">Startseite</a></li><li class="headline-level2"><a href="#produkt-detailseite">Produkt-Detailseite</a></li></ul></div></p>
<a name="allgemein"></a>
<h2>Allgemein</h2>
<p>Möchtest du, dass die Breadcrumb per JSON-LD übergeben werden, so musst du sicherstellen, dass die Option <code>Breadcrumb per JSON-LD übergeben</code> aktiv ist.</p>
<a name="startseite"></a>
<h2>Startseite</h2>
<p>Standardmäßig beginnt die Breadcrumb mit der ersten Kategorie, bspw. <code>Herren » Schuhe</code>. Über die Konfiguration <code>Startseite als eigenes Breadcrumb Element</code> kann definiert werden, dass zusätzlich auch ein Eintrag für die Startseite erfolgt, sodass die Breadcrumb in dem oben genannten Beispiel dann wie folgt aussehen würde: <code>Herren » Schuhe » Herren</code>.</p>
<p>Die Konfiguration unterscheidet zwischen der Übergabe in der JSON-LD sowie der Ausgabe der Breadcrumb im Shop. Somit ergeben sich die folgenden Optionen für diese Einstellung:</p>
<ul>
<li><strong>Nicht ausgeben</strong><br>Für die Startseite wird weder im Shop noch in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Nur im Shop ausgeben</strong><br>Für die Startseite wird nur im Shop ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Nur per Rich Snippet übertragen</strong><br>Für die Startseite wird nur in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Im Shop ausgeben und per Rich Snippet übertragen</strong><br>Der Breadcrumb Eintrag wird sowohl im Shop ausgegeben, als auch in der JSON-LD übergeben.</li>
</ul>
<a name="produkt-detailseite"></a>
<h2>Produkt-Detailseite</h2>
<p>Standardmäßig wird für das Produkt selbst auf der Detailseite kein Breadcrumb-Eintrag erstellt, bspw. <code>Herren » Schuhe</code>. Über die Konfiguration <code>Produktseite als eigenes Breadcrumb Element</code> kann definiert werden, dass zusätzlich auch ein Eintrag für die Produktseite erfolgt, sodass die Breadcrumb in dem oben genannten Beispiel dann wie folgt aussehen würde: <code>Herren » Schuhe » Nike Free 60</code>.</p>
<p>Die Konfiguration unterscheidet zwischen der Übergabe in der JSON-LD sowie der Ausgabe der Breadcrumb im Shop. Somit ergeben sich die folgenden Optionen für diese Einstellung:</p>
<ul>
<li><strong>Nicht ausgeben</strong><br>Für die Produktseite wird weder im Shop noch in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Nur im Shop ausgeben</strong><br>Für die Produktseite wird nur im Shop ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Nur per Rich Snippet übertragen</strong><br>Für die Produktseite wird nur in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Im Shop ausgeben und per Rich Snippet übertragen</strong><br>Der Breadcrumb Eintrag wird sowohl im Shop ausgegeben, als auch in der JSON-LD übergeben.</li>
</ul>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/300-rich-snippets-json-ld/200-breadcrumb',
    'parent' => 'en_300-modules/300-rich-snippets-json-ld',
    'seoUrl' => 'docs/seo-professional/modules/rich-snippets-json-ld/breadcrumb',
    'title' => 'Breadcrumb',
    'menuTitle' => 'Breadcrumb',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Breadcrumb</h1>
<p>Wenn du die Breadcrumb Daten übergibst, kann Google die Struktur der Seite optimal erfassen und sich ein besser Bild deiner Seitenstruktur verschaffen.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#allgemein">Allgemein</a></li><li class="headline-level2"><a href="#startseite">Startseite</a></li><li class="headline-level2"><a href="#produkt-detailseite">Produkt-Detailseite</a></li></ul></div></p>
<a name="allgemein"></a>
<h2>Allgemein</h2>
<p>Möchtest du, dass die Breadcrumb per JSON-LD übergeben werden, so musst du sicherstellen, dass die Option <code>Breadcrumb per JSON-LD übergeben</code> aktiv ist.</p>
<a name="startseite"></a>
<h2>Startseite</h2>
<p>Standardmäßig beginnt die Breadcrumb mit der ersten Kategorie, bspw. <code>Herren » Schuhe</code>. Über die Konfiguration <code>Startseite als eigenes Breadcrumb Element</code> kann definiert werden, dass zusätzlich auch ein Eintrag für die Startseite erfolgt, sodass die Breadcrumb in dem oben genannten Beispiel dann wie folgt aussehen würde: <code>Herren » Schuhe » Herren</code>.</p>
<p>Die Konfiguration unterscheidet zwischen der Übergabe in der JSON-LD sowie der Ausgabe der Breadcrumb im Shop. Somit ergeben sich die folgenden Optionen für diese Einstellung:</p>
<ul>
<li><strong>Nicht ausgeben</strong><br>Für die Startseite wird weder im Shop noch in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Nur im Shop ausgeben</strong><br>Für die Startseite wird nur im Shop ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Nur per Rich Snippet übertragen</strong><br>Für die Startseite wird nur in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Im Shop ausgeben und per Rich Snippet übertragen</strong><br>Der Breadcrumb Eintrag wird sowohl im Shop ausgegeben, als auch in der JSON-LD übergeben.</li>
</ul>
<a name="produkt-detailseite"></a>
<h2>Produkt-Detailseite</h2>
<p>Standardmäßig wird für das Produkt selbst auf der Detailseite kein Breadcrumb-Eintrag erstellt, bspw. <code>Herren » Schuhe</code>. Über die Konfiguration <code>Produktseite als eigenes Breadcrumb Element</code> kann definiert werden, dass zusätzlich auch ein Eintrag für die Produktseite erfolgt, sodass die Breadcrumb in dem oben genannten Beispiel dann wie folgt aussehen würde: <code>Herren » Schuhe » Nike Free 60</code>.</p>
<p>Die Konfiguration unterscheidet zwischen der Übergabe in der JSON-LD sowie der Ausgabe der Breadcrumb im Shop. Somit ergeben sich die folgenden Optionen für diese Einstellung:</p>
<ul>
<li><strong>Nicht ausgeben</strong><br>Für die Produktseite wird weder im Shop noch in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Nur im Shop ausgeben</strong><br>Für die Produktseite wird nur im Shop ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Nur per Rich Snippet übertragen</strong><br>Für die Produktseite wird nur in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.</li>
<li><strong>Im Shop ausgeben und per Rich Snippet übertragen</strong><br>Der Breadcrumb Eintrag wird sowohl im Shop ausgegeben, als auch in der JSON-LD übergeben.</li>
</ul>
<p></p>',
  ),
);