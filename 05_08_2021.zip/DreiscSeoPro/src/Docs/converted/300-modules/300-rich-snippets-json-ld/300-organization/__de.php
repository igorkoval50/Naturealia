<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/300-rich-snippets-json-ld/300-organization',
    'parent' => 'de_300-modules/300-rich-snippets-json-ld',
    'seoUrl' => 'docs/seo-professional/modules/rich-snippets-json-ld/organization',
    'title' => 'Unternehmen',
    'menuTitle' => 'Unternehmen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Unternehmen</h1>
<p>In diesem Bereich hast du die Möglichkeit Rich Snippet Daten der Bereiche <code>Logo</code> und <code>Lokales Unternehmen</code> zu übergeben.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#logo">Logo</a></li><li class="headline-level3"><a href="#konfigurationsfelder-fuer-die-logo-konfiguration">Konfigurationsfelder für die Logo-Konfiguration</a></li><li class="headline-level2"><a href="#lokales-unternehmen">Lokales Unternehmen</a></li><li class="headline-level3"><a href="#konfigurationsfelder-fuer-konfiguration-des-lokalen-unternehmens">Konfigurationsfelder für Konfiguration des lokalen Unternehmens</a></li></ul></div></p>
<a name="logo"></a>
<h2>Logo</h2>
<p>Hiermit wird das Bild angegeben, das Google als Logo deines Unternehmens in den Suchergebnissen und im Knowledge Graph verwendet. Möchtest du, dass dein Logo per JSON-LD übergeben werden, so musst du sicherstellen, dass die Option <code>Logo per JSON-LD übergeben</code> aktiv ist.</p>
<a name="konfigurationsfelder-fuer-die-logo-konfiguration"></a>
<h3>Konfigurationsfelder für die Logo-Konfiguration</h3>
<p>Neben der Schaltfläche zur Aktivierung der Logo Übergabe stehen die folgenden Einstellungen zur Verfügung:</p>
<ul>
<li><strong>URL des Logos</strong><br>Gebe hier die URL an die bei Google als Link für das Logo verwendet werden soll.</li>
<li><strong>Logo</strong><br>Über diese Einstellung wird das eigentliche Logo hinterlegt. Dieses muss im Format JPG, PNG oder GIF vorliegen sowie mindestens 112 × 112 Pixel groß sein.</li>
</ul>
<a name="lokales-unternehmen"></a>
<h2>Lokales Unternehmen</h2>
<p>Mithilfe der strukturierten Daten für lokale Unternehmen kannst du Google die Anschrift, Kontaktdaten sowie Öffnungszeiten deines Unternehmens mitteilen. Wie bei den Logo Daten muss die Übergabe auch hier über die Schaltfläche <code>Lokales Unternehmen per JSON-LD übergeben</code> explizit aktiviert werden.</p>
<a name="konfigurationsfelder-fuer-konfiguration-des-lokalen-unternehmens"></a>
<h3>Konfigurationsfelder für Konfiguration des lokalen Unternehmens</h3>
<p>Die Konfigurationsfelder <code>Name des Unternehmens</code>, <code>Telefonnummer</code> und <code>URL des Unternehmensstandorts</code> sowie die Adressangaben in dem Dialoglfeld <code>Adresse</code> beziehen sich auf das lokale Unternehmen und sollten soweit selbsterklärend sein.</p>
<p>Über die Konfiguration <code>Öffnungszeiten</code> kannst du die Öffnungszeiten der einzelnen Wochentage hinterlegen. Aktiviere hierzu über die Schaltfläche in der Spalte <code>Aktiv</code> den jeweiligen Wochentag. Anschließend kann die Öffnungs- sowie Schließzeit hinterlegt werden.</p>
<p><a data-dreisccmslightbox="images-670684" data-title="Konfiguration der Öffnungszeiten" href="wiki/dreisc_seo_pro/300-modules/300-rich-snippets-json-ld/300-organization/lightbox/oeffnungszeiten-lokales-unternehmen-shopware.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/300-rich-snippets-json-ld/300-organization/lightbox/oeffnungszeiten-lokales-unternehmen-shopware.png" alt="Konfiguration der Öffnungszeiten">
                        </a>
</p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/300-rich-snippets-json-ld/300-organization',
    'parent' => 'en_300-modules/300-rich-snippets-json-ld',
    'seoUrl' => 'docs/seo-professional/modules/rich-snippets-json-ld/organization',
    'title' => 'Unternehmen',
    'menuTitle' => 'Unternehmen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Unternehmen</h1>
<p>In diesem Bereich hast du die Möglichkeit Rich Snippet Daten der Bereiche <code>Logo</code> und <code>Lokales Unternehmen</code> zu übergeben.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#logo">Logo</a></li><li class="headline-level3"><a href="#konfigurationsfelder-fuer-die-logo-konfiguration">Konfigurationsfelder für die Logo-Konfiguration</a></li><li class="headline-level2"><a href="#lokales-unternehmen">Lokales Unternehmen</a></li><li class="headline-level3"><a href="#konfigurationsfelder-fuer-konfiguration-des-lokalen-unternehmens">Konfigurationsfelder für Konfiguration des lokalen Unternehmens</a></li></ul></div></p>
<a name="logo"></a>
<h2>Logo</h2>
<p>Hiermit wird das Bild angegeben, das Google als Logo deines Unternehmens in den Suchergebnissen und im Knowledge Graph verwendet. Möchtest du, dass dein Logo per JSON-LD übergeben werden, so musst du sicherstellen, dass die Option <code>Logo per JSON-LD übergeben</code> aktiv ist.</p>
<a name="konfigurationsfelder-fuer-die-logo-konfiguration"></a>
<h3>Konfigurationsfelder für die Logo-Konfiguration</h3>
<p>Neben der Schaltfläche zur Aktivierung der Logo Übergabe stehen die folgenden Einstellungen zur Verfügung:</p>
<ul>
<li><strong>URL des Logos</strong><br>Gebe hier die URL an die bei Google als Link für das Logo verwendet werden soll.</li>
<li><strong>Logo</strong><br>Über diese Einstellung wird das eigentliche Logo hinterlegt. Dieses muss im Format JPG, PNG oder GIF vorliegen sowie mindestens 112 × 112 Pixel groß sein.</li>
</ul>
<a name="lokales-unternehmen"></a>
<h2>Lokales Unternehmen</h2>
<p>Mithilfe der strukturierten Daten für lokale Unternehmen kannst du Google die Anschrift, Kontaktdaten sowie Öffnungszeiten deines Unternehmens mitteilen. Wie bei den Logo Daten muss die Übergabe auch hier über die Schaltfläche <code>Lokales Unternehmen per JSON-LD übergeben</code> explizit aktiviert werden.</p>
<a name="konfigurationsfelder-fuer-konfiguration-des-lokalen-unternehmens"></a>
<h3>Konfigurationsfelder für Konfiguration des lokalen Unternehmens</h3>
<p>Die Konfigurationsfelder <code>Name des Unternehmens</code>, <code>Telefonnummer</code> und <code>URL des Unternehmensstandorts</code> sowie die Adressangaben in dem Dialoglfeld <code>Adresse</code> beziehen sich auf das lokale Unternehmen und sollten soweit selbsterklärend sein.</p>
<p>Über die Konfiguration <code>Öffnungszeiten</code> kannst du die Öffnungszeiten der einzelnen Wochentage hinterlegen. Aktiviere hierzu über die Schaltfläche in der Spalte <code>Aktiv</code> den jeweiligen Wochentag. Anschließend kann die Öffnungs- sowie Schließzeit hinterlegt werden.</p>
<p><a data-dreisccmslightbox="images-915753" data-title="Konfiguration der Öffnungszeiten" href="wiki/dreisc_seo_pro/300-modules/300-rich-snippets-json-ld/300-organization/lightbox/oeffnungszeiten-lokales-unternehmen-shopware.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/300-rich-snippets-json-ld/300-organization/lightbox/oeffnungszeiten-lokales-unternehmen-shopware.png" alt="Konfiguration der Öffnungszeiten">
                        </a>
</p>',
  ),
);