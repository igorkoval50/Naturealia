<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/300-rich-snippets-json-ld',
    'parent' => 'de_300-modules',
    'seoUrl' => 'docs/seo-professional/modules/rich-snippets-json-ld',
    'title' => 'Rich Snippets (JSON-LD)',
    'menuTitle' => 'Rich Snippets (JSON-LD)',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Rich Snippets (JSON-LD)</h1>
<p>Im Shopware Standard werden die Rich Snippets durch sogenannte Mikrodaten im Quellcode übertragen. Über SEO Professional hast du die Möglichkeit diese Mikrodaten aus dem Quellcode zu entfernen und durch die von Google empfohlenen JSON-LD Rich Snippets zu ersetzen.</p>
<p>Hierbei werden neben den Standardfeldern aus dem Shopware Standard auch noch weitere Rich Snippets Felder übertragen, die über dieses Modul entsprechend konfiguriert werden können.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#rich-snippets-ueber-json-ld-aktivieren">Rich Snippets über JSON-LD aktivieren</a></li><li class="headline-level2"><a href="#allgemeine-information-zu-den-einstellungen">Allgemeine Information zu den Einstellungen</a></li><li class="headline-level3"><a href="#verkaufskanel">Verkaufskanel</a></li><li class="headline-level2"><a href="#rich-snippet-module">Rich Snippet Module</a></li></ul></div></p>
<a name="rich-snippets-ueber-json-ld-aktivieren"></a>
<h2>Rich Snippets über JSON-LD aktivieren</h2>
<p>Damit SEO Professional die Mikrodaten aus dem Shopware Standard durch JSON-LD Rich Snippets ersetzen und dir hierzu weitere Einstellungsmöglichkeiten zur Verfügung stellen kann, musst du zunächst sicherstellen, dass die entsprechende Option <code>Rich Snippets über JSON-LD aktivieren</code> im Tab <code>Allgemein</code> aktiv ist.</p>
<a name="allgemeine-information-zu-den-einstellungen"></a>
<h2>Allgemeine Information zu den Einstellungen</h2>
<a name="verkaufskanel"></a>
<h3>Verkaufskanel</h3>
<p>Standardmäßig werden die hier sowie in den Untermodulen hinterlegten Konfigurationen für alle Verkaufskanäle genutzt. Möchtest du eine Einstellung nur für einen bestimmten Verkaufskanel hinterlegen, so musst du diesen zunächst über das Feld <code>Verkaufskanel</code> auswählen. Das Verhalten ist hierbei anschließend analog zur Konfiguration der Produkt Varianten. Eine Vererbung findet also solange statt, bis das Link-Symbol einer Einstellung aufgelöst ist.</p>
<p><a data-dreisccmslightbox="images-277928" data-title="Verkaufskanel auswählen" href="wiki/dreisc_seo_pro/300-modules/300-rich-snippets-json-ld/lightbox/sales-channel-auswahl.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/300-rich-snippets-json-ld/lightbox/sales-channel-auswahl.png" alt="Verkaufskanel auswählen">
                        </a></p>
<a name="rich-snippet-module"></a>
<h2>Rich Snippet Module</h2>
<p>Die weiteren Einstellungen findest du in den folgenden Untermodulen:</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/rich-snippets-json-ld/products" class="nav--link link--entry">Produkte</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/rich-snippets-json-ld/breadcrumb" class="nav--link link--entry">Breadcrumb</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/rich-snippets-json-ld/organization" class="nav--link link--entry">Unternehmen</a></li></ul></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/300-rich-snippets-json-ld',
    'parent' => 'en_300-modules',
    'seoUrl' => 'docs/seo-professional/modules/rich-snippets-json-ld',
    'title' => 'Rich Snippets (JSON-LD)',
    'menuTitle' => 'Rich Snippets (JSON-LD)',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Rich Snippets (JSON-LD)</h1>
<p>Im Shopware Standard werden die Rich Snippets durch sogenannte Mikrodaten im Quellcode übertragen. Über SEO Professional hast du die Möglichkeit diese Mikrodaten aus dem Quellcode zu entfernen und durch die von Google empfohlenen JSON-LD Rich Snippets zu ersetzen.</p>
<p>Hierbei werden neben den Standardfeldern aus dem Shopware Standard auch noch weitere Rich Snippets Felder übertragen, die über dieses Modul entsprechend konfiguriert werden können.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#rich-snippets-ueber-json-ld-aktivieren">Rich Snippets über JSON-LD aktivieren</a></li><li class="headline-level2"><a href="#allgemeine-information-zu-den-einstellungen">Allgemeine Information zu den Einstellungen</a></li><li class="headline-level3"><a href="#verkaufskanel">Verkaufskanel</a></li><li class="headline-level2"><a href="#rich-snippet-module">Rich Snippet Module</a></li></ul></div></p>
<a name="rich-snippets-ueber-json-ld-aktivieren"></a>
<h2>Rich Snippets über JSON-LD aktivieren</h2>
<p>Damit SEO Professional die Mikrodaten aus dem Shopware Standard durch JSON-LD Rich Snippets ersetzen und dir hierzu weitere Einstellungsmöglichkeiten zur Verfügung stellen kann, musst du zunächst sicherstellen, dass die entsprechende Option <code>Rich Snippets über JSON-LD aktivieren</code> im Tab <code>Allgemein</code> aktiv ist.</p>
<a name="allgemeine-information-zu-den-einstellungen"></a>
<h2>Allgemeine Information zu den Einstellungen</h2>
<a name="verkaufskanel"></a>
<h3>Verkaufskanel</h3>
<p>Standardmäßig werden die hier sowie in den Untermodulen hinterlegten Konfigurationen für alle Verkaufskanäle genutzt. Möchtest du eine Einstellung nur für einen bestimmten Verkaufskanel hinterlegen, so musst du diesen zunächst über das Feld <code>Verkaufskanel</code> auswählen. Das Verhalten ist hierbei anschließend analog zur Konfiguration der Produkt Varianten. Eine Vererbung findet also solange statt, bis das Link-Symbol einer Einstellung aufgelöst ist.</p>
<p><a data-dreisccmslightbox="images-925497" data-title="Verkaufskanel auswählen" href="wiki/dreisc_seo_pro/300-modules/300-rich-snippets-json-ld/lightbox/sales-channel-auswahl.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/300-rich-snippets-json-ld/lightbox/sales-channel-auswahl.png" alt="Verkaufskanel auswählen">
                        </a></p>
<a name="rich-snippet-module"></a>
<h2>Rich Snippet Module</h2>
<p>Die weiteren Einstellungen findest du in den folgenden Untermodulen:</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/rich-snippets-json-ld/products" class="nav--link link--entry">Produkte</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/rich-snippets-json-ld/breadcrumb" class="nav--link link--entry">Breadcrumb</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/rich-snippets-json-ld/organization" class="nav--link link--entry">Unternehmen</a></li></ul></p>',
  ),
);