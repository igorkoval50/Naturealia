<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/200-redirect/110-create',
    'parent' => 'de_300-modules/200-redirect',
    'seoUrl' => 'docs/seo-professional/modules/redirect/create',
    'title' => 'Neue Weiterleitungen anlegen',
    'menuTitle' => 'Neue Weiterleitungen anlegen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Neue Weiterleitungen anlegen</h1>
<p>In dieser Anleitung wird beschrieben, wie du eine neue Weiterleitung in SEO Professional erstellen kannst.
<div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#vorbereitung">Vorbereitung</a></li><li class="headline-level2"><a href="#grundeinstellungen">Grundeinstellungen</a></li><li class="headline-level2"><a href="#quelle-der-weiterleitung">Quelle der Weiterleitung</a></li><li class="headline-level3"><a href="#quell-ressource-interne-url">Quell-Ressource: Interne URL</a></li><li class="headline-level3"><a href="#quell-ressource-produkt">Quell-Ressource: Produkt</a></li><li class="headline-level3"><a href="#quell-ressource-kategorie">Quell-Ressource: Kategorie</a></li><li class="headline-level2"><a href="#weiterleiten-auf-">weiterleiten auf ...</a></li><li class="headline-level3"><a href="#ziel-ressource-interne-url">Ziel-Ressource: Interne URL</a></li><li class="headline-level3"><a href="#ziel-ressource-externe-url">Ziel-Ressource: Externe URL</a></li><li class="headline-level3"><a href="#ziel-ressource-produkt">Ziel-Ressource: Produkt</a></li><li class="headline-level3"><a href="#ziel-ressource-kategorie">Ziel-Ressource: Kategorie</a></li><li class="headline-level2"><a href="#einschraenkungen">Einschränkungen</a></li><li class="headline-level3"><a href="#url-muss-den-shopware-kernel-aufrufen">URL muss den Shopware Kernel aufrufen</a></li><li class="headline-level3"><a href="#die-startseite-der-shops-kann-aktuell-nicht-weiterleitet-werden">Die Startseite der Shops kann aktuell nicht weiterleitet werden</a></li></ul></div></p>
<a name="vorbereitung"></a>
<h2>Vorbereitung</h2>
<p>Öffne zum Erstellen einer neuen Weiterleitung die Übersicht unter <code>SEO Professional » 301 und 302 URL Weiterleitungen</code> und klicke hier auf die Schaltfläche <code>Neue Weiterleitung anlegen</code></p>
<p><a data-dreisccmslightbox="images-184605" data-title="Neue Weiterleitung erstellen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/create.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/create.png" alt="Neue Weiterleitung erstellen">
                        </a></p>
<a name="grundeinstellungen"></a>
<h2>Grundeinstellungen</h2>
<p><a data-dreisccmslightbox="images-184605" data-title="Grundeinstellungen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/grundeinstellungen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/grundeinstellungen.png" alt="Grundeinstellungen">
                        </a></p>
<ul>
<li><strong>Aktiv</strong><br>Definiert, ob die Weiterleitung durchgeführt werden soll.</li>
<li><strong>HTTP Status</strong><br>Über diese Option kannst du konfigurieren, ob es sich um eine dauerhafte oder aber eine temporäre Weiterleitung handelt.</li>
</ul>
<a name="quelle-der-weiterleitung"></a>
<h2>Quelle der Weiterleitung</h2>
<p>Bei der Definition der Quelle der Weiterleitung muss zunächst konfiguriert werden, welche Quell-Ressource weitergeleitet werden soll. Im Standard kann eine interne URL, ein Produkt oder aber eine Kategorie weitergeleitet werden.</p>
<p><a data-dreisccmslightbox="images-184605" data-title="Grundeinstellungen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-der-weiterleitung_waehlen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-der-weiterleitung_waehlen.png" alt="Grundeinstellungen">
                        </a></p>
<a name="quell-ressource-interne-url"></a>
<h3>Quell-Ressource: Interne URL</h3>
<p><a data-dreisccmslightbox="images-184605" data-title="Quell-Ressource: Interne URL" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_interne-url.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_interne-url.png" alt="Quell-Ressource: Interne URL">
                        </a></p>
<ul>
<li><strong>Domain</strong><br>An dieser Stelle werden dir alle Domains der Sales Channels gelistet. Wähle hier die gewünschte Domain aus.</li>
<li><strong>Quell-URL</strong><br>Als Quell-URL muss der relative Pfad nach der Domain definiert werden.</li>
</ul>
<a name="quell-ressource-produkt"></a>
<h3>Quell-Ressource: Produkt</h3>
<p><a data-dreisccmslightbox="images-184605" data-title="Quell-Ressource: Produkt" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_article.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_article.png" alt="Quell-Ressource: Produkt">
                        </a></p>
<ul>
<li><strong>Produkt</strong><br>An dieser Stelle musst du das Produkt auswählen, für das eine Weiterleitung eingerichtet werden soll.</li>
<li><strong>Weiterleitung auf Domain(s) beschränken</strong><br>Standardmäßig greift die URL für alle Domains, unter der das definierte Produkt erreichbar ist und eine valide Weiterleitung durchgeführt werden kann. Wird diese Option aktiviert, so wird das Zusatzfeld <strong>Diese Weiterleitung nur bei den folgenden Domains durchführen</strong> freigeschaltet.</li>
<li><strong>Diese Weiterleitung nur bei den folgenden Domains durchführen</strong><br>Über dieses Feld kannst du konfigurieren, dass die bestehende Weiterleitung nur für bestimmte Domains durchgeführt werden soll.</li>
</ul>
<a name="quell-ressource-kategorie"></a>
<h3>Quell-Ressource: Kategorie</h3>
<p><a data-dreisccmslightbox="images-184605" data-title="Quell-Ressource: Produkt" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_kategorie.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_kategorie.png" alt="Quell-Ressource: Produkt">
                        </a></p>
<ul>
<li><strong>Kategorie</strong><br>An dieser Stelle musst du die Kategorie auswählen, für die eine Weiterleitung eingerichtet werden soll.</li>
<li><strong>Weiterleitung auf Domain(s) beschränken</strong><br>Standardmäßig greift die URL für alle Domains, unter der die definierte Kategorie erreichbar ist und eine valide Weiterleitung durchgeführt werden kann. Wird diese Option aktiviert, so wird das Zusatzfeld <strong>Diese Weiterleitung nur bei den folgenden Domains durchführen</strong> freigeschaltet.</li>
<li><strong>Diese Weiterleitung nur bei den folgenden Domains durchführen</strong><br>Über dieses Feld kannst du konfigurieren, dass die bestehende Weiterleitung nur für bestimmte Domains durchgeführt werden soll.</li>
</ul>
<a name="weiterleiten-auf-"></a>
<h2>weiterleiten auf ...</h2>
<p>Anschließend muss das Ziel der Weiterleitung bestimmt werden. Analog zur Quell-Ressource stehen hierbei eine interne URL, ein Produkt oder aber eine Kategorie zur Auswahl. Im Gegensatz zur Quell-Ressource kann als Typ zusätzlich noch eine externe URL als Ziel definiert werden.</p>
<p><a data-dreisccmslightbox="images-184605" data-title="Ziel der Weiterleitung wählen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-der-weiterleitung_waehlen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-der-weiterleitung_waehlen.png" alt="Ziel der Weiterleitung wählen">
                        </a></p>
<a name="ziel-ressource-interne-url"></a>
<h3>Ziel-Ressource: Interne URL</h3>
<p><a data-dreisccmslightbox="images-184605" data-title="Ziel-Ressource: Interne URL" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_interne-url.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_interne-url.png" alt="Ziel-Ressource: Interne URL">
                        </a></p>
<ul>
<li><strong>Domain</strong><br>An dieser Stelle werden dir alle Domains der Sales Channels gelistet. Wähle hier die gewünschte Domain aus.</li>
<li><strong>Ziel-URL</strong><br>Als Ziel-URL muss der relative Pfad nach der Domain definiert werden.</li>
</ul>
<a name="ziel-ressource-externe-url"></a>
<h3>Ziel-Ressource: Externe URL</h3>
<p><a data-dreisccmslightbox="images-184605" data-title="Ziel-Ressource: Externe URL" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_externe-url.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_externe-url.png" alt="Ziel-Ressource: Externe URL">
                        </a></p>
<ul>
<li><strong>URL</strong><br>Hinterlege an dieser Stelle die URL, an die eine Weiterleitung stattfinden soll.</li>
</ul>
<a name="ziel-ressource-produkt"></a>
<h3>Ziel-Ressource: Produkt</h3>
<p><a data-dreisccmslightbox="images-184605" data-title="Ziel-Ressource: Produkt" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_article.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_article.png" alt="Ziel-Ressource: Produkt">
                        </a></p>
<ul>
<li><strong>Produkt</strong><br>An dieser Stelle musst du das Produkt auswählen, das als Ziel der Weiterleitung genutzt werden soll.</li>
<li><strong>An abweichende Domain weiterleiten</strong><br>Standardmäßig wird bei der Weiterleitung auf ein Produkt die Domain der Weiterleitungsquelle beibehalten. Ist das jeweilige Produkt unter der Domain nicht erreichbar, so findet auch keine Weiterleitung statt. Wird die Option <code>An abweichende Domain weiterleiten</code> aktiviert, so kann das Standardverhalten angepasst werden, indem eine feste Domain ausgewählt werden kann, die als Ziel-Domain dienen soll.</li>
<li><strong>Abweichende Ziel-Domain</strong><br>Über diese Einstellung kannst du die Domain definieren, an die die Weiterleitung durchgeführt werden soll. Grundlegende Informationen hierzu findest du in der Beschreibung des Feldes <code>An abweichende Domain weiterleiten</code></li>
</ul>
<a name="ziel-ressource-kategorie"></a>
<h3>Ziel-Ressource: Kategorie</h3>
<p><a data-dreisccmslightbox="images-184605" data-title="Ziel-Ressource: Kategorie" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_kategorie.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_kategorie.png" alt="Ziel-Ressource: Kategorie">
                        </a></p>
<ul>
<li><strong>Kategorie</strong><br>An dieser Stelle musst du die Kategorie auswählen, die als Ziel der Weiterleitung genutzt werden soll.</li>
<li><strong>An abweichende Domain weiterleiten</strong><br>Standardmäßig wird bei der Weiterleitung auf eine Kategorie die Domain der Weiterleitungsquelle beibehalten. Ist die jeweilige Kategorie unter der Domain nicht erreichbar, so findet auch keine Weiterleitung statt. Wird die Option <code>An abweichende Domain weiterleiten</code> aktiviert, so kann das Standardverhalten angepasst werden, indem eine feste Domain ausgewählt werden kann, die als Ziel-Domain dienen soll.</li>
<li><strong>Abweichende Ziel-Domain</strong><br>Über diese Einstellung kannst du die Domain definieren, an die die Weiterleitung durchgeführt werden soll. Grundlegende Informationen hierzu findest du in der Beschreibung des Feldes <code>An abweichende Domain weiterleiten</code></li>
</ul>
<a name="einschraenkungen"></a>
<h2>Einschränkungen</h2>
<a name="url-muss-den-shopware-kernel-aufrufen"></a>
<h3>URL muss den Shopware Kernel aufrufen</h3>
<p>Eine Weiterleitung per SEO Professional kann nur dann aktiv werden, wenn beim Aufruf der jeweiligen URL auch der Shopware Kernel aufgerufen wird. Wird in der Serverkonfiguration bspw. definiert das URLs mit bestimmten Dateiendungen zu einer serverseitigen &quot;Not Found&quot; Seite führen, wenn diese nicht vorhanden sind, so kann hier auch keine Weiterleitung greifen. In diesem Fall müsste also sichergestellt werden, dass die Aufrufe auf die Shopware Instanz weitergeleitet werden.</p>
<a name="die-startseite-der-shops-kann-aktuell-nicht-weiterleitet-werden"></a>
<h3>Die Startseite der Shops kann aktuell nicht weiterleitet werden</h3>
<p>Wählt man als Weiterleitungsquelle die Root-Kategorie des jeweiligen Shops so findet in der aktuellen Versions des Plugins keine Weiterleitung der jeweiligen Startseite statt.</p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/200-redirect/110-create',
    'parent' => 'en_300-modules/200-redirect',
    'seoUrl' => 'docs/seo-professional/modules/redirect/create',
    'title' => 'Neue Weiterleitungen anlegen',
    'menuTitle' => 'Neue Weiterleitungen anlegen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Neue Weiterleitungen anlegen</h1>
<p>In dieser Anleitung wird beschrieben, wie du eine neue Weiterleitung in SEO Professional erstellen kannst.
<div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#vorbereitung">Vorbereitung</a></li><li class="headline-level2"><a href="#grundeinstellungen">Grundeinstellungen</a></li><li class="headline-level2"><a href="#quelle-der-weiterleitung">Quelle der Weiterleitung</a></li><li class="headline-level3"><a href="#quell-ressource-interne-url">Quell-Ressource: Interne URL</a></li><li class="headline-level3"><a href="#quell-ressource-produkt">Quell-Ressource: Produkt</a></li><li class="headline-level3"><a href="#quell-ressource-kategorie">Quell-Ressource: Kategorie</a></li><li class="headline-level2"><a href="#weiterleiten-auf-">weiterleiten auf ...</a></li><li class="headline-level3"><a href="#ziel-ressource-interne-url">Ziel-Ressource: Interne URL</a></li><li class="headline-level3"><a href="#ziel-ressource-externe-url">Ziel-Ressource: Externe URL</a></li><li class="headline-level3"><a href="#ziel-ressource-produkt">Ziel-Ressource: Produkt</a></li><li class="headline-level3"><a href="#ziel-ressource-kategorie">Ziel-Ressource: Kategorie</a></li><li class="headline-level2"><a href="#einschraenkungen">Einschränkungen</a></li><li class="headline-level3"><a href="#url-muss-den-shopware-kernel-aufrufen">URL muss den Shopware Kernel aufrufen</a></li><li class="headline-level3"><a href="#die-startseite-der-shops-kann-aktuell-nicht-weiterleitet-werden">Die Startseite der Shops kann aktuell nicht weiterleitet werden</a></li></ul></div></p>
<a name="vorbereitung"></a>
<h2>Vorbereitung</h2>
<p>Öffne zum Erstellen einer neuen Weiterleitung die Übersicht unter <code>SEO Professional » 301 und 302 URL Weiterleitungen</code> und klicke hier auf die Schaltfläche <code>Neue Weiterleitung anlegen</code></p>
<p><a data-dreisccmslightbox="images-121614" data-title="Neue Weiterleitung erstellen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/create.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/create.png" alt="Neue Weiterleitung erstellen">
                        </a></p>
<a name="grundeinstellungen"></a>
<h2>Grundeinstellungen</h2>
<p><a data-dreisccmslightbox="images-121614" data-title="Grundeinstellungen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/grundeinstellungen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/grundeinstellungen.png" alt="Grundeinstellungen">
                        </a></p>
<ul>
<li><strong>Aktiv</strong><br>Definiert, ob die Weiterleitung durchgeführt werden soll.</li>
<li><strong>HTTP Status</strong><br>Über diese Option kannst du konfigurieren, ob es sich um eine dauerhafte oder aber eine temporäre Weiterleitung handelt.</li>
</ul>
<a name="quelle-der-weiterleitung"></a>
<h2>Quelle der Weiterleitung</h2>
<p>Bei der Definition der Quelle der Weiterleitung muss zunächst konfiguriert werden, welche Quell-Ressource weitergeleitet werden soll. Im Standard kann eine interne URL, ein Produkt oder aber eine Kategorie weitergeleitet werden.</p>
<p><a data-dreisccmslightbox="images-121614" data-title="Grundeinstellungen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-der-weiterleitung_waehlen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-der-weiterleitung_waehlen.png" alt="Grundeinstellungen">
                        </a></p>
<a name="quell-ressource-interne-url"></a>
<h3>Quell-Ressource: Interne URL</h3>
<p><a data-dreisccmslightbox="images-121614" data-title="Quell-Ressource: Interne URL" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_interne-url.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_interne-url.png" alt="Quell-Ressource: Interne URL">
                        </a></p>
<ul>
<li><strong>Domain</strong><br>An dieser Stelle werden dir alle Domains der Sales Channels gelistet. Wähle hier die gewünschte Domain aus.</li>
<li><strong>Quell-URL</strong><br>Als Quell-URL muss der relative Pfad nach der Domain definiert werden.</li>
</ul>
<a name="quell-ressource-produkt"></a>
<h3>Quell-Ressource: Produkt</h3>
<p><a data-dreisccmslightbox="images-121614" data-title="Quell-Ressource: Produkt" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_article.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_article.png" alt="Quell-Ressource: Produkt">
                        </a></p>
<ul>
<li><strong>Produkt</strong><br>An dieser Stelle musst du das Produkt auswählen, für das eine Weiterleitung eingerichtet werden soll.</li>
<li><strong>Weiterleitung auf Domain(s) beschränken</strong><br>Standardmäßig greift die URL für alle Domains, unter der das definierte Produkt erreichbar ist und eine valide Weiterleitung durchgeführt werden kann. Wird diese Option aktiviert, so wird das Zusatzfeld <strong>Diese Weiterleitung nur bei den folgenden Domains durchführen</strong> freigeschaltet.</li>
<li><strong>Diese Weiterleitung nur bei den folgenden Domains durchführen</strong><br>Über dieses Feld kannst du konfigurieren, dass die bestehende Weiterleitung nur für bestimmte Domains durchgeführt werden soll.</li>
</ul>
<a name="quell-ressource-kategorie"></a>
<h3>Quell-Ressource: Kategorie</h3>
<p><a data-dreisccmslightbox="images-121614" data-title="Quell-Ressource: Produkt" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_kategorie.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/quelle-ressource_kategorie.png" alt="Quell-Ressource: Produkt">
                        </a></p>
<ul>
<li><strong>Kategorie</strong><br>An dieser Stelle musst du die Kategorie auswählen, für die eine Weiterleitung eingerichtet werden soll.</li>
<li><strong>Weiterleitung auf Domain(s) beschränken</strong><br>Standardmäßig greift die URL für alle Domains, unter der die definierte Kategorie erreichbar ist und eine valide Weiterleitung durchgeführt werden kann. Wird diese Option aktiviert, so wird das Zusatzfeld <strong>Diese Weiterleitung nur bei den folgenden Domains durchführen</strong> freigeschaltet.</li>
<li><strong>Diese Weiterleitung nur bei den folgenden Domains durchführen</strong><br>Über dieses Feld kannst du konfigurieren, dass die bestehende Weiterleitung nur für bestimmte Domains durchgeführt werden soll.</li>
</ul>
<a name="weiterleiten-auf-"></a>
<h2>weiterleiten auf ...</h2>
<p>Anschließend muss das Ziel der Weiterleitung bestimmt werden. Analog zur Quell-Ressource stehen hierbei eine interne URL, ein Produkt oder aber eine Kategorie zur Auswahl. Im Gegensatz zur Quell-Ressource kann als Typ zusätzlich noch eine externe URL als Ziel definiert werden.</p>
<p><a data-dreisccmslightbox="images-121614" data-title="Ziel der Weiterleitung wählen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-der-weiterleitung_waehlen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-der-weiterleitung_waehlen.png" alt="Ziel der Weiterleitung wählen">
                        </a></p>
<a name="ziel-ressource-interne-url"></a>
<h3>Ziel-Ressource: Interne URL</h3>
<p><a data-dreisccmslightbox="images-121614" data-title="Ziel-Ressource: Interne URL" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_interne-url.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_interne-url.png" alt="Ziel-Ressource: Interne URL">
                        </a></p>
<ul>
<li><strong>Domain</strong><br>An dieser Stelle werden dir alle Domains der Sales Channels gelistet. Wähle hier die gewünschte Domain aus.</li>
<li><strong>Ziel-URL</strong><br>Als Ziel-URL muss der relative Pfad nach der Domain definiert werden.</li>
</ul>
<a name="ziel-ressource-externe-url"></a>
<h3>Ziel-Ressource: Externe URL</h3>
<p><a data-dreisccmslightbox="images-121614" data-title="Ziel-Ressource: Externe URL" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_externe-url.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_externe-url.png" alt="Ziel-Ressource: Externe URL">
                        </a></p>
<ul>
<li><strong>URL</strong><br>Hinterlege an dieser Stelle die URL, an die eine Weiterleitung stattfinden soll.</li>
</ul>
<a name="ziel-ressource-produkt"></a>
<h3>Ziel-Ressource: Produkt</h3>
<p><a data-dreisccmslightbox="images-121614" data-title="Ziel-Ressource: Produkt" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_article.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_article.png" alt="Ziel-Ressource: Produkt">
                        </a></p>
<ul>
<li><strong>Produkt</strong><br>An dieser Stelle musst du das Produkt auswählen, das als Ziel der Weiterleitung genutzt werden soll.</li>
<li><strong>An abweichende Domain weiterleiten</strong><br>Standardmäßig wird bei der Weiterleitung auf ein Produkt die Domain der Weiterleitungsquelle beibehalten. Ist das jeweilige Produkt unter der Domain nicht erreichbar, so findet auch keine Weiterleitung statt. Wird die Option <code>An abweichende Domain weiterleiten</code> aktiviert, so kann das Standardverhalten angepasst werden, indem eine feste Domain ausgewählt werden kann, die als Ziel-Domain dienen soll.</li>
<li><strong>Abweichende Ziel-Domain</strong><br>Über diese Einstellung kannst du die Domain definieren, an die die Weiterleitung durchgeführt werden soll. Grundlegende Informationen hierzu findest du in der Beschreibung des Feldes <code>An abweichende Domain weiterleiten</code></li>
</ul>
<a name="ziel-ressource-kategorie"></a>
<h3>Ziel-Ressource: Kategorie</h3>
<p><a data-dreisccmslightbox="images-121614" data-title="Ziel-Ressource: Kategorie" href="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_kategorie.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/110-create/lightbox/ziel-ressource_kategorie.png" alt="Ziel-Ressource: Kategorie">
                        </a></p>
<ul>
<li><strong>Kategorie</strong><br>An dieser Stelle musst du die Kategorie auswählen, die als Ziel der Weiterleitung genutzt werden soll.</li>
<li><strong>An abweichende Domain weiterleiten</strong><br>Standardmäßig wird bei der Weiterleitung auf eine Kategorie die Domain der Weiterleitungsquelle beibehalten. Ist die jeweilige Kategorie unter der Domain nicht erreichbar, so findet auch keine Weiterleitung statt. Wird die Option <code>An abweichende Domain weiterleiten</code> aktiviert, so kann das Standardverhalten angepasst werden, indem eine feste Domain ausgewählt werden kann, die als Ziel-Domain dienen soll.</li>
<li><strong>Abweichende Ziel-Domain</strong><br>Über diese Einstellung kannst du die Domain definieren, an die die Weiterleitung durchgeführt werden soll. Grundlegende Informationen hierzu findest du in der Beschreibung des Feldes <code>An abweichende Domain weiterleiten</code></li>
</ul>
<a name="einschraenkungen"></a>
<h2>Einschränkungen</h2>
<a name="url-muss-den-shopware-kernel-aufrufen"></a>
<h3>URL muss den Shopware Kernel aufrufen</h3>
<p>Eine Weiterleitung per SEO Professional kann nur dann aktiv werden, wenn beim Aufruf der jeweiligen URL auch der Shopware Kernel aufgerufen wird. Wird in der Serverkonfiguration bspw. definiert das URLs mit bestimmten Dateiendungen zu einer serverseitigen &quot;Not Found&quot; Seite führen, wenn diese nicht vorhanden sind, so kann hier auch keine Weiterleitung greifen. In diesem Fall müsste also sichergestellt werden, dass die Aufrufe auf die Shopware Instanz weitergeleitet werden.</p>
<a name="die-startseite-der-shops-kann-aktuell-nicht-weiterleitet-werden"></a>
<h3>Die Startseite der Shops kann aktuell nicht weiterleitet werden</h3>
<p>Wählt man als Weiterleitungsquelle die Root-Kategorie des jeweiligen Shops so findet in der aktuellen Versions des Plugins keine Weiterleitung der jeweiligen Startseite statt.</p>
<p></p>',
  ),
);