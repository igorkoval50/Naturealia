<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/200-redirect/120-redirect-widget',
    'parent' => 'de_300-modules/200-redirect',
    'seoUrl' => 'docs/seo-professional/modules/redirect/redirect-widget',
    'title' => 'Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen',
    'menuTitle' => 'Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen</h1>
<p>In dem SEO-Tab der Produkte sowie der Kategorien findest du jeweils ein Widget für die Darstellung der Informationen bestehender Weiterleitung bzw. zur Erstellung von Weiterleitungen für das jeweilige Produkt / Kategorie.</p>
<p>Eine Beschreibung dieser Widgets findest du unter:<br>
<a href="docs/seo-professional/seo-settings/redirect-widget">SEO Professional » SEO Einstellungen » Weiterleitungs-Widget</a></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/200-redirect/120-redirect-widget',
    'parent' => 'en_300-modules/200-redirect',
    'seoUrl' => 'docs/seo-professional/modules/redirect/redirect-widget',
    'title' => 'Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen',
    'menuTitle' => 'Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen</h1>
<p>In dem SEO-Tab der Produkte sowie der Kategorien findest du jeweils ein Widget für die Darstellung der Informationen bestehender Weiterleitung bzw. zur Erstellung von Weiterleitungen für das jeweilige Produkt / Kategorie.</p>
<p>Eine Beschreibung dieser Widgets findest du unter:<br>
<a href="docs/seo-professional/seo-settings/redirect-widget">SEO Professional » SEO Einstellungen » Weiterleitungs-Widget</a></p>',
  ),
);