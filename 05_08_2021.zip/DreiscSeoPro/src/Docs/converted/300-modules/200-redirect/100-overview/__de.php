<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/200-redirect/100-overview',
    'parent' => 'de_300-modules/200-redirect',
    'seoUrl' => 'docs/seo-professional/modules/redirect/overview',
    'title' => 'Übersicht der Weiterleitungen',
    'menuTitle' => 'Übersicht der Weiterleitungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Übersicht der Weiterleitungen</h1>
<p>Unter <code>SEO Professional » 301 und 302 URL Weiterleitungen</code> erhältst Du eine Auflistung deiner angelegten Weiterleitungen mit den wichtigsten Informationen. Über einen Klick in den jeweiligen Spaltentitel kannst Du die Sortierung der Weiterleitungen ändern. Neben den einzelnen Spaltenbezeichnungen findest Du einen Button, über den du die Spalte ausblenden kannst. Über das allgemeine Suchfeld in der Administration können die angezeigten Weiterleitungen entsprechend eingegrenzt werden.</p>
<p><a data-dreisccmslightbox="images-855346" data-title="Übersicht der Weiterleitungen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/100-overview/lightbox/overview.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/100-overview/lightbox/overview.png" alt="Übersicht der Weiterleitungen">
                        </a></p>
<p>In der Übersicht kannst Du auf einen Blick die wichtigsten Informationen zu deinen Weiterleitungen entnehmen.
Im Standard ist die Übersicht wie folgt aufgebaut:</p>
<ul>
<li><strong>Aktiv</strong><br>Zeigt an, ob eine Weiterleitung aktiv ist.</li>
<li><strong>Quelle</strong><br>Kurze Beschreibung, was weitergeleitet wird. Handelt es sich nicht um eine URL, sondern bspw. um ein Produkt das weitergeleitet wird, so wird dies in eckigen Klammern davor angezeigt.</li>
<li><strong>Ziel</strong><br>Definiert das Ziel der Weiterleitung. Hierbei kommt die gleiche Syntax wie bei der Quelle zum Einsatz.</li>
<li><strong>HTTP Status Code</strong><br>Zeigt, ob es sich um eine temporäre oder dauerhafte Weiterleitung handelt.
</li>
</ul>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/200-redirect/100-overview',
    'parent' => 'en_300-modules/200-redirect',
    'seoUrl' => 'docs/seo-professional/modules/redirect/overview',
    'title' => 'Übersicht der Weiterleitungen',
    'menuTitle' => 'Übersicht der Weiterleitungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Übersicht der Weiterleitungen</h1>
<p>Unter <code>SEO Professional » 301 und 302 URL Weiterleitungen</code> erhältst Du eine Auflistung deiner angelegten Weiterleitungen mit den wichtigsten Informationen. Über einen Klick in den jeweiligen Spaltentitel kannst Du die Sortierung der Weiterleitungen ändern. Neben den einzelnen Spaltenbezeichnungen findest Du einen Button, über den du die Spalte ausblenden kannst. Über das allgemeine Suchfeld in der Administration können die angezeigten Weiterleitungen entsprechend eingegrenzt werden.</p>
<p><a data-dreisccmslightbox="images-67016" data-title="Übersicht der Weiterleitungen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/100-overview/lightbox/overview.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/100-overview/lightbox/overview.png" alt="Übersicht der Weiterleitungen">
                        </a></p>
<p>In der Übersicht kannst Du auf einen Blick die wichtigsten Informationen zu deinen Weiterleitungen entnehmen.
Im Standard ist die Übersicht wie folgt aufgebaut:</p>
<ul>
<li><strong>Aktiv</strong><br>Zeigt an, ob eine Weiterleitung aktiv ist.</li>
<li><strong>Quelle</strong><br>Kurze Beschreibung, was weitergeleitet wird. Handelt es sich nicht um eine URL, sondern bspw. um ein Produkt das weitergeleitet wird, so wird dies in eckigen Klammern davor angezeigt.</li>
<li><strong>Ziel</strong><br>Definiert das Ziel der Weiterleitung. Hierbei kommt die gleiche Syntax wie bei der Quelle zum Einsatz.</li>
<li><strong>HTTP Status Code</strong><br>Zeigt, ob es sich um eine temporäre oder dauerhafte Weiterleitung handelt.
</li>
</ul>',
  ),
);