<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/200-redirect/130-redirect-import-export',
    'parent' => 'de_300-modules/200-redirect',
    'seoUrl' => 'docs/seo-professional/modules/redirect/redirect-import-export',
    'title' => 'CSV Import und Export der Weiterleitungen',
    'menuTitle' => 'CSV Import und Export der Weiterleitungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>CSV Import und Export der Weiterleitungen</h1>
<p>Neben der manuellen Erfassungen der Weiterleitungen über die Adminstration, können die Weiterleitungen auch per CSV Datei importiert bzw. exportiert werden.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#vorbereitung">Vorbereitung</a></li><li class="headline-level2"><a href="#import">Import</a></li><li class="headline-level3"><a href="#einleitung">Einleitung</a></li><li class="headline-level3"><a href="#spaltenaufbau-der-csv">Spaltenaufbau der CSV</a></li><li class="headline-level4"><a href="#grundsaetzlicher-aufbau">Grundsätzlicher Aufbau</a></li><li class="headline-level4"><a href="#allgemeine-konfiguration">Allgemeine Konfiguration</a></li><li class="headline-level4"><a href="#weiterleitungsquelle">Weiterleitungsquelle</a></li><li class="headline-level4"><a href="#weiterleitungsziel">Weiterleitungsziel</a></li><li class="headline-level4"><a href="#spezielfelder">Spezielfelder</a></li><li class="headline-level3"><a href="#log">Log</a></li><li class="headline-level2"><a href="#export">Export</a></li><li class="headline-level3"><a href="#export-durchfuehren">Export durchführen</a></li><li class="headline-level2"><a href="#csv-beispiele-fuer-den-import">CSV-Beispiele für den Import</a></li><li class="headline-level3"><a href="#von-produktnummer-zu-produktnummer">Von Produktnummer zu Produktnummer</a></li><li class="headline-level3"><a href="#von-interner-url-zu-produktnummer">Von interner URL zu Produktnummer</a></li><li class="headline-level3"><a href="#von-interner-url-zu-produktnummer-bzw-kategorie">Von interner URL zu Produktnummer bzw Kategorie</a></li><li class="headline-level3"><a href="#von-interner-url-zu-produktnummer-bzw-kategorie-mit-aktiv-spalte">Von interner URL zu Produktnummer bzw Kategorie (mit Aktiv-Spalte)</a></li><li class="headline-level3"><a href="#von-produktnummer-zu-produktnummer-beschraenkt-auf-domains">Von Produktnummer zu Produktnummer (beschränkt auf Domains)</a></li><li class="headline-level3"><a href="#von-produktnummer-zu-produktnummer-auf-abweichende-domain-weiterleiten">Von Produktnummer zu Produktnummer (auf abweichende Domain weiterleiten)</a></li></ul></div></p>
<a name="vorbereitung"></a>
<h2>Vorbereitung</h2>
<p>Um einen Im- bzw. einen Export durchzuführen, muss zunächst das Modul geöffnet werden. Wechsel hierzu zur Liste der bestehenden Weiterleitungen unter <code>SEO Professional » 301 und 302 Weiterleitungen</code> und klicke hier auf die Schaltfläche <code>CSV Import / Export</code>.</p>
<p><a data-dreisccmslightbox="images-552143" data-title="CSV Import / Export öffnen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/redirect-weiterleitungs-dialog-oeffnen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/redirect-weiterleitungs-dialog-oeffnen.png" alt="CSV Import / Export öffnen">
                        </a></p>
<a name="import"></a>
<h2>Import</h2>
<a name="einleitung"></a>
<h3>Einleitung</h3>
<p>Für den Import müssen zwei Felder definiert werden. Zum einen die <code>eigentliche CSV Datei</code> zum anderen das <code>Spalten-Trennzeichen</code>, dass zum Auslesen der CSV Datei verwendet werden soll.</p>
<p>Eine CSV Import-Datei muss mindestens eine Weiterleitungsquelle sowie eine Weiterleitungsziel aufweisen. Spalten wie <code>Aktiv</code> oder <code>HTTP Status Code</code> hingegen sind optional, da hierfür Standardwerte vorliegen. Es können in einer CSV Datei auch mehrere Spalten für verschiedene Weiterleitungsquellen bzw. -ziele definiert werden. Es muss hierbei dann jedoch darauf geachtet werden, dass pro Zeile nur eine Quelle sowie Ziel definiert ist.</p>
<p>Das Spalten-Trennzeichen ist standardmäßig ein Semikolon, kann aber auch entsprechend abweichen. </p>
<p><a data-dreisccmslightbox="images-552143" data-title="Import von Weiterleitungen als CSV" href="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/import.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/import.png" alt="Import von Weiterleitungen als CSV">
                        </a></p>
<a name="spaltenaufbau-der-csv"></a>
<h3>Spaltenaufbau der CSV</h3>
<a name="grundsaetzlicher-aufbau"></a>
<h4>Grundsätzlicher Aufbau</h4>
<p>Die erste Zeile der CSV Datei muss eine Überschriftszeile sein, in der die unten definierten Spaltenbezeichnungen als Überschrift hinterlegt werden. Ab Zeile 2 folgen dann die eigentlichen Weiterleitungen.</p>
<a name="allgemeine-konfiguration"></a>
<h4>Allgemeine Konfiguration</h4>
<p>Bei den folgenden Spalten handelt es sich um die allgemeine Konfigurationen, die in der Import CSV Datei optional angegeben werden können:</p>
<table>
<thead>
<tr>
<th>Spalte</th>
<th>Beschreibung</th>
<th>Mögliche Werte</th>
<th>Pflichtfeld</th>
<th>Standardwert</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>active</strong></td>
<td>Über diese Spalte kann definiert werden, ob eine Weiterleitung nach dem Import direkt aktiv sein soll oder nicht.</td>
<td>1=Aktiv oder 2=Inaktiv</td>
<td>Nein</td>
<td>1</td>
</tr>
<tr>
<td><strong>httpStatusCode</strong></td>
<td>Diese Spalte gibt an, über welchen HTTP Status Code die Weiterleitung erfolgen soll.</td>
<td>301 oder 302</td>
<td>Nein</td>
<td>301</td>
</tr>
</tbody>
</table>
<a name="weiterleitungsquelle"></a>
<h4>Weiterleitungsquelle</h4>
<p>Wie bereits in der Einleitung beschrieben, muss mindestens eine Spalte für eine Weiterleitungsquelle in der CSV vorliegen. Deine CSV Datei muss also mindestens eine der folgenden Spalten aufweisen:</p>
<table>
<thead>
<tr>
<th>Spalte</th>
<th>Beschreibung</th>
<th>Beispielwert</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>sourceProductNumber</strong></td>
<td>Soll eine Weiterleitung für ein Produkt angelegt werden, so kann über diese Spalte die Produktnummer von dem Produkt hinterlegt werden, für das du eine Weiterleitung einrichten möchtest</td>
<td>SW-1000</td>
</tr>
<tr>
<td><strong>sourceInternalUrl</strong></td>
<td>Über diese Spalte kann eine interne URL weitergeleitet werden. Hierbei ist wichtig, dass in dieser Ziele die absolute URL angegeben wird. Der Importer teilt diese dann in Sales Channel Domain sowie die eigentliche interne URL auf</td>
<td><a href="http://www.shop.de/mein-redirect">http://www.shop.de/mein-redirect</a></td>
</tr>
<tr>
<td><strong>sourceCategoryId</strong></td>
<td>Möchtest du eine Kategorie weiterleiten, so musst du diese Spalte nutzen. Als Wert wird hierbei die ID der Kategorie hinterlegt. Hierbei handelt es sich um das Datenbankfeld <code>category.id</code></td>
<td>c542db9e9d964fe29a15061440a68730</td>
</tr>
<tr>
<td><strong>sourceProductId</strong></td>
<td>Bei dieser Spalte handelt es sich um eine Alternative zu der Spalte <code>sourceProductNumber</code>. Statt der Produktnummer gibst du hier die ID des Produkts an. (Datenbankfeld: product.id)</td>
<td>fe13aa4b47264e049b9bf84bd5e2a38a</td>
</tr>
</tbody>
</table>
<a name="weiterleitungsziel"></a>
<h4>Weiterleitungsziel</h4>
<p>Neben mindestens einer Weiterleitungsquelle, muss deine CSV Datei auch mindestens eine der folgenden Spalten als Weiterleitungsziel aufweisen:</p>
<table>
<thead>
<tr>
<th>Spalte</th>
<th>Beschreibung</th>
<th>Beispielwert</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>targetProductNumber</strong></td>
<td>Möchtest du eine Weiterleitung zu einem Produkt erstellen, so kannst du diese Spalte nutzen. Als Wert gibst du hier die Produktnummer des Ziels an.</td>
<td>SW-1006.1</td>
</tr>
<tr>
<td><strong>targetInternalUrl</strong></td>
<td>Über diese Spalte kannst du eine interne URL angeben, an die weitergeleitet werden soll. Hierbei ist wichtig, dass in dieser Ziele die absolute URL angegeben wird. Der Importer teilt diese dann in Sales Channel Domain sowie die eigentliche interne URL auf</td>
<td><a href="https://www.shop.de/ziel-url">https://www.shop.de/ziel-url</a></td>
</tr>
<tr>
<td><strong>targetCategoryId</strong></td>
<td>Für eine Weiterleitung auf eine Kategorie musst du diese Spalte nutzen. Als Wert wird hierbei die ID der Kategorie hinterlegt. Hierbei handelt es sich um das Datenbankfeld <code>category.id</code></td>
<td>c542db9e9d964fe29a15061440a68730</td>
</tr>
<tr>
<td><strong>targetProductId</strong></td>
<td>Wie bei der Weiterleitungsquelle handelt es sich bei dieser Spalte um eine Alternative zur Eingabe der Produktnummer. Bei dieser Spalte muss die ID des Produkts hinterlegt werden, auf das weitergeleitet werden soll.</td>
<td>fe13aa4b47264e049b9bf84bd5e2a38a</td>
</tr>
<tr>
<td><strong>targetExternalUrl</strong></td>
<td>Soll eine Weiterleitung auf eine externe Seite durchgeführt werden, so kannst du dies über diese Spalte realisieren.</td>
<td><a href="https://de.dreischild.de">https://de.dreischild.de</a></td>
</tr>
</tbody>
</table>
<a name="spezielfelder"></a>
<h4>Spezielfelder</h4>
<table>
<thead>
<tr>
<th>Spalte</th>
<th>Beschreibung</th>
<th>Beispielwert</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>sourceRestrictionDomains</strong></td>
<td>Über diese Spalte hast du die Möglichkeit Weiterleitungen auf bestimmte Sales Channel Domains zu begrenzen. Möchtest du hier mehr als eine Domain hinterlegen, so verwende eine Pipe (|) als Trennzeichen</td>
<td><a href="https://www.shop.de\\|https://www.shop.fr">https://www.shop.de\\|https://www.shop.fr</a></td>
</tr>
<tr>
<td><strong>targetDeviatingDomain</strong></td>
<td>Über diese Spalte hast du die Möglichkeit eine abweichende Domain für Weiterleitung zu definieren.</td>
<td><a href="http://www.shop.de">http://www.shop.de</a></td>
</tr>
</tbody>
</table>
<a name="log"></a>
<h3>Log</h3>
<p>Nachdem der Import durchgeführt wurde, findest du unterhalb des Uploadfeldes das Log des letzten Imports. Hierbei kannst du bei erfolgreich importierten Zeilen über <code>Konfiguration in neuem Tab öffnen</code> die erstellte Weiterleitung öffnen oder aber über <code>Fehlermeldung anzeigen</code> dir detailierte Informationen anzeigen, warum ein Import fehlgeschlagen ist.</p>
<p><a data-dreisccmslightbox="images-552143" data-title="Log des Imports" href="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/import-log.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/import-log.png" alt="Log des Imports">
                        </a></p>
<a name="export"></a>
<h2>Export</h2>
<p>Die CSV Exporte der Weiterleitungen haben den selben Aufbau wie die CSV Datei für den Import. Somit können exportierte Weiterleitungen über das Modul wieder importiert werden.</p>
<a name="export-durchfuehren"></a>
<h3>Export durchführen</h3>
<p>Zum erstellen eines Exports musst du zunächst auf den Tabreiter <code>Export</code> klicken. Anschließend kann die Erstellung der CSV Datei über <code>Export starten</code> gestartet werden. Ist dieser Prozess abgeschlossen, so wird die Schaltfläche <code>CSV Datei herunterladen</code> bereitgestellt, über die die CSV Datei bezogen werden kann.
<a data-dreisccmslightbox="images-552143" data-title="Export" href="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/export.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/export.png" alt="Export">
                        </a></p>
<a name="csv-beispiele-fuer-den-import"></a>
<h2>CSV-Beispiele für den Import</h2>
<a name="von-produktnummer-zu-produktnummer"></a>
<h3>Von Produktnummer zu Produktnummer</h3>
<pre><code class="language-csv">sourceProductNumber;    targetProductNumber
SW-1000;                SW-1006
SW-1004;                SW-1005</code></pre>
<a name="von-interner-url-zu-produktnummer"></a>
<h3>Von interner URL zu Produktnummer</h3>
<pre><code class="language-csv">sourceInternalUrl;                  targetProductNumber
http://www.shopware-dev.de/r-1006;  SW-1006
http://www.shopware-dev.de/r-1005;  SW-1005</code></pre>
<a name="von-interner-url-zu-produktnummer-bzw-kategorie"></a>
<h3>Von interner URL zu Produktnummer bzw Kategorie</h3>
<pre><code class="language-csv">sourceInternalUrl;                  targetProductNumber;    targetCategoryId
http://www.shopware-dev.de/r-1006;  SW-1006;
http://www.shopware-dev.de/r-1005;  ;                       c542db9e9d964fe29a15061440a68730</code></pre>
<a name="von-interner-url-zu-produktnummer-bzw-kategorie-mit-aktiv-spalte"></a>
<h3>Von interner URL zu Produktnummer bzw Kategorie (mit Aktiv-Spalte)</h3>
<pre><code class="language-csv">active; sourceInternalUrl;                  targetProductNumber;    targetCategoryId
1;      http://www.shopware-dev.de/r-1006;  SW-1006;
0;      http://www.shopware-dev.de/r-1005;  ;                       c542db9e9d964fe29a15061440a68730</code></pre>
<a name="von-produktnummer-zu-produktnummer-beschraenkt-auf-domains"></a>
<h3>Von Produktnummer zu Produktnummer (beschränkt auf Domains)</h3>
<pre><code class="language-csv">sourceProductNumber;    targetProductNumber;    sourceRestrictionDomains
SW-1000;                SW-1006;                http://www.shopware-dev.de|http://www.shopware-dev.de/en
SW-1004;                SW-1005;
SW-1001;                SW-1005;                http://www.shopware-dev.de</code></pre>
<a name="von-produktnummer-zu-produktnummer-auf-abweichende-domain-weiterleiten"></a>
<h3>Von Produktnummer zu Produktnummer (auf abweichende Domain weiterleiten)</h3>
<pre><code class="language-csv">sourceProductNumber;    targetProductNumber;    targetDeviatingDomain
SW-1000;                SW-1006;                http://www.shopware-dev.de/en
SW-1001;                SW-1005;                http://www.shopware-dev.de/en</code></pre>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/200-redirect/130-redirect-import-export',
    'parent' => 'en_300-modules/200-redirect',
    'seoUrl' => 'docs/seo-professional/modules/redirect/redirect-import-export',
    'title' => 'CSV Import und Export der Weiterleitungen',
    'menuTitle' => 'CSV Import und Export der Weiterleitungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>CSV Import und Export der Weiterleitungen</h1>
<p>Neben der manuellen Erfassungen der Weiterleitungen über die Adminstration, können die Weiterleitungen auch per CSV Datei importiert bzw. exportiert werden.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#vorbereitung">Vorbereitung</a></li><li class="headline-level2"><a href="#import">Import</a></li><li class="headline-level3"><a href="#einleitung">Einleitung</a></li><li class="headline-level3"><a href="#spaltenaufbau-der-csv">Spaltenaufbau der CSV</a></li><li class="headline-level4"><a href="#grundsaetzlicher-aufbau">Grundsätzlicher Aufbau</a></li><li class="headline-level4"><a href="#allgemeine-konfiguration">Allgemeine Konfiguration</a></li><li class="headline-level4"><a href="#weiterleitungsquelle">Weiterleitungsquelle</a></li><li class="headline-level4"><a href="#weiterleitungsziel">Weiterleitungsziel</a></li><li class="headline-level4"><a href="#spezielfelder">Spezielfelder</a></li><li class="headline-level3"><a href="#log">Log</a></li><li class="headline-level2"><a href="#export">Export</a></li><li class="headline-level3"><a href="#export-durchfuehren">Export durchführen</a></li><li class="headline-level2"><a href="#csv-beispiele-fuer-den-import">CSV-Beispiele für den Import</a></li><li class="headline-level3"><a href="#von-produktnummer-zu-produktnummer">Von Produktnummer zu Produktnummer</a></li><li class="headline-level3"><a href="#von-interner-url-zu-produktnummer">Von interner URL zu Produktnummer</a></li><li class="headline-level3"><a href="#von-interner-url-zu-produktnummer-bzw-kategorie">Von interner URL zu Produktnummer bzw Kategorie</a></li><li class="headline-level3"><a href="#von-interner-url-zu-produktnummer-bzw-kategorie-mit-aktiv-spalte">Von interner URL zu Produktnummer bzw Kategorie (mit Aktiv-Spalte)</a></li><li class="headline-level3"><a href="#von-produktnummer-zu-produktnummer-beschraenkt-auf-domains">Von Produktnummer zu Produktnummer (beschränkt auf Domains)</a></li><li class="headline-level3"><a href="#von-produktnummer-zu-produktnummer-auf-abweichende-domain-weiterleiten">Von Produktnummer zu Produktnummer (auf abweichende Domain weiterleiten)</a></li></ul></div></p>
<a name="vorbereitung"></a>
<h2>Vorbereitung</h2>
<p>Um einen Im- bzw. einen Export durchzuführen, muss zunächst das Modul geöffnet werden. Wechsel hierzu zur Liste der bestehenden Weiterleitungen unter <code>SEO Professional » 301 und 302 Weiterleitungen</code> und klicke hier auf die Schaltfläche <code>CSV Import / Export</code>.</p>
<p><a data-dreisccmslightbox="images-333613" data-title="CSV Import / Export öffnen" href="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/redirect-weiterleitungs-dialog-oeffnen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/redirect-weiterleitungs-dialog-oeffnen.png" alt="CSV Import / Export öffnen">
                        </a></p>
<a name="import"></a>
<h2>Import</h2>
<a name="einleitung"></a>
<h3>Einleitung</h3>
<p>Für den Import müssen zwei Felder definiert werden. Zum einen die <code>eigentliche CSV Datei</code> zum anderen das <code>Spalten-Trennzeichen</code>, dass zum Auslesen der CSV Datei verwendet werden soll.</p>
<p>Eine CSV Import-Datei muss mindestens eine Weiterleitungsquelle sowie eine Weiterleitungsziel aufweisen. Spalten wie <code>Aktiv</code> oder <code>HTTP Status Code</code> hingegen sind optional, da hierfür Standardwerte vorliegen. Es können in einer CSV Datei auch mehrere Spalten für verschiedene Weiterleitungsquellen bzw. -ziele definiert werden. Es muss hierbei dann jedoch darauf geachtet werden, dass pro Zeile nur eine Quelle sowie Ziel definiert ist.</p>
<p>Das Spalten-Trennzeichen ist standardmäßig ein Semikolon, kann aber auch entsprechend abweichen. </p>
<p><a data-dreisccmslightbox="images-333613" data-title="Import von Weiterleitungen als CSV" href="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/import.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/import.png" alt="Import von Weiterleitungen als CSV">
                        </a></p>
<a name="spaltenaufbau-der-csv"></a>
<h3>Spaltenaufbau der CSV</h3>
<a name="grundsaetzlicher-aufbau"></a>
<h4>Grundsätzlicher Aufbau</h4>
<p>Die erste Zeile der CSV Datei muss eine Überschriftszeile sein, in der die unten definierten Spaltenbezeichnungen als Überschrift hinterlegt werden. Ab Zeile 2 folgen dann die eigentlichen Weiterleitungen.</p>
<a name="allgemeine-konfiguration"></a>
<h4>Allgemeine Konfiguration</h4>
<p>Bei den folgenden Spalten handelt es sich um die allgemeine Konfigurationen, die in der Import CSV Datei optional angegeben werden können:</p>
<table>
<thead>
<tr>
<th>Spalte</th>
<th>Beschreibung</th>
<th>Mögliche Werte</th>
<th>Pflichtfeld</th>
<th>Standardwert</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>active</strong></td>
<td>Über diese Spalte kann definiert werden, ob eine Weiterleitung nach dem Import direkt aktiv sein soll oder nicht.</td>
<td>1=Aktiv oder 2=Inaktiv</td>
<td>Nein</td>
<td>1</td>
</tr>
<tr>
<td><strong>httpStatusCode</strong></td>
<td>Diese Spalte gibt an, über welchen HTTP Status Code die Weiterleitung erfolgen soll.</td>
<td>301 oder 302</td>
<td>Nein</td>
<td>301</td>
</tr>
</tbody>
</table>
<a name="weiterleitungsquelle"></a>
<h4>Weiterleitungsquelle</h4>
<p>Wie bereits in der Einleitung beschrieben, muss mindestens eine Spalte für eine Weiterleitungsquelle in der CSV vorliegen. Deine CSV Datei muss also mindestens eine der folgenden Spalten aufweisen:</p>
<table>
<thead>
<tr>
<th>Spalte</th>
<th>Beschreibung</th>
<th>Beispielwert</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>sourceProductNumber</strong></td>
<td>Soll eine Weiterleitung für ein Produkt angelegt werden, so kann über diese Spalte die Produktnummer von dem Produkt hinterlegt werden, für das du eine Weiterleitung einrichten möchtest</td>
<td>SW-1000</td>
</tr>
<tr>
<td><strong>sourceInternalUrl</strong></td>
<td>Über diese Spalte kann eine interne URL weitergeleitet werden. Hierbei ist wichtig, dass in dieser Ziele die absolute URL angegeben wird. Der Importer teilt diese dann in Sales Channel Domain sowie die eigentliche interne URL auf</td>
<td><a href="http://www.shop.de/mein-redirect">http://www.shop.de/mein-redirect</a></td>
</tr>
<tr>
<td><strong>sourceCategoryId</strong></td>
<td>Möchtest du eine Kategorie weiterleiten, so musst du diese Spalte nutzen. Als Wert wird hierbei die ID der Kategorie hinterlegt. Hierbei handelt es sich um das Datenbankfeld <code>category.id</code></td>
<td>c542db9e9d964fe29a15061440a68730</td>
</tr>
<tr>
<td><strong>sourceProductId</strong></td>
<td>Bei dieser Spalte handelt es sich um eine Alternative zu der Spalte <code>sourceProductNumber</code>. Statt der Produktnummer gibst du hier die ID des Produkts an. (Datenbankfeld: product.id)</td>
<td>fe13aa4b47264e049b9bf84bd5e2a38a</td>
</tr>
</tbody>
</table>
<a name="weiterleitungsziel"></a>
<h4>Weiterleitungsziel</h4>
<p>Neben mindestens einer Weiterleitungsquelle, muss deine CSV Datei auch mindestens eine der folgenden Spalten als Weiterleitungsziel aufweisen:</p>
<table>
<thead>
<tr>
<th>Spalte</th>
<th>Beschreibung</th>
<th>Beispielwert</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>targetProductNumber</strong></td>
<td>Möchtest du eine Weiterleitung zu einem Produkt erstellen, so kannst du diese Spalte nutzen. Als Wert gibst du hier die Produktnummer des Ziels an.</td>
<td>SW-1006.1</td>
</tr>
<tr>
<td><strong>targetInternalUrl</strong></td>
<td>Über diese Spalte kannst du eine interne URL angeben, an die weitergeleitet werden soll. Hierbei ist wichtig, dass in dieser Ziele die absolute URL angegeben wird. Der Importer teilt diese dann in Sales Channel Domain sowie die eigentliche interne URL auf</td>
<td><a href="https://www.shop.de/ziel-url">https://www.shop.de/ziel-url</a></td>
</tr>
<tr>
<td><strong>targetCategoryId</strong></td>
<td>Für eine Weiterleitung auf eine Kategorie musst du diese Spalte nutzen. Als Wert wird hierbei die ID der Kategorie hinterlegt. Hierbei handelt es sich um das Datenbankfeld <code>category.id</code></td>
<td>c542db9e9d964fe29a15061440a68730</td>
</tr>
<tr>
<td><strong>targetProductId</strong></td>
<td>Wie bei der Weiterleitungsquelle handelt es sich bei dieser Spalte um eine Alternative zur Eingabe der Produktnummer. Bei dieser Spalte muss die ID des Produkts hinterlegt werden, auf das weitergeleitet werden soll.</td>
<td>fe13aa4b47264e049b9bf84bd5e2a38a</td>
</tr>
<tr>
<td><strong>targetExternalUrl</strong></td>
<td>Soll eine Weiterleitung auf eine externe Seite durchgeführt werden, so kannst du dies über diese Spalte realisieren.</td>
<td><a href="https://de.dreischild.de">https://de.dreischild.de</a></td>
</tr>
</tbody>
</table>
<a name="spezielfelder"></a>
<h4>Spezielfelder</h4>
<table>
<thead>
<tr>
<th>Spalte</th>
<th>Beschreibung</th>
<th>Beispielwert</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>sourceRestrictionDomains</strong></td>
<td>Über diese Spalte hast du die Möglichkeit Weiterleitungen auf bestimmte Sales Channel Domains zu begrenzen. Möchtest du hier mehr als eine Domain hinterlegen, so verwende eine Pipe (|) als Trennzeichen</td>
<td><a href="https://www.shop.de\\|https://www.shop.fr">https://www.shop.de\\|https://www.shop.fr</a></td>
</tr>
<tr>
<td><strong>targetDeviatingDomain</strong></td>
<td>Über diese Spalte hast du die Möglichkeit eine abweichende Domain für Weiterleitung zu definieren.</td>
<td><a href="http://www.shop.de">http://www.shop.de</a></td>
</tr>
</tbody>
</table>
<a name="log"></a>
<h3>Log</h3>
<p>Nachdem der Import durchgeführt wurde, findest du unterhalb des Uploadfeldes das Log des letzten Imports. Hierbei kannst du bei erfolgreich importierten Zeilen über <code>Konfiguration in neuem Tab öffnen</code> die erstellte Weiterleitung öffnen oder aber über <code>Fehlermeldung anzeigen</code> dir detailierte Informationen anzeigen, warum ein Import fehlgeschlagen ist.</p>
<p><a data-dreisccmslightbox="images-333613" data-title="Log des Imports" href="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/import-log.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/import-log.png" alt="Log des Imports">
                        </a></p>
<a name="export"></a>
<h2>Export</h2>
<p>Die CSV Exporte der Weiterleitungen haben den selben Aufbau wie die CSV Datei für den Import. Somit können exportierte Weiterleitungen über das Modul wieder importiert werden.</p>
<a name="export-durchfuehren"></a>
<h3>Export durchführen</h3>
<p>Zum erstellen eines Exports musst du zunächst auf den Tabreiter <code>Export</code> klicken. Anschließend kann die Erstellung der CSV Datei über <code>Export starten</code> gestartet werden. Ist dieser Prozess abgeschlossen, so wird die Schaltfläche <code>CSV Datei herunterladen</code> bereitgestellt, über die die CSV Datei bezogen werden kann.
<a data-dreisccmslightbox="images-333613" data-title="Export" href="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/export.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/200-redirect/130-redirect-import-export/lightbox/export.png" alt="Export">
                        </a></p>
<a name="csv-beispiele-fuer-den-import"></a>
<h2>CSV-Beispiele für den Import</h2>
<a name="von-produktnummer-zu-produktnummer"></a>
<h3>Von Produktnummer zu Produktnummer</h3>
<pre><code class="language-csv">sourceProductNumber;    targetProductNumber
SW-1000;                SW-1006
SW-1004;                SW-1005</code></pre>
<a name="von-interner-url-zu-produktnummer"></a>
<h3>Von interner URL zu Produktnummer</h3>
<pre><code class="language-csv">sourceInternalUrl;                  targetProductNumber
http://www.shopware-dev.de/r-1006;  SW-1006
http://www.shopware-dev.de/r-1005;  SW-1005</code></pre>
<a name="von-interner-url-zu-produktnummer-bzw-kategorie"></a>
<h3>Von interner URL zu Produktnummer bzw Kategorie</h3>
<pre><code class="language-csv">sourceInternalUrl;                  targetProductNumber;    targetCategoryId
http://www.shopware-dev.de/r-1006;  SW-1006;
http://www.shopware-dev.de/r-1005;  ;                       c542db9e9d964fe29a15061440a68730</code></pre>
<a name="von-interner-url-zu-produktnummer-bzw-kategorie-mit-aktiv-spalte"></a>
<h3>Von interner URL zu Produktnummer bzw Kategorie (mit Aktiv-Spalte)</h3>
<pre><code class="language-csv">active; sourceInternalUrl;                  targetProductNumber;    targetCategoryId
1;      http://www.shopware-dev.de/r-1006;  SW-1006;
0;      http://www.shopware-dev.de/r-1005;  ;                       c542db9e9d964fe29a15061440a68730</code></pre>
<a name="von-produktnummer-zu-produktnummer-beschraenkt-auf-domains"></a>
<h3>Von Produktnummer zu Produktnummer (beschränkt auf Domains)</h3>
<pre><code class="language-csv">sourceProductNumber;    targetProductNumber;    sourceRestrictionDomains
SW-1000;                SW-1006;                http://www.shopware-dev.de|http://www.shopware-dev.de/en
SW-1004;                SW-1005;
SW-1001;                SW-1005;                http://www.shopware-dev.de</code></pre>
<a name="von-produktnummer-zu-produktnummer-auf-abweichende-domain-weiterleiten"></a>
<h3>Von Produktnummer zu Produktnummer (auf abweichende Domain weiterleiten)</h3>
<pre><code class="language-csv">sourceProductNumber;    targetProductNumber;    targetDeviatingDomain
SW-1000;                SW-1006;                http://www.shopware-dev.de/en
SW-1001;                SW-1005;                http://www.shopware-dev.de/en</code></pre>',
  ),
);