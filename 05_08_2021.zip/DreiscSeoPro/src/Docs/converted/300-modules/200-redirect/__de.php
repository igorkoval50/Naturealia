<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/200-redirect',
    'parent' => 'de_300-modules',
    'seoUrl' => 'docs/seo-professional/modules/redirect',
    'title' => '301 und 302 URL Weiterleitungen',
    'menuTitle' => '301 und 302 URL Weiterleitungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>301 und 302 URL Weiterleitungen</h1>
<p>Über das SEO Professional Modul <strong>301 und 302 URL Weiterleitungen</strong> können über die Administration Url Weiterleitungen eingerichtet werden. Hierbei kann eine Url an eine andere Url, einen Artikel oder eine Kategorie weitergeleitet werden. Über den HTTP Status Code kann definiert werden, ob es sich um eine dauerhafte (301) oder temporäre (302) Weiterleitung handelt.</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect/overview" class="nav--link link--entry">Übersicht der Weiterleitungen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect/create" class="nav--link link--entry">Neue Weiterleitungen anlegen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect/redirect-widget" class="nav--link link--entry">Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect/redirect-import-export" class="nav--link link--entry">CSV Import und Export der Weiterleitungen</a></li></ul></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/200-redirect',
    'parent' => 'en_300-modules',
    'seoUrl' => 'docs/seo-professional/modules/redirect',
    'title' => '301 und 302 URL Weiterleitungen',
    'menuTitle' => '301 und 302 URL Weiterleitungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>301 und 302 URL Weiterleitungen</h1>
<p>Über das SEO Professional Modul <strong>301 und 302 URL Weiterleitungen</strong> können über die Administration Url Weiterleitungen eingerichtet werden. Hierbei kann eine Url an eine andere Url, einen Artikel oder eine Kategorie weitergeleitet werden. Über den HTTP Status Code kann definiert werden, ob es sich um eine dauerhafte (301) oder temporäre (302) Weiterleitung handelt.</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect/overview" class="nav--link link--entry">Übersicht der Weiterleitungen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect/create" class="nav--link link--entry">Neue Weiterleitungen anlegen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect/redirect-widget" class="nav--link link--entry">Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect/redirect-import-export" class="nav--link link--entry">CSV Import und Export der Weiterleitungen</a></li></ul></p>',
  ),
);