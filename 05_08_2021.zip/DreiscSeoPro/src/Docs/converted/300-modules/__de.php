<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional/modules',
    'title' => 'SEO Professional Module',
    'menuTitle' => 'Module',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SEO Professional Module</h1>
<p>In den hier aufgelisteten Unterkategorien findest du die Anleitungen zu den jeweiligen Modulen von SEO Professional.</p>
<p><h2 class="sub-headline">Unterkategorien</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators" class="nav--link link--entry">Produkt- und Kategorie Bulk Generator</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect" class="nav--link link--entry">301 und 302 URL Weiterleitungen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/rich-snippets-json-ld" class="nav--link link--entry">Rich Snippets (JSON-LD)</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/settings" class="nav--link link--entry">Weitere Einstellungen</a></li></ul></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional/modules',
    'title' => 'SEO Professional Module',
    'menuTitle' => 'Module',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SEO Professional Module</h1>
<p>In den hier aufgelisteten Unterkategorien findest du die Anleitungen zu den jeweiligen Modulen von SEO Professional.</p>
<p><h2 class="sub-headline">Unterkategorien</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/bulk-generators" class="nav--link link--entry">Produkt- und Kategorie Bulk Generator</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/redirect" class="nav--link link--entry">301 und 302 URL Weiterleitungen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/rich-snippets-json-ld" class="nav--link link--entry">Rich Snippets (JSON-LD)</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules/settings" class="nav--link link--entry">Weitere Einstellungen</a></li></ul></p>',
  ),
);