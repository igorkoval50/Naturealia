<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/900-settings/100-seo-settings',
    'parent' => 'de_300-modules/900-settings',
    'seoUrl' => 'docs/seo-professional/modules/settings/seo-settings',
    'title' => 'SEO Einstellungen',
    'menuTitle' => 'SEO Einstellungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SEO Einstellungen</h1>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#bulk-generatoren">Bulk Generatoren</a></li><li class="headline-level3"><a href="#bulk-generatoren-beim-speicherprozess-starten">Bulk Generatoren beim Speicherprozess starten</a></li><li class="headline-level2"><a href="#meta-tags">Meta-Tags</a></li><li class="headline-level3"><a href="#konfiguration-der-pixel--bzw-zeichenlaengen-der-meta-tags">Konfiguration der Pixel- bzw. Zeichenlängen der Meta Tags</a></li><li class="headline-level4"><a href="#verwendung-der-konfiguration">Verwendung der Konfiguration</a></li><li class="headline-level3"><a href="#robots-tag">Robots-Tag</a></li><li class="headline-level4"><a href="#standard-robots-tag">Standard Robots-Tag</a></li><li class="headline-level4"><a href="#noindex-request-parameter-query">Noindex Request Parameter Query</a></li><li class="headline-level2"><a href="#serp-vorschau">SERP Vorschau</a></li><li class="headline-level3"><a href="#verkaufskanal-vorauswahl">Verkaufskanal Vorauswahl</a></li><li class="headline-level2"><a href="#canonical-urls">Canonical Urls</a></li><li class="headline-level3"><a href="#verkaufskanal-vorauswahl">Verkaufskanal Vorauswahl</a></li><li class="headline-level2"><a href="#social-media">Social Media</a></li><li class="headline-level3"><a href="#konfiguration-der-zeichenlaengen">Konfiguration der Zeichenlängen</a></li><li class="headline-level4"><a href="#verwendung-der-konfiguration">Verwendung der Konfiguration</a></li></ul></div></p>
<a name="bulk-generatoren"></a>
<h2>Bulk Generatoren</h2>
<a name="bulk-generatoren-beim-speicherprozess-starten"></a>
<h3>Bulk Generatoren beim Speicherprozess starten</h3>
<p>Ist diese Option aktiv, so wird beim Speichern einer Kategorie bzw. eines Produkts automatisch der Bulk Generator für die jeweilige Entity gestartet. Es muss somit nicht extra der Bulk Generator gestartet werden, um die SEO Daten zu generieren.<br><br>Aus Performance-Gründen kann es unter Umständen Sinn machen diese Option zu deaktivieren, wenn bspw. eine große Menge an Daten per ERP abgeglichen wird.</p>
<a name="meta-tags"></a>
<h2>Meta-Tags</h2>
<a name="konfiguration-der-pixel--bzw-zeichenlaengen-der-meta-tags"></a>
<h3>Konfiguration der Pixel- bzw. Zeichenlängen der Meta Tags</h3>
<p>Für die Meta Tags <code>Meta Titel</code>, <code>Meta Beschreibung</code> sowie <code>Keywords</code> kannst du an dieser Stelle jeweils die folgenden Konfigurationen definieren:</p>
<ul>
<li>
<p><strong>Empfohlene Pixellänge von</strong> bzw. <strong>Empfohlene Zeichenlänge von</strong>:<br>Gibt die empfohlene Mindestanzahl der Pixel bzw. Zeichen an, die für die jeweilige Meta Angabe eingegeben werden sollte.</p>
</li>
<li>
<p><strong>bis</strong>:<br>Gibt die empfohlene Maximalanzahl der Pixel bzw. Zeichen an, die für die jeweilige Meta Angabe eingegeben werden sollte.</p>
</li>
<li>
<p><strong>Maximale Pixellänge</strong> bzw. <strong>Maximale Zeichenlänge</strong>:<br>Gibt die maximale Anzahl der Pixel bzw. Zeichen an, die für die jeweilige Meta Angabe eingegeben werden dürfen.</p>
</li>
</ul>
<a name="verwendung-der-konfiguration"></a>
<a name="verwendung-der-konfiguration"></a>
<h4>Verwendung der Konfiguration</h4>
<p>Die hier hinterlegte Konfiguration dient als Grundlage für andere Funktionen von SEO Professional. So wird bei Eingabe der Meta-Tags bspw. eine Zeichen- bzw. Pixellänge innerhalb des empfohlenen Bereichs <em>grün</em>, ein Wert zwischen dem bis- und Maximalwert <em>orange</em> und ein Wert über der maximalen Zeichen- bzw. Pixellänge <em>rot</em> dargestellt.</p>
<p>Weitere Informationen zu den Meta-Tags findest du unter:
<a href="docs/seo-professional/seo-settings/meta-tags">SEO Professional » SEO Einstellungen » Meta Tags</a></p>
<a name="robots-tag"></a>
<h3>Robots-Tag</h3>
<a name="standard-robots-tag"></a>
<h4>Standard Robots-Tag</h4>
<p>Wird für ein Produkt bzw. eine Kategorie kein Robots-Tag explizit definiert, so wird der jeweilige Standard Robots-Tag ausgegeben. Diese Standardwerte lassen sich an dieser Stelle über die Auswahlfelder <code>Standard Robots-Tag für Produkte</code> und <code>Standard Robots-Tag für Kategorien</code> hinterlegen.</p>
<a name="noindex-request-parameter-query"></a>
<h4>Noindex Request Parameter Query</h4>
<p>Haben wir für eine Kategorie bspw. <code>index,follow</code> als Robots-Tag definiert, so ist es meistens trotzdem nicht gewünscht, dass die Kategorieseite auch dann indexiert wird, wenn Filter, andere Sortierungen usw. aktiv sind. Grund ist, dass wir in diesem Fall verschiedene Seiten mit dem gleichen Inhalt hätten, was zu Duplicate Content führen würde. Auch ist es üblich, dass man nur die erste Seite des Kategorielistings indexieren lässt.</p>
<p>Um dies zu realisieren, können wir über die Option <code>Noindex Request Parameter Query</code> Bedingungen definieren, die dafür sorgen, dass als Robot Tag <code>noindex</code> ausgegeben wird. </p>
<p>SEO Professional gleicht hierbei die Bedingungen mit den GET-Parametern der URL ab und wird entsprechend aktiv, sobald eine Bedingung greift. Schauen wir uns hierzu einmal die vordefinierte Konfiguration an:</p>
<p><code>sort!=name-asc; p&gt;1; properties; rating; min-price; max-price; manufacturer</code></p>
<p>Hierbei haben wir standardmäßig <code>7 Bedingungen</code>, die vordefiniert sind. Die einzelnen Bedingungen werden jeweils mit einem Semikolon getrennt. Die Bedingung <code>sort!=name-asc</code> sag aus, dass immer dann <code>noindex</code> verwendet werden soll, wenn der GET Parameter <code>sort</code> vorhanden, nicht aber dem Wert <code>name-asc</code> entspricht. Anders gesagt werden somit also nur die Kategorieseiten mit der Sortierung <code>Name aufsteigend</code> indexiert. Sollten Sie eine andere Standardsortierung nutzen, so sollten Sie diese Bedingung entsprechend anpassen.</p>
<p>Die nächste Standard-Bedingung ist <code>p&gt;1</code>. Diese definiert, dass nur die erste Kategorieseite indexiert wird, da der Parameter <code>p</code> für die aktuelle Seitennummer steht und die Bedingung besagt, dass <code>noindex</code> verwendet werden soll, wenn dieser Parameter größer 1 ist. </p>
<p>Die weiteren Bedingungen <code>properties</code>, <code>rating</code>,  <code>min-price</code>, <code>max-price</code> und <code>manufacturer</code> wurden ohne Operator definiert. Es wird entsprechend <code>noindex</code> verwendet, sobald sich einer dieser Parameter in der URL befindet.</p>
<p><strong>Operatoren in der Übersicht</strong><br>
In der folgenden Tabelle finden Sie eine Auflistung der verfügbaren Operatoren:</p>
<table>
<thead>
<tr>
<th>Operator</th>
<th>Beschreibung</th>
<th>Beispiel</th>
</tr>
</thead>
<tbody>
<tr>
<td>[OHNE OPERATOR]</td>
<td>Prüft, ob der GET Parameter in der URL definiert ist</td>
<td>manufacturer</td>
</tr>
<tr>
<td>=</td>
<td>Prüft, ob der GET Parameter mit dem definierten Wert übereinstimmt</td>
<td>view=detail</td>
</tr>
<tr>
<td>!=</td>
<td>Prüft, ob der GET Parameter mit dem definierten Wert NICHT übereinstimmt. Hierbei muss der Parameter jedoch definiert sein.</td>
<td>sort!=name-asc</td>
</tr>
<tr>
<td>&gt;</td>
<td>Prüft, ob der GET Parameter größer als der definierte Wert ist</td>
<td>p&gt;1</td>
</tr>
<tr>
<td>&lt;</td>
<td>Prüft, ob der GET Parameter kleiner als der definierte Wert ist</td>
<td>number&lt;10</td>
</tr>
<tr>
<td>&gt;=</td>
<td>Prüft, ob der GET Parameter größer als der definierte Wert ist oder übereinstimmt</td>
<td>p&gt;=2</td>
</tr>
<tr>
<td>&lt;=</td>
<td>Prüft, ob der GET Parameter kleiner als der definierte Wert ist oder übereinstimmt</td>
<td>number=&lt;9</td>
</tr>
</tbody>
</table>
<a name="serp-vorschau"></a>
<h2>SERP Vorschau</h2>
<a name="verkaufskanal-vorauswahl"></a>
<a name="verkaufskanal-vorauswahl"></a>
<h3>Verkaufskanal Vorauswahl</h3>
<p>Standardmäßig muss in der Konfiguration der Canonical Urls eines Produkts bzw. Kategorie zunächst der Verkaufskanal ausgewählt werden, für den Anpassung durchgeführt werden soll. Wird hier ein Verkaufskanel ausgewählt, so wird dieser bei den Produkten und Kategorien automatisch vorausgewählt.</p>
<a name="canonical-urls"></a>
<h2>Canonical Urls</h2>
<a name="verkaufskanal-vorauswahl"></a>
<a name="verkaufskanal-vorauswahl"></a>
<h3>Verkaufskanal Vorauswahl</h3>
<p>Standardmäßig muss zur Anzeige der SERP Vorschau eines Produkts bzw. Kategorie zunächst der Verkaufskanal ausgewählt werden, für den die Vorschau angezeigt werden soll. Wird hier ein Verkaufskanel ausgewählt, so wird dieser bei den Produkten und Kategorien automatisch vorausgewählt.</p>
<a name="social-media"></a>
<h2>Social Media</h2>
<a name="konfiguration-der-zeichenlaengen"></a>
<h3>Konfiguration der Zeichenlängen</h3>
<p>Für die Social Media Felder <code>Facebook Titel</code>, <code>Facebook Beschreibung</code> sowie <code>Twitter Titel</code> und <code>Twitter Beschreibung</code> kannst du an dieser Stelle jeweils die <code>folgenden Konfigurationen definieren:</code></p>
<ul>
<li>
<p><strong>Empfohlene Pixellänge von</strong> bzw. <strong>Empfohlene Zeichenlänge von</strong>:<br>Gibt die empfohlene Mindestanzahl der Zeichen an, die für die jeweilige Social Media Angabe eingegeben werden sollte.</p>
</li>
<li>
<p><strong>bis</strong>:<br>Gibt die empfohlene Maximalanzahl der Zeichen an, die für die jeweilige Social Media Angabe eingegeben werden sollte.</p>
</li>
<li>
<p><strong>Maximale Pixellänge</strong> bzw. <strong>Maximale Zeichenlänge</strong>:<br>Gibt die maximale Anzahl der Zeichen an, die für die jeweilige Social Media Angabe eingegeben werden dürfen.</p>
</li>
</ul>
<a name="verwendung-der-konfiguration"></a>
<a name="verwendung-der-konfiguration"></a>
<h4>Verwendung der Konfiguration</h4>
<p>Die hier hinterlegte Konfiguration dient als Grundlage für die Darstellung der Social Media Felder.</p>
<p>Weitere Informationen zu den Social Media Feldern findest du unter:
<a href="docs/seo-professional/seo-settings/social-media">SEO Professional » SEO Einstellungen » Social Media</a></p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/900-settings/100-seo-settings',
    'parent' => 'en_300-modules/900-settings',
    'seoUrl' => 'docs/seo-professional/modules/settings/seo-settings',
    'title' => 'SEO Einstellungen',
    'menuTitle' => 'SEO Einstellungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SEO Einstellungen</h1>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#bulk-generatoren">Bulk Generatoren</a></li><li class="headline-level3"><a href="#bulk-generatoren-beim-speicherprozess-starten">Bulk Generatoren beim Speicherprozess starten</a></li><li class="headline-level2"><a href="#meta-tags">Meta-Tags</a></li><li class="headline-level3"><a href="#konfiguration-der-pixel--bzw-zeichenlaengen-der-meta-tags">Konfiguration der Pixel- bzw. Zeichenlängen der Meta Tags</a></li><li class="headline-level4"><a href="#verwendung-der-konfiguration">Verwendung der Konfiguration</a></li><li class="headline-level3"><a href="#robots-tag">Robots-Tag</a></li><li class="headline-level4"><a href="#standard-robots-tag">Standard Robots-Tag</a></li><li class="headline-level4"><a href="#noindex-request-parameter-query">Noindex Request Parameter Query</a></li><li class="headline-level2"><a href="#serp-vorschau">SERP Vorschau</a></li><li class="headline-level3"><a href="#verkaufskanal-vorauswahl">Verkaufskanal Vorauswahl</a></li><li class="headline-level2"><a href="#canonical-urls">Canonical Urls</a></li><li class="headline-level3"><a href="#verkaufskanal-vorauswahl">Verkaufskanal Vorauswahl</a></li><li class="headline-level2"><a href="#social-media">Social Media</a></li><li class="headline-level3"><a href="#konfiguration-der-zeichenlaengen">Konfiguration der Zeichenlängen</a></li><li class="headline-level4"><a href="#verwendung-der-konfiguration">Verwendung der Konfiguration</a></li></ul></div></p>
<a name="bulk-generatoren"></a>
<h2>Bulk Generatoren</h2>
<a name="bulk-generatoren-beim-speicherprozess-starten"></a>
<h3>Bulk Generatoren beim Speicherprozess starten</h3>
<p>Ist diese Option aktiv, so wird beim Speichern einer Kategorie bzw. eines Produkts automatisch der Bulk Generator für die jeweilige Entity gestartet. Es muss somit nicht extra der Bulk Generator gestartet werden, um die SEO Daten zu generieren.<br><br>Aus Performance-Gründen kann es unter Umständen Sinn machen diese Option zu deaktivieren, wenn bspw. eine große Menge an Daten per ERP abgeglichen wird.</p>
<a name="meta-tags"></a>
<h2>Meta-Tags</h2>
<a name="konfiguration-der-pixel--bzw-zeichenlaengen-der-meta-tags"></a>
<h3>Konfiguration der Pixel- bzw. Zeichenlängen der Meta Tags</h3>
<p>Für die Meta Tags <code>Meta Titel</code>, <code>Meta Beschreibung</code> sowie <code>Keywords</code> kannst du an dieser Stelle jeweils die folgenden Konfigurationen definieren:</p>
<ul>
<li>
<p><strong>Empfohlene Pixellänge von</strong> bzw. <strong>Empfohlene Zeichenlänge von</strong>:<br>Gibt die empfohlene Mindestanzahl der Pixel bzw. Zeichen an, die für die jeweilige Meta Angabe eingegeben werden sollte.</p>
</li>
<li>
<p><strong>bis</strong>:<br>Gibt die empfohlene Maximalanzahl der Pixel bzw. Zeichen an, die für die jeweilige Meta Angabe eingegeben werden sollte.</p>
</li>
<li>
<p><strong>Maximale Pixellänge</strong> bzw. <strong>Maximale Zeichenlänge</strong>:<br>Gibt die maximale Anzahl der Pixel bzw. Zeichen an, die für die jeweilige Meta Angabe eingegeben werden dürfen.</p>
</li>
</ul>
<a name="verwendung-der-konfiguration"></a>
<a name="verwendung-der-konfiguration"></a>
<h4>Verwendung der Konfiguration</h4>
<p>Die hier hinterlegte Konfiguration dient als Grundlage für andere Funktionen von SEO Professional. So wird bei Eingabe der Meta-Tags bspw. eine Zeichen- bzw. Pixellänge innerhalb des empfohlenen Bereichs <em>grün</em>, ein Wert zwischen dem bis- und Maximalwert <em>orange</em> und ein Wert über der maximalen Zeichen- bzw. Pixellänge <em>rot</em> dargestellt.</p>
<p>Weitere Informationen zu den Meta-Tags findest du unter:
<a href="docs/seo-professional/seo-settings/meta-tags">SEO Professional » SEO Einstellungen » Meta Tags</a></p>
<a name="robots-tag"></a>
<h3>Robots-Tag</h3>
<a name="standard-robots-tag"></a>
<h4>Standard Robots-Tag</h4>
<p>Wird für ein Produkt bzw. eine Kategorie kein Robots-Tag explizit definiert, so wird der jeweilige Standard Robots-Tag ausgegeben. Diese Standardwerte lassen sich an dieser Stelle über die Auswahlfelder <code>Standard Robots-Tag für Produkte</code> und <code>Standard Robots-Tag für Kategorien</code> hinterlegen.</p>
<a name="noindex-request-parameter-query"></a>
<h4>Noindex Request Parameter Query</h4>
<p>Haben wir für eine Kategorie bspw. <code>index,follow</code> als Robots-Tag definiert, so ist es meistens trotzdem nicht gewünscht, dass die Kategorieseite auch dann indexiert wird, wenn Filter, andere Sortierungen usw. aktiv sind. Grund ist, dass wir in diesem Fall verschiedene Seiten mit dem gleichen Inhalt hätten, was zu Duplicate Content führen würde. Auch ist es üblich, dass man nur die erste Seite des Kategorielistings indexieren lässt.</p>
<p>Um dies zu realisieren, können wir über die Option <code>Noindex Request Parameter Query</code> Bedingungen definieren, die dafür sorgen, dass als Robot Tag <code>noindex</code> ausgegeben wird. </p>
<p>SEO Professional gleicht hierbei die Bedingungen mit den GET-Parametern der URL ab und wird entsprechend aktiv, sobald eine Bedingung greift. Schauen wir uns hierzu einmal die vordefinierte Konfiguration an:</p>
<p><code>sort!=name-asc; p&gt;1; properties; rating; min-price; max-price; manufacturer</code></p>
<p>Hierbei haben wir standardmäßig <code>7 Bedingungen</code>, die vordefiniert sind. Die einzelnen Bedingungen werden jeweils mit einem Semikolon getrennt. Die Bedingung <code>sort!=name-asc</code> sag aus, dass immer dann <code>noindex</code> verwendet werden soll, wenn der GET Parameter <code>sort</code> vorhanden, nicht aber dem Wert <code>name-asc</code> entspricht. Anders gesagt werden somit also nur die Kategorieseiten mit der Sortierung <code>Name aufsteigend</code> indexiert. Sollten Sie eine andere Standardsortierung nutzen, so sollten Sie diese Bedingung entsprechend anpassen.</p>
<p>Die nächste Standard-Bedingung ist <code>p&gt;1</code>. Diese definiert, dass nur die erste Kategorieseite indexiert wird, da der Parameter <code>p</code> für die aktuelle Seitennummer steht und die Bedingung besagt, dass <code>noindex</code> verwendet werden soll, wenn dieser Parameter größer 1 ist. </p>
<p>Die weiteren Bedingungen <code>properties</code>, <code>rating</code>,  <code>min-price</code>, <code>max-price</code> und <code>manufacturer</code> wurden ohne Operator definiert. Es wird entsprechend <code>noindex</code> verwendet, sobald sich einer dieser Parameter in der URL befindet.</p>
<p><strong>Operatoren in der Übersicht</strong><br>
In der folgenden Tabelle finden Sie eine Auflistung der verfügbaren Operatoren:</p>
<table>
<thead>
<tr>
<th>Operator</th>
<th>Beschreibung</th>
<th>Beispiel</th>
</tr>
</thead>
<tbody>
<tr>
<td>[OHNE OPERATOR]</td>
<td>Prüft, ob der GET Parameter in der URL definiert ist</td>
<td>manufacturer</td>
</tr>
<tr>
<td>=</td>
<td>Prüft, ob der GET Parameter mit dem definierten Wert übereinstimmt</td>
<td>view=detail</td>
</tr>
<tr>
<td>!=</td>
<td>Prüft, ob der GET Parameter mit dem definierten Wert NICHT übereinstimmt. Hierbei muss der Parameter jedoch definiert sein.</td>
<td>sort!=name-asc</td>
</tr>
<tr>
<td>&gt;</td>
<td>Prüft, ob der GET Parameter größer als der definierte Wert ist</td>
<td>p&gt;1</td>
</tr>
<tr>
<td>&lt;</td>
<td>Prüft, ob der GET Parameter kleiner als der definierte Wert ist</td>
<td>number&lt;10</td>
</tr>
<tr>
<td>&gt;=</td>
<td>Prüft, ob der GET Parameter größer als der definierte Wert ist oder übereinstimmt</td>
<td>p&gt;=2</td>
</tr>
<tr>
<td>&lt;=</td>
<td>Prüft, ob der GET Parameter kleiner als der definierte Wert ist oder übereinstimmt</td>
<td>number=&lt;9</td>
</tr>
</tbody>
</table>
<a name="serp-vorschau"></a>
<h2>SERP Vorschau</h2>
<a name="verkaufskanal-vorauswahl"></a>
<a name="verkaufskanal-vorauswahl"></a>
<h3>Verkaufskanal Vorauswahl</h3>
<p>Standardmäßig muss in der Konfiguration der Canonical Urls eines Produkts bzw. Kategorie zunächst der Verkaufskanal ausgewählt werden, für den Anpassung durchgeführt werden soll. Wird hier ein Verkaufskanel ausgewählt, so wird dieser bei den Produkten und Kategorien automatisch vorausgewählt.</p>
<a name="canonical-urls"></a>
<h2>Canonical Urls</h2>
<a name="verkaufskanal-vorauswahl"></a>
<a name="verkaufskanal-vorauswahl"></a>
<h3>Verkaufskanal Vorauswahl</h3>
<p>Standardmäßig muss zur Anzeige der SERP Vorschau eines Produkts bzw. Kategorie zunächst der Verkaufskanal ausgewählt werden, für den die Vorschau angezeigt werden soll. Wird hier ein Verkaufskanel ausgewählt, so wird dieser bei den Produkten und Kategorien automatisch vorausgewählt.</p>
<a name="social-media"></a>
<h2>Social Media</h2>
<a name="konfiguration-der-zeichenlaengen"></a>
<h3>Konfiguration der Zeichenlängen</h3>
<p>Für die Social Media Felder <code>Facebook Titel</code>, <code>Facebook Beschreibung</code> sowie <code>Twitter Titel</code> und <code>Twitter Beschreibung</code> kannst du an dieser Stelle jeweils die <code>folgenden Konfigurationen definieren:</code></p>
<ul>
<li>
<p><strong>Empfohlene Pixellänge von</strong> bzw. <strong>Empfohlene Zeichenlänge von</strong>:<br>Gibt die empfohlene Mindestanzahl der Zeichen an, die für die jeweilige Social Media Angabe eingegeben werden sollte.</p>
</li>
<li>
<p><strong>bis</strong>:<br>Gibt die empfohlene Maximalanzahl der Zeichen an, die für die jeweilige Social Media Angabe eingegeben werden sollte.</p>
</li>
<li>
<p><strong>Maximale Pixellänge</strong> bzw. <strong>Maximale Zeichenlänge</strong>:<br>Gibt die maximale Anzahl der Zeichen an, die für die jeweilige Social Media Angabe eingegeben werden dürfen.</p>
</li>
</ul>
<a name="verwendung-der-konfiguration"></a>
<a name="verwendung-der-konfiguration"></a>
<h4>Verwendung der Konfiguration</h4>
<p>Die hier hinterlegte Konfiguration dient als Grundlage für die Darstellung der Social Media Felder.</p>
<p>Weitere Informationen zu den Social Media Feldern findest du unter:
<a href="docs/seo-professional/seo-settings/social-media">SEO Professional » SEO Einstellungen » Social Media</a></p>
<p></p>',
  ),
);