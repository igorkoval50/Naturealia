<?php return array (
  'DE' => 
  array (
    'path' => 'de_300-modules/900-settings',
    'parent' => 'de_300-modules',
    'seoUrl' => 'docs/seo-professional/modules/settings',
    'title' => 'Weitere Einstellungen',
    'menuTitle' => 'Weitere Einstellungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Weitere Einstellungen</h1>
<p>Unter <code>SEO Professional » Weitere Einstellungen</code> findest du weitere Konfigurationsmöglichkeiten zu den Modulen sowie allgemeine SEO Einstellungen.</p>
<a name="verkaufskanel"></a>
<h2>Verkaufskanel</h2>
<p>Standardmäßig werden die hier sowie in den Untermodulen hinterlegten Konfigurationen für alle Verkaufskanäle genutzt. Möchtest du eine Einstellung nur für einen bestimmten Verkaufskanel hinterlegen, so musst du diesen zunächst über das Feld <code>Verkaufskanel</code> auswählen. Das Verhalten ist hierbei anschließend analog zur Konfiguration der Produkt Varianten. Eine Vererbung findet also solange statt, bis das Link-Symbol einer Einstellung aufgelöst ist.</p>
<p><a data-dreisccmslightbox="images-418718" data-title="Verkaufskanel auswählen" href="wiki/dreisc_seo_pro/300-modules/900-settings/lightbox/sales-channel-auswahl.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/900-settings/lightbox/sales-channel-auswahl.png" alt="Verkaufskanel auswählen">
                        </a></p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/settings/seo-settings" class="nav--link link--entry">SEO Einstellungen</a></li></ul></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_300-modules/900-settings',
    'parent' => 'en_300-modules',
    'seoUrl' => 'docs/seo-professional/modules/settings',
    'title' => 'Weitere Einstellungen',
    'menuTitle' => 'Weitere Einstellungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Weitere Einstellungen</h1>
<p>Unter <code>SEO Professional » Weitere Einstellungen</code> findest du weitere Konfigurationsmöglichkeiten zu den Modulen sowie allgemeine SEO Einstellungen.</p>
<a name="verkaufskanel"></a>
<h2>Verkaufskanel</h2>
<p>Standardmäßig werden die hier sowie in den Untermodulen hinterlegten Konfigurationen für alle Verkaufskanäle genutzt. Möchtest du eine Einstellung nur für einen bestimmten Verkaufskanel hinterlegen, so musst du diesen zunächst über das Feld <code>Verkaufskanel</code> auswählen. Das Verhalten ist hierbei anschließend analog zur Konfiguration der Produkt Varianten. Eine Vererbung findet also solange statt, bis das Link-Symbol einer Einstellung aufgelöst ist.</p>
<p><a data-dreisccmslightbox="images-686836" data-title="Verkaufskanel auswählen" href="wiki/dreisc_seo_pro/300-modules/900-settings/lightbox/sales-channel-auswahl.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/300-modules/900-settings/lightbox/sales-channel-auswahl.png" alt="Verkaufskanel auswählen">
                        </a></p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/modules/settings/seo-settings" class="nav--link link--entry">SEO Einstellungen</a></li></ul></p>',
  ),
);