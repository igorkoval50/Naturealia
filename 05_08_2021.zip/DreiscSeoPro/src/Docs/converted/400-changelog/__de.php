<?php return array (
  'DE' => 
  array (
    'path' => 'de_400-changelog',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional/changelog',
    'title' => 'Changelog',
    'menuTitle' => 'Changelog',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Changelog</h1>
<p>Auf dieser Seite findest du alle Anpassungen die mit den einzelnen Versionen des Plugins SEO Professional umgesetzt wurden.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#version-686">Version 6.8.6</a></li><li class="headline-level2"><a href="#version-685">Version 6.8.5</a></li><li class="headline-level2"><a href="#version-684">Version 6.8.4</a></li><li class="headline-level2"><a href="#version-683">Version 6.8.3</a></li><li class="headline-level2"><a href="#version-682">Version 6.8.2</a></li><li class="headline-level2"><a href="#version-681">Version 6.8.1</a></li><li class="headline-level2"><a href="#version-680">Version 6.8.0</a></li><li class="headline-level2"><a href="#version-6717">Version 6.7.17</a></li><li class="headline-level2"><a href="#version-6716">Version 6.7.16</a></li><li class="headline-level2"><a href="#version-6715">Version 6.7.15</a></li><li class="headline-level2"><a href="#version-6714">Version 6.7.14</a></li><li class="headline-level2"><a href="#version-6713">Version 6.7.13</a></li><li class="headline-level2"><a href="#version-6712">Version 6.7.12</a></li><li class="headline-level2"><a href="#version-6711">Version 6.7.11</a></li><li class="headline-level2"><a href="#version-6710">Version 6.7.10</a></li><li class="headline-level2"><a href="#version-679">Version 6.7.9</a></li><li class="headline-level2"><a href="#version-678">Version 6.7.8</a></li><li class="headline-level2"><a href="#version-677">Version 6.7.7</a></li><li class="headline-level2"><a href="#version-676">Version 6.7.6</a></li><li class="headline-level2"><a href="#version-675">Version 6.7.5</a></li><li class="headline-level2"><a href="#version-674">Version 6.7.4</a></li><li class="headline-level2"><a href="#version-673">Version 6.7.3</a></li><li class="headline-level2"><a href="#version-672">Version 6.7.2</a></li><li class="headline-level2"><a href="#version-671">Version 6.7.1</a></li><li class="headline-level2"><a href="#version-670">Version 6.7.0</a></li><li class="headline-level2"><a href="#version-660">Version 6.6.0</a></li><li class="headline-level2"><a href="#version-652">Version 6.5.2</a></li><li class="headline-level2"><a href="#version-651">Version 6.5.1</a></li><li class="headline-level2"><a href="#version-650">Version 6.5.0</a></li><li class="headline-level2"><a href="#version-642">Version 6.4.2</a></li><li class="headline-level2"><a href="#version-641">Version 6.4.1</a></li><li class="headline-level2"><a href="#version-640">Version 6.4.0</a></li><li class="headline-level2"><a href="#version-630">Version 6.3.0</a></li><li class="headline-level2"><a href="#version-620">Version 6.2.0</a></li><li class="headline-level2"><a href="#version-610">Version 6.1.0</a></li><li class="headline-level2"><a href="#version-602">Version 6.0.2</a></li><li class="headline-level2"><a href="#version-601">Version 6.0.1</a></li><li class="headline-level2"><a href="#version-600">Version 6.0.0</a></li></ul></div></p>
<a name="version-686"></a>
<h2>Version 6.8.6</h2>
<ul>
<li>Plugin Fehler in Verbindung mit Detailseiten Erlebniswelten behoben (getReviews() must be an instance of Shopware\\Storefront\\Page\\Product\\Review\\ReviewLoaderResult, null returned)</li>
</ul>
<a name="version-685"></a>
<h2>Version 6.8.5</h2>
<ul>
<li>Fehlende Datei für Update auf die Version 6.8.4 hinzugefügt.</li>
</ul>
<a name="version-684"></a>
<h2>Version 6.8.4</h2>
<ul>
<li>Das automatische Ausführen der Bulk Generatoren beim Speichern eines Entities kann nun per Einstellung unter <a href="docs/seo-professional/modules/settings/seo-settings#bulk-generatoren-beim-speicherprozess-starten">SEO Professional » Weitere Einstellungen » SEO Einstellungen</a> abgeschaltet werden.</li>
<li>Die Bulk Generatoren werden fortan nicht mehr beim Indexieren in der handle Methode ausgeführt.</li>
</ul>
<a name="version-683"></a>
<h2>Version 6.8.3</h2>
<ul>
<li>Unter bestimmten Voraussetzungen wurde die Live Template Variable ##shopName## nicht mehr aufgelöst.</li>
</ul>
<a name="version-682"></a>
<h2>Version 6.8.2</h2>
<ul>
<li>setContainer bei DreiscSeoRedirectController ergänzt.</li>
</ul>
<a name="version-681"></a>
<h2>Version 6.8.1</h2>
<ul>
<li>PHP 8.0 Support</li>
</ul>
<a name="version-680"></a>
<h2>Version 6.8.0</h2>
<ul>
<li>Shopware 6.4 Kompatibilität</li>
</ul>
<a name="version-6717"></a>
<h2>Version 6.7.17</h2>
<ul>
<li>Bei Varianten konnte bei den Bulk Templates nicht auf die Daten des Hauptartikels zurückgegriffen werden. Hier wurde nun die Vererbung aktiviert.</li>
</ul>
<a name="version-6716"></a>
<h2>Version 6.7.16</h2>
<ul>
<li>Unter bestimmten Umständen wurde bei dem Generieren der Urls über den Bulk Generator nicht der isModified Flag gesetzt. Hierdurch wurden diese URLs abschließend wieder durch den Shopware Standard URL Generator überschrieben.</li>
<li>Bei den Canonical-Einstellungen wurde das Feld <code>Externe URL (Canonical Link)</code> vom Typ <code>Url</code> auf den Typ <code>Text</code> angepasst, da ansonsten eine Speicherung der externen URL nicht möglich war.</li>
</ul>
<a name="version-6715"></a>
<h2>Version 6.7.15</h2>
<ul>
<li>Über ein internes Caching der SEO Bulk Einstellungen konnte die Performance der Bulk Generatoren optimiert werden.</li>
</ul>
<a name="version-6714"></a>
<h2>Version 6.7.14</h2>
<ul>
<li>Unterstützung des Live Templates ##shopName## bei Kategorien.</li>
<li>Anpassung der für kommende Versionen als @deprecated markierte Codeelemente.</li>
</ul>
<a name="version-6713"></a>
<h2>Version 6.7.13</h2>
<ul>
<li>Die URL des Logos sowie des Unternehmensstandortes der Rich Snippet Unternehmensdaten konnten nicht gespeichert werden. Dieses Verhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-6712"></a>
<h2>Version 6.7.12</h2>
<ul>
<li>In bestimmten Konstellationen wurde die Live Variable ##shopName## nicht korrekt durch den Shopnamen ersetzt. Dieses Verhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-6711"></a>
<h2>Version 6.7.11</h2>
<ul>
<li>Beim Export von Weiterleitungen wurde eine fehlerhafte URL erstellt, die zu dem folgenden Fehler führte: <code>Requested api version v1 not available, available versions are v2, v3.</code>. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-6710"></a>
<h2>Version 6.7.10</h2>
<ul>
<li>Beim Generieren von Varianten kam es unter bestimmten Umständen zu einem Fehler des Bulk Generators (Call getCategories on null). Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-679"></a>
<h2>Version 6.7.9</h2>
<ul>
<li>Fehler beim Generieren des Canonical Links behoben.</li>
</ul>
<a name="version-678"></a>
<h2>Version 6.7.8</h2>
<ul>
<li>Mit inaktiver Option <code>Rich Snippets über JSON-LD aktivieren</code> wurden in der Storefront keine sprechenden URLs mehr ausgegeben. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-677"></a>
<h2>Version 6.7.7</h2>
<ul>
<li>Aufgrund der Performance Probleme mit dem Shopware DAL wurden die Bulk Generatoren auf Plain SQL umgestellt. Somit wird eine schnellere Datenspeicherung realisiert.</li>
<li>In manchen Fällen wurde die Meta Description nicht korrekt ausgegeben. Dieses Problem wurde nun behoben.</li>
</ul>
<a name="version-676"></a>
<h2>Version 6.7.6</h2>
<ul>
<li>Performance Update der Bulk Generatoren</li>
<li>Template Variablen wurden bei dem erstellen / bearbeiten der Bulk Templates nicht in das Formular übernommen. Dieses Verhalten wurde behoben. </li>
</ul>
<a name="version-675"></a>
<h2>Version 6.7.5</h2>
<ul>
<li>Umstellung der Produkt- und Kategorie Indexer auf die neue EntityIndexer Struktur.</li>
<li>Fehler bei der Darstellung der Canonical-URL Einstellungen behoben.</li>
</ul>
<a name="version-674"></a>
<h2>Version 6.7.4</h2>
<ul>
<li>Es kam zu einer Fehlermeldung, wenn ein anderes Plugin einen Decorator für die Shopware Router Komponente definiert hat. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-673"></a>
<h2>Version 6.7.3</h2>
<ul>
<li>Kompatibilität zu Shopware 6.3.0 hergestellt.</li>
</ul>
<a name="version-672"></a>
<h2>Version 6.7.2</h2>
<ul>
<li>Bei aktivem JSON-LD kam es vor, dass Teile der Rich Snippets Tags trotzdem ausgegeben wurden. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-671"></a>
<h2>Version 6.7.1</h2>
<ul>
<li>In den URls die über den Bulk Generator erstellt werden, können nun auch Sonderzeichen wie der Punkt und das &quot;~&quot;-Zeichen verwendet werden.</li>
<li>Allgemein wurden Sonderzeichen durch den Bulk Generator automatisch escaped. Dieses wurden durch den Twig Renderer verursacht. Die Konfiguration wurde hier nun angepasst, sodass die Sonderzeichen auch als solche dargestellt werden.</li>
</ul>
<a name="version-670"></a>
<h2>Version 6.7.0</h2>
<ul>
<li>Für Facebook und Twitter können ab dieser Version der Titel, die Beschreibungen sowie die Bilder definiert werden, die beim Teilen des Produkts / der Seite ausgegeben werden. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/seo-settings/social-media">SEO Professional » SEO Einstellungen » Social Media</a></li>
<li>Der Titel sowie die Beschreibung für Facebook und Twitter können per Bulk Template erstellt werden.</li>
<li>Die empfohlene Länge sowie die Maximallänge der Facebook und Twitter Titel sowie Beschreibungen können in den Einstellungen selbst definiert werden.</li>
<li>Die Weiterleitungen können nun als CSV Datei importiert sowie exportiert werden. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/redirect/redirect-import-export">Plugin Dokumentationen » SEO Professional » Module » 301 und 302 URL Weiterleitungen » CSV Import und Export der Weiterleitungen</a></li>
<li>Es können nun auch Weiterleitungen an die Startseite konfiguriert werden.</li>
</ul>
<a name="version-660"></a>
<h2>Version 6.6.0</h2>
<ul>
<li>Als Canonical Link wird im Shopware Standard immer der SEO Pfad der jeweiligen Seite übergeben. Ab dieser Version ist es möglich für Produkte und Kategorien abweichende Canonical Links zu hinterlegen. Hierbei kann eine feste externe URL hinterlegt oder aber ein Produkt bzw. eine Kategorie ausgewählt werden, dessen SEO Pfad als Canonical Link verwendet werden soll. Weitere Informationen zu der neuen Einstellung findest du unter: <a href="docs/seo-professional/seo-settings/canonical-urls#canonical-link">SEO Professional » SEO Einstellungen » Canonical Urls » Canonical Link</a></li>
</ul>
<a name="version-652"></a>
<h2>Version 6.5.2</h2>
<ul>
<li>Im Shopware Standard wird das Canonical Links Tag auf der Startseite sowie den Kategorieseiten nicht ausgegeben (Stand Shopware 6.2). Bis dies über den Shopware Standard gewährleistet wird, wird die Ausgabe ab dieser Version über SEO Professional sichergestellt. Weitere Informationen findest du unter: <a href="https://issues.shopware.com/issues/NEXT-8662">https://issues.shopware.com/issues/NEXT-8662</a> </li>
<li>Im Bulk Generator für URLs steht nun der komplette Kategoriebaum zur Auswahl zur Verfügung. Dieser wird entsprechend nicht mehr auf die Kategorien des ausgewählten Sales Channels heruntergebrochen, um eine Auswahl der Service und Footer Seiten zu gewährleisten.</li>
</ul>
<a name="version-651"></a>
<h2>Version 6.5.1</h2>
<ul>
<li>In der Version 6.5.0 kam es zu der Fehlermeldung <code>ltrim() expects parameter 1 to be string, boolean given</code>, wenn ein Saleschannel mit virtueller Domain genutzt wurde. Bspw.: <code>http://www.shop.de/at</code>. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-650"></a>
<h2>Version 6.5.0</h2>
<ul>
<li>Bei den Produkten sowie den Kategorien wurden die Meta-Tags Administration um die  Konfiguration des Robots Tags erweitert. Somit kann nun für die Seiten deifniert werden, ob diese indexiert und Links auf diesen Seiten verfolgt werden sollen. Ausführliche Informationen zu dieser neuen Einstellung findest du unter: <a href="docs/seo-professional/seo-settings/meta-tags#robots-tag">SEO Professional » SEO Einstellungen » Meta Tags » Robots Tag</a></li>
<li>In den SEO Einstellungen kann des Weiteren ein Standard Robots-Tag definiert werden, der verwendet wird, wenn für eine Kategorie bzw. ein Produkt kein Robots-Tag explizit angegeben wurde. Ebenfalls kann auch die neue Option <code>Noindex Request Parameter Query</code> definiert werden, über die Bedingungen konfiguriert werden können, die dafür sorgen, dass ein Robots-Tag auf <code>noindex</code> umgestellt wird. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/settings/seo-settings">SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta Tags</a></li>
<li>Über den <code>Produkt-</code> sowie den <code>Kategorie Bulk Generator</code> können jetzt auch die Einstellungen für den Robots Tag definiert werden.</li>
<li>Möchtest du dir für ein Produkt bzw. eine Kategorie die SERP Vorschau anschauen oder aber die Canonical Url bearbeiten, so musst du zuvor immer erst den Verkaufskanel auswählen den du bearbeiten möchtest. Um die Workflows hier zu erleichtern kannst du nun jeweils einen Verkaufskanel als Vorauswahl definieren. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/settings/seo-settings">SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta Tags</a></li>
</ul>
<a name="version-642"></a>
<h2>Version 6.4.2</h2>
<ul>
<li>Bei den Migrationen findet bei den Rückgabewerten der Methode <code>getCreationTimestamp</code>jetzt eine explizite Datentypumwandlung auf den Datentyp <code>int</code> statt, da das Plugin ansonsten unter bestimmten Serverbedingungen nicht installiert werden konnte.</li>
<li>Die Anpassungen der Version 6.0.2 bzgl. Löschen der Weiterleitungen in der Administration hat in Produktivsystemen mit aktivem Cache noch nicht funktioniert. Ab dieser Version wird der Cache Tag der jeweiligen Weiterleitung geleert.</li>
</ul>
<a name="version-641"></a>
<h2>Version 6.4.1</h2>
<ul>
<li>Die Methode <code>extractInheritableAttributes</code> der <code>Klasse DreiscSeoPro\\Decorator\\Shopware\\Storefront\\Routing\\RequestTransformerDecorator</code> hatte keinen Rückgabewert. Dies führte dazu, dass es teilweise bei der Registrierung zu einer Fehlermeldung kam. Dieses Fehlverhalten wurde behoben. </li>
</ul>
<a name="version-640"></a>
<h2>Version 6.4.0</h2>
<ul>
<li>Die Rich Snippets Konfiguration wurde um die Bereiche <code>Logo</code> und <code>Lokales Unternehmen</code> erweitert. Weitere Informationen hierzu findest du unter <a href="docs/seo-professional/modules/rich-snippets-json-ld/organization">SEO Professional » Module » Rich Snippets (JSON-LD) » Unternehmen</a></li>
<li>Die Konfigurationen der Rich Snippets Einstellungen können nun pro Sales Channel hinterlegt werden.</li>
<li>Bei den abweichenden Werten für die Rich Snippets, die unter <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a> konfiguriert werden können, wurde die Vererbung bei Varianten implementiert.  </li>
</ul>
<a name="version-630"></a>
<h2>Version 6.3.0</h2>
<ul>
<li>Es ist nun möglich Rich Snippets der Bereiche <code>Produkt</code> und <code>Breadcrumb</code> über SEO Professional auszugeben. Die standardmäßig vorhandenen Rich Snippet Mircodaten werden aus dem Quellcode entfernt und durch JSON-LD Daten ersetzt. Informationen zu den Einstellungsmöglichkeiten findest du unter: <a href="docs/seo-professional/modules/rich-snippets-json-ld">SEO Professional » Module » Rich Snippets (JSON-LD)</a></li>
</ul>
<a name="version-620"></a>
<h2>Version 6.2.0</h2>
<ul>
<li>Die empfohlene sowie die maximale Zeichen- bzw. Pixellänge der Meta Tags kann nun konfiguriert werden. Die Einstellungen hierzu findest du unter <code>SEO Professional » Einstellugen</code>. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/settings/seo-settings">SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta Tags</a></li>
</ul>
<a name="version-610"></a>
<h2>Version 6.1.0</h2>
<ul>
<li>Die Bulk Generatoren können jetzt auch direkt über die Adminstration gestartet werden. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/bulk-generators/execute-bulk-generator#2-moeglichkeit-bulk-generatoren-ueber-die-administration-starten">Bulk Generator ausführen</a></li>
</ul>
<a name="version-602"></a>
<h2>Version 6.0.2</h2>
<ul>
<li>Die Weiterleitungen wurden bei aktivem HTTP Cache nicht direkt übernommen. Dieses Verhalten wurde entsprechend angepasst.</li>
<li>Das Löschen der Weiterleitungen hat mit der aktuellen Version nicht mehr funktioniert, da das Shopware DAL diese nicht löschen konnte. Daher wurde das Löschen der Weiterleitungen auf Plain SQL umgestellt und ein Ticket bei der shopware AG eröffnet. (<a href="https://issues.shopware.com/issues/NEXT-7866">https://issues.shopware.com/issues/NEXT-7866</a>)</li>
</ul>
<a name="version-601"></a>
<h2>Version 6.0.1</h2>
<ul>
<li>In dieser Version wurde das Icon für die Plugin Manager hinzugefügt.</li>
</ul>
<a name="version-600"></a>
<h2>Version 6.0.0</h2>
<ul>
<li>Initiales Release für Shopware 6. Zum aktuellen Zeitpunkt stehen noch nicht alle Funktionen bereit die unter Shopware 5 bei SEO Professional möglich waren. Diese und noch weitere Funktionen werden im Laufe der kommeden Wochen / Monate nach und nach erweitert. Angedacht sind hierbei aktuell monatliche Updates.</li>
</ul>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_400-changelog',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional/changelog',
    'title' => 'Changelog',
    'menuTitle' => 'Changelog',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Changelog</h1>
<p>Auf dieser Seite findest du alle Anpassungen die mit den einzelnen Versionen des Plugins SEO Professional umgesetzt wurden.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#version-686">Version 6.8.6</a></li><li class="headline-level2"><a href="#version-685">Version 6.8.5</a></li><li class="headline-level2"><a href="#version-684">Version 6.8.4</a></li><li class="headline-level2"><a href="#version-683">Version 6.8.3</a></li><li class="headline-level2"><a href="#version-682">Version 6.8.2</a></li><li class="headline-level2"><a href="#version-681">Version 6.8.1</a></li><li class="headline-level2"><a href="#version-680">Version 6.8.0</a></li><li class="headline-level2"><a href="#version-6717">Version 6.7.17</a></li><li class="headline-level2"><a href="#version-6716">Version 6.7.16</a></li><li class="headline-level2"><a href="#version-6715">Version 6.7.15</a></li><li class="headline-level2"><a href="#version-6714">Version 6.7.14</a></li><li class="headline-level2"><a href="#version-6713">Version 6.7.13</a></li><li class="headline-level2"><a href="#version-6712">Version 6.7.12</a></li><li class="headline-level2"><a href="#version-6711">Version 6.7.11</a></li><li class="headline-level2"><a href="#version-6710">Version 6.7.10</a></li><li class="headline-level2"><a href="#version-679">Version 6.7.9</a></li><li class="headline-level2"><a href="#version-678">Version 6.7.8</a></li><li class="headline-level2"><a href="#version-677">Version 6.7.7</a></li><li class="headline-level2"><a href="#version-676">Version 6.7.6</a></li><li class="headline-level2"><a href="#version-675">Version 6.7.5</a></li><li class="headline-level2"><a href="#version-674">Version 6.7.4</a></li><li class="headline-level2"><a href="#version-673">Version 6.7.3</a></li><li class="headline-level2"><a href="#version-672">Version 6.7.2</a></li><li class="headline-level2"><a href="#version-671">Version 6.7.1</a></li><li class="headline-level2"><a href="#version-670">Version 6.7.0</a></li><li class="headline-level2"><a href="#version-660">Version 6.6.0</a></li><li class="headline-level2"><a href="#version-652">Version 6.5.2</a></li><li class="headline-level2"><a href="#version-651">Version 6.5.1</a></li><li class="headline-level2"><a href="#version-650">Version 6.5.0</a></li><li class="headline-level2"><a href="#version-642">Version 6.4.2</a></li><li class="headline-level2"><a href="#version-641">Version 6.4.1</a></li><li class="headline-level2"><a href="#version-640">Version 6.4.0</a></li><li class="headline-level2"><a href="#version-630">Version 6.3.0</a></li><li class="headline-level2"><a href="#version-620">Version 6.2.0</a></li><li class="headline-level2"><a href="#version-610">Version 6.1.0</a></li><li class="headline-level2"><a href="#version-602">Version 6.0.2</a></li><li class="headline-level2"><a href="#version-601">Version 6.0.1</a></li><li class="headline-level2"><a href="#version-600">Version 6.0.0</a></li></ul></div></p>
<a name="version-686"></a>
<h2>Version 6.8.6</h2>
<ul>
<li>Plugin Fehler in Verbindung mit Detailseiten Erlebniswelten behoben (getReviews() must be an instance of Shopware\\Storefront\\Page\\Product\\Review\\ReviewLoaderResult, null returned)</li>
</ul>
<a name="version-685"></a>
<h2>Version 6.8.5</h2>
<ul>
<li>Fehlende Datei für Update auf die Version 6.8.4 hinzugefügt.</li>
</ul>
<a name="version-684"></a>
<h2>Version 6.8.4</h2>
<ul>
<li>Das automatische Ausführen der Bulk Generatoren beim Speichern eines Entities kann nun per Einstellung unter <a href="docs/seo-professional/modules/settings/seo-settings#bulk-generatoren-beim-speicherprozess-starten">SEO Professional » Weitere Einstellungen » SEO Einstellungen</a> abgeschaltet werden.</li>
<li>Die Bulk Generatoren werden fortan nicht mehr beim Indexieren in der handle Methode ausgeführt.</li>
</ul>
<a name="version-683"></a>
<h2>Version 6.8.3</h2>
<ul>
<li>Unter bestimmten Voraussetzungen wurde die Live Template Variable ##shopName## nicht mehr aufgelöst.</li>
</ul>
<a name="version-682"></a>
<h2>Version 6.8.2</h2>
<ul>
<li>setContainer bei DreiscSeoRedirectController ergänzt.</li>
</ul>
<a name="version-681"></a>
<h2>Version 6.8.1</h2>
<ul>
<li>PHP 8.0 Support</li>
</ul>
<a name="version-680"></a>
<h2>Version 6.8.0</h2>
<ul>
<li>Shopware 6.4 Kompatibilität</li>
</ul>
<a name="version-6717"></a>
<h2>Version 6.7.17</h2>
<ul>
<li>Bei Varianten konnte bei den Bulk Templates nicht auf die Daten des Hauptartikels zurückgegriffen werden. Hier wurde nun die Vererbung aktiviert.</li>
</ul>
<a name="version-6716"></a>
<h2>Version 6.7.16</h2>
<ul>
<li>Unter bestimmten Umständen wurde bei dem Generieren der Urls über den Bulk Generator nicht der isModified Flag gesetzt. Hierdurch wurden diese URLs abschließend wieder durch den Shopware Standard URL Generator überschrieben.</li>
<li>Bei den Canonical-Einstellungen wurde das Feld <code>Externe URL (Canonical Link)</code> vom Typ <code>Url</code> auf den Typ <code>Text</code> angepasst, da ansonsten eine Speicherung der externen URL nicht möglich war.</li>
</ul>
<a name="version-6715"></a>
<h2>Version 6.7.15</h2>
<ul>
<li>Über ein internes Caching der SEO Bulk Einstellungen konnte die Performance der Bulk Generatoren optimiert werden.</li>
</ul>
<a name="version-6714"></a>
<h2>Version 6.7.14</h2>
<ul>
<li>Unterstützung des Live Templates ##shopName## bei Kategorien.</li>
<li>Anpassung der für kommende Versionen als @deprecated markierte Codeelemente.</li>
</ul>
<a name="version-6713"></a>
<h2>Version 6.7.13</h2>
<ul>
<li>Die URL des Logos sowie des Unternehmensstandortes der Rich Snippet Unternehmensdaten konnten nicht gespeichert werden. Dieses Verhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-6712"></a>
<h2>Version 6.7.12</h2>
<ul>
<li>In bestimmten Konstellationen wurde die Live Variable ##shopName## nicht korrekt durch den Shopnamen ersetzt. Dieses Verhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-6711"></a>
<h2>Version 6.7.11</h2>
<ul>
<li>Beim Export von Weiterleitungen wurde eine fehlerhafte URL erstellt, die zu dem folgenden Fehler führte: <code>Requested api version v1 not available, available versions are v2, v3.</code>. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-6710"></a>
<h2>Version 6.7.10</h2>
<ul>
<li>Beim Generieren von Varianten kam es unter bestimmten Umständen zu einem Fehler des Bulk Generators (Call getCategories on null). Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-679"></a>
<h2>Version 6.7.9</h2>
<ul>
<li>Fehler beim Generieren des Canonical Links behoben.</li>
</ul>
<a name="version-678"></a>
<h2>Version 6.7.8</h2>
<ul>
<li>Mit inaktiver Option <code>Rich Snippets über JSON-LD aktivieren</code> wurden in der Storefront keine sprechenden URLs mehr ausgegeben. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-677"></a>
<h2>Version 6.7.7</h2>
<ul>
<li>Aufgrund der Performance Probleme mit dem Shopware DAL wurden die Bulk Generatoren auf Plain SQL umgestellt. Somit wird eine schnellere Datenspeicherung realisiert.</li>
<li>In manchen Fällen wurde die Meta Description nicht korrekt ausgegeben. Dieses Problem wurde nun behoben.</li>
</ul>
<a name="version-676"></a>
<h2>Version 6.7.6</h2>
<ul>
<li>Performance Update der Bulk Generatoren</li>
<li>Template Variablen wurden bei dem erstellen / bearbeiten der Bulk Templates nicht in das Formular übernommen. Dieses Verhalten wurde behoben. </li>
</ul>
<a name="version-675"></a>
<h2>Version 6.7.5</h2>
<ul>
<li>Umstellung der Produkt- und Kategorie Indexer auf die neue EntityIndexer Struktur.</li>
<li>Fehler bei der Darstellung der Canonical-URL Einstellungen behoben.</li>
</ul>
<a name="version-674"></a>
<h2>Version 6.7.4</h2>
<ul>
<li>Es kam zu einer Fehlermeldung, wenn ein anderes Plugin einen Decorator für die Shopware Router Komponente definiert hat. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-673"></a>
<h2>Version 6.7.3</h2>
<ul>
<li>Kompatibilität zu Shopware 6.3.0 hergestellt.</li>
</ul>
<a name="version-672"></a>
<h2>Version 6.7.2</h2>
<ul>
<li>Bei aktivem JSON-LD kam es vor, dass Teile der Rich Snippets Tags trotzdem ausgegeben wurden. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-671"></a>
<h2>Version 6.7.1</h2>
<ul>
<li>In den URls die über den Bulk Generator erstellt werden, können nun auch Sonderzeichen wie der Punkt und das &quot;~&quot;-Zeichen verwendet werden.</li>
<li>Allgemein wurden Sonderzeichen durch den Bulk Generator automatisch escaped. Dieses wurden durch den Twig Renderer verursacht. Die Konfiguration wurde hier nun angepasst, sodass die Sonderzeichen auch als solche dargestellt werden.</li>
</ul>
<a name="version-670"></a>
<h2>Version 6.7.0</h2>
<ul>
<li>Für Facebook und Twitter können ab dieser Version der Titel, die Beschreibungen sowie die Bilder definiert werden, die beim Teilen des Produkts / der Seite ausgegeben werden. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/seo-settings/social-media">SEO Professional » SEO Einstellungen » Social Media</a></li>
<li>Der Titel sowie die Beschreibung für Facebook und Twitter können per Bulk Template erstellt werden.</li>
<li>Die empfohlene Länge sowie die Maximallänge der Facebook und Twitter Titel sowie Beschreibungen können in den Einstellungen selbst definiert werden.</li>
<li>Die Weiterleitungen können nun als CSV Datei importiert sowie exportiert werden. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/redirect/redirect-import-export">Plugin Dokumentationen » SEO Professional » Module » 301 und 302 URL Weiterleitungen » CSV Import und Export der Weiterleitungen</a></li>
<li>Es können nun auch Weiterleitungen an die Startseite konfiguriert werden.</li>
</ul>
<a name="version-660"></a>
<h2>Version 6.6.0</h2>
<ul>
<li>Als Canonical Link wird im Shopware Standard immer der SEO Pfad der jeweiligen Seite übergeben. Ab dieser Version ist es möglich für Produkte und Kategorien abweichende Canonical Links zu hinterlegen. Hierbei kann eine feste externe URL hinterlegt oder aber ein Produkt bzw. eine Kategorie ausgewählt werden, dessen SEO Pfad als Canonical Link verwendet werden soll. Weitere Informationen zu der neuen Einstellung findest du unter: <a href="docs/seo-professional/seo-settings/canonical-urls#canonical-link">SEO Professional » SEO Einstellungen » Canonical Urls » Canonical Link</a></li>
</ul>
<a name="version-652"></a>
<h2>Version 6.5.2</h2>
<ul>
<li>Im Shopware Standard wird das Canonical Links Tag auf der Startseite sowie den Kategorieseiten nicht ausgegeben (Stand Shopware 6.2). Bis dies über den Shopware Standard gewährleistet wird, wird die Ausgabe ab dieser Version über SEO Professional sichergestellt. Weitere Informationen findest du unter: <a href="https://issues.shopware.com/issues/NEXT-8662">https://issues.shopware.com/issues/NEXT-8662</a> </li>
<li>Im Bulk Generator für URLs steht nun der komplette Kategoriebaum zur Auswahl zur Verfügung. Dieser wird entsprechend nicht mehr auf die Kategorien des ausgewählten Sales Channels heruntergebrochen, um eine Auswahl der Service und Footer Seiten zu gewährleisten.</li>
</ul>
<a name="version-651"></a>
<h2>Version 6.5.1</h2>
<ul>
<li>In der Version 6.5.0 kam es zu der Fehlermeldung <code>ltrim() expects parameter 1 to be string, boolean given</code>, wenn ein Saleschannel mit virtueller Domain genutzt wurde. Bspw.: <code>http://www.shop.de/at</code>. Dieses Fehlverhalten wurde mit dieser Version behoben.</li>
</ul>
<a name="version-650"></a>
<h2>Version 6.5.0</h2>
<ul>
<li>Bei den Produkten sowie den Kategorien wurden die Meta-Tags Administration um die  Konfiguration des Robots Tags erweitert. Somit kann nun für die Seiten deifniert werden, ob diese indexiert und Links auf diesen Seiten verfolgt werden sollen. Ausführliche Informationen zu dieser neuen Einstellung findest du unter: <a href="docs/seo-professional/seo-settings/meta-tags#robots-tag">SEO Professional » SEO Einstellungen » Meta Tags » Robots Tag</a></li>
<li>In den SEO Einstellungen kann des Weiteren ein Standard Robots-Tag definiert werden, der verwendet wird, wenn für eine Kategorie bzw. ein Produkt kein Robots-Tag explizit angegeben wurde. Ebenfalls kann auch die neue Option <code>Noindex Request Parameter Query</code> definiert werden, über die Bedingungen konfiguriert werden können, die dafür sorgen, dass ein Robots-Tag auf <code>noindex</code> umgestellt wird. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/settings/seo-settings">SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta Tags</a></li>
<li>Über den <code>Produkt-</code> sowie den <code>Kategorie Bulk Generator</code> können jetzt auch die Einstellungen für den Robots Tag definiert werden.</li>
<li>Möchtest du dir für ein Produkt bzw. eine Kategorie die SERP Vorschau anschauen oder aber die Canonical Url bearbeiten, so musst du zuvor immer erst den Verkaufskanel auswählen den du bearbeiten möchtest. Um die Workflows hier zu erleichtern kannst du nun jeweils einen Verkaufskanel als Vorauswahl definieren. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/settings/seo-settings">SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta Tags</a></li>
</ul>
<a name="version-642"></a>
<h2>Version 6.4.2</h2>
<ul>
<li>Bei den Migrationen findet bei den Rückgabewerten der Methode <code>getCreationTimestamp</code>jetzt eine explizite Datentypumwandlung auf den Datentyp <code>int</code> statt, da das Plugin ansonsten unter bestimmten Serverbedingungen nicht installiert werden konnte.</li>
<li>Die Anpassungen der Version 6.0.2 bzgl. Löschen der Weiterleitungen in der Administration hat in Produktivsystemen mit aktivem Cache noch nicht funktioniert. Ab dieser Version wird der Cache Tag der jeweiligen Weiterleitung geleert.</li>
</ul>
<a name="version-641"></a>
<h2>Version 6.4.1</h2>
<ul>
<li>Die Methode <code>extractInheritableAttributes</code> der <code>Klasse DreiscSeoPro\\Decorator\\Shopware\\Storefront\\Routing\\RequestTransformerDecorator</code> hatte keinen Rückgabewert. Dies führte dazu, dass es teilweise bei der Registrierung zu einer Fehlermeldung kam. Dieses Fehlverhalten wurde behoben. </li>
</ul>
<a name="version-640"></a>
<h2>Version 6.4.0</h2>
<ul>
<li>Die Rich Snippets Konfiguration wurde um die Bereiche <code>Logo</code> und <code>Lokales Unternehmen</code> erweitert. Weitere Informationen hierzu findest du unter <a href="docs/seo-professional/modules/rich-snippets-json-ld/organization">SEO Professional » Module » Rich Snippets (JSON-LD) » Unternehmen</a></li>
<li>Die Konfigurationen der Rich Snippets Einstellungen können nun pro Sales Channel hinterlegt werden.</li>
<li>Bei den abweichenden Werten für die Rich Snippets, die unter <a href="docs/seo-professional/seo-settings/rich-snippet">SEO Professional » SEO Einstellungen » Rich Snippets</a> konfiguriert werden können, wurde die Vererbung bei Varianten implementiert.  </li>
</ul>
<a name="version-630"></a>
<h2>Version 6.3.0</h2>
<ul>
<li>Es ist nun möglich Rich Snippets der Bereiche <code>Produkt</code> und <code>Breadcrumb</code> über SEO Professional auszugeben. Die standardmäßig vorhandenen Rich Snippet Mircodaten werden aus dem Quellcode entfernt und durch JSON-LD Daten ersetzt. Informationen zu den Einstellungsmöglichkeiten findest du unter: <a href="docs/seo-professional/modules/rich-snippets-json-ld">SEO Professional » Module » Rich Snippets (JSON-LD)</a></li>
</ul>
<a name="version-620"></a>
<h2>Version 6.2.0</h2>
<ul>
<li>Die empfohlene sowie die maximale Zeichen- bzw. Pixellänge der Meta Tags kann nun konfiguriert werden. Die Einstellungen hierzu findest du unter <code>SEO Professional » Einstellugen</code>. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/settings/seo-settings">SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta Tags</a></li>
</ul>
<a name="version-610"></a>
<h2>Version 6.1.0</h2>
<ul>
<li>Die Bulk Generatoren können jetzt auch direkt über die Adminstration gestartet werden. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/bulk-generators/execute-bulk-generator#2-moeglichkeit-bulk-generatoren-ueber-die-administration-starten">Bulk Generator ausführen</a></li>
</ul>
<a name="version-602"></a>
<h2>Version 6.0.2</h2>
<ul>
<li>Die Weiterleitungen wurden bei aktivem HTTP Cache nicht direkt übernommen. Dieses Verhalten wurde entsprechend angepasst.</li>
<li>Das Löschen der Weiterleitungen hat mit der aktuellen Version nicht mehr funktioniert, da das Shopware DAL diese nicht löschen konnte. Daher wurde das Löschen der Weiterleitungen auf Plain SQL umgestellt und ein Ticket bei der shopware AG eröffnet. (<a href="https://issues.shopware.com/issues/NEXT-7866">https://issues.shopware.com/issues/NEXT-7866</a>)</li>
</ul>
<a name="version-601"></a>
<h2>Version 6.0.1</h2>
<ul>
<li>In dieser Version wurde das Icon für die Plugin Manager hinzugefügt.</li>
</ul>
<a name="version-600"></a>
<h2>Version 6.0.0</h2>
<ul>
<li>Initiales Release für Shopware 6. Zum aktuellen Zeitpunkt stehen noch nicht alle Funktionen bereit die unter Shopware 5 bei SEO Professional möglich waren. Diese und noch weitere Funktionen werden im Laufe der kommeden Wochen / Monate nach und nach erweitert. Angedacht sind hierbei aktuell monatliche Updates.</li>
</ul>
<p></p>',
  ),
);