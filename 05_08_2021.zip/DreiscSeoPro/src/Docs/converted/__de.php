<?php return array (
  'DE' => 
  array (
    'path' => '',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional',
    'title' => 'SEO Professional',
    'menuTitle' => 'SEO Professional',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SEO Professional</h1>
<p>Das Plugin SEO Professional vereint eine große Anzahl an SEO Einstellungen / Optimierung in nur einem Plugin. Hierbei setzt das Plugin da an, wo Shopware aufhört und unterstützt Dich dabei dein Ranking bei den Suchmaschinen zu optimieren.</p>
<p>In dieser Dokumentation findest du alle relevanten Informationen zur Bedienung und Adminstration des Plugins.</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/first-steps" class="nav--link link--entry">Erste Schritte</a></li><li class="nav--entry"><a href="/docs/seo-professional/changelog" class="nav--link link--entry">Changelog</a></li></ul><h2 class="sub-headline">Unterkategorien</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/seo-settings" class="nav--link link--entry">SEO Einstellungen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules" class="nav--link link--entry">SEO Professional Module</a></li></ul></p>',
  ),
  'EN' => 
  array (
    'path' => '',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional',
    'title' => 'SEO Professional',
    'menuTitle' => 'SEO Professional',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SEO Professional</h1>
<p>Das Plugin SEO Professional vereint eine große Anzahl an SEO Einstellungen / Optimierung in nur einem Plugin. Hierbei setzt das Plugin da an, wo Shopware aufhört und unterstützt Dich dabei dein Ranking bei den Suchmaschinen zu optimieren.</p>
<p>In dieser Dokumentation findest du alle relevanten Informationen zur Bedienung und Adminstration des Plugins.</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/first-steps" class="nav--link link--entry">Erste Schritte</a></li><li class="nav--entry"><a href="/docs/seo-professional/changelog" class="nav--link link--entry">Changelog</a></li></ul><h2 class="sub-headline">Unterkategorien</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/seo-settings" class="nav--link link--entry">SEO Einstellungen</a></li><li class="nav--entry"><a href="/docs/seo-professional/modules" class="nav--link link--entry">SEO Professional Module</a></li></ul></p>',
  ),
);