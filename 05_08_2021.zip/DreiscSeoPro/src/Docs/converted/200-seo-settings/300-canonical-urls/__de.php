<?php return array (
  'DE' => 
  array (
    'path' => 'de_200-seo-settings/300-canonical-urls',
    'parent' => 'de_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/canonical-urls',
    'title' => 'Canonical Urls',
    'menuTitle' => 'Canonical Urls',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Canonical Urls</h1>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#einfuehrung">Einführung</a></li><li class="headline-level2"><a href="#seo-pfad">SEO Pfad</a></li><li class="headline-level3"><a href="#ausgabe-der-bulk-informationen">Ausgabe der Bulk Informationen</a></li><li class="headline-level2"><a href="#canonical-link">Canonical Link</a></li></ul></div></p>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>Bei der Konfiguration der Canonical Urls handelt es sich um die Shopware Standard Konfiguration der Canonical Urls, die durch SEO Professional jedoch entsprechend erweitert / aufbereitet wird.</p>
<p><a data-dreisccmslightbox="images-896756" data-title="Konfiguration der Canonical Urls" href="wiki/dreisc_seo_pro/200-seo-settings/300-canonical-urls/lightbox/canonical-url-panel.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/300-canonical-urls/lightbox/canonical-url-panel.png" alt="Konfiguration der Canonical Urls">
                        </a></p>
<a name="seo-pfad"></a>
<h2>SEO Pfad</h2>
<a name="ausgabe-der-bulk-informationen"></a>
<h3>Ausgabe der Bulk Informationen</h3>
<p>Über die Bulk Generatoren kann das Generierung der Canonical Urls automatisiert werden. (siehe: <a href="docs/seo-professional/modules/bulk-generators">Module » Produkt- und Kategorie Bulk Generator</a>) Damit du auf einen Blick siehst, ob eine Url per Bulk generiert wurde bzw. generiert wird, wird die Bulk Konfiguration direkt mitgeladen und unterhalb des SEO Pfads ausgegeben. </p>
<p>Dies ist besonders dann relevant, wenn für die Bulk Konfiguration die Option &quot;Werte überschrieben&quot; aktiv ist. In diesem Fall wird zusätzlich der Hinweis ausgegeben, dass Änderungen an diesem Feld wieder überschrieben werden. </p>
<p>Des Weiteren kann mit einem Klick auf den Namen der Bulk Konfiguration diese direkt geöffnet werden.</p>
<a name="canonical-link"></a>
<h2>Canonical Link</h2>
<p>Standardmäßig wird der SEO Pfad auch als Canonical Link ausgegeben. In manchen Fällen ist es jedoch erforderlich, dass der Canonical Link auf ein anderes Produkt, Kategorie bzw. andere Seite zeigt.</p>
<p>Ein Beispiel hierfür könnte sein, dass du ein Produkt mit mehreren Varianten hast, sich die Beschreibungstexte der Varianten aber kaum / gar nicht unterscheiden. In diesem Fall macht es Sinn die Canonical Links aller Varianten auf die Url einer definierten Variante zu setzen, um doppelten Kontent zu vermeiden.</p>
<p>Über das Feld <code>Canonical Link</code> können die folgenden Ziel-Typen definiert werden:</p>
<ul>
<li>
<p><strong>Den SEO Pfad als Canonical Link ausgeben</strong><br>Hierbei handelt es sich um das Standardverhalten. Als Canonical Link wird also entsprechend der SEO Pfad, sprich die sprechende Url des Produkts / Kategorie ausgegeben.</p>
</li>
<li>
<p><strong>Externe Url als Canonical Link ausgeben</strong><br>Wird diese Option ausgewählt, so wird das Feld <code>Externe URL (Canonical Link)</code> angezeigt. Die hier definierte URL wird als Canonical ausgegeben.</p>
</li>
<li>
<p><strong>URL eines Produkts als Canonical Link ausgeben</strong><br>Wird diese Option ausgewählt, so wird das Feld <code>Produkt (Canonical Link)</code> angezeigt. Hier kann anschließend ein Produkt ausgewählt werden, dessen SEO Pfad als Canonical Link definiert werden soll.</p>
</li>
<li>
<p><strong>URL einer Kategorie als Canonical Link ausgeben</strong><br>Wird diese Option ausgewählt, so wird das Feld <code>Kategorie (Canonical Link)</code> angezeigt. Hier kann anschließend eine Kategorie ausgewählt werden, dessen SEO Pfad als Canonical Link definiert werden soll.</p>
</li>
</ul>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_200-seo-settings/300-canonical-urls',
    'parent' => 'en_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/canonical-urls',
    'title' => 'Canonical Urls',
    'menuTitle' => 'Canonical Urls',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Canonical Urls</h1>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#einfuehrung">Einführung</a></li><li class="headline-level2"><a href="#seo-pfad">SEO Pfad</a></li><li class="headline-level3"><a href="#ausgabe-der-bulk-informationen">Ausgabe der Bulk Informationen</a></li><li class="headline-level2"><a href="#canonical-link">Canonical Link</a></li></ul></div></p>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>Bei der Konfiguration der Canonical Urls handelt es sich um die Shopware Standard Konfiguration der Canonical Urls, die durch SEO Professional jedoch entsprechend erweitert / aufbereitet wird.</p>
<p><a data-dreisccmslightbox="images-858341" data-title="Konfiguration der Canonical Urls" href="wiki/dreisc_seo_pro/200-seo-settings/300-canonical-urls/lightbox/canonical-url-panel.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/300-canonical-urls/lightbox/canonical-url-panel.png" alt="Konfiguration der Canonical Urls">
                        </a></p>
<a name="seo-pfad"></a>
<h2>SEO Pfad</h2>
<a name="ausgabe-der-bulk-informationen"></a>
<h3>Ausgabe der Bulk Informationen</h3>
<p>Über die Bulk Generatoren kann das Generierung der Canonical Urls automatisiert werden. (siehe: <a href="docs/seo-professional/modules/bulk-generators">Module » Produkt- und Kategorie Bulk Generator</a>) Damit du auf einen Blick siehst, ob eine Url per Bulk generiert wurde bzw. generiert wird, wird die Bulk Konfiguration direkt mitgeladen und unterhalb des SEO Pfads ausgegeben. </p>
<p>Dies ist besonders dann relevant, wenn für die Bulk Konfiguration die Option &quot;Werte überschrieben&quot; aktiv ist. In diesem Fall wird zusätzlich der Hinweis ausgegeben, dass Änderungen an diesem Feld wieder überschrieben werden. </p>
<p>Des Weiteren kann mit einem Klick auf den Namen der Bulk Konfiguration diese direkt geöffnet werden.</p>
<a name="canonical-link"></a>
<h2>Canonical Link</h2>
<p>Standardmäßig wird der SEO Pfad auch als Canonical Link ausgegeben. In manchen Fällen ist es jedoch erforderlich, dass der Canonical Link auf ein anderes Produkt, Kategorie bzw. andere Seite zeigt.</p>
<p>Ein Beispiel hierfür könnte sein, dass du ein Produkt mit mehreren Varianten hast, sich die Beschreibungstexte der Varianten aber kaum / gar nicht unterscheiden. In diesem Fall macht es Sinn die Canonical Links aller Varianten auf die Url einer definierten Variante zu setzen, um doppelten Kontent zu vermeiden.</p>
<p>Über das Feld <code>Canonical Link</code> können die folgenden Ziel-Typen definiert werden:</p>
<ul>
<li>
<p><strong>Den SEO Pfad als Canonical Link ausgeben</strong><br>Hierbei handelt es sich um das Standardverhalten. Als Canonical Link wird also entsprechend der SEO Pfad, sprich die sprechende Url des Produkts / Kategorie ausgegeben.</p>
</li>
<li>
<p><strong>Externe Url als Canonical Link ausgeben</strong><br>Wird diese Option ausgewählt, so wird das Feld <code>Externe URL (Canonical Link)</code> angezeigt. Die hier definierte URL wird als Canonical ausgegeben.</p>
</li>
<li>
<p><strong>URL eines Produkts als Canonical Link ausgeben</strong><br>Wird diese Option ausgewählt, so wird das Feld <code>Produkt (Canonical Link)</code> angezeigt. Hier kann anschließend ein Produkt ausgewählt werden, dessen SEO Pfad als Canonical Link definiert werden soll.</p>
</li>
<li>
<p><strong>URL einer Kategorie als Canonical Link ausgeben</strong><br>Wird diese Option ausgewählt, so wird das Feld <code>Kategorie (Canonical Link)</code> angezeigt. Hier kann anschließend eine Kategorie ausgewählt werden, dessen SEO Pfad als Canonical Link definiert werden soll.</p>
</li>
</ul>
<p></p>',
  ),
);