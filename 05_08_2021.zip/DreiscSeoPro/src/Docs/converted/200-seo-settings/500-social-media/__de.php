<?php return array (
  'DE' => 
  array (
    'path' => 'de_200-seo-settings/500-social-media',
    'parent' => 'de_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/social-media',
    'title' => 'Social Media',
    'menuTitle' => 'Social Media',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Social Media</h1>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#einfuehrung">Einführung</a></li><li class="headline-level2"><a href="#facebook">Facebook</a></li><li class="headline-level2"><a href="#twitter">Twitter</a></li><li class="headline-level2"><a href="#konfiguration-der-standard-facebook-und-twitter-laengenwerte">Konfiguration der Standard Facebook und Twitter Längenwerte</a></li></ul></div></p>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>Über die Konfiguration der Social Media Felder bist du in der Lage Einfluss auf die Erscheinung deiner Shopseiten zu nehmen, die auf den Social Media Plattformen geteilt werden.</p>
<a name="facebook"></a>
<h2>Facebook</h2>
<p>Über die Facebook OpenGraph Angaben kannst du definieren, mit welchem Titel, Beschreibung sowie Bild das jeweilige Produkt bzw. die jeweilige Seite angezeigt werden soll, wenn dieses bei Facebook geteilt wird.</p>
<p>Hierzu stehen dir an dieser Stelle die Felder: <code>Facebook Titel</code>, <code>Facebook Beschreibung</code> sowie <code>Facebook Bild</code> zur Verfügung.</p>
<p>Über den Sharing Debugger von Facebook kannst du überprüfen, wie anschließend das Resultat deiner Konfiguration aussieht. Diesen findest Du unter: <a href="https://developers.facebook.com/tools/debug/sharing">https://developers.facebook.com/tools/debug/sharing</a></p>
<p><a data-dreisccmslightbox="images-249614" data-title="Verfügbare Facebook OpenGraph Einstellungen" href="wiki/dreisc_seo_pro/200-seo-settings/500-social-media/lightbox/facebook.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/500-social-media/lightbox/facebook.png" alt="Verfügbare Facebook OpenGraph Einstellungen">
                        </a></p>
<a name="twitter"></a>
<h2>Twitter</h2>
<p>Durch Twitter Cards hast die Möglichkeit weitere Informationen zum Produkt bzw. zur aktuellen Seite zu übergeben. Diese werden als Twitter Card ausgegeben, wenn jemand dein Produkt auf Twitter teilt.</p>
<p>Über den Card Validator von Twitter kannst Du überprüfen, wie anschließend das Resultat deiner Konfiguration aussieht. Diesen findest Du unter: <a href="https://cards-dev.twitter.com/validator">https://cards-dev.twitter.com/validator</a></p>
<p><a data-dreisccmslightbox="images-249614" data-title="Verfügbare Twitter Cards Einstellungen" href="wiki/dreisc_seo_pro/200-seo-settings/500-social-media/lightbox/twitter.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/500-social-media/lightbox/twitter.png" alt="Verfügbare Twitter Cards Einstellungen">
                        </a></p>
<a name="konfiguration-der-standard-facebook-und-twitter-laengenwerte"></a>
<h2>Konfiguration der Standard Facebook und Twitter Längenwerte</h2>
<p>Die empfohlene Längen bzw. Maximalwerte für die Facebook und Twitter Felder können auf die eigenen Bedürfnisse angepasst und umkonfiguriert werden. Weitere Informationen zu den Einstellungen findest du unter: <a href="docs/seo-professional/modules/settings/seo-settings#social-media">SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Social Media</a></p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_200-seo-settings/500-social-media',
    'parent' => 'en_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/social-media',
    'title' => 'Social Media',
    'menuTitle' => 'Social Media',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Social Media</h1>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#einfuehrung">Einführung</a></li><li class="headline-level2"><a href="#facebook">Facebook</a></li><li class="headline-level2"><a href="#twitter">Twitter</a></li><li class="headline-level2"><a href="#konfiguration-der-standard-facebook-und-twitter-laengenwerte">Konfiguration der Standard Facebook und Twitter Längenwerte</a></li></ul></div></p>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>Über die Konfiguration der Social Media Felder bist du in der Lage Einfluss auf die Erscheinung deiner Shopseiten zu nehmen, die auf den Social Media Plattformen geteilt werden.</p>
<a name="facebook"></a>
<h2>Facebook</h2>
<p>Über die Facebook OpenGraph Angaben kannst du definieren, mit welchem Titel, Beschreibung sowie Bild das jeweilige Produkt bzw. die jeweilige Seite angezeigt werden soll, wenn dieses bei Facebook geteilt wird.</p>
<p>Hierzu stehen dir an dieser Stelle die Felder: <code>Facebook Titel</code>, <code>Facebook Beschreibung</code> sowie <code>Facebook Bild</code> zur Verfügung.</p>
<p>Über den Sharing Debugger von Facebook kannst du überprüfen, wie anschließend das Resultat deiner Konfiguration aussieht. Diesen findest Du unter: <a href="https://developers.facebook.com/tools/debug/sharing">https://developers.facebook.com/tools/debug/sharing</a></p>
<p><a data-dreisccmslightbox="images-896586" data-title="Verfügbare Facebook OpenGraph Einstellungen" href="wiki/dreisc_seo_pro/200-seo-settings/500-social-media/lightbox/facebook.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/500-social-media/lightbox/facebook.png" alt="Verfügbare Facebook OpenGraph Einstellungen">
                        </a></p>
<a name="twitter"></a>
<h2>Twitter</h2>
<p>Durch Twitter Cards hast die Möglichkeit weitere Informationen zum Produkt bzw. zur aktuellen Seite zu übergeben. Diese werden als Twitter Card ausgegeben, wenn jemand dein Produkt auf Twitter teilt.</p>
<p>Über den Card Validator von Twitter kannst Du überprüfen, wie anschließend das Resultat deiner Konfiguration aussieht. Diesen findest Du unter: <a href="https://cards-dev.twitter.com/validator">https://cards-dev.twitter.com/validator</a></p>
<p><a data-dreisccmslightbox="images-896586" data-title="Verfügbare Twitter Cards Einstellungen" href="wiki/dreisc_seo_pro/200-seo-settings/500-social-media/lightbox/twitter.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/500-social-media/lightbox/twitter.png" alt="Verfügbare Twitter Cards Einstellungen">
                        </a></p>
<a name="konfiguration-der-standard-facebook-und-twitter-laengenwerte"></a>
<h2>Konfiguration der Standard Facebook und Twitter Längenwerte</h2>
<p>Die empfohlene Längen bzw. Maximalwerte für die Facebook und Twitter Felder können auf die eigenen Bedürfnisse angepasst und umkonfiguriert werden. Weitere Informationen zu den Einstellungen findest du unter: <a href="docs/seo-professional/modules/settings/seo-settings#social-media">SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Social Media</a></p>
<p></p>',
  ),
);