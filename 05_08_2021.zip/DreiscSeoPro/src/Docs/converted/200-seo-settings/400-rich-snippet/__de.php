<?php return array (
  'DE' => 
  array (
    'path' => 'de_200-seo-settings/400-rich-snippet',
    'parent' => 'de_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/rich-snippet',
    'title' => 'Rich Snippets',
    'menuTitle' => 'Rich Snippets',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Rich Snippets</h1>
<p><em>Diese Einstellung steht lediglich für Produkte zur Verfügung.</em>
<div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#einfuehrung">Einführung</a></li><li class="headline-level2"><a href="#konfigurationsfelder">Konfigurationsfelder</a></li></ul></div></p>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>Über SEO Professional hast du die Möglichkeit Rich Snippets über JSON-LD einzubinden. Ist dies gewünscht, muss sichergestellt werden, dass die Einstellung <code>Rich Snippets über JSON-LD aktivieren</code> unter <code>SEO Professional » Rich Snippets (JSON-LD) » Allgemein</code> aktiviert ist.</p>
<p>Unter <code>SEO Professional » Rich Snippets (JSON-LD)</code> hast du die Möglichkeit Standardwerte und -verhalten festzulegen, die bei den Rich Snippets zum Einsatz kommen. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/rich-snippets-json-ld">SEO Professional » Module » Rich Snippets (JSON-LD)</a></p>
<a name="konfigurationsfelder"></a>
<h2>Konfigurationsfelder</h2>
<p>Bei der Konfiguration der Rich Snippets in den SEO Einstellungen des jeweiligen Produkts, ist es möglich abweichende Werte zu definieren, die dann statt der definierten Standardwerte ausgegeben werden.</p>
<p>Es liegen die folgenden Felder vor, um abweichende Werte zu definieren:</p>
<ul>
<li>Abweichender Produktzustand</li>
<li>Abweichende Produktverfügbarkeit</li>
<li>Abweichende händlerspezifische Kennung (sku)</li>
<li>Abweichende Herstellerteile-Nummer (mpn)</li>
<li>Abweichendes &quot;Preis gültig bis&quot;-Datum (priceValidUntil)</li>
</ul>
<p><a data-dreisccmslightbox="images-882308" data-title="Abweichende Rich Snippet Einstellungen konfigurieren" href="wiki/dreisc_seo_pro/200-seo-settings/400-rich-snippet/lightbox/rich-snippets-einstellungen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/400-rich-snippet/lightbox/rich-snippets-einstellungen.png" alt="Abweichende Rich Snippet Einstellungen konfigurieren">
                        </a></p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_200-seo-settings/400-rich-snippet',
    'parent' => 'en_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/rich-snippet',
    'title' => 'Rich Snippets',
    'menuTitle' => 'Rich Snippets',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Rich Snippets</h1>
<p><em>Diese Einstellung steht lediglich für Produkte zur Verfügung.</em>
<div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#einfuehrung">Einführung</a></li><li class="headline-level2"><a href="#konfigurationsfelder">Konfigurationsfelder</a></li></ul></div></p>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>Über SEO Professional hast du die Möglichkeit Rich Snippets über JSON-LD einzubinden. Ist dies gewünscht, muss sichergestellt werden, dass die Einstellung <code>Rich Snippets über JSON-LD aktivieren</code> unter <code>SEO Professional » Rich Snippets (JSON-LD) » Allgemein</code> aktiviert ist.</p>
<p>Unter <code>SEO Professional » Rich Snippets (JSON-LD)</code> hast du die Möglichkeit Standardwerte und -verhalten festzulegen, die bei den Rich Snippets zum Einsatz kommen. Weitere Informationen hierzu findest du unter: <a href="docs/seo-professional/modules/rich-snippets-json-ld">SEO Professional » Module » Rich Snippets (JSON-LD)</a></p>
<a name="konfigurationsfelder"></a>
<h2>Konfigurationsfelder</h2>
<p>Bei der Konfiguration der Rich Snippets in den SEO Einstellungen des jeweiligen Produkts, ist es möglich abweichende Werte zu definieren, die dann statt der definierten Standardwerte ausgegeben werden.</p>
<p>Es liegen die folgenden Felder vor, um abweichende Werte zu definieren:</p>
<ul>
<li>Abweichender Produktzustand</li>
<li>Abweichende Produktverfügbarkeit</li>
<li>Abweichende händlerspezifische Kennung (sku)</li>
<li>Abweichende Herstellerteile-Nummer (mpn)</li>
<li>Abweichendes &quot;Preis gültig bis&quot;-Datum (priceValidUntil)</li>
</ul>
<p><a data-dreisccmslightbox="images-995780" data-title="Abweichende Rich Snippet Einstellungen konfigurieren" href="wiki/dreisc_seo_pro/200-seo-settings/400-rich-snippet/lightbox/rich-snippets-einstellungen.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/400-rich-snippet/lightbox/rich-snippets-einstellungen.png" alt="Abweichende Rich Snippet Einstellungen konfigurieren">
                        </a></p>
<p></p>',
  ),
);