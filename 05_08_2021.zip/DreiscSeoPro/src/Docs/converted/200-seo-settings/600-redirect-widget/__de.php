<?php return array (
  'DE' => 
  array (
    'path' => 'de_200-seo-settings/600-redirect-widget',
    'parent' => 'de_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/redirect-widget',
    'title' => 'Weiterleitungs-Widget',
    'menuTitle' => 'Weiterleitungs-Widget',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Weiterleitungs-Widget</h1>
<p>Bzgl. der Weiterleitungen wird im SEO Tab ein Widget für die Darstellung der Informationen bestehender Weiterleitung bzw. zur Erstellung von Weiterleitungen für das jeweilige Produkt bzw. Kategorie ausgegeben.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#widget-bei-bestehender-weiterleitung">Widget bei bestehender Weiterleitung</a></li><li class="headline-level3"><a href="#detailinformationen-zur-weiterleitung-anzeigen">Detailinformationen zur Weiterleitung anzeigen</a></li><li class="headline-level2"><a href="#widget-bei-nicht-vorhandener-weiterleitung">Widget bei nicht vorhandener Weiterleitung</a></li><li class="headline-level2"><a href="#weitere-informationen-zu-den-weiterleitungen">Weitere Informationen zu den Weiterleitungen</a></li></ul></div></p>
<a name="widget-bei-bestehender-weiterleitung"></a>
<h2>Widget bei bestehender Weiterleitung</h2>
<p>Wurde für ein Produkt bzw. eine Kategorie bereits eine Weiterleitung definiert, so findest du in dem jeweiligen Modul eine entsprechende Hinweisbox ganz oben im ersten Tab
<a data-dreisccmslightbox="images-991680" data-title="Widget bei bestehender Weiterleitung" href="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-bestehende-weiterleitung.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-bestehende-weiterleitung.png" alt="Widget bei bestehender Weiterleitung">
                        </a></p>
<a name="detailinformationen-zur-weiterleitung-anzeigen"></a>
<h3>Detailinformationen zur Weiterleitung anzeigen</h3>
<p>Um weitere Informationen der Weiterleitung anzeigen zu lassen, reicht ein Klick auf die Schaltfäche <code>Details anzeigen</code>. Neben zusätzlichen Informationen wird so auch die Schaltfläche <code>Konfiguration der Weiterleitung öffnen</code> sichtbar, über die die Konfiguration der Weiterleitung geöffnet werden kann.
<a data-dreisccmslightbox="images-991680" data-title="Widget bei bestehender Weiterleitung" href="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-bestehende-weiterleitung-mit-details.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-bestehende-weiterleitung-mit-details.png" alt="Widget bei bestehender Weiterleitung">
                        </a></p>
<a name="widget-bei-nicht-vorhandener-weiterleitung"></a>
<h2>Widget bei nicht vorhandener Weiterleitung</h2>
<p>Wurde für ein Produkt bzw. eine Kategorie noch keine Weiterleitung hinterlegt, so findest du ganz unten in dem SEO Tab das Widget zur Erstellung einer Weiterleitung.</p>
<p><a data-dreisccmslightbox="images-991680" data-title="Infobox, dass keine Weiterleitung vorliegt" href="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-keine-weiterleitung.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-keine-weiterleitung.png" alt="Infobox, dass keine Weiterleitung vorliegt">
                        </a></p>
<p>Mit einem Klick auf die Schaltfläche <code>Jetzt eine Weiterleitung für dieses Produkt erstellen</code> bzw. <code>Jetzt eine Weiterleitung für diese Kategorie erstellen</code> wird der Dialog zur Erstellung einer Weiterleitung automatisch geöffnet. Hierbei ist als Weiterleitungs-Quelle dann bereits das Produkt bzw. die Kategorie vorausgewählt.
<a data-dreisccmslightbox="images-991680" data-title="Das Produkt bzw. die Kategorie ist bereits vorausgewählt" href="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-vorauswahl-der-kategorie.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-vorauswahl-der-kategorie.png" alt="Das Produkt bzw. die Kategorie ist bereits vorausgewählt">
                        </a></p>
<a name="weitere-informationen-zu-den-weiterleitungen"></a>
<h2>Weitere Informationen zu den Weiterleitungen</h2>
<p>Weitere Informationen zu der Konfiguration von Weiterleitungen findest du unter:
<a href="docs/seo-professional/modules/redirect">SEO Professional » Module » 301 und 302 URL Weiterleitungen</a></p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_200-seo-settings/600-redirect-widget',
    'parent' => 'en_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/redirect-widget',
    'title' => 'Weiterleitungs-Widget',
    'menuTitle' => 'Weiterleitungs-Widget',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>Weiterleitungs-Widget</h1>
<p>Bzgl. der Weiterleitungen wird im SEO Tab ein Widget für die Darstellung der Informationen bestehender Weiterleitung bzw. zur Erstellung von Weiterleitungen für das jeweilige Produkt bzw. Kategorie ausgegeben.</p>
<p><div class="table-of-content"><h2>Inhaltsverzeichnis</h2><ul><li class="headline-level2"><a href="#widget-bei-bestehender-weiterleitung">Widget bei bestehender Weiterleitung</a></li><li class="headline-level3"><a href="#detailinformationen-zur-weiterleitung-anzeigen">Detailinformationen zur Weiterleitung anzeigen</a></li><li class="headline-level2"><a href="#widget-bei-nicht-vorhandener-weiterleitung">Widget bei nicht vorhandener Weiterleitung</a></li><li class="headline-level2"><a href="#weitere-informationen-zu-den-weiterleitungen">Weitere Informationen zu den Weiterleitungen</a></li></ul></div></p>
<a name="widget-bei-bestehender-weiterleitung"></a>
<h2>Widget bei bestehender Weiterleitung</h2>
<p>Wurde für ein Produkt bzw. eine Kategorie bereits eine Weiterleitung definiert, so findest du in dem jeweiligen Modul eine entsprechende Hinweisbox ganz oben im ersten Tab
<a data-dreisccmslightbox="images-537492" data-title="Widget bei bestehender Weiterleitung" href="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-bestehende-weiterleitung.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-bestehende-weiterleitung.png" alt="Widget bei bestehender Weiterleitung">
                        </a></p>
<a name="detailinformationen-zur-weiterleitung-anzeigen"></a>
<h3>Detailinformationen zur Weiterleitung anzeigen</h3>
<p>Um weitere Informationen der Weiterleitung anzeigen zu lassen, reicht ein Klick auf die Schaltfäche <code>Details anzeigen</code>. Neben zusätzlichen Informationen wird so auch die Schaltfläche <code>Konfiguration der Weiterleitung öffnen</code> sichtbar, über die die Konfiguration der Weiterleitung geöffnet werden kann.
<a data-dreisccmslightbox="images-537492" data-title="Widget bei bestehender Weiterleitung" href="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-bestehende-weiterleitung-mit-details.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-bestehende-weiterleitung-mit-details.png" alt="Widget bei bestehender Weiterleitung">
                        </a></p>
<a name="widget-bei-nicht-vorhandener-weiterleitung"></a>
<h2>Widget bei nicht vorhandener Weiterleitung</h2>
<p>Wurde für ein Produkt bzw. eine Kategorie noch keine Weiterleitung hinterlegt, so findest du ganz unten in dem SEO Tab das Widget zur Erstellung einer Weiterleitung.</p>
<p><a data-dreisccmslightbox="images-537492" data-title="Infobox, dass keine Weiterleitung vorliegt" href="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-keine-weiterleitung.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-widget-keine-weiterleitung.png" alt="Infobox, dass keine Weiterleitung vorliegt">
                        </a></p>
<p>Mit einem Klick auf die Schaltfläche <code>Jetzt eine Weiterleitung für dieses Produkt erstellen</code> bzw. <code>Jetzt eine Weiterleitung für diese Kategorie erstellen</code> wird der Dialog zur Erstellung einer Weiterleitung automatisch geöffnet. Hierbei ist als Weiterleitungs-Quelle dann bereits das Produkt bzw. die Kategorie vorausgewählt.
<a data-dreisccmslightbox="images-537492" data-title="Das Produkt bzw. die Kategorie ist bereits vorausgewählt" href="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-vorauswahl-der-kategorie.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/600-redirect-widget/lightbox/seo-tab-vorauswahl-der-kategorie.png" alt="Das Produkt bzw. die Kategorie ist bereits vorausgewählt">
                        </a></p>
<a name="weitere-informationen-zu-den-weiterleitungen"></a>
<h2>Weitere Informationen zu den Weiterleitungen</h2>
<p>Weitere Informationen zu der Konfiguration von Weiterleitungen findest du unter:
<a href="docs/seo-professional/modules/redirect">SEO Professional » Module » 301 und 302 URL Weiterleitungen</a></p>
<p></p>',
  ),
);