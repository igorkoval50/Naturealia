<?php return array (
  'DE' => 
  array (
    'path' => 'de_200-seo-settings',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional/seo-settings',
    'title' => 'SEO Einstellungen',
    'menuTitle' => 'SEO Einstellungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SEO Einstellungen</h1>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>SEO Professional erweitert bei den jeweiligen Shopware Modulen (Artikel, Kategorien usw.) die Einstellungen um einen zusätzlichen SEO Tab. Alle SEO Einstellungen aus dem Shopware Standard und die SEO Einstellungen von SEO Professional werden an dieser Stelle zentral zur Verfügung gestellt. Die Standard-Felder der Konfiguration der Meta-Tags sowie der Canonical Url sind entsprechend nicht mehr an der Originalstelle zu finden, sondern werden mit der Installation des Plugins in den neuen Tab verschoben.</p>
<p><a data-dreisccmslightbox="images-944787" data-title="SEO Tab im Produkt Module" href="wiki/dreisc_seo_pro/200-seo-settings/lightbox/seo-tab.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/lightbox/seo-tab.png" alt="SEO Tab im Produkt Module">
                        </a></p>
<a name="dokumentation-der-einzelnen-seo-einstellungen"></a>
<h2>Dokumentation der einzelnen SEO Einstellungen</h2>
<p>Die Beschreibungen zu den jeweiligen SEO Einstellungen finden Sie auf den folgenden Unterseiten.</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/meta-tags" class="nav--link link--entry">Meta Tags</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/serp-preview" class="nav--link link--entry">SERP Vorschau</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/canonical-urls" class="nav--link link--entry">Canonical Urls</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/rich-snippet" class="nav--link link--entry">Rich Snippets</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/social-media" class="nav--link link--entry">Social Media</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/redirect-widget" class="nav--link link--entry">Weiterleitungs-Widget</a></li></ul></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_200-seo-settings',
    'parent' => '',
    'seoUrl' => 'docs/seo-professional/seo-settings',
    'title' => 'SEO Einstellungen',
    'menuTitle' => 'SEO Einstellungen',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SEO Einstellungen</h1>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>SEO Professional erweitert bei den jeweiligen Shopware Modulen (Artikel, Kategorien usw.) die Einstellungen um einen zusätzlichen SEO Tab. Alle SEO Einstellungen aus dem Shopware Standard und die SEO Einstellungen von SEO Professional werden an dieser Stelle zentral zur Verfügung gestellt. Die Standard-Felder der Konfiguration der Meta-Tags sowie der Canonical Url sind entsprechend nicht mehr an der Originalstelle zu finden, sondern werden mit der Installation des Plugins in den neuen Tab verschoben.</p>
<p><a data-dreisccmslightbox="images-476583" data-title="SEO Tab im Produkt Module" href="wiki/dreisc_seo_pro/200-seo-settings/lightbox/seo-tab.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/lightbox/seo-tab.png" alt="SEO Tab im Produkt Module">
                        </a></p>
<a name="dokumentation-der-einzelnen-seo-einstellungen"></a>
<h2>Dokumentation der einzelnen SEO Einstellungen</h2>
<p>Die Beschreibungen zu den jeweiligen SEO Einstellungen finden Sie auf den folgenden Unterseiten.</p>
<p><h2 class="sub-headline">Artikel</h2><ul class="articles-nav--tree"><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/meta-tags" class="nav--link link--entry">Meta Tags</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/serp-preview" class="nav--link link--entry">SERP Vorschau</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/canonical-urls" class="nav--link link--entry">Canonical Urls</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/rich-snippet" class="nav--link link--entry">Rich Snippets</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/social-media" class="nav--link link--entry">Social Media</a></li><li class="nav--entry"><a href="/docs/seo-professional/seo-settings/redirect-widget" class="nav--link link--entry">Weiterleitungs-Widget</a></li></ul></p>',
  ),
);