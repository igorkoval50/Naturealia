<?php return array (
  'DE' => 
  array (
    'path' => 'de_200-seo-settings/200-serp-preview',
    'parent' => 'de_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/serp-preview',
    'title' => 'SERP Vorschau',
    'menuTitle' => 'SERP Vorschau',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SERP Vorschau</h1>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>Google nutzt den Meta Titel sowie die Meta Beschreibung für die Darstellung der Suchergebnisse. Die SERP Vorschau unterstützt dich bei der Optimierung der SEO Daten und zeigt an, wie das Google Suchergebnis aussehen kann. </p>
<p>Hierbei ist zu beachten, dass das endgültige Suchergebnis von der Vorschau abweichen kann. Hintergrund ist hierbei, dass Google nicht komplett offenlegt, wie die Suchergebnisse generiert werden. Daher kommt es durchaus vor, dass bspw. ein Meta Titel nur 550 Pixel Breite aufweist, ein anderer aber über die komplette Breite von 600 px angezeigt wird. Gleiches gilt für die Meta Beschreibung. Auch kann es unter bestimmten Umständen sein, dass die Meta Daten vereinzelt komplett verworfen werden und Google eigene Inhalte generiert.</p>
<p>Weitere Informationen zu dem Meta Titel sowie der Meta Beschreibung findest du in dieser Dokumentation unter:<br>
<a href="docs/seo-professional/seo-settings/meta-tags">SEO Professional » SEO Einstellungen » Meta Tags</a></p>
<p><a data-dreisccmslightbox="images-431709" data-title="Konfiguration der Meta-Tags" href="wiki/dreisc_seo_pro/200-seo-settings/200-serp-preview/lightbox/serp-vorschau.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/200-serp-preview/lightbox/serp-vorschau.png" alt="Konfiguration der Meta-Tags">
                        </a></p>
<p></p>',
  ),
  'EN' => 
  array (
    'path' => 'en_200-seo-settings/200-serp-preview',
    'parent' => 'en_200-seo-settings',
    'seoUrl' => 'docs/seo-professional/seo-settings/serp-preview',
    'title' => 'SERP Vorschau',
    'menuTitle' => 'SERP Vorschau',
    'content' => '<style type="text/css">

dl dt {
    font-weight: bolder;
    margin-top: 1rem;
}

dl dd {
    padding-left: 2rem;
}

h2 code {
    font-size: 32px;
}

.category--description ul {
    padding-left: 2rem;
}

dt code,
li code,
table code,
p code {
    font-family: monospace, monospace;
    background-color: #f9f9f9;
    font-size: 16px;
}
</style>
<h1>SERP Vorschau</h1>
<a name="einfuehrung"></a>
<h2>Einführung</h2>
<p>Google nutzt den Meta Titel sowie die Meta Beschreibung für die Darstellung der Suchergebnisse. Die SERP Vorschau unterstützt dich bei der Optimierung der SEO Daten und zeigt an, wie das Google Suchergebnis aussehen kann. </p>
<p>Hierbei ist zu beachten, dass das endgültige Suchergebnis von der Vorschau abweichen kann. Hintergrund ist hierbei, dass Google nicht komplett offenlegt, wie die Suchergebnisse generiert werden. Daher kommt es durchaus vor, dass bspw. ein Meta Titel nur 550 Pixel Breite aufweist, ein anderer aber über die komplette Breite von 600 px angezeigt wird. Gleiches gilt für die Meta Beschreibung. Auch kann es unter bestimmten Umständen sein, dass die Meta Daten vereinzelt komplett verworfen werden und Google eigene Inhalte generiert.</p>
<p>Weitere Informationen zu dem Meta Titel sowie der Meta Beschreibung findest du in dieser Dokumentation unter:<br>
<a href="docs/seo-professional/seo-settings/meta-tags">SEO Professional » SEO Einstellungen » Meta Tags</a></p>
<p><a data-dreisccmslightbox="images-218203" data-title="Konfiguration der Meta-Tags" href="wiki/dreisc_seo_pro/200-seo-settings/200-serp-preview/lightbox/serp-vorschau.png">
                            <img class="has--border is--rounded padding-10" src="wiki/dreisc_seo_pro/200-seo-settings/200-serp-preview/lightbox/serp-vorschau.png" alt="Konfiguration der Meta-Tags">
                        </a></p>
<p></p>',
  ),
);