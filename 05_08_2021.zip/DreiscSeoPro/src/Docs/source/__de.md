[title]: <>(SEO Professional)
[menuTitle]: <>()
[url]: <>(docs/seo-professional)

# SEO Professional
Das Plugin SEO Professional vereint eine große Anzahl an SEO Einstellungen / Optimierung in nur einem Plugin. Hierbei setzt das Plugin da an, wo Shopware aufhört und unterstützt Dich dabei dein Ranking bei den Suchmaschinen zu optimieren.

In dieser Dokumentation findest du alle relevanten Informationen zur Bedienung und Adminstration des Plugins.

[sub]
