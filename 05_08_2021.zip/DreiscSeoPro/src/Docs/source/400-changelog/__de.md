[title]: <>(Changelog)
[menuTitle]: <>()
[url]: <>()

# Changelog
Auf dieser Seite findest du alle Anpassungen die mit den einzelnen Versionen des Plugins SEO Professional umgesetzt wurden.

[toc]
## Version 6.8.6
- Plugin Fehler in Verbindung mit Detailseiten Erlebniswelten behoben (getReviews() must be an instance of Shopware\Storefront\Page\Product\Review\ReviewLoaderResult, null returned)

## Version 6.8.5
- Fehlende Datei für Update auf die Version 6.8.4 hinzugefügt.

## Version 6.8.4
- Das automatische Ausführen der Bulk Generatoren beim Speichern eines Entities kann nun per Einstellung unter [SEO Professional » Weitere Einstellungen » SEO Einstellungen](./../300-modules/900-settings/100-seo-settings/__de.md#bulk-generatoren-beim-speicherprozess-starten) abgeschaltet werden.
- Die Bulk Generatoren werden fortan nicht mehr beim Indexieren in der handle Methode ausgeführt.

## Version 6.8.3
- Unter bestimmten Voraussetzungen wurde die Live Template Variable ##shopName## nicht mehr aufgelöst.

## Version 6.8.2
- setContainer bei DreiscSeoRedirectController ergänzt.

## Version 6.8.1
- PHP 8.0 Support

## Version 6.8.0
- Shopware 6.4 Kompatibilität

## Version 6.7.17
- Bei Varianten konnte bei den Bulk Templates nicht auf die Daten des Hauptartikels zurückgegriffen werden. Hier wurde nun die Vererbung aktiviert.

## Version 6.7.16
- Unter bestimmten Umständen wurde bei dem Generieren der Urls über den Bulk Generator nicht der isModified Flag gesetzt. Hierdurch wurden diese URLs abschließend wieder durch den Shopware Standard URL Generator überschrieben.
- Bei den Canonical-Einstellungen wurde das Feld ``Externe URL (Canonical Link)`` vom Typ ``Url`` auf den Typ ``Text`` angepasst, da ansonsten eine Speicherung der externen URL nicht möglich war.

## Version 6.7.15
- Über ein internes Caching der SEO Bulk Einstellungen konnte die Performance der Bulk Generatoren optimiert werden.

## Version 6.7.14
- Unterstützung des Live Templates ##shopName## bei Kategorien.
- Anpassung der für kommende Versionen als @deprecated markierte Codeelemente.

## Version 6.7.13
- Die URL des Logos sowie des Unternehmensstandortes der Rich Snippet Unternehmensdaten konnten nicht gespeichert werden. Dieses Verhalten wurde mit dieser Version behoben.

## Version 6.7.12
- In bestimmten Konstellationen wurde die Live Variable ##shopName## nicht korrekt durch den Shopnamen ersetzt. Dieses Verhalten wurde mit dieser Version behoben.

## Version 6.7.11
- Beim Export von Weiterleitungen wurde eine fehlerhafte URL erstellt, die zu dem folgenden Fehler führte: ``Requested api version v1 not available, available versions are v2, v3.``. Dieses Fehlverhalten wurde mit dieser Version behoben.

## Version 6.7.10
- Beim Generieren von Varianten kam es unter bestimmten Umständen zu einem Fehler des Bulk Generators (Call getCategories on null). Dieses Fehlverhalten wurde mit dieser Version behoben.

## Version 6.7.9
- Fehler beim Generieren des Canonical Links behoben.

## Version 6.7.8
- Mit inaktiver Option ``Rich Snippets über JSON-LD aktivieren`` wurden in der Storefront keine sprechenden URLs mehr ausgegeben. Dieses Fehlverhalten wurde mit dieser Version behoben.

## Version 6.7.7
- Aufgrund der Performance Probleme mit dem Shopware DAL wurden die Bulk Generatoren auf Plain SQL umgestellt. Somit wird eine schnellere Datenspeicherung realisiert.
- In manchen Fällen wurde die Meta Description nicht korrekt ausgegeben. Dieses Problem wurde nun behoben.

## Version 6.7.6
- Performance Update der Bulk Generatoren
- Template Variablen wurden bei dem erstellen / bearbeiten der Bulk Templates nicht in das Formular übernommen. Dieses Verhalten wurde behoben. 

## Version 6.7.5
- Umstellung der Produkt- und Kategorie Indexer auf die neue EntityIndexer Struktur.
- Fehler bei der Darstellung der Canonical-URL Einstellungen behoben.

## Version 6.7.4
- Es kam zu einer Fehlermeldung, wenn ein anderes Plugin einen Decorator für die Shopware Router Komponente definiert hat. Dieses Fehlverhalten wurde mit dieser Version behoben.

## Version 6.7.3
- Kompatibilität zu Shopware 6.3.0 hergestellt.
 
## Version 6.7.2
- Bei aktivem JSON-LD kam es vor, dass Teile der Rich Snippets Tags trotzdem ausgegeben wurden. Dieses Fehlverhalten wurde mit dieser Version behoben.

## Version 6.7.1
- In den URls die über den Bulk Generator erstellt werden, können nun auch Sonderzeichen wie der Punkt und das "~"-Zeichen verwendet werden.
- Allgemein wurden Sonderzeichen durch den Bulk Generator automatisch escaped. Dieses wurden durch den Twig Renderer verursacht. Die Konfiguration wurde hier nun angepasst, sodass die Sonderzeichen auch als solche dargestellt werden.

## Version 6.7.0
- Für Facebook und Twitter können ab dieser Version der Titel, die Beschreibungen sowie die Bilder definiert werden, die beim Teilen des Produkts / der Seite ausgegeben werden. Weitere Informationen hierzu findest du unter: [SEO Professional » SEO Einstellungen » Social Media](./../200-seo-settings/500-social-media/__de.md)
- Der Titel sowie die Beschreibung für Facebook und Twitter können per Bulk Template erstellt werden.
- Die empfohlene Länge sowie die Maximallänge der Facebook und Twitter Titel sowie Beschreibungen können in den Einstellungen selbst definiert werden.
- Die Weiterleitungen können nun als CSV Datei importiert sowie exportiert werden. Weitere Informationen hierzu findest du unter: [Plugin Dokumentationen » SEO Professional » Module » 301 und 302 URL Weiterleitungen » CSV Import und Export der Weiterleitungen](./../300-modules/200-redirect/130-redirect-import-export/__de.md)
- Es können nun auch Weiterleitungen an die Startseite konfiguriert werden.

## Version 6.6.0
- Als Canonical Link wird im Shopware Standard immer der SEO Pfad der jeweiligen Seite übergeben. Ab dieser Version ist es möglich für Produkte und Kategorien abweichende Canonical Links zu hinterlegen. Hierbei kann eine feste externe URL hinterlegt oder aber ein Produkt bzw. eine Kategorie ausgewählt werden, dessen SEO Pfad als Canonical Link verwendet werden soll. Weitere Informationen zu der neuen Einstellung findest du unter: [SEO Professional » SEO Einstellungen » Canonical Urls » Canonical Link](./../200-seo-settings/300-canonical-urls/__de.md#canonical-link)

## Version 6.5.2
- Im Shopware Standard wird das Canonical Links Tag auf der Startseite sowie den Kategorieseiten nicht ausgegeben (Stand Shopware 6.2). Bis dies über den Shopware Standard gewährleistet wird, wird die Ausgabe ab dieser Version über SEO Professional sichergestellt. Weitere Informationen findest du unter: [https://issues.shopware.com/issues/NEXT-8662](https://issues.shopware.com/issues/NEXT-8662) 
- Im Bulk Generator für URLs steht nun der komplette Kategoriebaum zur Auswahl zur Verfügung. Dieser wird entsprechend nicht mehr auf die Kategorien des ausgewählten Sales Channels heruntergebrochen, um eine Auswahl der Service und Footer Seiten zu gewährleisten.

## Version 6.5.1
- In der Version 6.5.0 kam es zu der Fehlermeldung `ltrim() expects parameter 1 to be string, boolean given`, wenn ein Saleschannel mit virtueller Domain genutzt wurde. Bspw.: `http://www.shop.de/at`. Dieses Fehlverhalten wurde mit dieser Version behoben.

## Version 6.5.0
- Bei den Produkten sowie den Kategorien wurden die Meta-Tags Administration um die  Konfiguration des Robots Tags erweitert. Somit kann nun für die Seiten deifniert werden, ob diese indexiert und Links auf diesen Seiten verfolgt werden sollen. Ausführliche Informationen zu dieser neuen Einstellung findest du unter: [SEO Professional » SEO Einstellungen » Meta Tags » Robots Tag](./../200-seo-settings/100-meta-tags/__de.md#robots-tag)
- In den SEO Einstellungen kann des Weiteren ein Standard Robots-Tag definiert werden, der verwendet wird, wenn für eine Kategorie bzw. ein Produkt kein Robots-Tag explizit angegeben wurde. Ebenfalls kann auch die neue Option `Noindex Request Parameter Query` definiert werden, über die Bedingungen konfiguriert werden können, die dafür sorgen, dass ein Robots-Tag auf `noindex` umgestellt wird. Weitere Informationen hierzu findest du unter: [SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta Tags](./../300-modules/900-settings/100-seo-settings/__de.md)
- Über den `Produkt-` sowie den `Kategorie Bulk Generator` können jetzt auch die Einstellungen für den Robots Tag definiert werden.
- Möchtest du dir für ein Produkt bzw. eine Kategorie die SERP Vorschau anschauen oder aber die Canonical Url bearbeiten, so musst du zuvor immer erst den Verkaufskanel auswählen den du bearbeiten möchtest. Um die Workflows hier zu erleichtern kannst du nun jeweils einen Verkaufskanel als Vorauswahl definieren. Weitere Informationen hierzu findest du unter: [SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta Tags](./../300-modules/900-settings/100-seo-settings/__de.md)


## Version 6.4.2
- Bei den Migrationen findet bei den Rückgabewerten der Methode `getCreationTimestamp`jetzt eine explizite Datentypumwandlung auf den Datentyp `int` statt, da das Plugin ansonsten unter bestimmten Serverbedingungen nicht installiert werden konnte.
- Die Anpassungen der Version 6.0.2 bzgl. Löschen der Weiterleitungen in der Administration hat in Produktivsystemen mit aktivem Cache noch nicht funktioniert. Ab dieser Version wird der Cache Tag der jeweiligen Weiterleitung geleert.

## Version 6.4.1
- Die Methode `extractInheritableAttributes` der `Klasse DreiscSeoPro\Decorator\Shopware\Storefront\Routing\RequestTransformerDecorator` hatte keinen Rückgabewert. Dies führte dazu, dass es teilweise bei der Registrierung zu einer Fehlermeldung kam. Dieses Fehlverhalten wurde behoben. 

## Version 6.4.0
- Die Rich Snippets Konfiguration wurde um die Bereiche `Logo` und `Lokales Unternehmen` erweitert. Weitere Informationen hierzu findest du unter [SEO Professional » Module » Rich Snippets (JSON-LD) » Unternehmen](./../300-modules/300-rich-snippets-json-ld/300-organization/__de.md)
- Die Konfigurationen der Rich Snippets Einstellungen können nun pro Sales Channel hinterlegt werden.
- Bei den abweichenden Werten für die Rich Snippets, die unter [SEO Professional » SEO Einstellungen » Rich Snippets](./../200-seo-settings/400-rich-snippet/__de.md) konfiguriert werden können, wurde die Vererbung bei Varianten implementiert.  

## Version 6.3.0
- Es ist nun möglich Rich Snippets der Bereiche `Produkt` und `Breadcrumb` über SEO Professional auszugeben. Die standardmäßig vorhandenen Rich Snippet Mircodaten werden aus dem Quellcode entfernt und durch JSON-LD Daten ersetzt. Informationen zu den Einstellungsmöglichkeiten findest du unter: [SEO Professional » Module » Rich Snippets \(JSON-LD)](./../300-modules/300-rich-snippets-json-ld/__de.md)

## Version 6.2.0
- Die empfohlene sowie die maximale Zeichen- bzw. Pixellänge der Meta Tags kann nun konfiguriert werden. Die Einstellungen hierzu findest du unter `SEO Professional » Einstellugen`. Weitere Informationen hierzu findest du unter: [SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta Tags](./../300-modules/900-settings/100-seo-settings/__de.md)


## Version 6.1.0
- Die Bulk Generatoren können jetzt auch direkt über die Adminstration gestartet werden. Weitere Informationen hierzu findest du unter: [Bulk Generator ausführen](./../300-modules/100-bulk-generators/250-execute-bulk-generator/__de.md#2-moeglichkeit-bulk-generatoren-ueber-die-administration-starten)

## Version 6.0.2
- Die Weiterleitungen wurden bei aktivem HTTP Cache nicht direkt übernommen. Dieses Verhalten wurde entsprechend angepasst.
- Das Löschen der Weiterleitungen hat mit der aktuellen Version nicht mehr funktioniert, da das Shopware DAL diese nicht löschen konnte. Daher wurde das Löschen der Weiterleitungen auf Plain SQL umgestellt und ein Ticket bei der shopware AG eröffnet. (https://issues.shopware.com/issues/NEXT-7866)

## Version 6.0.1
- In dieser Version wurde das Icon für die Plugin Manager hinzugefügt.

## Version 6.0.0
- Initiales Release für Shopware 6. Zum aktuellen Zeitpunkt stehen noch nicht alle Funktionen bereit die unter Shopware 5 bei SEO Professional möglich waren. Diese und noch weitere Funktionen werden im Laufe der kommeden Wochen / Monate nach und nach erweitert. Angedacht sind hierbei aktuell monatliche Updates.

[sub]
