[title]: <>(Erste Schritte)
[menuTitle]: <>()
[url]: <>()

# Erste Schritte

## Installation 
SEO Professional kann ausschließlich über den Shopware Store erworben werden. Stelle sicher, dass du das Plugin installiert und aktiviert hast. 

Weitere Informationen hierzu findest du in der [**Shopware 6 Dokumentation**](https://docs.shopware.com/de/shopware-6-de/einstellungen/plugins?category=shopware-6-de/einstellungen/plugins-menue)

## SEO Professional Adminstration
Nachdem das Plugin installiert und aktiviert wurde, ist die Adminstration im Hauptmenü zu finden.

![SEO Professional Hauptmenü in der Shopware Administration](./img/seo-professional-menue.png)

Alle weiteren Informationen zu den einzelnen Modulen findest du unter dem Menüpunkt [**Module**](./../300-modules/__de.md).

## Deine nächsten Schritte
Nachdem die Installation abgeschlossen ist, macht es Sinn sich mit den SEO Einstellungen zu beschäftigen, die SEO Professional für die verschiedenen Shopware Module bereitstellt. Einen Guide hierzu findet du unter [**SEO Einstellungen**](./../200-seo-settings/__de.md).

Darüber hinaus bietet SEO Professional verschiedene Module an, die dich in deinem SEO Alltag unterstützen können. Beschreibungen dieser Module findest du unter [**SEO Professional Module**](./../300-modules/__de.md)

[sub]
