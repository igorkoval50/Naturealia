[title]: <>(Meta Tags)
[menuTitle]: <>()
[url]: <>()

# Meta Tags

[toc]

## Einführung
Bei der Konfiguration der Meta-Tags handelt es sich um die Shopware Standard Konfiguration der Meta-Tag Felder, die durch SEO Professional jedoch entsprechend erweitert / aufbereitet werden.

Darüber hinaus kann an dieser Stelle der Robots-Tag für die jeweilige Seite konfiguriert werden.

![Konfiguration der Meta-Tags](./lightbox/meta-tags-einstellungen-mit-robots-tag.png)

## Ausgabe der Zeichen- bzw. Pixellänge
Über deine Modifikation der Meta Tag Felder findet eine Zählung der aktuell verwendeten Zeichen bzw. Pixel statt. Diese werden rechts neben dem Label des Feldes ausgegeben. 

Zusätzlich zu dieser Ausgabe wird ein farbiger Balken angezeigt, der dir als visuelle Hilfe dienen soll. Hierbei werden die folgenden Farben ausgegeben:

- **rot**<br>Wird bei dem Meta Titel sowie der Meta Beschreibung ausgegeben, wenn gar kein Wert vorhanden ist
- **orange**<br>Wird ausgegeben, wenn ein Meta Tag Wert zu kurz bzw. zu lang ist.
- **grün**<br>Ist der Balken grün, so entspricht die Länge unserer Empfehlung.
- **hellgrün/gelb**<br>In diesem Fall hat die Länge des Werts eine Länge erreicht, die manchmal von Google ausgegeben, teilweise aber auch bereits gekürzt wird.

Standardmäßig sind die folgenden Werte definiert:
- **Meta Titel**<br>Empfohlene Länge 150 bis 550 Pixel, maximal 600 Pixel
- **Meta Beschreibung**<br>Empfohlene Länge 35 bis 130 Zeichen, maximal 160 Zeichen
- **Keywords**<br>Empfohlene Länge 30 bis 255 Zeichen, maximal 255 Zeichen

Diese Standardwerte können entsprechend auf die eigenen Bedürfnisse angepasst und umkonfiguriert werden. Weitere Informationen zu den Einstellungen findest du unter: [SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta-Tags](./../../300-modules/900-settings/100-seo-settings/__de.md)

## Ausgabe der Bulk Informationen
Über die Bulk Generatoren kann das Generierung der Meta Tags automatisiert werden. (siehe: [Module » Produkt- und Kategorie Bulk Generator](./../../300-modules/100-bulk-generators/__de.md)) Damit du auf einen Blick siehst, ob ein Meta Tag per Bulk generiert wurde bzw. generiert wird, wird die Bulk Konfiguration des jeweiligen Feldes direkt mitgeladen und unterhalb der Textbox ausgegeben. 

Dies ist besonders dann relevant, wenn für die Bulk Konfiguration die Option "Werte überschrieben" aktiv ist. In diesem Fall wird zusätzlich der Hinweis ausgegeben, dass Änderungen an diesem Feld wieder überschrieben werden. 

Des Weiteren kann mit einem Klick auf den Namen der Bulk Konfiguration diese direkt geöffnet werden.

## Robots-Tag
Über den Robots Tag wird zum einen definiert, ob die aktuelle Seite bei Google indexiert oder ignoriert werden soll. Hierbei wird der Wert "index" bzw. "noindex" übergeben. Es kann bspw. Sinn machen eine Seite auf "noindex" zu setzen, wenn sie Content enthält, der bereits auf anderen Seiten vorhanden ist. Alternativ kann in diesem Fall der Canonical Link auf die jeweils andere Seite gesetzt werden.

Des Weiteren wird über dieses Tag bestimmt, ob Links auf der aktuellen Seite von Google verfolgt werden sollen. Als Werte werden hierbei "follow" bzw. "nofollow" übergeben. Ein Nofollow kann Sinn machen, da somit auch keine Linkkraft (Link Juice) weitergegeben wird.

Wird an dieser Stelle kein Robots-Tag angegeben, so greift automatisch der Standard Robots-Tag des Produkts bzw. der Kategorie. Informationen wie du die Standardwerte konfigurieren kannst, findest du unter: [SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Meta-Tags » Robots-Tag](./../../300-modules/900-settings/100-seo-settings/__de.md).

## FAQ: Warum wird die Länge des Meta Titels in Pixel gemessen und wie funktioniert das?
Allgemein empfiehlt man für den Meta Titel 15 bis 55 Zeichen, maximal jedoch 70 Zeichen. Die Meta Titel die bei den Suchergebnissen angezeigt werden sind jedoch nie breiter als 600 Pixel. Breitere Titel werden von Google automatisch gekürzt. Da jedes Zeichen nun eine individuelle Breite hat (schmales Zeichen: "i", breite Zeichen: "X") macht es bei dem Meta Titel daher mehr Sinn direkt mit der Pixelbreite zu kalkulieren und hier 600 Pixel nicht zu überschreiten. 

Zur Berechnung dieser Länge haben wir bei der Entwicklung die gängigsten Zeichen und Sonderzeichen "ausgemessen" und in einer Kalkulationstabelle erfasst, sodass wir die Summe der Zeichenkette ermitteln können. Solltest du Zeichen verwenden, die noch nicht erfasst sind, so kannst du uns diese gerne per Shopware Ticket zukommen lassen. In diesem Fall würden sie entsprechend mit aufnehmen, um die Pixelberechnung so genau wie möglich zu machen.

## FAQ: Wie sollte der optimale Titel meiner Shopware Seite ausehen?
- Stelle zunächst einmal sicher, das überhaupt für jede Seite ein Title-Tag hinterlegt ist.
- Versetze dich in die Lage des suchenden Kunden und optimiere den Titel entsprechend kundenorientiert.
- Vermeide gleiche Titel für unterschiedliche Seiten. Erstelle pro Seite einen individuellen Titel. (Für viele Produkte / Kategorien geht dies schnell über die Bulk Konfiguratoren)
- Das Keyword zu dem die Seite ranken soll, sollte sich im Title-Tag wieder finden.<br>Hierbei sollte der Titel der Seite möglichst mit diesem Keyword beginnen
- Stelle Sie sicher, dass der Titel zu dem Inhalt der Seite passt. Anderenfalls kann es sein, dass Google den hinterlegten Titel ignoriert und einen eigenen generiert. <br><br>Weitere Informationen hierzu du in dem nächsten FAQ: "Mein hinterlegter Titel / Meta Description wird nicht in den Suchergebnissen angezeigt. Warum?"

## FAQ: Mein hinterlegter Titel / Meta Description wird nicht in den Suchergebnissen angezeigt. Warum?

Wenn hinterlegte SEO Einstellungen nicht übernommen werden kann dies mehrere Gründe.

### 1) Werden die Daten korrekt im Template ausgegeben?

Als erstes sollte einmal geprüft werden, ob die hinterlegten SEO Daten im Template korrekt ausgegeben werden. Hierzu reicht es, wenn man auf der entsprechenden Seite sich über die rechte Maustaste den Quellcode der Seite anzeigen lässt.

Hierbei sollten die Werte der folgenden Tags dargestellt werden:

- **Titel der Seite**<br>``<title>[..]</title>``
- **Meta-Description**<br>
 ``<meta name="description" content="[..]" />``
- **Facebook Beschreibung**<br>
 ``<meta property="og:description" content="[..]" />``
- **Twitter Beschreibung**<br>
 ``<meta name="twitter:description" content="[..]" />``
 
**Bei mir werden die Daten nicht korrekt im Quellcode angezeigt. Warum?**<br>
Werden die SEO Einstellungen nicht oder fehlerhaft im Quellcode angezeigt, so kann kann dies verschiedene Gründe haben:
 
Ein häufiger Grund ist, dass durch das eigene Theme Anpassungen durchgeführt wurden, die mit dem Plugin nicht kompatibel sind. Aus diesem Grund wäre der erste Schritt einmal das Standard Theme zu aktivieren, um zu prüfen, ob dies der Grund ist.
 
Ein weiterer Anlaufpunkt sind weitere Plugins, die auf dem System installiert sind. Hierbei sollten Plugins, die mit dem Problem in Verbindung stehen einmal testhalber deaktiviert und anschließend der Cache geleert werden.
 
Sollte sich so der Fehler nicht finden lassen, so stehen wir dir gerne per Shopware Support Ticket zur Verfügung.

### 2) Die Indexierung braucht Zeit
Ein weiterer Punkt ist, dass die Daten nicht direkt übernommen werden. Die Seiten müssen zunächst durch Google neu indexiert werden, damit eine Änderung übernommen wird. Das Crawlen kann einige Tage bis Wochen dauern.

Weitere Informationen hierzu findest du unter:<br>
https://support.google.com/webmasters/answer/6065812?hl=de

### 3) Falsche Anzeige in den Suchergebnissen trotz korrekter Übergabe
Auch wenn die Daten - wie oben beschrieben - korrekt an das Storefront übergeben werden, so kann es trotzdem dazu kommen, dass statt der hinterlegten Daten andere dargestellt werden. Ein häufiger Grund ist hierbei, dass die Suchmaschine den hinterlegten Inhalt nicht als nicht passend einstuft und daher einen eigenen Kontent generiert. Auch kam es in der Vergangenheit schon vor, dass die Facebook Beschreibung als Meta Description herangezogen wurde.

Weitere Informationen hierzu findest du unter:
- https://www.sistrix.de/frag-sistrix/onpage-optimierung/meta-element-meta-tag/meine-eigene-meta-description-wird-nicht-in-den-suchergebnissen-angezeigt-warum/
- https://www.seohit.de/title-oder-description-tag-werden-falsch-angezeigt-moegliche-ursachen/
- https://support.google.com/webmasters/answer/35624?hl=en

[sub]
