[title]: <>(Social Media)
[menuTitle]: <>()
[url]: <>()

# Social Media
[toc]

## Einführung
Über die Konfiguration der Social Media Felder bist du in der Lage Einfluss auf die Erscheinung deiner Shopseiten zu nehmen, die auf den Social Media Plattformen geteilt werden.

## Facebook
Über die Facebook OpenGraph Angaben kannst du definieren, mit welchem Titel, Beschreibung sowie Bild das jeweilige Produkt bzw. die jeweilige Seite angezeigt werden soll, wenn dieses bei Facebook geteilt wird.

Hierzu stehen dir an dieser Stelle die Felder: `Facebook Titel`, `Facebook Beschreibung` sowie `Facebook Bild` zur Verfügung.

Über den Sharing Debugger von Facebook kannst du überprüfen, wie anschließend das Resultat deiner Konfiguration aussieht. Diesen findest Du unter: [https://developers.facebook.com/tools/debug/sharing](https://developers.facebook.com/tools/debug/sharing)

![Verfügbare Facebook OpenGraph Einstellungen](./lightbox/facebook.png)

## Twitter
Durch Twitter Cards hast die Möglichkeit weitere Informationen zum Produkt bzw. zur aktuellen Seite zu übergeben. Diese werden als Twitter Card ausgegeben, wenn jemand dein Produkt auf Twitter teilt.

Über den Card Validator von Twitter kannst Du überprüfen, wie anschließend das Resultat deiner Konfiguration aussieht. Diesen findest Du unter: [https://cards-dev.twitter.com/validator](https://cards-dev.twitter.com/validator)

![Verfügbare Twitter Cards Einstellungen](./lightbox/twitter.png)

## Konfiguration der Standard Facebook und Twitter Längenwerte
Die empfohlene Längen bzw. Maximalwerte für die Facebook und Twitter Felder können auf die eigenen Bedürfnisse angepasst und umkonfiguriert werden. Weitere Informationen zu den Einstellungen findest du unter: [SEO Professional » Module » Weitere Einstellungen » SEO Einstellungen » Social Media](./../../300-modules/900-settings/100-seo-settings/__de.md#social-media)

[sub]
