[title]: <>(Canonical Urls)
[menuTitle]: <>()
[url]: <>()

# Canonical Urls

[toc]

## Einführung
Bei der Konfiguration der Canonical Urls handelt es sich um die Shopware Standard Konfiguration der Canonical Urls, die durch SEO Professional jedoch entsprechend erweitert / aufbereitet wird.

![Konfiguration der Canonical Urls](./lightbox/canonical-url-panel.png)

## SEO Pfad
### Ausgabe der Bulk Informationen
Über die Bulk Generatoren kann das Generierung der Canonical Urls automatisiert werden. (siehe: [Module » Produkt- und Kategorie Bulk Generator](./../../300-modules/100-bulk-generators/__de.md)) Damit du auf einen Blick siehst, ob eine Url per Bulk generiert wurde bzw. generiert wird, wird die Bulk Konfiguration direkt mitgeladen und unterhalb des SEO Pfads ausgegeben. 

Dies ist besonders dann relevant, wenn für die Bulk Konfiguration die Option "Werte überschrieben" aktiv ist. In diesem Fall wird zusätzlich der Hinweis ausgegeben, dass Änderungen an diesem Feld wieder überschrieben werden. 

Des Weiteren kann mit einem Klick auf den Namen der Bulk Konfiguration diese direkt geöffnet werden.

## Canonical Link
Standardmäßig wird der SEO Pfad auch als Canonical Link ausgegeben. In manchen Fällen ist es jedoch erforderlich, dass der Canonical Link auf ein anderes Produkt, Kategorie bzw. andere Seite zeigt.

Ein Beispiel hierfür könnte sein, dass du ein Produkt mit mehreren Varianten hast, sich die Beschreibungstexte der Varianten aber kaum / gar nicht unterscheiden. In diesem Fall macht es Sinn die Canonical Links aller Varianten auf die Url einer definierten Variante zu setzen, um doppelten Kontent zu vermeiden.

Über das Feld `Canonical Link` können die folgenden Ziel-Typen definiert werden:
- **Den SEO Pfad als Canonical Link ausgeben**<br>Hierbei handelt es sich um das Standardverhalten. Als Canonical Link wird also entsprechend der SEO Pfad, sprich die sprechende Url des Produkts / Kategorie ausgegeben.

- **Externe Url als Canonical Link ausgeben**<br>Wird diese Option ausgewählt, so wird das Feld `Externe URL (Canonical Link)` angezeigt. Die hier definierte URL wird als Canonical ausgegeben.

- **URL eines Produkts als Canonical Link ausgeben**<br>Wird diese Option ausgewählt, so wird das Feld `Produkt (Canonical Link)` angezeigt. Hier kann anschließend ein Produkt ausgewählt werden, dessen SEO Pfad als Canonical Link definiert werden soll.

- **URL einer Kategorie als Canonical Link ausgeben**<br>Wird diese Option ausgewählt, so wird das Feld `Kategorie (Canonical Link)` angezeigt. Hier kann anschließend eine Kategorie ausgewählt werden, dessen SEO Pfad als Canonical Link definiert werden soll.

[sub]
