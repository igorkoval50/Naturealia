[title]: <>(Rich Snippets)
[menuTitle]: <>()
[url]: <>()

# Rich Snippets
*Diese Einstellung steht lediglich für Produkte zur Verfügung.*
[toc]

## Einführung
Über SEO Professional hast du die Möglichkeit Rich Snippets über JSON-LD einzubinden. Ist dies gewünscht, muss sichergestellt werden, dass die Einstellung `Rich Snippets über JSON-LD aktivieren` unter `SEO Professional » Rich Snippets (JSON-LD) » Allgemein` aktiviert ist.

Unter `SEO Professional » Rich Snippets (JSON-LD)` hast du die Möglichkeit Standardwerte und -verhalten festzulegen, die bei den Rich Snippets zum Einsatz kommen. Weitere Informationen hierzu findest du unter: [SEO Professional » Module » Rich Snippets \(JSON-LD)](./../../300-modules/300-rich-snippets-json-ld/__de.md)

## Konfigurationsfelder
Bei der Konfiguration der Rich Snippets in den SEO Einstellungen des jeweiligen Produkts, ist es möglich abweichende Werte zu definieren, die dann statt der definierten Standardwerte ausgegeben werden.

Es liegen die folgenden Felder vor, um abweichende Werte zu definieren:

- Abweichender Produktzustand
- Abweichende Produktverfügbarkeit
- Abweichende händlerspezifische Kennung (sku)
- Abweichende Herstellerteile-Nummer (mpn)
- Abweichendes "Preis gültig bis"-Datum (priceValidUntil)

![Abweichende Rich Snippet Einstellungen konfigurieren](./lightbox/rich-snippets-einstellungen.png)

[sub]
