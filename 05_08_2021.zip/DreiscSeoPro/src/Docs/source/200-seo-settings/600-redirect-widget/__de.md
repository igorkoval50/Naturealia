[title]: <>(Weiterleitungs-Widget)
[menuTitle]: <>()
[url]: <>()

# Weiterleitungs-Widget
Bzgl. der Weiterleitungen wird im SEO Tab ein Widget für die Darstellung der Informationen bestehender Weiterleitung bzw. zur Erstellung von Weiterleitungen für das jeweilige Produkt bzw. Kategorie ausgegeben.

[toc]

## Widget bei bestehender Weiterleitung
Wurde für ein Produkt bzw. eine Kategorie bereits eine Weiterleitung definiert, so findest du in dem jeweiligen Modul eine entsprechende Hinweisbox ganz oben im ersten Tab
![Widget bei bestehender Weiterleitung](./lightbox/seo-tab-widget-bestehende-weiterleitung.png)

### Detailinformationen zur Weiterleitung anzeigen
Um weitere Informationen der Weiterleitung anzeigen zu lassen, reicht ein Klick auf die Schaltfäche `Details anzeigen`. Neben zusätzlichen Informationen wird so auch die Schaltfläche `Konfiguration der Weiterleitung öffnen` sichtbar, über die die Konfiguration der Weiterleitung geöffnet werden kann.
![Widget bei bestehender Weiterleitung](./lightbox/seo-tab-widget-bestehende-weiterleitung-mit-details.png)

## Widget bei nicht vorhandener Weiterleitung
Wurde für ein Produkt bzw. eine Kategorie noch keine Weiterleitung hinterlegt, so findest du ganz unten in dem SEO Tab das Widget zur Erstellung einer Weiterleitung.

![Infobox, dass keine Weiterleitung vorliegt](./lightbox/seo-tab-widget-keine-weiterleitung.png)

Mit einem Klick auf die Schaltfläche `Jetzt eine Weiterleitung für dieses Produkt erstellen` bzw. `Jetzt eine Weiterleitung für diese Kategorie erstellen` wird der Dialog zur Erstellung einer Weiterleitung automatisch geöffnet. Hierbei ist als Weiterleitungs-Quelle dann bereits das Produkt bzw. die Kategorie vorausgewählt.
![Das Produkt bzw. die Kategorie ist bereits vorausgewählt](./lightbox/seo-tab-vorauswahl-der-kategorie.png)

## Weitere Informationen zu den Weiterleitungen
Weitere Informationen zu der Konfiguration von Weiterleitungen findest du unter:
[SEO Professional » Module » 301 und 302 URL Weiterleitungen](./../../300-modules/200-redirect/__de.md)

[sub]
