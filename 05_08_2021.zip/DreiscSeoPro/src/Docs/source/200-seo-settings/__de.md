[title]: <>(SEO Einstellungen)
[menuTitle]: <>()
[url]: <>()

# SEO Einstellungen

## Einführung
SEO Professional erweitert bei den jeweiligen Shopware Modulen (Artikel, Kategorien usw.) die Einstellungen um einen zusätzlichen SEO Tab. Alle SEO Einstellungen aus dem Shopware Standard und die SEO Einstellungen von SEO Professional werden an dieser Stelle zentral zur Verfügung gestellt. Die Standard-Felder der Konfiguration der Meta-Tags sowie der Canonical Url sind entsprechend nicht mehr an der Originalstelle zu finden, sondern werden mit der Installation des Plugins in den neuen Tab verschoben.

![SEO Tab im Produkt Module](./lightbox/seo-tab.png)

## Dokumentation der einzelnen SEO Einstellungen
Die Beschreibungen zu den jeweiligen SEO Einstellungen finden Sie auf den folgenden Unterseiten.



[sub]
