[title]: <>(SERP Vorschau)
[menuTitle]: <>()
[url]: <>()

# SERP Vorschau

## Einführung
Google nutzt den Meta Titel sowie die Meta Beschreibung für die Darstellung der Suchergebnisse. Die SERP Vorschau unterstützt dich bei der Optimierung der SEO Daten und zeigt an, wie das Google Suchergebnis aussehen kann. 

Hierbei ist zu beachten, dass das endgültige Suchergebnis von der Vorschau abweichen kann. Hintergrund ist hierbei, dass Google nicht komplett offenlegt, wie die Suchergebnisse generiert werden. Daher kommt es durchaus vor, dass bspw. ein Meta Titel nur 550 Pixel Breite aufweist, ein anderer aber über die komplette Breite von 600 px angezeigt wird. Gleiches gilt für die Meta Beschreibung. Auch kann es unter bestimmten Umständen sein, dass die Meta Daten vereinzelt komplett verworfen werden und Google eigene Inhalte generiert.

Weitere Informationen zu dem Meta Titel sowie der Meta Beschreibung findest du in dieser Dokumentation unter:<br>
[SEO Professional » SEO Einstellungen » Meta Tags](./../100-meta-tags/__de.md)

![Konfiguration der Meta-Tags](./lightbox/serp-vorschau.png)


[sub]
