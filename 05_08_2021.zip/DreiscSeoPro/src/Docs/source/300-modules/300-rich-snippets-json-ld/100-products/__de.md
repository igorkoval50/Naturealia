[title]: <>(Produkte)
[menuTitle]: <>()
[url]: <>()

# Produkte
Wenn du deine Produktseiten mit Rich Snippet Markup auszeichnest, kann Google ausführliche Produktinformationen anzeigen. Nutzer sehen dann Preis, Verfügbarkeit, Bewertungsergebnisse usw. direkt in den Suchergebnissen.

[toc]

## Zustand der Produkte
Über diese Konfiguration kannst du einen `Standardwert für den Zustand der Produkte` definieren. Hierbei stehen die folgenden Werte als Auswahl zur Verfügung: 

- Neu
- Gebraucht
- Generalüberholt
- Beschädigt

Der hier ausgewählte Standardwert wird für alle Produkte übergeben, bei denen kein `abweichender Produktzustand` definiert wurde. Wie du einen abweichenden Zustand für ein Produkt hinterlegen kannst, erfährst du unter: [SEO Professional » SEO Einstellungen » Rich Snippets](./../../../200-seo-settings/400-rich-snippet/__de.md)

## Verfügbarkeit der Produkte
In diesem Bereich der Konfiguration kannst du Standardwerte für die Verfügbarkeit der Produkte definieren. Hierbei unterscheiden wir zwischen normalen Produkten sowie Produkten, die für den Abverkauf definiert wurden. Hier unterteilen wir anschließend noch, ob diese Lagerbestand aufweisen oder nicht. Hierdurch ergeben sich die folgenden Standardwerte die definiert werden können:

- Standardwert für die Verfügbarkeit von normalen Produkten
- Standardwert für die Verfügbarkeit von normalen Produkten ohne Lagerbestand 
- Standardwert für die Verfügbarkeit von Abverkauf-Produkten 
- Standardwert für die Verfügbarkeit von Abverkauf-Produkten ohne Lagerbestand 

Die hier ausgewählten Standardwerte werden für alle Produkte übergeben, bei denen keine `abweichende Verfügbarkeit` definiert wurde. Wie du eine abweichende Verfügbarkeit für ein Produkt hinterlegen kannst, erfährst du unter: [SEO Professional » SEO Einstellungen » Rich Snippets](./../../../200-seo-settings/400-rich-snippet/__de.md)

## Händlerspezifische Kennung
Unter `Standardwert für Händlerspezifische Kennung` kannst du den Wert definieren, der standardmäßig als SKU Wert übergeben werden soll. Wir empfehlen hier die Produktnummer zu übergeben. Alternativ kann hier per Konfiguration bestimmt werden, dass die Herstellernummer übergeben wird, falls vorhanden.

Der hier ausgewählte Standardwert wird für alle Produkte übergeben, bei denen keine `abweichende händlerspezifische Kennung` definiert wurde. Wie du eine abweichende händlerspezifische Kennung für ein Produkt hinterlegen kannst, erfährst du unter: [SEO Professional » SEO Einstellungen » Rich Snippets](./../../../200-seo-settings/400-rich-snippet/__de.md)

## Herstellerteile-Nummer
Unter `Standardwert für Herstellerteile-Nummer` kannst du den Wert definieren, der standardmäßig als MPN Wert übergeben werden soll. Wir empfehlen hier die Übergabe der Herstellernummer, falls vorhanden. Alternativ kann hier per Konfiguration bestimmt werden, dass die Produktnummer übergeben wird.

Der hier ausgewählte Standardwert wird für alle Produkte übergeben, bei denen keine `abweichende Herstellerteile-Nummer` definiert wurde. Wie du eine abweichende Herstellerteile-Nummer für ein Produkt hinterlegen kannst, erfährst du unter: [SEO Professional » SEO Einstellungen » Rich Snippets](./../../../200-seo-settings/400-rich-snippet/__de.md)

## Preis gültig bis Datum
Die Konfiguration `Preis gültig bis Datum` setzt das Rich Snippet Feld `priceValidUntil`. Hierbei handelt es sich um ein von Google empfohlendes Feld, dass angibt, wie lange der aktuelle Preis gültig ist.

Über `Standardwert für das Feld "Preis gültig bis Datum" (priceValidUntil)` kann ein Standardwert konfiguriert werden, der für die Produkte verwendet werden soll. Neben der Einstellung, dass das Feld gar nicht ausgegeben werden soll, kann das aktuelle Datum oder das aktuelle Datum + \[Zeitraum] ausgewählt werden. Zusätzlich steht die Option `Aktuelles Datum + eigene Anzahl an Tagen` zur Verfügung. Wählst du diese Option aus, so erscheint das Feld `Anzahl an Tagen`, was in diesem Fall ebenfalls ausgefüllt werden muss.

Möchtest du für ein spezifisches Produkt ein festes Datum für diesen Wert setzen, so ist über das Feld `Abweichendes "Preis gültig bis"-Datum` möglich. Weitere Informationen hierzu findest du unter: [SEO Professional » SEO Einstellungen » Rich Snippets](./../../../200-seo-settings/400-rich-snippet/__de.md)
   
## Bewertungen
Werden Produktbewertungen an Google übergeben, so muss auch ein Autor der Bewertung übergeben werden. Wird dies nicht gemacht, so quittiert Google dies mit einer Fehlermeldung.

Über die Konfiguration `Autor der Bewertung` kann entsprechend definiert werden, welcher Wert als Autor übergeben werden soll. Hierbei stehen die folgenden Optionen zur Auswahl:

- **Dieses Feld standardmäßig nicht ausgeben**<br>Wird nicht empfohlen, da Google die Bewertung dann als nicht vollständig bewertet.
- **Statischen Wert übergeben (Textbaustein)**<br>Ist diese Option aktiv, so wird ein als Textbaustein definierter Wert als Autor übergeben. Der Textbaustein kann über die Schaltfläche `Textbaustein Konfiguration in neuem Fenster öffnen` bearbeitet werden, sobald die Option ausgewählt wurde.
- **Vorname des Kunden übergeben**<br>Ist diese Option aktiv, so wird der Vorname des Kunden übergeben: `Beispiel: Max`
- **Vorname + Anfangsbuchstabe des Nachnamen des Kunden übergeben (empfohlen)**<br>Ist diese Option aktiv, so wird der Vorname sowie der Anfangsbuchstabe des Nachnamen des Kunden übergeben: `Beispiel: Max M.`
- **Vorname + Nachname des Kunden übergeben (Einverständnis der Kunden vorausgesetzt!)**<br>Ist diese Option aktiv, so wird der Vor- sowie Nachnamen des Kunden übergeben: `Beispiel: Max Müller`<br><br>***Wichtiger Hinweis:*** Wählen Sie diese Option nur dann, wenn Sie rechtlich geprüft haben, dass Sie Vor- und Nachname des Kunden an dieser Stelle ausgeben dürfen!

## Weitere Produkt-Einstellungen
### Name des Verkäufers
Über das Feld `Name des Verkäufers` ist es möglich den Namen des Verkäufers zu hinterlegen. In den Rich Snippets wird dieser Wert als `@type: Organization » seller` ausgegeben. Wir empfehlen hier den Namen Ihrer Firma zu hinterlegen.

[sub]
