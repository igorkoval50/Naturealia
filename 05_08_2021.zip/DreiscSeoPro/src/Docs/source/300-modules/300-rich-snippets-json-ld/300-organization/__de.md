[title]: <>(Unternehmen)
[menuTitle]: <>()
[url]: <>()

# Unternehmen
In diesem Bereich hast du die Möglichkeit Rich Snippet Daten der Bereiche `Logo` und `Lokales Unternehmen` zu übergeben.

[toc]

## Logo
Hiermit wird das Bild angegeben, das Google als Logo deines Unternehmens in den Suchergebnissen und im Knowledge Graph verwendet. Möchtest du, dass dein Logo per JSON-LD übergeben werden, so musst du sicherstellen, dass die Option `Logo per JSON-LD übergeben` aktiv ist.

### Konfigurationsfelder für die Logo-Konfiguration
Neben der Schaltfläche zur Aktivierung der Logo Übergabe stehen die folgenden Einstellungen zur Verfügung:
- **URL des Logos**<br>Gebe hier die URL an die bei Google als Link für das Logo verwendet werden soll.
- **Logo**<br>Über diese Einstellung wird das eigentliche Logo hinterlegt. Dieses muss im Format JPG, PNG oder GIF vorliegen sowie mindestens 112 × 112 Pixel groß sein.

## Lokales Unternehmen
Mithilfe der strukturierten Daten für lokale Unternehmen kannst du Google die Anschrift, Kontaktdaten sowie Öffnungszeiten deines Unternehmens mitteilen. Wie bei den Logo Daten muss die Übergabe auch hier über die Schaltfläche `Lokales Unternehmen per JSON-LD übergeben` explizit aktiviert werden.

### Konfigurationsfelder für Konfiguration des lokalen Unternehmens
Die Konfigurationsfelder `Name des Unternehmens`, `Telefonnummer` und `URL des Unternehmensstandorts` sowie die Adressangaben in dem Dialoglfeld `Adresse` beziehen sich auf das lokale Unternehmen und sollten soweit selbsterklärend sein.

Über die Konfiguration `Öffnungszeiten` kannst du die Öffnungszeiten der einzelnen Wochentage hinterlegen. Aktiviere hierzu über die Schaltfläche in der Spalte `Aktiv` den jeweiligen Wochentag. Anschließend kann die Öffnungs- sowie Schließzeit hinterlegt werden.

![Konfiguration der Öffnungszeiten](./lightbox/oeffnungszeiten-lokales-unternehmen-shopware.png)
[sub]
