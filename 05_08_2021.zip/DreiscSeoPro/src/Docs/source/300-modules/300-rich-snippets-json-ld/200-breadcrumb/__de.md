[title]: <>(Breadcrumb)
[menuTitle]: <>()
[url]: <>()

# Breadcrumb
Wenn du die Breadcrumb Daten übergibst, kann Google die Struktur der Seite optimal erfassen und sich ein besser Bild deiner Seitenstruktur verschaffen.

[toc]

## Allgemein
Möchtest du, dass die Breadcrumb per JSON-LD übergeben werden, so musst du sicherstellen, dass die Option `Breadcrumb per JSON-LD übergeben` aktiv ist.

## Startseite
Standardmäßig beginnt die Breadcrumb mit der ersten Kategorie, bspw. `Herren » Schuhe`. Über die Konfiguration `Startseite als eigenes Breadcrumb Element` kann definiert werden, dass zusätzlich auch ein Eintrag für die Startseite erfolgt, sodass die Breadcrumb in dem oben genannten Beispiel dann wie folgt aussehen würde: `Herren » Schuhe » Herren`.

Die Konfiguration unterscheidet zwischen der Übergabe in der JSON-LD sowie der Ausgabe der Breadcrumb im Shop. Somit ergeben sich die folgenden Optionen für diese Einstellung:
- **Nicht ausgeben**<br>Für die Startseite wird weder im Shop noch in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.
- **Nur im Shop ausgeben**<br>Für die Startseite wird nur im Shop ein Eintrag für die Breadcrumb erzeugt.
- **Nur per Rich Snippet übertragen**<br>Für die Startseite wird nur in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.
- **Im Shop ausgeben und per Rich Snippet übertragen**<br>Der Breadcrumb Eintrag wird sowohl im Shop ausgegeben, als auch in der JSON-LD übergeben.

## Produkt-Detailseite
Standardmäßig wird für das Produkt selbst auf der Detailseite kein Breadcrumb-Eintrag erstellt, bspw. `Herren » Schuhe`. Über die Konfiguration `Produktseite als eigenes Breadcrumb Element` kann definiert werden, dass zusätzlich auch ein Eintrag für die Produktseite erfolgt, sodass die Breadcrumb in dem oben genannten Beispiel dann wie folgt aussehen würde: `Herren » Schuhe » Nike Free 60`.

Die Konfiguration unterscheidet zwischen der Übergabe in der JSON-LD sowie der Ausgabe der Breadcrumb im Shop. Somit ergeben sich die folgenden Optionen für diese Einstellung:
- **Nicht ausgeben**<br>Für die Produktseite wird weder im Shop noch in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.
- **Nur im Shop ausgeben**<br>Für die Produktseite wird nur im Shop ein Eintrag für die Breadcrumb erzeugt.
- **Nur per Rich Snippet übertragen**<br>Für die Produktseite wird nur in der JSON-LD ein Eintrag für die Breadcrumb erzeugt.
- **Im Shop ausgeben und per Rich Snippet übertragen**<br>Der Breadcrumb Eintrag wird sowohl im Shop ausgegeben, als auch in der JSON-LD übergeben.

[sub]
