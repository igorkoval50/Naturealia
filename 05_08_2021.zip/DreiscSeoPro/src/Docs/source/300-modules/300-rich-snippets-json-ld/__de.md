[title]: <>(Rich Snippets (JSON-LD))
[menuTitle]: <>()
[url]: <>()

# Rich Snippets (JSON-LD)
Im Shopware Standard werden die Rich Snippets durch sogenannte Mikrodaten im Quellcode übertragen. Über SEO Professional hast du die Möglichkeit diese Mikrodaten aus dem Quellcode zu entfernen und durch die von Google empfohlenen JSON-LD Rich Snippets zu ersetzen.

Hierbei werden neben den Standardfeldern aus dem Shopware Standard auch noch weitere Rich Snippets Felder übertragen, die über dieses Modul entsprechend konfiguriert werden können.

[toc]

## Rich Snippets über JSON-LD aktivieren
Damit SEO Professional die Mikrodaten aus dem Shopware Standard durch JSON-LD Rich Snippets ersetzen und dir hierzu weitere Einstellungsmöglichkeiten zur Verfügung stellen kann, musst du zunächst sicherstellen, dass die entsprechende Option `Rich Snippets über JSON-LD aktivieren` im Tab `Allgemein` aktiv ist.

## Allgemeine Information zu den Einstellungen
### Verkaufskanel
Standardmäßig werden die hier sowie in den Untermodulen hinterlegten Konfigurationen für alle Verkaufskanäle genutzt. Möchtest du eine Einstellung nur für einen bestimmten Verkaufskanel hinterlegen, so musst du diesen zunächst über das Feld `Verkaufskanel` auswählen. Das Verhalten ist hierbei anschließend analog zur Konfiguration der Produkt Varianten. Eine Vererbung findet also solange statt, bis das Link-Symbol einer Einstellung aufgelöst ist.

![Verkaufskanel auswählen](./lightbox/sales-channel-auswahl.png)


## Rich Snippet Module
Die weiteren Einstellungen findest du in den folgenden Untermodulen:

[sub]
