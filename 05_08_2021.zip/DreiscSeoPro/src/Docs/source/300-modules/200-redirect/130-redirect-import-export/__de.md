[title]: <>(CSV Import und Export der Weiterleitungen)
[menuTitle]: <>()
[url]: <>()

# CSV Import und Export der Weiterleitungen
Neben der manuellen Erfassungen der Weiterleitungen über die Adminstration, können die Weiterleitungen auch per CSV Datei importiert bzw. exportiert werden.

[toc]

## Vorbereitung
Um einen Im- bzw. einen Export durchzuführen, muss zunächst das Modul geöffnet werden. Wechsel hierzu zur Liste der bestehenden Weiterleitungen unter `SEO Professional » 301 und 302 Weiterleitungen` und klicke hier auf die Schaltfläche `CSV Import / Export`.

![CSV Import / Export öffnen](./lightbox/redirect-weiterleitungs-dialog-oeffnen.png)

## Import
### Einleitung
Für den Import müssen zwei Felder definiert werden. Zum einen die `eigentliche CSV Datei` zum anderen das `Spalten-Trennzeichen`, dass zum Auslesen der CSV Datei verwendet werden soll.

Eine CSV Import-Datei muss mindestens eine Weiterleitungsquelle sowie eine Weiterleitungsziel aufweisen. Spalten wie `Aktiv` oder `HTTP Status Code` hingegen sind optional, da hierfür Standardwerte vorliegen. Es können in einer CSV Datei auch mehrere Spalten für verschiedene Weiterleitungsquellen bzw. -ziele definiert werden. Es muss hierbei dann jedoch darauf geachtet werden, dass pro Zeile nur eine Quelle sowie Ziel definiert ist.

Das Spalten-Trennzeichen ist standardmäßig ein Semikolon, kann aber auch entsprechend abweichen. 

![Import von Weiterleitungen als CSV](./lightbox/import.png)

### Spaltenaufbau der CSV
#### Grundsätzlicher Aufbau
Die erste Zeile der CSV Datei muss eine Überschriftszeile sein, in der die unten definierten Spaltenbezeichnungen als Überschrift hinterlegt werden. Ab Zeile 2 folgen dann die eigentlichen Weiterleitungen.

#### Allgemeine Konfiguration
Bei den folgenden Spalten handelt es sich um die allgemeine Konfigurationen, die in der Import CSV Datei optional angegeben werden können:

| Spalte | Beschreibung | Mögliche Werte | Pflichtfeld | Standardwert |
| --- | --- | --- |
| **active** | Über diese Spalte kann definiert werden, ob eine Weiterleitung nach dem Import direkt aktiv sein soll oder nicht. | 1=Aktiv oder 2=Inaktiv | Nein | 1 |
| **httpStatusCode** | Diese Spalte gibt an, über welchen HTTP Status Code die Weiterleitung erfolgen soll. | 301 oder 302 | Nein | 301 |

#### Weiterleitungsquelle
Wie bereits in der Einleitung beschrieben, muss mindestens eine Spalte für eine Weiterleitungsquelle in der CSV vorliegen. Deine CSV Datei muss also mindestens eine der folgenden Spalten aufweisen:

| Spalte | Beschreibung | Beispielwert |
| --- | --- |
| **sourceProductNumber** | Soll eine Weiterleitung für ein Produkt angelegt werden, so kann über diese Spalte die Produktnummer von dem Produkt hinterlegt werden, für das du eine Weiterleitung einrichten möchtest | SW-1000 | 
| **sourceInternalUrl** | Über diese Spalte kann eine interne URL weitergeleitet werden. Hierbei ist wichtig, dass in dieser Ziele die absolute URL angegeben wird. Der Importer teilt diese dann in Sales Channel Domain sowie die eigentliche interne URL auf | http://www.shop.de/mein-redirect | 
| **sourceCategoryId** | Möchtest du eine Kategorie weiterleiten, so musst du diese Spalte nutzen. Als Wert wird hierbei die ID der Kategorie hinterlegt. Hierbei handelt es sich um das Datenbankfeld `category.id` | c542db9e9d964fe29a15061440a68730 | 
| **sourceProductId** | Bei dieser Spalte handelt es sich um eine Alternative zu der Spalte `sourceProductNumber`. Statt der Produktnummer gibst du hier die ID des Produkts an. (Datenbankfeld: product.id)  | fe13aa4b47264e049b9bf84bd5e2a38a | 

#### Weiterleitungsziel
Neben mindestens einer Weiterleitungsquelle, muss deine CSV Datei auch mindestens eine der folgenden Spalten als Weiterleitungsziel aufweisen:

| Spalte | Beschreibung | Beispielwert |
| --- | --- |
| **targetProductNumber** | Möchtest du eine Weiterleitung zu einem Produkt erstellen, so kannst du diese Spalte nutzen. Als Wert gibst du hier die Produktnummer des Ziels an. | SW-1006.1 | 
| **targetInternalUrl** | Über diese Spalte kannst du eine interne URL angeben, an die weitergeleitet werden soll. Hierbei ist wichtig, dass in dieser Ziele die absolute URL angegeben wird. Der Importer teilt diese dann in Sales Channel Domain sowie die eigentliche interne URL auf | https://www.shop.de/ziel-url | 
| **targetCategoryId** | Für eine Weiterleitung auf eine Kategorie musst du diese Spalte nutzen. Als Wert wird hierbei die ID der Kategorie hinterlegt. Hierbei handelt es sich um das Datenbankfeld `category.id`  | c542db9e9d964fe29a15061440a68730 | 
| **targetProductId** | Wie bei der Weiterleitungsquelle handelt es sich bei dieser Spalte um eine Alternative zur Eingabe der Produktnummer. Bei dieser Spalte muss die ID des Produkts hinterlegt werden, auf das weitergeleitet werden soll. | fe13aa4b47264e049b9bf84bd5e2a38a | 
| **targetExternalUrl** | Soll eine Weiterleitung auf eine externe Seite durchgeführt werden, so kannst du dies über diese Spalte realisieren. | https://de.dreischild.de | 

#### Spezielfelder

| Spalte | Beschreibung | Beispielwert |
| --- | --- |
| **sourceRestrictionDomains** | Über diese Spalte hast du die Möglichkeit Weiterleitungen auf bestimmte Sales Channel Domains zu begrenzen. Möchtest du hier mehr als eine Domain hinterlegen, so verwende eine Pipe (\|) als Trennzeichen | https://www.shop.de\|https://www.shop.fr | 
| **targetDeviatingDomain** | Über diese Spalte hast du die Möglichkeit eine abweichende Domain für Weiterleitung zu definieren. | http://www.shop.de | 

### Log
Nachdem der Import durchgeführt wurde, findest du unterhalb des Uploadfeldes das Log des letzten Imports. Hierbei kannst du bei erfolgreich importierten Zeilen über `Konfiguration in neuem Tab öffnen` die erstellte Weiterleitung öffnen oder aber über `Fehlermeldung anzeigen` dir detailierte Informationen anzeigen, warum ein Import fehlgeschlagen ist.

![Log des Imports](./lightbox/import-log.png)

## Export
Die CSV Exporte der Weiterleitungen haben den selben Aufbau wie die CSV Datei für den Import. Somit können exportierte Weiterleitungen über das Modul wieder importiert werden.

### Export durchführen
Zum erstellen eines Exports musst du zunächst auf den Tabreiter `Export` klicken. Anschließend kann die Erstellung der CSV Datei über `Export starten` gestartet werden. Ist dieser Prozess abgeschlossen, so wird die Schaltfläche `CSV Datei herunterladen` bereitgestellt, über die die CSV Datei bezogen werden kann. 
![Export](./lightbox/export.png)

## CSV-Beispiele für den Import
### Von Produktnummer zu Produktnummer
```csv
sourceProductNumber;    targetProductNumber
SW-1000;                SW-1006
SW-1004;                SW-1005
```

### Von interner URL zu Produktnummer
```csv
sourceInternalUrl;                  targetProductNumber
http://www.shopware-dev.de/r-1006;  SW-1006
http://www.shopware-dev.de/r-1005;  SW-1005
```

### Von interner URL zu Produktnummer bzw Kategorie
```csv
sourceInternalUrl;                  targetProductNumber;    targetCategoryId
http://www.shopware-dev.de/r-1006;  SW-1006;
http://www.shopware-dev.de/r-1005;  ;                       c542db9e9d964fe29a15061440a68730
```

### Von interner URL zu Produktnummer bzw Kategorie (mit Aktiv-Spalte)
```csv
active; sourceInternalUrl;                  targetProductNumber;    targetCategoryId
1;      http://www.shopware-dev.de/r-1006;  SW-1006;
0;      http://www.shopware-dev.de/r-1005;  ;                       c542db9e9d964fe29a15061440a68730
```

### Von Produktnummer zu Produktnummer (beschränkt auf Domains)
```csv
sourceProductNumber;    targetProductNumber;    sourceRestrictionDomains
SW-1000;                SW-1006;                http://www.shopware-dev.de|http://www.shopware-dev.de/en
SW-1004;                SW-1005;
SW-1001;                SW-1005;                http://www.shopware-dev.de
```

### Von Produktnummer zu Produktnummer (auf abweichende Domain weiterleiten)
```csv
sourceProductNumber;    targetProductNumber;    targetDeviatingDomain
SW-1000;                SW-1006;                http://www.shopware-dev.de/en
SW-1001;                SW-1005;                http://www.shopware-dev.de/en
```

