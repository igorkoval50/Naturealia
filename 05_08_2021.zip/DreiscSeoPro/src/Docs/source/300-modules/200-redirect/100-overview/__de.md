[title]: <>(Übersicht der Weiterleitungen)
[menuTitle]: <>()
[url]: <>()

# Übersicht der Weiterleitungen
Unter `SEO Professional » 301 und 302 URL Weiterleitungen` erhältst Du eine Auflistung deiner angelegten Weiterleitungen mit den wichtigsten Informationen. Über einen Klick in den jeweiligen Spaltentitel kannst Du die Sortierung der Weiterleitungen ändern. Neben den einzelnen Spaltenbezeichnungen findest Du einen Button, über den du die Spalte ausblenden kannst. Über das allgemeine Suchfeld in der Administration können die angezeigten Weiterleitungen entsprechend eingegrenzt werden.

![Übersicht der Weiterleitungen](./lightbox/overview.png)

In der Übersicht kannst Du auf einen Blick die wichtigsten Informationen zu deinen Weiterleitungen entnehmen.
Im Standard ist die Übersicht wie folgt aufgebaut:

- **Aktiv**<br>Zeigt an, ob eine Weiterleitung aktiv ist.
- **Quelle**<br>Kurze Beschreibung, was weitergeleitet wird. Handelt es sich nicht um eine URL, sondern bspw. um ein Produkt das weitergeleitet wird, so wird dies in eckigen Klammern davor angezeigt.
- **Ziel**<br>Definiert das Ziel der Weiterleitung. Hierbei kommt die gleiche Syntax wie bei der Quelle zum Einsatz.
- **HTTP Status Code**<br>Zeigt, ob es sich um eine temporäre oder dauerhafte Weiterleitung handelt.
[sub]
