[title]: <>(Neue Weiterleitungen anlegen)
[menuTitle]: <>()
[url]: <>()

# Neue Weiterleitungen anlegen
In dieser Anleitung wird beschrieben, wie du eine neue Weiterleitung in SEO Professional erstellen kannst.
[toc]

## Vorbereitung
Öffne zum Erstellen einer neuen Weiterleitung die Übersicht unter `SEO Professional » 301 und 302 URL Weiterleitungen` und klicke hier auf die Schaltfläche `Neue Weiterleitung anlegen`

![Neue Weiterleitung erstellen](./lightbox/create.png)

## Grundeinstellungen
![Grundeinstellungen](./lightbox/grundeinstellungen.png)

- **Aktiv**<br>Definiert, ob die Weiterleitung durchgeführt werden soll.
- **HTTP Status**<br>Über diese Option kannst du konfigurieren, ob es sich um eine dauerhafte oder aber eine temporäre Weiterleitung handelt.

## Quelle der Weiterleitung
Bei der Definition der Quelle der Weiterleitung muss zunächst konfiguriert werden, welche Quell-Ressource weitergeleitet werden soll. Im Standard kann eine interne URL, ein Produkt oder aber eine Kategorie weitergeleitet werden.
 
![Grundeinstellungen](./lightbox/quelle-der-weiterleitung_waehlen.png)

### Quell-Ressource: Interne URL
![Quell-Ressource: Interne URL](./lightbox/quelle-ressource_interne-url.png)

- **Domain**<br>An dieser Stelle werden dir alle Domains der Sales Channels gelistet. Wähle hier die gewünschte Domain aus.
- **Quell-URL**<br>Als Quell-URL muss der relative Pfad nach der Domain definiert werden.

### Quell-Ressource: Produkt
![Quell-Ressource: Produkt](./lightbox/quelle-ressource_article.png)

- **Produkt**<br>An dieser Stelle musst du das Produkt auswählen, für das eine Weiterleitung eingerichtet werden soll.
- **Weiterleitung auf Domain(s) beschränken**<br>Standardmäßig greift die URL für alle Domains, unter der das definierte Produkt erreichbar ist und eine valide Weiterleitung durchgeführt werden kann. Wird diese Option aktiviert, so wird das Zusatzfeld **Diese Weiterleitung nur bei den folgenden Domains durchführen** freigeschaltet.
- **Diese Weiterleitung nur bei den folgenden Domains durchführen**<br>Über dieses Feld kannst du konfigurieren, dass die bestehende Weiterleitung nur für bestimmte Domains durchgeführt werden soll.

### Quell-Ressource: Kategorie
![Quell-Ressource: Produkt](./lightbox/quelle-ressource_kategorie.png)

- **Kategorie**<br>An dieser Stelle musst du die Kategorie auswählen, für die eine Weiterleitung eingerichtet werden soll.
- **Weiterleitung auf Domain(s) beschränken**<br>Standardmäßig greift die URL für alle Domains, unter der die definierte Kategorie erreichbar ist und eine valide Weiterleitung durchgeführt werden kann. Wird diese Option aktiviert, so wird das Zusatzfeld **Diese Weiterleitung nur bei den folgenden Domains durchführen** freigeschaltet.
- **Diese Weiterleitung nur bei den folgenden Domains durchführen**<br>Über dieses Feld kannst du konfigurieren, dass die bestehende Weiterleitung nur für bestimmte Domains durchgeführt werden soll.


## weiterleiten auf ...
Anschließend muss das Ziel der Weiterleitung bestimmt werden. Analog zur Quell-Ressource stehen hierbei eine interne URL, ein Produkt oder aber eine Kategorie zur Auswahl. Im Gegensatz zur Quell-Ressource kann als Typ zusätzlich noch eine externe URL als Ziel definiert werden.

![Ziel der Weiterleitung wählen](./lightbox/ziel-der-weiterleitung_waehlen.png)

### Ziel-Ressource: Interne URL
![Ziel-Ressource: Interne URL](./lightbox/ziel-ressource_interne-url.png)

- **Domain**<br>An dieser Stelle werden dir alle Domains der Sales Channels gelistet. Wähle hier die gewünschte Domain aus.
- **Ziel-URL**<br>Als Ziel-URL muss der relative Pfad nach der Domain definiert werden.

### Ziel-Ressource: Externe URL
![Ziel-Ressource: Externe URL](./lightbox/ziel-ressource_externe-url.png)

- **URL**<br>Hinterlege an dieser Stelle die URL, an die eine Weiterleitung stattfinden soll.

### Ziel-Ressource: Produkt
![Ziel-Ressource: Produkt](./lightbox/ziel-ressource_article.png)

- **Produkt**<br>An dieser Stelle musst du das Produkt auswählen, das als Ziel der Weiterleitung genutzt werden soll.
- **An abweichende Domain weiterleiten**<br>Standardmäßig wird bei der Weiterleitung auf ein Produkt die Domain der Weiterleitungsquelle beibehalten. Ist das jeweilige Produkt unter der Domain nicht erreichbar, so findet auch keine Weiterleitung statt. Wird die Option `An abweichende Domain weiterleiten` aktiviert, so kann das Standardverhalten angepasst werden, indem eine feste Domain ausgewählt werden kann, die als Ziel-Domain dienen soll.
- **Abweichende Ziel-Domain**<br>Über diese Einstellung kannst du die Domain definieren, an die die Weiterleitung durchgeführt werden soll. Grundlegende Informationen hierzu findest du in der Beschreibung des Feldes `An abweichende Domain weiterleiten`

### Ziel-Ressource: Kategorie
![Ziel-Ressource: Kategorie](./lightbox/ziel-ressource_kategorie.png)

- **Kategorie**<br>An dieser Stelle musst du die Kategorie auswählen, die als Ziel der Weiterleitung genutzt werden soll.
- **An abweichende Domain weiterleiten**<br>Standardmäßig wird bei der Weiterleitung auf eine Kategorie die Domain der Weiterleitungsquelle beibehalten. Ist die jeweilige Kategorie unter der Domain nicht erreichbar, so findet auch keine Weiterleitung statt. Wird die Option `An abweichende Domain weiterleiten` aktiviert, so kann das Standardverhalten angepasst werden, indem eine feste Domain ausgewählt werden kann, die als Ziel-Domain dienen soll.
- **Abweichende Ziel-Domain**<br>Über diese Einstellung kannst du die Domain definieren, an die die Weiterleitung durchgeführt werden soll. Grundlegende Informationen hierzu findest du in der Beschreibung des Feldes `An abweichende Domain weiterleiten`

## Einschränkungen

### URL muss den Shopware Kernel aufrufen
Eine Weiterleitung per SEO Professional kann nur dann aktiv werden, wenn beim Aufruf der jeweiligen URL auch der Shopware Kernel aufgerufen wird. Wird in der Serverkonfiguration bspw. definiert das URLs mit bestimmten Dateiendungen zu einer serverseitigen "Not Found" Seite führen, wenn diese nicht vorhanden sind, so kann hier auch keine Weiterleitung greifen. In diesem Fall müsste also sichergestellt werden, dass die Aufrufe auf die Shopware Instanz weitergeleitet werden.

### Die Startseite der Shops kann aktuell nicht weiterleitet werden
Wählt man als Weiterleitungsquelle die Root-Kategorie des jeweiligen Shops so findet in der aktuellen Versions des Plugins keine Weiterleitung der jeweiligen Startseite statt.

[sub]
