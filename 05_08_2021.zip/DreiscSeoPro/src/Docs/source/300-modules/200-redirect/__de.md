[title]: <>(301 und 302 URL Weiterleitungen)
[menuTitle]: <>()
[url]: <>()

# 301 und 302 URL Weiterleitungen
Über das SEO Professional Modul **301 und 302 URL Weiterleitungen** können über die Administration Url Weiterleitungen eingerichtet werden. Hierbei kann eine Url an eine andere Url, einen Artikel oder eine Kategorie weitergeleitet werden. Über den HTTP Status Code kann definiert werden, ob es sich um eine dauerhafte (301) oder temporäre (302) Weiterleitung handelt.


[sub]
