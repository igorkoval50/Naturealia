[title]: <>(Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen)
[menuTitle]: <>()
[url]: <>()

# Weiterleitungs-Widget in den Produkt- und Kategorieeinstellungen
In dem SEO-Tab der Produkte sowie der Kategorien findest du jeweils ein Widget für die Darstellung der Informationen bestehender Weiterleitung bzw. zur Erstellung von Weiterleitungen für das jeweilige Produkt / Kategorie.

Eine Beschreibung dieser Widgets findest du unter:<br>
[SEO Professional » SEO Einstellungen » Weiterleitungs-Widget](./../../../200-seo-settings/600-redirect-widget/__de.md)
