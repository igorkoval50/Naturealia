[title]: <>(Weitere Einstellungen)
[menuTitle]: <>()
[url]: <>()

# Weitere Einstellungen
Unter `SEO Professional » Weitere Einstellungen` findest du weitere Konfigurationsmöglichkeiten zu den Modulen sowie allgemeine SEO Einstellungen.

## Verkaufskanel
Standardmäßig werden die hier sowie in den Untermodulen hinterlegten Konfigurationen für alle Verkaufskanäle genutzt. Möchtest du eine Einstellung nur für einen bestimmten Verkaufskanel hinterlegen, so musst du diesen zunächst über das Feld `Verkaufskanel` auswählen. Das Verhalten ist hierbei anschließend analog zur Konfiguration der Produkt Varianten. Eine Vererbung findet also solange statt, bis das Link-Symbol einer Einstellung aufgelöst ist.

![Verkaufskanel auswählen](./lightbox/sales-channel-auswahl.png)

[sub]
