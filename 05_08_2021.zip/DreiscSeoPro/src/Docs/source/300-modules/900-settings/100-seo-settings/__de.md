[title]: <>(SEO Einstellungen)
[menuTitle]: <>()
[url]: <>()

# SEO Einstellungen

[toc]

## Bulk Generatoren
### Bulk Generatoren beim Speicherprozess starten
Ist diese Option aktiv, so wird beim Speichern einer Kategorie bzw. eines Produkts automatisch der Bulk Generator für die jeweilige Entity gestartet. Es muss somit nicht extra der Bulk Generator gestartet werden, um die SEO Daten zu generieren.<br><br>Aus Performance-Gründen kann es unter Umständen Sinn machen diese Option zu deaktivieren, wenn bspw. eine große Menge an Daten per ERP abgeglichen wird.

## Meta-Tags
### Konfiguration der Pixel- bzw. Zeichenlängen der Meta Tags
Für die Meta Tags `Meta Titel`, `Meta Beschreibung` sowie `Keywords` kannst du an dieser Stelle jeweils die folgenden Konfigurationen definieren:

- **Empfohlene Pixellänge von** bzw. **Empfohlene Zeichenlänge von**:<br>Gibt die empfohlene Mindestanzahl der Pixel bzw. Zeichen an, die für die jeweilige Meta Angabe eingegeben werden sollte.

- **bis**:<br>Gibt die empfohlene Maximalanzahl der Pixel bzw. Zeichen an, die für die jeweilige Meta Angabe eingegeben werden sollte.

- **Maximale Pixellänge** bzw. **Maximale Zeichenlänge**:<br>Gibt die maximale Anzahl der Pixel bzw. Zeichen an, die für die jeweilige Meta Angabe eingegeben werden dürfen.

#### Verwendung der Konfiguration
Die hier hinterlegte Konfiguration dient als Grundlage für andere Funktionen von SEO Professional. So wird bei Eingabe der Meta-Tags bspw. eine Zeichen- bzw. Pixellänge innerhalb des empfohlenen Bereichs *grün*, ein Wert zwischen dem bis- und Maximalwert *orange* und ein Wert über der maximalen Zeichen- bzw. Pixellänge *rot* dargestellt.

Weitere Informationen zu den Meta-Tags findest du unter:
[SEO Professional » SEO Einstellungen » Meta Tags](./../../../200-seo-settings/100-meta-tags/__de.md)

### Robots-Tag
#### Standard Robots-Tag
Wird für ein Produkt bzw. eine Kategorie kein Robots-Tag explizit definiert, so wird der jeweilige Standard Robots-Tag ausgegeben. Diese Standardwerte lassen sich an dieser Stelle über die Auswahlfelder `Standard Robots-Tag für Produkte` und `Standard Robots-Tag für Kategorien` hinterlegen.

#### Noindex Request Parameter Query
Haben wir für eine Kategorie bspw. `index,follow` als Robots-Tag definiert, so ist es meistens trotzdem nicht gewünscht, dass die Kategorieseite auch dann indexiert wird, wenn Filter, andere Sortierungen usw. aktiv sind. Grund ist, dass wir in diesem Fall verschiedene Seiten mit dem gleichen Inhalt hätten, was zu Duplicate Content führen würde. Auch ist es üblich, dass man nur die erste Seite des Kategorielistings indexieren lässt.

Um dies zu realisieren, können wir über die Option `Noindex Request Parameter Query` Bedingungen definieren, die dafür sorgen, dass als Robot Tag `noindex` ausgegeben wird. 

SEO Professional gleicht hierbei die Bedingungen mit den GET-Parametern der URL ab und wird entsprechend aktiv, sobald eine Bedingung greift. Schauen wir uns hierzu einmal die vordefinierte Konfiguration an:

```sort!=name-asc; p>1; properties; rating; min-price; max-price; manufacturer```

Hierbei haben wir standardmäßig `7 Bedingungen`, die vordefiniert sind. Die einzelnen Bedingungen werden jeweils mit einem Semikolon getrennt. Die Bedingung `sort!=name-asc` sag aus, dass immer dann `noindex` verwendet werden soll, wenn der GET Parameter `sort` vorhanden, nicht aber dem Wert `name-asc` entspricht. Anders gesagt werden somit also nur die Kategorieseiten mit der Sortierung `Name aufsteigend` indexiert. Sollten Sie eine andere Standardsortierung nutzen, so sollten Sie diese Bedingung entsprechend anpassen.

Die nächste Standard-Bedingung ist `p>1`. Diese definiert, dass nur die erste Kategorieseite indexiert wird, da der Parameter `p` für die aktuelle Seitennummer steht und die Bedingung besagt, dass `noindex` verwendet werden soll, wenn dieser Parameter größer 1 ist. 

Die weiteren Bedingungen `properties`, `rating`,  `min-price`, `max-price` und `manufacturer` wurden ohne Operator definiert. Es wird entsprechend `noindex` verwendet, sobald sich einer dieser Parameter in der URL befindet.

**Operatoren in der Übersicht**<br>
In der folgenden Tabelle finden Sie eine Auflistung der verfügbaren Operatoren:

Operator | Beschreibung | Beispiel
-------- | -------- | --------
\[OHNE OPERATOR]   | Prüft, ob der GET Parameter in der URL definiert ist  | manufacturer
=   | Prüft, ob der GET Parameter mit dem definierten Wert übereinstimmt   | view=detail
!=   | Prüft, ob der GET Parameter mit dem definierten Wert NICHT übereinstimmt. Hierbei muss der Parameter jedoch definiert sein.   | sort!=name-asc
>   | Prüft, ob der GET Parameter größer als der definierte Wert ist   | p>1
<   | Prüft, ob der GET Parameter kleiner als der definierte Wert ist   | number<10
>=   | Prüft, ob der GET Parameter größer als der definierte Wert ist oder übereinstimmt   | p>=2
<=   | Prüft, ob der GET Parameter kleiner als der definierte Wert ist oder übereinstimmt   | number=<9

## SERP Vorschau
### Verkaufskanal Vorauswahl
Standardmäßig muss in der Konfiguration der Canonical Urls eines Produkts bzw. Kategorie zunächst der Verkaufskanal ausgewählt werden, für den Anpassung durchgeführt werden soll. Wird hier ein Verkaufskanel ausgewählt, so wird dieser bei den Produkten und Kategorien automatisch vorausgewählt.

## Canonical Urls
### Verkaufskanal Vorauswahl
Standardmäßig muss zur Anzeige der SERP Vorschau eines Produkts bzw. Kategorie zunächst der Verkaufskanal ausgewählt werden, für den die Vorschau angezeigt werden soll. Wird hier ein Verkaufskanel ausgewählt, so wird dieser bei den Produkten und Kategorien automatisch vorausgewählt.

## Social Media
### Konfiguration der Zeichenlängen
Für die Social Media Felder `Facebook Titel`, `Facebook Beschreibung` sowie `Twitter Titel` und `Twitter Beschreibung` kannst du an dieser Stelle jeweils die `folgenden Konfigurationen definieren:`

- **Empfohlene Pixellänge von** bzw. **Empfohlene Zeichenlänge von**:<br>Gibt die empfohlene Mindestanzahl der Zeichen an, die für die jeweilige Social Media Angabe eingegeben werden sollte.

- **bis**:<br>Gibt die empfohlene Maximalanzahl der Zeichen an, die für die jeweilige Social Media Angabe eingegeben werden sollte.

- **Maximale Pixellänge** bzw. **Maximale Zeichenlänge**:<br>Gibt die maximale Anzahl der Zeichen an, die für die jeweilige Social Media Angabe eingegeben werden dürfen.

#### Verwendung der Konfiguration
Die hier hinterlegte Konfiguration dient als Grundlage für die Darstellung der Social Media Felder.

Weitere Informationen zu den Social Media Feldern findest du unter:
[SEO Professional » SEO Einstellungen » Social Media](./../../../200-seo-settings/500-social-media/__de.md)

[sub]
