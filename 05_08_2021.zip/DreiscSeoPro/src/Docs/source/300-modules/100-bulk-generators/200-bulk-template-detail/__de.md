[title]: <>(Eigene Bulk Templates erstellen und bestehende bearbeiten)
[menuTitle]: <>()
[url]: <>()

# Eigene Bulk Templates erstellen und bestehende bearbeiten
In diesem Abschnitt der Anleitung beschreiben wir, wie man eigene Templates erstellt sowie bestehende Templates bearbeitet.

[toc]

## Voraussetzung
Als Voraussetzung für diese Anleitung solltest du dir zunächst einmal die [Allgemeine Informationen zu den Bulk Generatoren sowie die Erste Schritte](./../100-general-info/__de.md) anschauen. Hier wird u.a. auch beschrieben, wie du in die Konfigurationsoberfläche gelangst.

## Einstellungen der Bulk Templates
Bei der Konfiguration der Templates stehen die folgenden Einstellung zur Verfügung:

- **Name**<br>Definiert den internen Namen für das Template. Bei den von uns vorinstallierten Templates findest du hier Bezeichnungen wie `dreiscSeoBulkProduct.defaultTemplates.metaTitle.productName`. Hierbei handelt es sich lediglich um ein Textbaustein, sodass wir den Namen mehrsprachig zur Verfügung stellen können. Legst du eigene Templates an, so kann hier eine ganz normale Bezeichnung als Name hinterlegt werden.

- **Vorschau-Produkt**<br>Hierbei handelt es sich um eine Auswahl, die ausschließlich für den `Produkt Bulk Generator` zur Verfügung steht. Erst wenn du hier ein Produkt ausgewählt hast, wird unten die entsprechende Vorschau des Templates angezeigt. Die Auswahl des Vorschau-Produkts wird nicht gespeichert. D.h., dass entsprechend bei jeder Bearbeitung des Templates ein Produkt ausgewählt werden muss, wenn eine Vorschau erwünscht ist.

- **Leerzeichen zwischen HTML-Tags entfernen**<br>Ist diese Option aktiv, so werden Leerzeichen zwischen den HTML Tags entsprechend entfernt. Hierbei wird der Twig Filter spaceless auf das gesamte Template angewandt.<br><br>Weitere Informationen zu diesem Filter findest du unter:<br>[https://twig.symfony.com/doc/3.x/filters/spaceless.html](https://twig.symfony.com/doc/3.x/filters/spaceless.html)

- **Template**<br>Diese Option beherbergt das eigentiche Template.

- **Vorschau**<br>In diesem Bereich wird die Vorschau des Templates angezeigt. Diese wird aktualisiert, sobald du eine Anpassung an dem Template durchführst. (Beachte bei dem Produkt Bulk Generator hierbei die Option `Vorschau-Produkt`)

![Einstellungen der Bulk Templates](./lightbox/einstellungen-der-bulk-templates.png)

## Allgemeine Informationen zu dem Template-Code
Um eine maximale Flexibilität bei Generierung der Template zu gewährleisten, haben wir uns dazu entschieden, die Templates auf Basis von Twig zu gestalten. Hierbei handelt es sich um die Template Engine, die auch bei der Gestaltung der Storefront Themes zum Einsatz kommt. Um also eigene Templates zu erstellen, ist es erforderlich, dass du zumindest die Grundlagen dieser Engine erlernst oder aber entsprechend deine Shopware Agentur mit der Erstellung beauftragst.

Solltest du dich dazu entscheiden hier einen Einstieg zu finden und dich selbst ans Werk zu machen, so legen wir dir den folgenden Getting started Guide ans Herz:

[https://twig.symfony.com/doc/3.x/templates.html](https://twig.symfony.com/doc/3.x/templates.html)

Des Weiteren findest du in unserer Dokumentation einen [Exkurs für die wichtigsten Code Snippets](./../300-exkurs-die-wichtigsten-code-snippets/__de.md) sowie einen [Exkurs für die Verwendung von Zusatzfeldern in Bulk Templates](./../400-exkurs-custom-fields/__de.md)

## Verfügbare Variablen für das Template
Zur Gestaltung der Templates stehen dir eine Reihe von Variablen zur Verfügung, die du innerhalb der Templates nutzen kannst. (Eine genauere Auflistung findest du unten) Um diese komfortabel nutzen zu können, kannst du dir diese mit einem Klick auf die Auswahlbox `Variable hinzufügen` anzeigen und mit einem weiteren Klick auf die jeweilige Variable entsprechend im Template einfügen.

![Variable hinzufügen](./lightbox/variable-hinzufuegen.png)

### Live Template Variablen und Autoload-Variablen
Neben den normalen Variablen existieren auch sogenannte Live Template Variablen. Diese erkennst du daran, dass sie am Anfang sowie am Ende jeweils zwei Rautezeichen aufweisen, wie bspw. `##shopName##`. Diese Variablen werden erst in der Storefront aufgelöst, da erst hier der Context feststeht. Im Fall des Shopnamens also der Verkaufskanal über den die Seite aufgerufen wurde. Ein weiteres Beispiel für eine Live Template Variable wäre bspw. der Preis eines Produkts. Dieser kann pro Kunde, Shop, Rabatt usw. ganz unterschiedlich sein. Für die Adminstration heißt das, dass hier nach der Generierung noch `##VARIABLEN_NAME##` zu sehen ist.

In der Auswahl der verfügbaren Variablen findest du teilweise Variablen mit einem `[↯]`-Zeichem im Pfad wie bspw. `(product.manufacturer[↯].translated.name)`. Dies kennzeichnet lediglich, dass der Teil dieser Variable nur dann geladen wird, wenn dieser im Template definiert wurde. Nutzt du im o.g. Beispiel also `product.manufacturer` im Template, so werden auch alle Herstellerinformationen des Produkts geladen.

### Variablen für Produkte
Für den `Produkt Bulk Generator` stehen die folgenden Variablen zur Auswahl:

- **isVariant** » Gibt an, ob es sich um eine Variante handelt
- **product** » Beinhaltet die Daten des aktuellen Produkts (ProductEntity)
    - **product.id** » Id des Produkts
    - **product.translated.name** » Name des Produkts
    - **product.translated.description** » Beschreibung des Produkts
    - **product.translated.keywords** » Keywords / Schlüsselwörter
    - **product.productNumber** » Produktnummer
    - **product.manufacturerNumber** » Herstellernummer
    - **product.manufacturer.id** » Id des Herstellers
    - **product.manufacturer[↯].translated.name** » Name des Herstellers
    - **product.manufacturer[↯].translated.description** » Beschreibung des Herstellers
    - **product.ean** » EAN Nummer
    - **product.restockTime** » Wiederauffüllzeit in Tagen
    - **product.deliveryTime[↯].translated.name** » Lieferzeit
    - **product.markAsTopseller** » Produkt hervorheben [if-Beispiel]
    - **product.isCloseout** » Abverkauf [if-Beispiel]
    - **product.shippingFree** » Versandkostenfrei [if-Beispiel]
    - **product.stock** » Lagerbestand
    - **product.availableStock** » Verfügbarer Bestand
    - **product.minPurchase** » Mindestabnahme
    - **product.maxPurchase** » Maximalabnahme
    - **product.purchaseSteps** » Staffelung
    - **product.packUnit** » Verpackungseinheit
    - **product.purchaseUnit** » Verkaufseinheit
    - **product.referenceUnit** » Grundeinheit
    - **product.weight** » Gewicht
    - **product.width** » Breite
    - **product.height** » Höhe
    - **product.length** » Länge
    - **product.releaseDate.date** » Erscheinungsdatum
    - **product.properties[↯]** » Eigenschaften des Produkts [if-Beispiel]
        - *Beispiel für eine Implementierung unter "Produktname + Ausgabe der Produkteigenschaften" (Meta Beschreibung)*
        - **product.properties[n].translated.name** » Name der Eigenschaft (bspw.: Grün)
        - **product.properties[n].groupId** » Id der Eigenschaftsgruppe
        - **product.properties[n].group.translated.name** » Name der Eigenschaftsgruppe (bspw. Farbe)
    - **product.options[↯]** » Varianten-Eigenschaften [if-Beispiel]
        - *Beispiel für eine Implementierung unter "Produktname [+ Variantenoptionen bei Varianten]" (Meta Titel)
        - **product.options[n].translated.name** » Name der Varianteneigenschaft (bspw.: M)
        - **product.options[n].group.translated.name** » Name der Gruppe der Varianteneigenschaft (bspw.: Größe)
    - **product.tax.taxRate** » Steuersatz des Produkts
- **productSeo** » Beinhaltet die aufbereiteten SEO Einstellungen des 
    - **productSeo.metaTitle** » Meta Titel des Produkts
    - **productSeo.isInheritedMetaTitle** » Meta Titel des Produkts wurde vererbt [if-Beispiel]
    - **productSeo.metaDescription** » Meta Beschreibung des Produkts
    - **productSeo.isInheritedMetaDescription** » Meta Beschreibung des Produkts wurde vererbt [if-Beispiel]
    - **productSeo.url** » URL des Produkts
    - **productSeo.isInheritedUrl** » URL des Produkts wurde vererbt [if-Beispiel]
- **mainCategory** »Beinhaltet die Daten der Hauptkategorie des Produkts*¹ (CategoryEntity)<br>\(Bitte beachten: Diese Variable steht nur bei der SEO Einstellung SEO-URL zur Verfügung)
    - **mainCategory.id** » Id der Hauptkategorie des Produkts
    - **mainCategory.translated.name** » Name der Hauptkategorie des Produkts
    - **mainCategory.translated.description** » Beschreibung der Hauptkategorie des Produkts
    - **mainCategory.translated.breadcrumb** » Breadcrumb der Hauptkategorie des Produkts
    - **mainCategory.type** » Kategory-Typ der Hauptkategorie des Produkts
- **mainCategorySeo** » Beinhaltet die aufbereiteten SEO Einstellungen der Hauptkategorie des Produkts*¹<br>\(Bitte beachten: Diese Variable steht nur bei der SEO Einstellung SEO-URL zur Verfügung)
    - **mainCategorySeo.metaTitle** » Meta Titel der Hauptkategorie
    - **mainCategorySeo.isInheritedMetaTitle** » Meta Titel der Hauptkategorie wurde vererbt [if-Beispiel]
    - **mainCategorySeo.metaDescription** » Meta Beschreibung der Hauptkategorie
    - **mainCategorySeo.isInheritedMetaDescription** » Meta Beschreibung der Hauptkategorie wurde vererbt [if-Beispiel]
    - **mainCategorySeo.url** » URL der Hauptkategorie
    - **mainCategorySeo.isInheritedUrl** » URL der Hauptkategorie wurde vererbt
- **##productPrice##** » Diese Live Template Variable gibt den aktuellen Preis an. (Kann nicht für die SEO Einstellung SEO-URL verwendet werden)

`*¹ Hauptkategorie des Produkts: Hauptkategorie, die in den Artikelstammdaten unter "Canonical Urls" für den jeweiligen Vertriebskanal ausgewählt wurde.`

### Variablen für Kategorien
Für den `Kategorie Bulk Generator` stehen die folgenden Variablen zur Auswahl:

- **category** » Beinhaltet die Daten der Kategorie (CategoryEntity)
    - **category.id** » Id der Kategorie des Produkts
    - **category.translated.name** » Name der Kategorie
    - **category.translated.description** » Beschreibung der Kategorie
    - **category.translated.breadcrumb** » Breadcrumb der Kategorie
- **categorySeo** » Beinhaltet die aufbereiteten SEO Einstellungen der Kategorie
    - **categorySeo.metaTitle** » Meta Titel der Kategorie
    - **categorySeo.isInheritedMetaTitle** » Meta Titel der Kategorie wurde vererbt [if-Beispiel]
    - **categorySeo.metaDescription** » Meta Beschreibung der Kategorie
    - **categorySeo.isInheritedMetaDescription** » Meta Beschreibung der Kategorie wurde vererbt [if-Beispiel]
    - **categorySeo.url** » URL der Kategorie
    - **categorySeo.isInheritedUrl** » URL der Kategorie wurde vererbt
- **categoryParentSeo** » Beinhaltet die aufbereiteten SEO Einstellungen der direkten Eltern-Kategorie (category.parent)
    - **categoryParentSeo.metaTitle** » Meta Titel der Eltern-Kategorie
    - **categoryParentSeo.isInheritedMetaTitle** » Meta Titel der Eltern-Kategorie wurde vererbt [if-Beispiel]
    - **categoryParentSeo.metaDescription** » Meta Beschreibung der Eltern-Kategorie
    - **categoryParentSeo.isInheritedMetaDescription** » Meta Beschreibung der Eltern-Kategorie wurde vererbt [if-Beispiel]
    - **categoryParentSeo.url** » URL der Eltern-Kategorie
    - **categoryParentSeo.isInheritedUrl** » URL der Eltern-Kategorie wurde vererbt
- **parentCategories** » Beinhaltet die Daten der Eltern-Kategorien der aktuellen Kategory (CategoryEntity[])
- **childCategories** » Beinhaltet die Daten der Kind-Kategorien der aktuellen Kategory (CategoryEntity[])

### Allgemeine Variablen
Die folgenden Variablen stehen sowohl beim `Produkt Bulk Generator` als auch beim `Kategorie Bulk Generator` zur Auswahl:

- **language** » Beinhaltet das LanguageEntity des aktuellen Generators
    - **language.locale.code** » Locale Code der Sprache (bspw.: de-DE)
- **systemDefaults**
    - **systemDefaults.LANGUAGE_SYSTEM** » Id der Standard-Sprache des Shops
    - **systemDefaults.CURRENCY** » Id der Standard-Währung des Shops
- **##shopName##** » Diese Live Template Variable gibt den Shopname des aktuellen Context an. (Kann nicht für die SEO Einstellung SEO-URL verwendet werden)

## Beispiel: Produktname + ausgewählte Eigenschaft ausgeben
In dem folgenden Template Beispiel werden die Produkt Eigenschaft iteriert und nach der Eigenschaft Farbe gesucht. 

```twig
{# Set the variables initial #}
{% set value = [] %}
{% set color = '' %}

{# Add the product properties #}
{% set groupNames = [] %}
{% set propertiesGroupedByProperties = [] %}
{# Iterate the product properties and try to find the group name "Farbe" #}
{% if product.properties is defined %}
	{% for property in product.properties %}
	    {% set groupId = property.groupId %} 
	    {% set groupName = property.group.translated.name %} 
	    {% set propertyName = property.translated.name %}
	    
	    {% if 'Farbe' == groupName %}
	        {% set color = propertyName %}
	    {% endif %}
	    
    {% endfor %}
{% endif %}

{% set value = value|merge([product.translated.name]) %}

{% if color is not empty %}
    {% set value = value|merge(["in der Farbe"]) %}
    {% set value = value|merge([color]) %}
{% endif %}

{{ value|join(' ') }}
```
Ergebnis:
```html
[Produktname] in der Farbe [Farbwert]
```
[sub]
