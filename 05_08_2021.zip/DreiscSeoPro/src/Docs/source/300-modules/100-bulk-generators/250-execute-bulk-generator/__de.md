[title]: <>(Bulk Generator ausführen)
[menuTitle]: <>()
[url]: <>()

# Bulk Generator ausführen
In diesem Guide beschreiben wir dir, wie du den Bulk Generator startest bzw. dieser automatisch gestartet wird.

[toc]

## 1. Möglichkeit: Automatische Generierung durch Speicherung
Standardmäßig werden die Bulk Generatoren immer dann ausgeführt, wenn ein neues Produkt, Kategorie usw. angelegt oder aber Anpassungen an diesem vorgenommen werden. In diesem Fall wird nach der eigentlichen Speicherung geschaut, ob ein Bulk Template für das jeweilige Element definiert ist und anschließend in diesem Fall ausgeführt.

Ist diese automatische Generierung nicht gewünscht, so kann diese in den Einstellungen abgeschaltet werden. Weitere Informationen hierzu findest du unter [SEO Professional » Weitere Einstellungen » SEO Einstellungen](./../../900-settings/100-seo-settings/__de.md#bulk-generatoren-beim-speicherprozess-starten)

**Wichtiger Hinweis**: Der Prozess wird nicht ausgeführt, wenn bei bestehenden Elementen lediglich die "Speichern"-Schaltfläche betätigt wird, da der Shopware Speicherprozess erst angestoßen wird, wenn sich ein Wert verändert hat.

## 2. Möglichkeit: Bulk Generatoren über die Administration starten
Sowohl im Produkt- als auch im Kategorie Bulk Generator Modul findest du oben in der Smart Bar die Schaltfläche ``Generator starten``. Hierüber ist es möglich den Bulk Generator für alle Produkte bzw. alle Kategorien direkt aus der Adminstration heraus zu starten.

![Generator starten Schaltfläche](./lightbox/generator-starten-button.png)

## 3. Möglichkeit: Bulk Generatoren per Shopware CLI starten
Um die Bulk Generatoren für alle Produkte, Kategorien usw. per Shopware CLI durchlaufen zu lassen, werden die folgenden Shopware CLI Befehle bereitgestellt, die per Shell ausgeführt werden können:

```bash
#Produkt Bulk Generator starten
bin/console dreisc-seo:bulk-generator:product
```

```bash
#Kategorie Bulk Generator starten
bin/console dreisc-seo:bulk-generator:category
```

Diese Befehle können bei Bedarf - wie jeder andere Shopware CLI Befehl auch - in den Server Cronjobs mit aufgenommen werden.

[sub]
