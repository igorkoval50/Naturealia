[title]: <>(Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte)
[menuTitle]: <>()
[url]: <>()

# Allgemeine Informationen zu den Bulk Generatoren / Erste Schritte
In diesem Abschnitt der Anleitung werden die ersten Schritte mit den Bulk Generatoren, sowie wichtige allgemeine Informationen beschrieben.

[toc]

## Allgemeine Funktionsweise der Bulk Generatoren
Die grundsätzliche Idee hinter den Bulk Generatoren ist, dass auf Kategoriebasis Templates hinterlegt werden können, die bestimmen, wie sich SEO Einstellungen wie die URL oder aber der Meta Titel eines Produkts bzw. Kategorie zusammensetzt.

Hierbei ist es möglich eine Vererbung an die jeweiligen Unterkategorien zu aktivieren. So wird das jeweilige Template auch für die Unterkategorien bzw. Produkte der Unterkategorien angewand. Diese Vererbung wird erst dann unterbrochen, wenn für eine bestimmte Unterkategorie ein eigenes Template hinterlegt wird.

## Vorbereitung
Öffne zur Administration der Bulk Generatoren das Produkt- bzw. Kategorie Bulk Generator Modul. Dieses findest du unter dem Menüpunkt `SEO Professional » Produkt Bulk Generator` bzw. `SEO Professional » Kategorie Bulk Generator`.

![Bulk Generator Module im Admin](./img/bulk-module-shopware-admin.png)

## Übersicht der Adminstration
Die Adminstration der jeweiligen Module ist wie folgt aufgebaut:

- **Bereich A (In der Abbildung blau markiert)**<br>In diesem Bereich des Moduls findet die Auswahl der SEO Einstellung statt, für die ein Generator Template hinterlegt werden soll. Die Auswahl des `Verkaufskanals` steht hierbei nur in Verbindung mit der SEO Einstellung `SEO-URL` zur Verfügung, da diese im Gegensatz zu bspw. dem Meta Titel pro Verkaufskanal gespeichert wird.

- **Bereich B (In der Abbildung rot markiert)**<br>Dieser Bereich dient nur Auswahl der Kategorie, für die ein neues Bulk Generator Template hinterlegt bzw. ein bestehendes bearbeitet werden soll. 

- **Bereich C (In der Abbildung grün markiert)**<br>Nachdem die Auswahl der Bereiche A und B abgeschlossen ist, wird die Detailansicht der Auswahl geladen. Da zu Beginn noch keine Template hinterlegt sind, wird hier zunächst nur ein Hinweis ausgegeben. 

![Übersicht der Adminstration](./lightbox/bereiche-der-administration.png)

## Bulk Generator Template hinterlegen
Nachdem, wie oben beschrieben, die gewünschte SEO Einstellung sowie Kategorie ausgewählt wurde, kann das eigene Template hinterlegt werden. Klicken Sie hierzu zunächst auf die Schaltfläche `Bulk Template hinterlegen`.

![Bulk Template hinterlegen](./img/bulk-template-hinterlegen.png)

## Bulk Einstellungen
Zur Einstellung des jeweiligen Bulk Generators stehen die folgenden Optionen zur Verfügung:

- **Wert überschreiben**<br>Standardmäßig werden die SEO Einstellung durch den Bulk Generator nur dann hinterlegt, wenn die jeweilige SEO Einstellung leer ist. Ist diese Option aktiv, so greift das Bulk Template immer, sodass bestehende Werte entsprechend überschrieben werden.<br><br>`Sonderfall SEO-URL:` Bei den URLs ist zu beachten, dass die durch den Shopware Standard generierten URLs ebenfalls als "leere Einstellung" angesehen werden. Die Standard SEO Urls werden also entsprechend auch dann überschrieben, wenn diese Option nicht aktiv ist.

- **Template vererben**<br>Standardmäßig wird ein Template immer nur für die aktuelle Kategorie hinterlegt. Somit greift ein Template immer nur für die Kategorie bzw. bei dem Produkt Bulk Generator für alle Produkte der jeweiligen Kategorie. Ist diese Option aktiv, so wird das Template auch an die Unterkategorien weitervererbt, sodass das jeweilige Template auch für diese Kategorien greift.

- **Bulk Template**<br>Diese Option bestimmt, welches Template für die aktuell Kategorie genutzt werden soll. Weitere Informationen zu den Template finden Sie weiter unten.

- **Priorität**<br>Diese Option steht ausschließlich für den `Produkt Bulk Generator` zur Verfügung und ist nur dann relevant, wenn ein Produkt mehreren Katgorien zugewiesen ist und diesen jeweils Bulk Generator Templates über dieses Tool zugewiesen wurden. In diesem Fall entscheidet die Höhe des Prioritätswerts, welche Bulk Generator Konfiguration für das jeweilige Produkt verwendet werden soll. Hierbei gilt: Es wird die Bulk Konfiguration verwendet, bei dem der Wert des Feldes `Priorität` am höchsten ist. 

![Bulk Einstellungen](./img/bulk-einstellungen.png)

## Verfügbare Bulk Templates
In diesem Bereich kannst du neue Templates erstellen sowie bestehende Templates bearbeiten oder löschen. Klicke zum Hinzufügen eines neuen Templates auf `Neues Bulk Template erstellen`. Zum Bearbeiten eines Templates reicht es, wenn du auf den Beschreibungstext klickst oder aber über das Contextmenü den Eintrag `Editieren` nutzt. Möchtest du ein Template löschen, so funktioniert dies ebenfalls über das Contextmenü unter `Löschen`. Alternativ können mehrere links angehakt und über das `Mülleimer-Icon` oben rechts zusammen gelöscht werden.

![Verfügbare Bulk Templates](./img/verfuegbare-bulk-templates.png)

## Bulk Templates erstellen und bearbeiten
Um mit den Bulk Generatoren richtig durchzustarten, solltest du dich damit beschäftigen, wie man bestehende Templates bearbeitet sowie neue Templates erstellen kann.

Eine Guide hierzu findest du unter:<br>
[Eigene Bulk Templates erstellen und bestehende bearbeiten](./../200-bulk-template-detail/__de.md)

## Bulk Generator ausführen
Nachdem du die Bulk Templates nach deinen Wünschen definiert hat, muss der Bulk Generator Prozess gestartet werden, sodass die SEO Einstellungen entsprechend hinterlegt werden. 

Wie dies funktioniert erfährst du unter: <br>
[Bulk Generator ausführen](./../250-execute-bulk-generator/__de.md)

[sub]
