[title]: <>(Exkurs: Die wichtigsten Code Snippets)
[menuTitle]: <>()
[url]: <>()

# Exkurs: Die wichtigsten Code Snippets
Wie bereits in dem Artikel [Eigene Bulk Templates erstellen und bestehende bearbeiten](./../200-bulk-template-detail/__de.md) beschrieben, werden Grundkenntnisse in Twig vorausgesetzt, um bestehende Templates zu bearbeiten bzw. eigene zu erstellen.

Eine Übersicht der wichtigsten Code Snippets für Bulk Templates finden Sie in diesem Exkurs

[toc]

## Verwendung von Variablen
Die Ausgabe der Variablen erfolgt immer in eckigen Klammern. Willst du bei einem Produkt Bulk Template also bspw. den Produktnamen ausgeben, so reicht folgendes Snippet:
```twig
{{ product.translated.name }}
```

## Bedingungen in Templates
Bedingungen werden durch `if`-Anweisungen geprüft. Wir definieren also einen Code, der nur ausgeführt wird, wenn die Bedingung erfüllt wird. In dem u.g. Fall prüfen wir bspw., ob das definierte Zusatzfeld definiert ist.

```twig
{% if product.customFields.custom_myfield is defined %}
    {{ product.customFields.custom_myfield }}
{% endif %}
```

Optional kann an dieser Stelle auch eine `else`-Anweisung hinzugefügt werden, die den Code definiert, der ausgeführt wird, wenn die Bedingung nicht zutrifft. In dem u.g. Fall die Ausgabe des Zusatzfeldes, wenn definiert, ansonsten die Ausgabe des Produktnamens.
```twig
{% if product.customFields.custom_myfield is defined %}
    {{ product.customFields.custom_myfield }}
{% else %}
    {{ product.translated.name }}
{% endif %}
```

## Elemente sammeln und anschließend gemeinsam ausgeben
In manchen Fällen macht es Sinn eine Variable aus mehreren Werten zusammenzusetzen und diese anschließend gesammelt auszugeben.

Dies ist bspw. bei dem Standard-Template `Name des Hersteller + Produktname [+ Produktnummer bei Varianten]` für die SEO Einstellung `SEO-URL` der Fall. Hier werden die Bestandteile der URL zunächst gesammelt und anschließend mit einem Slash getrennt ausgegeben.

```twig
{% set url = [] %}

{# Add the manufacturer name #}
{% if product.manufacturer is defined %}
    {% set url = url|merge([product.manufacturer.translated.name]) %}
{% endif %}

{# Add the product name #}
{% set url = url|merge([product.translated.name]) %}

{# Add the product number, if it is a variant #}
{% if isVariant %}
    {% set url = url|merge([product.productNumber]) %}
{% endif %}

{# Convert the array to an string and output. Seperated by slashes #}
{{ url|join('/') }}
```

Hierbei definieren wir zunächst ein `Array`, der all unsere Elemente halten soll.
```twig
{% set url = [] %}
```

Die einzelnen Elemente werden mit dem `merge`-Filter nach und nach hinzugefügt.
```twig
{% set url = url|merge([product.manufacturer.translated.name]) %}
```
```twig
{% set url = url|merge([product.translated.name]) %}
```
```twig
{% set url = url|merge([product.productNumber]) %}
```

Zur Ausgabe wandeln wir den `Array` in mit dem `join`-Filter in eine Zeichenkette um und geben diese aus.
```twig
{{ url|join('/') }}
```

## Weiche für Sprachvarianten
Ein Template kann in der Regel für alle Sprachen verwendet werden. Um trotzdem jeweilige Sprache des aktuellen Context reagieren zu können, kann diese entsprechend abgefragt werden:
```twig
{% if 'de-DE' == language.locale.code %}
    {% set url = url|merge(['unsere-topseller']) %}
{% else %}
    {% set url = url|merge(['our-topseller']) %}
{% endif %}
```

## Weiche für Varianten
Soll bei dem `Produkt Bulk Generator` eine abweichende Logik für Varianten definiert werden, so kann die Variable `isVariant` verwendet werden:
```twig
{% if isVariant %}
{# Enter your code here ... #}
{% endif %}
```

[sub]
