[title]: <>(Exkurs: Zusatzfelder in Bulk Templates einbinden)
[menuTitle]: <>()
[url]: <>()

# Exkurs: Zusatzfelder in Bulk Templates einbinden
In diesem Exkurs erklären wir dir, wie du Zusatzfelder in Bulk Templates nutzen kannst.

[toc]

## Einleitung
Unter den Standard Bulk Templates, die bereits mit SEO Professional vorinstalliert sind, findest du Templates wie `Eigenes Zusatzfeld falls vorhanden, ansonsten Kategoriename`. Bei diesen Templates handelt es sich um Beispiele, die so nicht direkt eingesetzt werden können, da diese auf individuelle Zusatzfelder aufbauen, die zunächst angelegt werden müssen.

So wird in dem o.g. Beispiel Template exemplarisch die Variable `product.customFields.custom_myfield` verwendet. Welche Schritte notwendig sind, um diese einzurichten, wird Thema dieses Exkurses sein.

```twig
{# HINWEIS: Ersetzen Sie **custom_myfield** durch den technischen Namen Ihres Zusatzfeldes #}
{# NOTE: Replace **custom_myfield** with the technical name of your free text field #}
{% if product.customFields.custom_myfield is defined %}
    {{ product.customFields.custom_myfield }}
{% else %}
    {{ product.translated.name }}
{% endif %}
```

## Konfiguration der Zusatzfelder öffnen
Die Konfiguration der Zusatzfelder finden Sie unter `Einstellungen » System » Zusatzfelder`
![Konfiguration der Zusatzfelder](./lightbox/weg-zur-zusatzfeld-konfiguration.png)

## Set auswählen / neu erstellen
Als nächstes muss entsprechend ein neues Set erstellt werden. Klicken Sie hierzu auf `Set anlegen` (Es kann hier später natürlich ein beliebiges Set genutzt werden)

![Neues Set erstellen](./lightbox/neues-set-anlegen.png)

## Set und Felder konfigurieren
Schauen wir uns den Namen der oben verwendeten Variable an (`custom_myfield`), so sehen wir, dass diese mit einem Unterstrich getrennt ist. Der Teil vor dem Unterstrich entspricht dem technischen Namen des Sets. Der Teil nach dem Unterstrich entspricht dem Namen des Zusatzfeldes. 

Entsprechend konfigurieren wir das Set wie folgt und klicken anschließend auf `Speichern`.

![Set konfigurieren](./lightbox/set-konfiguration.png) 

Im unteren Bereich findet die Konfiguration der Felder statt. Hier klicken wir entsprechend auf `Neues Zusatzfeld`.

![Neues Zusatzfeld erstellen](./lightbox/neues-feld-hinzufuegen.png)

Als Konfiguration definieren wir hier die folgenden Werte. <br>**Achtung: Stellen Sie hier sicher, dass zwischen `custom` und `myfield` nur ein Unterstrich ist!**

Abschließend speichern wir die Einstellung über `Hinzufügen` und **müssen auch noch einmal das Set speichern!**

![Beispiel Feld erstellen](./lightbox/beispiel-feld.png)

Rufen wir nun die Details eines Produkts auf, so lässt sich ein Wert für das neue Feld hinterlegen.

![Beispiel Feld erstellen](./lightbox/testfeld.png)

Führen wir nun ein Test des Bulk Templates durch, so sehen wir in der Vorschau, dass der Wert des neuen Zusatzfeldes entsprechend übernommen wird.

![Zusatzfeld in Bulk Template](./lightbox/zusatzfeld-wird-vom-bulk-template-uebernommen.png)

[sub]
