[title]: <>(Produkt- und Kategorie Bulk Generator)
[menuTitle]: <>()
[url]: <>()

# Produkt- und Kategorie Bulk Generator
Über die SEO Bulk Generatoren bist du in der Lage die Shopware SEO Einstellungen der Produkte sowie der Kategorien per Template automatisch zu generieren. Die Templates zum Generieren der SEO Einstellungen können hierbei pro Kategorie definiert werden.

Neben bereits vorbereiteten Beispiel-Templates, können eigene individuelle Templates über die Einstellungen des Moduls erstellt werden. Über die Template Vorschau Funktion können diese während der Erstellung direkt getestet werden, um die Funktionsfähigkeit sicherzustellen.

[sub]
