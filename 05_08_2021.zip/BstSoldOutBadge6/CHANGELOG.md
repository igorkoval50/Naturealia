# 1.0.0
Initial Release of the Plugin

# 1.1.0
Display Soldout Badge on Product Detail Page

# 1.1.1
Fix line break for sold out badge

# 1.2.0
Implement Color-Picker in Plugin Config

# 1.2.1
Fix problem with missing badge on search result page and sliders

# 1.2.2
Change logic to determine frontend for badge display

# 1.2.3
Fixing an error when a sold out product is added to the shopping cart

# 1.3.0
Add a new snippet for the display of the info text in the badge that the text per language can be maintained
