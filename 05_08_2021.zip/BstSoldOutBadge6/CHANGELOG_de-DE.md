# 1.0.0
Initial Release des Plugins

# 1.1.0
Anzeige des Soldout Badge auf der Produkt-Detailseite

# 1.1.1
Korrektur fehlender Zeilenumbruchs für Sold-Out Badge

# 1.2.0
Implementierung des Color-Pickers in der Plugin-Konfiguration

# 1.2.1
Problembehebung des fehlenden Badge auf der Suchergebnissseite und im Slider

# 1.2.2
Ändern der Logik zum Bestimmen des Frontend für die Anzeige des Badge

# 1.2.3
Beheben eines Fehlers wenn ein ausverkauftes Produkt in den Warenkorb gelegt wird

# 1.3.0
Hinzufügen eines neuen Snippet für die Anzeige des Infotext im Badge damit der Text pro Sprache gepflegt werden kann
