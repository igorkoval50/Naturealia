<?php
/**
 * NOTICE OF LICENSE
 *
 * @copyright  Copyright (c) 10.03.2020 brainstation GbR
 * @author     Mike Becker<mike@brainstation.de>
 */
declare(strict_types=1);

namespace BstSoldOutBadge6;

use Shopware\Core\Framework\Plugin;

class BstSoldOutBadge6 extends Plugin
{
}