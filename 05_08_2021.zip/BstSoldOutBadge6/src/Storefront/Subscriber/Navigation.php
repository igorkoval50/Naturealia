<?php
/**
 * NOTICE OF LICENSE
 *
 * @copyright  Copyright (c) 01.03.2020 brainstation GbR
 * @author     Mike Becker<mike@brainstation.de>
 */
declare(strict_types=1);

namespace BstSoldOutBadge6\Storefront\Subscriber;

use BstSoldOutBadge6\Struct\ConfigData;
use BstSoldOutBadge6\Struct\SoldOut;
use Doctrine\DBAL\Connection;
use Psr\Log\LoggerInterface;
use Shopware\Core\Content\Product\Events\ProductListingResultEvent;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Content\Product\ProductEvents;
use Shopware\Core\Framework\Adapter\Translation\Translator;
use Shopware\Core\Framework\DataAbstractionLayer\Event\EntityLoadedEvent;
use Shopware\Core\Content\Product\SalesChannel\SalesChannelProductEntity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Shopware\Storefront\Page\Product\ProductPageLoadedEvent;
use Shopware\Storefront\Pagelet\Header\HeaderPageletLoadedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Shopware\Core\Framework\Api\Context\SalesChannelApiSource;

class Navigation implements EventSubscriberInterface
{
    const EXTENSION_NAME = 'BstSoldOutBadge6';

    /** @var EntityRepositoryInterface */
    private $productRepository;

    /** @var SystemConfigService */
    private $systemConfigService;

    /** @var Connection */
    private $connection;

    /** @var Translator */
    private $translator;

    /** @var LoggerInterface */
    private $logger;

    /** @var ConfigData */
    private $config;

    /**
     * Frontend constructor.
     * @param SystemConfigService $systemConfigService
     * @param LoggerInterface $logger
     */
    public function __construct(
        EntityRepositoryInterface $productRepository,
        SystemConfigService $systemConfigService,
        Connection $connection,
        Translator $translator,
        LoggerInterface $logger
    )
    {
        $this->productRepository = $productRepository;
        $this->systemConfigService = $systemConfigService;
        $this->connection = $connection;
        $this->translator = $translator;
        $this->logger = $logger;
    }

    /**
     * @return array
     */
    public static function getSubscribedEvents(): array
    {
        return [
            HeaderPageletLoadedEvent::class => 'onPageLoaded',
            ProductPageLoadedEvent::class => 'onProductLoad',
            ProductEvents::PRODUCT_LOADED_EVENT => 'onProductsLoaded'
        ];
    }

    public function onProductsLoaded(EntityLoadedEvent $event): void
    {
        if (!$this->config) {
            return;
        }

        if ($event->getContext()->getSource() instanceof SalesChannelApiSource) {
            /** @var ProductEntity $productEntity */
            foreach ($event->getEntities() as $productEntity) {
                $this->extendProductEntity($productEntity);
            }
        }
    }

    /**
     * @param SalesChannelContext $context
     * @param boolean $asArray
     * @return ConfigData
     */
    private function getConfigData(SalesChannelContext $context, $asArray = false)
    {
        if (!$this->config) {
            $this->config = new ConfigData($this->systemConfigService, $context);
        }

        if ($asArray) {
            return $this->config->getConfig();
        }

        return $this->config;
    }

    /**
     * @param HeaderPageletLoadedEvent $event
     */
    public function onPageLoaded(HeaderPageletLoadedEvent $event): void
    {
        $event->getPagelet()->addExtension(self::EXTENSION_NAME, $this->getConfigData($event->getSalesChannelContext()));
    }

    /**
     * @param ProductPageLoadedEvent $event
     */
    public function onProductLoad(ProductPageLoadedEvent $event): void
    {
        // configuration not saved already
        if (!$this->config) {
            return;
        }

        /** @var SalesChannelProductEntity $productEntity */
        $productEntity = $event->getPage()->getProduct();
        $this->extendProductEntity($productEntity);
    }

    /**
     * @param $productEntity
     * @throws \Shopware\Core\Framework\Uuid\Exception\InvalidUuidException
     */
    private function extendProductEntity($productEntity)
    {
        $showStatus = ($this->config->showStatus ? $this->config->showStatus : 'stock');

        // get struct for extension
        $soldOutStruct = new SoldOut();

        $isOutOfStock = !($productEntity->getAvailableStock() > 0);
        // check stock for all variants
        if ($productEntity->getParentId() != '') {
            $totalVariantAvailableStock = 0;

            $query = $this->connection->createQueryBuilder()
                ->select('p.id, p.available_stock')
                ->from('product p')
                ->where('p.parent_id = :parent_id')
                ->setParameter('parent_id', Uuid::fromHexToBytes($productEntity->getParentId()));

            if ($result = $query->execute()->fetchAll()) {
                // summarize variants available stock
                foreach ($result as $variant)
                {
                    $totalVariantAvailableStock += $variant['available_stock'];
                }
            }
            $isOutOfStock = !($totalVariantAvailableStock > 0);
        }

        if ($showStatus == 'stock') {
            $soldOutStruct->setIsSoldOut($isOutOfStock);
        } else {
            // not mark as sold out if product is not closed out
            $soldOutStruct->setIsSoldOut($isOutOfStock && $productEntity->getIsCloseout());
        }

        $config = $this->config->getConfig();
        if (empty($config['infoText'])) {
            $config['infoText'] = $this->translator->trans('bst_sold_out_badge.infoText');
        }
        $this->config->setConfig($config);

        $productEntity->addExtension(self::EXTENSION_NAME, $soldOutStruct);
    }
}
