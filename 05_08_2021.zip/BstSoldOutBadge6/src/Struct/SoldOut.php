<?php
/**
 * NOTICE OF LICENSE
 *
 * @copyright  Copyright (c) 16.03.2020 brainstation GbR
 * @author     Mike Becker<mike@brainstation.de>
 */
namespace BstSoldOutBadge6\Struct;

use Shopware\Core\Framework\Struct\Struct;

class SoldOut extends Struct
{
    /** @var boolean */
    protected $isSoldOut;

    /**
     * @return mixed
     */
    public function getIsSoldOut()
    {
        return $this->isSoldOut;
    }

    /**
     * @param mixed $isSoldOut
     */
    public function setIsSoldOut($isSoldOut)
    {
        $this->isSoldOut = $isSoldOut;

        return $this;
    }
}