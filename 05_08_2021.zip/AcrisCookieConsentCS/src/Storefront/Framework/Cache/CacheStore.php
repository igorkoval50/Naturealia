<?php declare(strict_types=1);

namespace Acris\CookieConsent\Storefront\Framework\Cache;

use Acris\CookieConsent\Subscriber\ResponseCacheSubscriber;
use Shopware\Storefront\Framework\Cache\CacheResponseSubscriber;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\HttpCache\StoreInterface;

class CacheStore implements StoreInterface
{
    /**
     * @var StoreInterface
     */
    private $parent;
    /**
     * @var ResponseCacheSubscriber
     */
    private $responseCacheSubscriber;

    public function __construct(
        StoreInterface $parent,
        ResponseCacheSubscriber $responseCacheSubscriber
    ) {
        $this->parent = $parent;
        $this->responseCacheSubscriber = $responseCacheSubscriber;
    }

    public function lookup(Request $request)
    {
        if($request->cookies->has(CacheResponseSubscriber::CONTEXT_CACHE_COOKIE) === true
            && $request->cookies->get(CacheResponseSubscriber::CONTEXT_CACHE_COOKIE)) {
            return $this->parent->lookup($request);
        }

        $acrisRememberCookie = $request->cookies->get('acris_cookie_acc', '');
        $permissionCookie = $request->cookies->get('cookie-preference', '');
        if($permissionCookie || $acrisRememberCookie) {
            $denied = $permissionCookie . "_" . $acrisRememberCookie;
        } else {
            return $this->parent->lookup($request);
        }

        $request->cookies->set(CacheResponseSubscriber::CONTEXT_CACHE_COOKIE, $this->responseCacheSubscriber->generateCacheHash($denied));

        return $this->parent->lookup($request);
    }

    public function write(Request $request, Response $response)
    {
        return $this->parent->write($request, $response);
    }

    public function invalidate(Request $request): void
    {
        $this->parent->invalidate($request);
    }

    /**
     * Cleanups storage.
     */
    public function cleanup(): void
    {
        $this->parent->cleanup();
    }

    /**
     * Tries to lock the cache for a given Request, without blocking.
     *
     * @return bool|string true if the lock is acquired, the path to the current lock otherwise
     */
    public function lock(Request $request)
    {
        return $this->parent->lookup($request);
    }

    /**
     * Releases the lock for the given Request.
     *
     * @return bool False if the lock file does not exist or cannot be unlocked, true otherwise
     */
    public function unlock(Request $request)
    {
        return $this->parent->unlock($request);
    }

    /**
     * Returns whether or not a lock exists.
     *
     * @return bool true if lock exists, false otherwise
     */
    public function isLocked(Request $request)
    {
        return $this->parent->isLocked($request);
    }

    public function purge($url)
    {
        return $this->parent->purge($url);
    }
}
