<?php declare(strict_types=1);

namespace Acris\CookieConsent\Storefront\Controller;

use Acris\CookieConsent\Components\CookiesAcceptService;
use Acris\CookieConsent\Components\CookieService;
use Shopware\Core\Framework\Routing\Annotation\RouteScope;
use Shopware\Core\PlatformRequest;
use Shopware\Core\SalesChannelRequest;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextServiceInterface;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Shopware\Storefront\Controller\StorefrontController;
use Shopware\Storefront\Framework\Routing\RequestTransformer;
use Shopware\Storefront\Page\GenericPageLoader;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @RouteScope(scopes={"storefront"})
 */
class CookieConsentController extends StorefrontController
{
    const COOKIE_STRING_SEPERATOR = "_||_";

    /**
     * @var CookiesAcceptService
     */
    private $cookiesAcceptService;
    /**
     * @var CookieService
     */
    private $cookieService;

    public function __construct(CookiesAcceptService $cookiesAcceptService, CookieService $cookieService)
    {
        $this->cookiesAcceptService = $cookiesAcceptService;
        $this->cookieService = $cookieService;
    }

    /**
     * @Route("/cookie-consent/remember", name="frontend.cookieConsent.remember", options={"seo"="false"}, methods={"GET"}, defaults={"XmlHttpRequest": true})
     */
    public function rememberCookie(Request $request): Response
    {
        /** @var SalesChannelContext $salesChannelContext */
        $salesChannelContext = $request->attributes->get(PlatformRequest::ATTRIBUTE_SALES_CHANNEL_CONTEXT_OBJECT);
        $cookieName = $request->query->get('c');
        $this->cookieService->insertCookieIfNotKnown($salesChannelContext, $cookieName);
        return new JsonResponse(['success' => true]);
    }

    /**
     * @Route("/cookie-consent/accept", name="frontend.cookieConsent.accept", options={"seo"="false"}, methods={"POST"}, defaults={"XmlHttpRequest": true})
     */
    public function accept(Request $request): Response
    {
        $accept = $request->request->get('accept');

        $session = $this->container->get('session');
        $session->set("acrisCookieAccepted", $accept);

        $response = new JsonResponse(['success' => true]);

        $deniedGroups = $this->cookiesAcceptService->getDeniedCookiesFromSession($session, 'acrisCookieGroupsDenied');
        $deniedCookies = $this->cookiesAcceptService->getDeniedCookiesFromSession($session, 'acrisCookiesDenied');
        $this->cookiesAcceptService->setAllowCookies($response, $deniedGroups, $deniedCookies);

        return $response;
    }

    /**
     * @Route("/cookie-consent/allow-cookie-group", name="frontend.cookieConsent.allowCookieGroup", options={"seo"="false"}, methods={"POST"}, defaults={"XmlHttpRequest": true})
     */
    public function allowCookieGroup(Request $request): Response
    {
        $groupId = $request->request->get('groupId');
        $cookieId = $request->request->get('cookieId');
        $allow = $request->request->get('allow');
        $session = $this->container->get('session');

        /** @var SalesChannelContext $salesChannelContext */
        $salesChannelContext = $request->attributes->get(PlatformRequest::ATTRIBUTE_SALES_CHANNEL_CONTEXT_OBJECT);

        $sessionSaveString = "";
        $id = "";
        if($groupId) {
            $id = $groupId;
            $sessionSaveString = 'acrisCookieGroupsDenied';
            $this->cookiesAcceptService->removeCookiesDenyRememberByGroup($session, $groupId, $salesChannelContext->getContext());
        } elseif($cookieId) {
            $id = $cookieId;
            $sessionSaveString = 'acrisCookiesDenied';
        }

        if(!$sessionSaveString || !$id) return new JsonResponse(['success' => false]);

        $denied = $session->get($sessionSaveString, []);
        if($allow && in_array($id, $denied)) {
            unset($denied[$id]);
            $session->set($sessionSaveString, $denied);
        } elseif(!in_array($id, $denied)) {
            $denied[$id] = $id;
            $session->set($sessionSaveString, $denied);
        }

        return new JsonResponse(['success' => true]);
    }

    /**
     * @Route("/cookie-consent/allow-only-functional", name="frontend.cookieConsent.allowOnlyFunctional", options={"seo"="false"}, methods={"POST"}, defaults={"XmlHttpRequest": true})
     */
    public function allowOnlyFunctional(Request $request): Response
    {
        $session = $this->container->get('session');

        /** @var SalesChannelContext $salesChannelContext */
        $salesChannelContext = $request->attributes->get(PlatformRequest::ATTRIBUTE_SALES_CHANNEL_CONTEXT_OBJECT);

        $deniedGroups = $this->cookieService->getNotFunctionalCookieGroupIds($salesChannelContext);

        $session->set('acrisCookieGroupsDenied', $deniedGroups);
        $session->remove('acrisCookiesDenied');

        $response = new JsonResponse(['success' => true]);

        sort($deniedGroups);
        $deniedGroupsString = implode(self::COOKIE_STRING_SEPERATOR, $deniedGroups);
        $this->cookiesAcceptService->setAllowCookies($response, $deniedGroupsString);

        $session->set("acrisCookieAccepted", true);

        return $response;
    }

    /**
     * @Route("/cookie-consent/allow-all", name="frontend.cookieConsent.allowAll", options={"seo"="false"}, methods={"POST"}, defaults={"XmlHttpRequest": true})
     */
    public function allowAll(Request $request)
    {
        $session = $this->container->get('session');

        $session->remove('acrisCookieGroupsDenied');
        $session->remove('acrisCookiesDenied');

        $response = new JsonResponse(['success' => true]);

        $this->cookiesAcceptService->setAllowCookies($response);

        $session->set("acrisCookieAccepted", true);

        return $response;
    }
}
