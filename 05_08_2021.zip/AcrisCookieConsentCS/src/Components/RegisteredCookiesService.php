<?php declare(strict_types=1);
/**
 * ACRIS Shopware Plugin
 * Copyright (c) - ACRIS E-Commerce GmbH
 *
 * Die Urheberrechte verbleiben bei der ACRIS E-Commerce GmbH.
 * Sie dürfen vom Auftraggeber während und nach der Beendigung
 * der Zusammenarbeit ausschließlich für die vereinbarten Zwe-
 * cke verändert werden. Der Auftraggeber ist nicht berechtigt
 * ohne ausdrückliche Zustimmung des Auftragnehmers das Werk zu
 * vervielfältigen und / oder zu verbreiten. Änderungen bzw. Be-
 * arbeitungen von Leistungen des Auftragnehmers, wie insbeson-
 * dere deren Weiterentwicklung durch den Auftragnehmer (Käufer)
 * oder durch für diesen tätige Dritte, sind nur mit ausdrückli-
 * cher Zustimmung der ACRIS E-Commerce GmbH zulässig.
 *
 * Es gelten die AGB der ACRIS E-Commerce GmbH in der aktuell
 * gültigen Fassung.
 */

namespace Acris\CookieConsent\Components;

use Acris\CookieConsent\AcrisCookieConsentCS as AcrisCookieConsent;
use Acris\CookieConsent\Custom\CookieEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Core\System\Snippet\Aggregate\SnippetSet\SnippetSetEntity;
use Shopware\Storefront\Framework\Cookie\CookieProviderInterface;
use Shopware\Core\System\Snippet\SnippetService;

class RegisteredCookiesService
{
    /**
     * @var CookieProviderInterface
     */
    private $cookieProvider;
    /**
     * @var CookieService
     */
    private $cookieService;
    /**
     * @var SnippetService
     */
    private $snippetService;
    /**
     * @var array
     */
    private $snippetSets;
    /**
     * @var EntityRepositoryInterface
     */
    private $snippetSetRepository;
    /**
     * @var EntityRepositoryInterface
     */
    private $cookieGroupRepository;

    public function __construct(CookieProviderInterface $cookieProvider, CookieService $cookieService, SnippetService $snippetService, EntityRepositoryInterface $snippetSetRepository, EntityRepositoryInterface $cookieGroupRepository)
    {
        $this->cookieProvider = $cookieProvider;
        $this->cookieService = $cookieService;
        $this->snippetService = $snippetService;
        $this->snippetSets = [];
        $this->snippetSetRepository = $snippetSetRepository;
        $this->cookieGroupRepository = $cookieGroupRepository;
    }

    public function getKnownShopCookies(SalesChannelContext $salesChannelContext, EntityCollection $availableCookies)
    {
        $functionalCookieGroupId = null;
        foreach ($this->cookieProvider->getCookieGroups() as $cookieGroup) {
            if(array_key_exists('entries', $cookieGroup) === false) {
                // checks if single cookie
                if(array_key_exists('cookie', $cookieGroup) === true) {
                    $orgCookieGroup = $cookieGroup;
                    $cookieGroup = [
                        'entries' => [$cookieGroup]
                    ];
                    if(array_key_exists('snippet_name', $orgCookieGroup) === true) {
                        $cookieGroup['snippet_name'] = $orgCookieGroup['snippet_name'];
                    }
                } else {
                    continue;
                }
            }
            $isRequired = array_key_exists('isRequired', $cookieGroup) && $cookieGroup['isRequired'];
            $cookieGroupId = null;
            if($isRequired && !$functionalCookieGroupId) {
                $functionalCookieGroupId = $this->cookieService->findGroupIdByIdentification($salesChannelContext, AcrisCookieConsent::DEFAULT_FUNCTIONAL_GROUP_IDENTIFICATION);
            } else {
                if(array_key_exists('snippet_name', $cookieGroup) === true && $cookieGroup['snippet_name']) {
                    $cookieGroupResult = $this->cookieGroupRepository->search((new Criteria())->addFilter(new EqualsFilter('identification', $cookieGroup['snippet_name'])), $salesChannelContext->getContext());
                    if($cookieGroupResult->getTotal() == 0) {
                        $cookieGroupId = Uuid::randomHex();
                        $cookieGroupText = $this->getTranslationOfCookieInfos($cookieGroup, $salesChannelContext);
                        $cookieGroupData = [
                            'id' => $cookieGroupId,
                            'identification' => $cookieGroup['snippet_name']
                        ];
                        if(!empty($cookieGroupText)) {
                            $cookieGroupData = array_merge($cookieGroupData, $cookieGroupText);
                        }
                        $this->cookieGroupRepository->create([$cookieGroupData], $salesChannelContext->getContext());
                    } else {
                        $cookieGroupId = $cookieGroupResult->first()->getId();
                    }
                }
            }

            foreach ($cookieGroup['entries'] as $cookie) {
                if(is_array($cookie) === false || array_key_exists('cookie', $cookie) === false || !$cookie['cookie']) {
                    continue;
                }

                if($this->getShopwarePluginCookieDontInsert($cookie['cookie'], $salesChannelContext) === true) {
                    continue;
                }

                if($this->cookieService->isCookieKnownForSalesChannel($cookie['cookie'], $availableCookies, $salesChannelContext->getSalesChannel()->getId(), $salesChannelContext->getContext()) === true) {
                    continue;
                }

                $additionalCookieData = [];
                if($isRequired === true && $functionalCookieGroupId) {
                    $additionalCookieData['cookieGroupId'] = $functionalCookieGroupId;
                } elseif($cookieGroupId) {
                    $additionalCookieData['cookieGroupId'] = $cookieGroupId;
                }
                $cookieText = $this->getTranslationOfCookieInfos($cookie, $salesChannelContext);
                if(!empty($cookieText)) {
                    $additionalCookieData = array_merge($additionalCookieData, $cookieText);
                }
                if(array_key_exists('value', $cookie) && $cookie['value']) {
                    $additionalCookieData['defaultValue'] = (string) $cookie['value'];
                }
                $additionalCookieData['unknown'] = false;
                $additionalCookieData['active'] = true;
                $additionalCookieData['provider'] = 'Shopware Plugin';

                $this->cookieService->insertCookieIfNotKnown($salesChannelContext, $cookie['cookie'], false, $availableCookies, $additionalCookieData, true);
            }
        }
    }

    private function getTranslationOfCookieInfos(array $snippetData, SalesChannelContext $salesChannelContext)
    {
        $snippetName = "";
        if(array_key_exists('snippet_name', $snippetData) === true && $snippetData['snippet_name']) {
            $snippetName = $snippetData['snippet_name'];
        }
        $snippetDescription = "";
        if(array_key_exists('snippet_description', $snippetData) === true && $snippetData['snippet_description']) {
            $snippetDescription = $snippetData['snippet_description'];
        }

        if(!$snippetName) {
            return [];
        }

        $snippetResult = $this->getTranslation($snippetName, 'title', $salesChannelContext);
        if($snippetDescription) {
            $snippetResult = $this->getTranslation($snippetDescription, 'description', $salesChannelContext, $snippetResult);
        }

        return $snippetResult;
    }

    public function getTranslation($snippet, $type, SalesChannelContext $salesChannelContext, $translationMerge = [])
    {
        $snippetsResult = $this->snippetService->getList(1, 25, $salesChannelContext->getContext(), ['translationKey' => [$snippet]], []);

        if(empty($snippetsResult)) {
            $translationMerge[$type] = $snippet;
            return $translationMerge;
        }

        if(empty($this->snippetSets)) {
            $this->snippetSets = $this->snippetSetRepository->search(new Criteria(), $salesChannelContext->getContext());
        }

        if(array_key_exists('data', $snippetsResult) === false || array_key_exists($snippet, $snippetsResult['data']) === false) {
            $translationMerge[$type] = $snippet;
            return $translationMerge;
        }

        if(array_key_exists('translations', $translationMerge) === false) {
            $translationMerge['translations'] = [];
        }

        foreach ($snippetsResult['data'][$snippet] as $snippetData) {
            if(array_key_exists('setId', $snippetData) === false || array_key_exists('value', $snippetData) === false || !$snippetData['value']) {
                continue;
            }
            $isoCode = $this->getIsoCodeBySetId($snippetData['setId']);
            if(!$isoCode) {
                continue;
            }
            $translationMerge['translations'][$isoCode][$type] = $snippetData['value'];
        }
        if(empty($translationMerge['translations'])) {
            $translationMerge[$type] = $snippet;
        }
        return $translationMerge;
    }

    private function getIsoCodeBySetId($setId): string
    {
        /** @var SnippetSetEntity $snippetSet */
        foreach ($this->snippetSets->getElements() as $snippetSet) {
            if($snippetSet->getId() === $setId) {
                return $snippetSet->getIso();
            }
        }
        return "";
    }

    private function getShopwarePluginCookieDontInsert(?string $cookieName, SalesChannelContext $salesChannelContext): bool
    {
        switch ($cookieName) {
            case 'google-analytics-enabled':
                return !$salesChannelContext->getSalesChannel()->getAnalytics() || !$salesChannelContext->getSalesChannel()->getAnalytics()->isActive() || !$salesChannelContext->getSalesChannel()->getAnalytics()->getTrackingId();
        }
        return false;
    }
}
