import AcrisCookieConsentPlugin from './plugin/acris-cookie-consent/acris-cookie-consent.plugin';
import CookieConfigurationPlugin from './plugin/cookie/cookie-configuration.plugin';

window.PluginManager.register('AcrisCookieConsent', AcrisCookieConsentPlugin, '[data-acris-cookie-consent]');
window.PluginManager.register('CookieConfiguration', CookieConfigurationPlugin, '[data-acris-cookie-consent]');
