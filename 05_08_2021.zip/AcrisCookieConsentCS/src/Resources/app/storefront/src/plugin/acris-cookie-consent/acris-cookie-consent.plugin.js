import Plugin from 'src/plugin-system/plugin.class';
import HttpClient from 'src/service/http-client.service';
import Iterator from 'src/helper/iterator.helper';
import DomAccess from 'src/helper/dom-access.helper';
import CookieStorage from 'src/helper/storage/cookie-storage.helper';
import DeviceDetection from 'src/helper/device-detection.helper';

import { COOKIE_CONFIGURATION_UPDATE } from 'src/plugin/cookie/cookie-configuration.plugin';

export default class AcrisCookieConsentPlugin extends Plugin {

    static options = {
        cookiePermissionAcceptButtonSelector: '#cookieConsentAcceptButton',

        cookiePermissionAcceptOnlyFunctionalButtonSelector: '#cookieConsentAcceptOnlyFunctional',

        cookiePermissionAcceptAllButtonSelector: '#cookieConsentAcceptAllButton',

        cookiePermissionActivateModal: '#cookieAcivateModal',

        acceptOnlyFunctionalCookiesUrl: '',

        acceptAllCookiesUrl: '',

        acceptCookieSettingsUrl: '',

        acceptCookieUrl: '',

        cookieGroupCheckboxSelector: '.cookie-setting--switch--group',

        cookieCheckboxSelector: '.cookie-setting--switch--group[data-cookieid]',

        acrisAllowCookie: 'acris_cookie_acc',

        disabledClass: 'is-disabled',

        hasAcceptedClass: 'has--accepted',

        cookiePreference: 'cookie-preference',

        notFunctionalSelector: '.is--not-functional',

        csrfTokenAccept: '',

        csrfTokenAcceptOnlyFunctional: '',

        csrfTokenAcceptAll: '',

        csrfTokenAcceptCookie: '',

        submitEvent: (DeviceDetection.isTouchDevice()) ? 'touchstart' : 'click',

        customLinkSelector: `[href="${window.router['frontend.cookie.offcanvas']}"]`,

        pageReload: false,

        dataLayerCookieNamePrefix: 'acrisCookie.',

        dataLayerCookieIdPrefix: 'acrisCookieUniqueId.',

        dataLayerCookieNameFirstActivatedPrefix: 'acrisCookie.firstActivated.',

        dataLayerCookieIdFirstActivatedPrefix: 'acrisCookieUniqueId.firstActivated.',

        dataLayerCookieStateEventName: 'acrisCookieStateChanged',

        cookieNameLandingPage: 'acris_cookie_landing_page',

        cookieNameLandingReferrer: 'acris_cookie_referrer',

        dontAddToDataLayer: false,

        cookieNameActivatedCookies: 'acris_cookie_first_activated'
    };

    init() {
        this.lastState = {
            active: [],
            inactive: []
        };

        this._client = new HttpClient(window.accessKey, window.contextToken);
        this._collectComponents();
        this.lastState = this.getCurrentCookieState(true);
        this._registerEvents();
        this._openModal();
        this.saveReferrerAndLandingPage();
        this.addCookieStateToDataLayer();
    }

    /**
     * collect all needed components
     *
     * @private
     */
    _collectComponents() {
        this.acceptButton = DomAccess.querySelector(this.el, this.options.cookiePermissionAcceptButtonSelector, false);

        this.acceptOnlyFunctionalButton = DomAccess.querySelector(this.el, this.options.cookiePermissionAcceptOnlyFunctionalButtonSelector, false);
        this.acceptAllButton = DomAccess.querySelector(this.el, this.options.cookiePermissionAcceptAllButtonSelector, false);

        this.cookieGroupCheckboxes = DomAccess.querySelectorAll(this.el, this.options.cookieGroupCheckboxSelector, false);

        this.cookieCheckboxes = DomAccess.querySelectorAll(this.el, this.options.cookieCheckboxSelector, false);
    }

    getCurrentCookieState(initial) {
        const cookiesAccepted = this.checkCookiesAccepted();
        const activeCookieNames = [];
        const inactiveCookieNames = [];

        if(!this.cookieCheckboxes) {
            return;
        }

        Iterator.iterate(this.cookieCheckboxes, (cookieCheckbox) => {
            if(cookieCheckbox.dataset.cookiename) {
                if(initial === true && !cookiesAccepted) {
                    inactiveCookieNames.push(cookieCheckbox.dataset.cookiename);
                } else {
                    if(cookieCheckbox.checked) {
                        activeCookieNames.push(cookieCheckbox.dataset.cookiename);
                    } else {
                        inactiveCookieNames.push(cookieCheckbox.dataset.cookiename);
                    }
                }
            }
        });

        return {
            active: activeCookieNames,
            inactive: inactiveCookieNames
        };
    }

    /**
     * registers all needed event listeners
     *
     * @private
     */
    _registerEvents() {
        if(this.acceptButton) this.acceptButton.addEventListener('click', this.onAcceptCookieSettings.bind(this));
        if(this.acceptOnlyFunctionalButton) this.acceptOnlyFunctionalButton.addEventListener('click', this.onAcceptOnlyFunctionalCookies.bind(this));
        if(this.acceptAllButton) this.acceptAllButton.addEventListener('click', this.onAcceptAllCookies.bind(this));

        if(this.cookieGroupCheckboxes) {
            Iterator.iterate(this.cookieGroupCheckboxes, (cookieGroupCheckBox) => {
                cookieGroupCheckBox.addEventListener('change', this.onChangeCookieGroupCheckbox.bind(this));
            });
        }

        /* from Shopware cookie plugin */
        const { submitEvent, customLinkSelector } = this.options;

        Array.from(document.querySelectorAll(customLinkSelector)).forEach(customLink => {
            customLink.addEventListener(submitEvent, this._handleCustomLink.bind(this));
        });
    }

    /**
     * opens the cookie modal window
     *
     * @private
     */
    _openModal() {
        this.modal = DomAccess.querySelector(this.el, this.options.cookiePermissionActivateModal, false);
        this.cookieAccepted = DomAccess.querySelector(document, '.acris-cookie-consent.has--accepted', false);
        if(this.modal && !this.cookieAccepted) {
            document.getElementById("cookieActivateModalLink").click();
        }
    }

    onAcceptCookieSettings() {
        CookieStorage.setItem(this.options.cookiePreference, '1', '30');
        this.checkCookieBoxes(null, true);
        this.hideCookieNoteContainer();
        this.addCookieStateToDataLayer(true);

        this._client.post(this.options.acceptCookieSettingsUrl, JSON.stringify({'accept': true, '_csrf_token': this.options.csrfTokenAccept}), this.onAcceptCookies.bind(this));
    }

    onAcceptOnlyFunctionalCookies() {
        this.changeNotFunctionalCookiesAndGroups(false);
        this.checkCookieBoxes(null, true);
        this.hideCookieNoteContainer();
        this.addCookieStateToDataLayer();

        this._client.post(this.options.acceptOnlyFunctionalCookiesUrl, JSON.stringify({'_csrf_token': this.options.csrfTokenAcceptOnlyFunctional}), function () { });
    }

    onAcceptAllCookies(){
        this.changeNotFunctionalCookiesAndGroups(true);
        this.checkCookieBoxes(null, true);
        this.hideCookieNoteContainer();
        this.addCookieStateToDataLayer(true);

        this._client.post(this.options.acceptAllCookiesUrl, JSON.stringify({'_csrf_token': this.options.csrfTokenAcceptAll}), this.onAcceptCookies.bind(this));
    }

    onAcceptCookies() {
        if(this.options.pageReload) {
            location.reload();
        }
    }

    onChangeCookieGroupCheckbox(event) {
        var target = event.target,
            enabled = target.checked,
            groupId = target.dataset.groupid,
            cookieId = target.dataset.cookieid,
            cookieName = target.dataset.cookiename;

        if(groupId) {
            this.switchAllCookies(target, groupId, enabled);
        }
        if(cookieName) {
            this.checkCookieBoxes(target);
        }
        this.addCookieStateToDataLayer();

        this._client.post(this.options.acceptCookieUrl, JSON.stringify({
            'allow': enabled,
            'groupId': groupId,
            'cookieId': cookieId,
            '_csrf_token': this.options.csrfTokenAcceptCookie
        }), function () { });
    }

    switchAllCookies(groupEl, groupId, enabled) {
        var cookieCheckboxes = DomAccess.querySelectorAll(this.el, '*[data-groupidcookie="'+groupId+'"]', false);
        this.switchCookieCheckboxes(cookieCheckboxes, enabled);
    }

    changeNotFunctionalCookiesAndGroups (activate){
        var checkboxes = DomAccess.querySelectorAll(this.el, this.options.notFunctionalSelector + " " + this.options.cookieGroupCheckboxSelector, false);
        this.switchCookieCheckboxes(checkboxes, activate);
    }

    switchCookieCheckboxes(cookieCheckboxes, activate) {
        if(cookieCheckboxes !== false) {
            Iterator.iterate(cookieCheckboxes, (cookieCheckbox) => {
                if(activate === true) {
                    cookieCheckbox.checked = true;
                    cookieCheckbox.disabled = false;
                } else {
                    cookieCheckbox.checked = false;
                    if(cookieCheckbox.dataset.groupidcookie) cookieCheckbox.disabled = "disabled";
                }
            });
            this.checkCookieBoxes(cookieCheckboxes);
        }
    }

    checkCookieBoxes(cookieCheckboxes, force) {
        if(cookieCheckboxes === undefined || cookieCheckboxes === false) cookieCheckboxes = null;
        if(force === undefined) force = false;
        if(force === false && !this.checkCookiesAccepted()) return;

        if(cookieCheckboxes === null) cookieCheckboxes = this.cookieCheckboxes;

        if(cookieCheckboxes) {
            Iterator.iterate(cookieCheckboxes, (cookieCheckbox) => {
                if(cookieCheckbox.dataset.cookiename) {
                    if(cookieCheckbox.dataset.cookievalue) {
                        this.enableCookieByNameAndValue(cookieCheckbox.dataset.cookiename, cookieCheckbox.dataset.cookievalue, cookieCheckbox.checked);
                    }
                    this.enableCookieByName(cookieCheckbox.dataset.cookiename, cookieCheckbox.checked);
                }
            });
        }
        this.fireUpdateCookiesEvent();
    }

    checkCookiesAccepted() {
        return CookieStorage.getItem(this.options.acrisAllowCookie);
    }

    enableCookieByNameAndValue(name, value, enabled) {
        if(enabled) {
            const date = new Date();
            date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000));
            window.acrisCookiePrivacy.remeberCookieValue(name, `${name}=${value};expires=${date.toUTCString()};path=/`);
        } else {
            window.acrisCookiePrivacy.denyCookieByName(name);
        }
    }

    enableCookieByName(name, enabled) {
        if(window.acrisCookiePrivacy) {
            if(enabled) {
                window.acrisCookiePrivacy.allowCookieByName(name);
            } else {
                window.acrisCookiePrivacy.denyCookieByName(name);
            }
        }
    }

    fireUpdateCookiesEvent() {
        const currentState = this.getCurrentCookieState(false);
        const updatedCookies = this._getUpdatedCookies(currentState);
        this.lastState = currentState;
        document.$emitter.publish(COOKIE_CONFIGURATION_UPDATE, updatedCookies);
    }

    hideCookieNoteContainer() {
        this.el.classList.add(this.options.hasAcceptedClass);
    }

    /**
     * Prevent the event default e.g. for anchor elements using the href-selector
     *
     * @param event
     * @private
     */
    _handleCustomLink(event) {
        event.preventDefault();

        window.openCookieConsentManager();
    }

    /**
     * Shopware cookie consent: Compare the current in-/active cookies to the initialState and return updated cookies only
     *
     * @param currentState
     * @private
     */
    _getUpdatedCookies(currentState) {
        const { lastState } = this;
        const updated = {};

        if(currentState && currentState.active) {
            currentState.active.forEach(currentCheckbox => {
                if (lastState.inactive.includes(currentCheckbox) === true) {
                    updated[currentCheckbox] = true;
                }
            });
        }

        if(currentState && currentState.inactive) {
            currentState.inactive.forEach(currentCheckbox => {
                if (lastState.active.includes(currentCheckbox)) {
                    updated[currentCheckbox] = false;
                }
            });
        }

        return updated;
    }

    addCookieStateToDataLayer(accepted) {
        let cookies = [],
            checked,
            firstActivated = false,
            cookiesAccepted = this.checkCookiesAccepted() || accepted;
        window.dataLayer = window.dataLayer || [];

        if(this.options.dontAddToDataLayer) {
            return;
        }

        if(!this.cookieCheckboxes) {
            return;
        }

        Iterator.iterate(this.cookieCheckboxes, (cookieCheckbox) => {
            if(cookieCheckbox.dataset.cookiename) {
                if(!cookiesAccepted) {
                    checked = false;
                } else {
                    checked = cookieCheckbox.checked;
                }

                if(checked === true) {
                    firstActivated = this.checkFirstActivated(cookieCheckbox.dataset.cookieid);
                }

                cookies.push({
                    cookieId: cookieCheckbox.dataset.cookiename,
                    enabled: checked,
                    uniqueId: cookieCheckbox.dataset.cookieid,
                    name: cookieCheckbox.dataset.cookietitle,
                    firstActivated: firstActivated
                });
                this.addToDataLayer(this.options.dataLayerCookieNamePrefix + cookieCheckbox.dataset.cookiename, checked);
                this.addToDataLayer(this.options.dataLayerCookieIdPrefix + cookieCheckbox.dataset.cookieid, checked);

                if(firstActivated === true) {
                    this.addToDataLayer(this.options.dataLayerCookieNameFirstActivatedPrefix + cookieCheckbox.dataset.cookiename, true);
                    this.addToDataLayer(this.options.dataLayerCookieIdFirstActivatedPrefix + cookieCheckbox.dataset.cookieid, true);
                }
            }
        });

        window.dataLayer.push({
            'acrisCookieState': cookies
        });

        window.dataLayer.push({'event': this.options.dataLayerCookieStateEventName});
    }

    addToDataLayer(name, value) {
        let singleDataLayerCookie = {};
        singleDataLayerCookie[name] = value;
        window.dataLayer.push(singleDataLayerCookie);
    }

    saveReferrerAndLandingPage() {
        let landingPageUrl = CookieStorage.getItem(this.options.cookieNameLandingPage);
        window.dataLayer = window.dataLayer || [];

        if(!landingPageUrl) {
            document.cookie = this.options.cookieNameLandingPage + "=" + window.location.pathname + window.location.search + ";path=/";
            document.cookie = this.options.cookieNameLandingReferrer + "=" + document.referrer + ";path=/";
        }

        window.dataLayer.push({
            'acrisCookieLandingpage': CookieStorage.getItem(this.options.cookieNameLandingPage),
            'acrisCookieReferrer': CookieStorage.getItem(this.options.cookieNameLandingReferrer)
        });
    }

    checkFirstActivated(cookieId) {
        var cookieIds = [],
            activatedCookiesString = CookieStorage.getItem(this.options.cookieNameActivatedCookies);
        if(activatedCookiesString) {
            cookieIds = activatedCookiesString.split("|");
            if(cookieIds.includes(String(cookieId))) {
                return false;
            }
        }
        cookieIds.push(cookieId);
        activatedCookiesString = cookieIds.join("|");
        document.cookie = this.options.cookieNameActivatedCookies + "=" + activatedCookiesString + ";path=/";
        return true;
    }

    openOffCanvas() {
        window.openCookieConsentManager();
    }
}

window.openCookieConsentManager = function() {
    var cookieNote = DomAccess.querySelector(document, '.acris-cookie-consent.has--accepted', false);
    if(cookieNote) cookieNote.classList.remove("has--accepted");
    var modal = DomAccess.querySelector(document, '#cookieAcivateModal', false);
    if(modal) document.getElementById("cookieActivateModalLink").click();
};
