const { Component } = Shopware;

import template from './acris-cookie-index.html.twig';
import './acris-cookie-index.scss';

Component.register('acris-cookie-index', {
    template
});
