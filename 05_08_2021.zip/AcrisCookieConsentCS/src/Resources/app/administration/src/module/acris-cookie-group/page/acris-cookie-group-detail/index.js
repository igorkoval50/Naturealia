const { Component } = Shopware;
const { Mixin } = Shopware;

import template from './acris-cookie-group-detail.html.twig';

Component.register('acris-cookie-group-detail', {
    template,
    inject: ['repositoryFactory', 'context'],

    mixins: [
        Mixin.getByName('listing'),
        Mixin.getByName('notification'),
        Mixin.getByName('placeholder')
    ],

    data() {
        return {
            item: {},
            itemId: null,
            isLoading: false,
            isSaveSuccessful: false,
            repository: null
        };
    },

    metaInfo() {
        return {
            title: this.$createTitle()
        };
    },

    updated() {
        this.componentUpdated();
    },

    created() {
        this.createdComponent();
    },

    methods: {
        getCookieGroup() {
            this.isLoading = true;
            this.repository
                .get(this.$route.params.id, Shopware.Context.api)
                .then((entity) => {
                    this.item = entity;
                    this.isLoading = false;
                });
        },

        createdComponent() {
            this.repository = this.repositoryFactory.create('acris_cookie_group');
            this.getCookieGroup();
            this.initializeFurtherProductComponents();
        },

        initializeFurtherProductComponents() {
            this.isLoading = false;
        },

        saveFinish() {
            this.isSaveSuccessful = false;
        },

        onSave() {
            const titleSaveError = this.$tc('acris-cookie-group.detail.notificationSaveErrorMessageTitle');
            const messageSaveError = this.$tc(
                'acris-cookie-group.detail.notificationSaveErrorMessage', 0, { title: this.item.title, description: this.item.description }
            );
            const titleSaveSuccess = this.$tc('acris-cookie-group.detail.notificationSaveSuccessMessageTitle');
            const messageSaveSuccess = this.$tc(
                'acris-cookie-group.detail.notificationSaveSuccessMessage', 0, { title: this.item.title, description: this.item.description }
            );

            this.isSaveSuccessful = false;
            this.isLoading = true;

            this.repository
                .save(this.item, Shopware.Context.api)
                .then(() => {
                this.getCookieGroup();
                this.createNotificationSuccess({
                    title: titleSaveSuccess,
                    message: messageSaveSuccess
                });

                this.isLoading = false;
                this.isSaveSuccessful = true;
            }).catch((exception) => {
                this.createNotificationError({
                    title: titleSaveError,
                    message: messageSaveError
                });
                this.isLoading = false;
                throw exception;
            });
        },

        componentUpdated() {
            if (this.item) {
                if(this.titleSelected !== true) {
                    this.userInputValue = this.item.title;
                }
                this.titleSelected = false;

                if(this.descriptionSelected !== true) {
                    this.userInputValue = this.item.description;
                }
                this.descriptionSelected = false;
            }
        },

        onChangeLanguage(languageId) {
            this.getCookieGroup();
        }
    }
});
