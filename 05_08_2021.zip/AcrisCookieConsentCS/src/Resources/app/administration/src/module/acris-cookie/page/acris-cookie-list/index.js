const { Component } = Shopware;
const { Mixin } = Shopware;
const { Criteria } = Shopware.Data;

import template from './acris-cookie-list.html.twig';
import './acris-cookie-list.scss';

Component.register('acris-cookie-list', {
    template,

    inject: ['repositoryFactory', 'context'],

    mixins: [
        Mixin.getByName('listing'),
        Mixin.getByName('notification'),
        Mixin.getByName('placeholder')
    ],

    data() {
        return {
            items: null,
            repository: null,
            isLoading: false,
            showDeleteModal: false,
            total: 0,
            groups: null
        };
    },

    metaInfo() {
        return {
            title: this.$createTitle()
        };
    },

    computed: {
        columns() {
            return [{
                property: 'cookieId',
                inlineEdit: 'string',
                label: 'acris-cookie.list.columnCookieId',
                allowResize: true
            }, {
                property: 'title',
                inlineEdit: 'string',
                label: 'acris-cookie.list.columnTitle',
                allowResize: true
            }, {
                property: 'description',
                inlineEdit: 'string',
                label: 'acris-cookie.list.columnDescription',
                allowResize: true
            }, {
                property: 'cookieGroup',
                inlineEdit: 'string',
                label: 'acris-cookie.list.columnCookieGroup',
                allowResize: true
            }, {
                property: 'provider',
                inlineEdit: 'string',
                label: 'acris-cookie.list.providers',
                allowResize: true
            }, {
                property: 'isDefault',
                inlineEdit: 'boolean',
                label: 'acris-cookie.list.columnDefault',
                allowResize: true
            }, {
                property: 'active',
                inlineEdit: 'boolean',
                label: 'acris-cookie.list.columnActive',
                allowResize: true
            }];
        },

        entityRepository() {
            return this.repositoryFactory.create('acris_cookie');
        },
    },

    methods: {
        getList() {
            this.isLoading = true;
            const criteria = new Criteria(this.page, this.limit);
            criteria.addAssociation('cookieGroup');
            return this.entityRepository
                .search(criteria, Shopware.Context.api)
                .then((result) => {
                    this.items = result;
                    this.total = result.total;
                    this.isLoading = false;
                });
        },

        onDelete(id) {
            this.showDeleteModal = id;
        },

        onCloseDeleteModal() {
            this.showDeleteModal = false;
        },

        onConfirmDelete(id) {
            this.showDeleteModal = false;
            return this.entityRepository.delete(id, Shopware.Context.api).then(() => {
                this.getList();
            });
        },

        onChangeLanguage(languageId) {
            this.getList();
        }
    }
});
