const { Component } = Shopware;
const { StateDeprecated } = Shopware;
const { Mixin } = Shopware;
const { Criteria } = Shopware.Data;

import template from './acris-cookie-detail.html.twig';

Component.register('acris-cookie-detail', {
    template,

    inject: ['repositoryFactory', 'context'],

    mixins: [
        Mixin.getByName('listing'),
        Mixin.getByName('notification'),
        Mixin.getByName('placeholder')
    ],

    data() {
        return {
            cookieGroups: [],
            item: null,
            isLoading: false,
            processSuccess: false,
            repository: null
        };
    },

    metaInfo() {
        return {
            title: this.$createTitle()
        };
    },

    computed: {
        languageStore() {
            return StateDeprecated.getStore('language');
        },
        cookieGroupsRepository() {
            return this.repositoryFactory.create('acris_cookie_group');
        },
    },

    created() {
        this.createdComponent();

    },

    methods: {
        getCookie() {
            this.repository
                .get(this.$route.params.id, Shopware.Context.api)
                .then((entity) => {
                    this.item = entity;
                    if (this.item.unknown === true) {
                        if (!Shopware.State.getters['context/isSystemDefaultLanguage']) {
                            Shopware.State.commit('context/resetLanguageToDefault');
                        }
                    }
                });
        },

        onClickSave() {
            this.isLoading = true;
            const titleSaveError = this.$tc('acris-cookie.detail.notificationSaveErrorMessageTitle');
            const messageSaveError = this.$tc(
                'acris-cookie.detail.notificationSaveErrorMessage', 0, { title: this.item.title, description: this.item.description }
            );
            const titleSaveSuccess = this.$tc('acris-cookie.detail.notificationSaveSuccessMessageTitle');
            const messageSaveSuccess = this.$tc(
                'acris-cookie.detail.notificationSaveSuccessMessage', 0, { title: this.item.title, description: this.item.description }
            );

            if (this.item.unknown) {
                delete this.item.unknown;
            }

            this.repository
                .save(this.item, Shopware.Context.api)
                .then(() => {
                    this.getCookie();
                    this.isLoading = false;
                    this.processSuccess = true;
                    this.createNotificationSuccess({
                        title: titleSaveSuccess,
                        message: messageSaveSuccess
                    });
                }).catch(() => {
                    this.isLoading = false;
                    this.createNotificationError({
                        title: titleSaveError,
                        message: messageSaveError
                });
            });
        },

        saveFinish() {
            this.processSuccess = false;
        },

        createdComponent() {
            this.repository = this.repositoryFactory.create('acris_cookie');
            this.getCookie();
            this.initializeFurtherProductComponents();
        },

        initializeFurtherProductComponents() {
            const criteria = new Criteria(1, 100);

            this.cookieGroupsRepository.search(criteria, Shopware.Context.api).then((searchResult) => {
                this.cookieGroups = searchResult;
            });
            this.isLoading = false;
        },

        onChangeLanguage() {
            this.getCookie();
        },
    }
});
