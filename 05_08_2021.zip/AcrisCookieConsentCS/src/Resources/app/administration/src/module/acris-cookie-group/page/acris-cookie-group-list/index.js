import template from './acris-cookie-group-list.html.twig';
import './acris-cookie-group-list.scss';

const { Component, Mixin } = Shopware;
const { Criteria } = Shopware.Data;

Component.register('acris-cookie-group-list', {
    template,

    inject: ['repositoryFactory'],

    mixins: [
        Mixin.getByName('listing'),
        Mixin.getByName('notification'),
        Mixin.getByName('placeholder')
    ],

    data() {
        return {
            items: [],
            repository: null,
            isLoading: false,
            showDeleteModal: false,
            total: 0
        };
    },


    metaInfo() {
        return {
            title: this.$createTitle()
        };
    },

    computed: {
        columns() {
            return [{
                property: 'title',
                label: 'acris-cookie-group.list.columnTitle',
                routerLink: 'acris.cookie.group.detail',
                allowResize: true
            }, {
                property: 'description',
                label: 'acris-cookie-group.list.columnDescription',
                routerLink: 'acris.cookie.group.detail',
                allowResize: true
            }];
        },

        entityRepository() {
            return this.repositoryFactory.create('acris_cookie_group');
        }
    },

    methods: {
        onDelete(id) {
            this.showDeleteModal = id;
        },

        onCloseDeleteModal() {
            this.showDeleteModal = false;
        },

        onConfirmDelete(id) {
            this.showDeleteModal = false;

            return this.entityRepository.delete(id, Shopware.Context.api).then(() => {
                this.getList();
            });
        },

        getList() {
            this.isLoading = true;
            const criteria = new Criteria(this.page, this.limit);
            return this.entityRepository
                .search(criteria, Shopware.Context.api)
                .then((result) => {
                    this.items = result;
                    this.total = result.total;
                    this.isLoading = false;
                });
        },

        onChangeLanguage(languageId) {
            this.getList();
        }
    }
});
