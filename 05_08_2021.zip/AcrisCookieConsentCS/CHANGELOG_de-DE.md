# 3.0.3
- Behebt ein mögliches Problem in Verbindung mit diversen Drittanbieter Plugins.

# 3.0.2
- Optimize module of cookie group in administration.

# 3.0.1
- Performance Optimierungen

# 3.0.0
- Kompatibilität mit Shopware >= 6.4.0.0.

# 2.8.10
- Verbesserte Kompatibilität mit anderen Plugins beim Öffnen des Cookie Hinweises.

# 2.8.9
- Behebt Probleme, bei dem der Cookie Hinweis durch ein JavaScript Problem beim Akzeptieren der Cookies immer wieder erscheint.
- Beugt Probleme vor, die durch Sonderzeichen verschiedener Art verursacht werden können.

# 2.8.8
- Behebt ein Problem bei dem Cookie von anderen Drittanbieter Plugins nicht automatisch erkannt werden.

# 2.8.7
- Problem mit fehlenden Sprachdaten behoben.

# 2.8.6
- Entfernt den Textbaustein acrisCookieConsent.footerCmsPageLinkPrefixFirst und fügt statt dessen 3 Textbausteine ein acrisCookieConsent.footerCmsPageLinkPrefixFirstFirst, acrisCookieConsent.footerCmsPageLinkPrefixFirstSecond und acrisCookieConsent.footerCmsPageLinkPrefixFirstThird für eine bessere Individualisierbarkeit.
- Entfernt veraltete Textbaustein Services.

# 2.8.5
- Das von Shopware im Standard eingefügte Google Analytics Cookie wird ab sofort nicht mehr hinzugefügt, sofern Google Analytics im Verkaufskanal nicht als aktiv gekennzeichnet wurde oder keine Tracking-ID angegeben wurde.

# 2.8.4
- Behebt ein mögliches Problem bei der spezifischen Änderung von Cookies oder Cookie Gruppen funktionale Cookies löschen können.

# 2.8.3
- Behebt ein Problem bei dem die maximale Zeichenlänge der Cookie-ID auf 255 Zeichen beschränkt ist.

# 2.8.2
- Behebt ein Problem wenn beim erneuten öffnen des Browsers und der Anzeige des Cookie Hinweises wenn dieser bereits akzeptiert wurde. 
- Die Beschreibung der Cookie Gruppen wird ab sofort auch als HTML im Storefront ausgegeben.
- Optimierung der Cache Behandlung im Zusammenspiel mit anderen ACRIS Plugins.

# 2.8.1
- Behebt ein Problem bei dem funktionale Cookies einem Verkaufskanal zugeordnet werden und dies Probleme verursachen kann. 
- Wird die automatische Cookie Erkennung deaktiviert, wird auch keine extra Anfrage an den Server zur Erkennung des Cookies gestellt.
- Die Einstellung "Cookie Einstellungen beim Seitenaufruf aufklappen" zeigt ab sofort die gewünschte Wirkung.
- Cookies von Shopware Plugins werden auch erkannt, wenn die automatische Cookie Erkennung deaktiviert wurde.

# 2.8.0
- Fügt ein neues Cookie "acris_cookie_first_activated" hinzu. Dieses speichert welche Cookies bereits vom Benutzer zum ersten Mala akzeptiert wurden. Das Update ermöglicht es somit den Referrer und die Landing Page korrekt nachträglich an Google Analytics zu übermitteln. Achtung: Es ist ein Update der Tag Manager konfiguration erfordelich, sobald dies bereits für Landing Page und Referrer konfiguriert wurde.

# 2.7.0
- Ergänzung des Google Analytics Conversion-Tracking Cookies _gac. Wichtig: Sofern das Google Analytics Cookie beim Tagmanager für eine zusätzliche Übergabe von Referrer und Landingpage konfiguriert wurde, muss diese ID nun im Tagmanager aktualisiert werden.

# 2.6.1
- Behebt Probleme beim Speichern von HTML Text im Admin Bereich bei Shopware 6.3.x

# 2.6.0
- Fügt die Option für zusätzlich CMS-Seiten Links ein wie z.B. einem Impressum Link. 
- Fügt die Möglichkeit hinzu eine Überschrift im Cookie Hinweis anzuzeigen. 
- Fügt die Möglichkeit ein den Cookie Status nicht in den DataLayer zu übernehmen.

# 2.5.1
- Kompatibilität mit Shopware 6.3.x.

# 2.5.0
- Speichert den Referrer und die erst besuchte Seite der Benutzer in separate Cookies und fügt sie dem DataLayer hinzu.

# 2.4.0
- Ermöglicht es den Button "Cookies akzeptieren" am Ende des Informationstextes anzugeben anstatt ihn als eigenen Button anzuführen.
- Behebt ein Problem beim Laden des Links der Datenschutzseite von den Plugineinstellungen.

# 2.3.0
- Fügt ein neues Event acrisCookieStateChanged zum DataLayer hinzu zur besseren Weiterverarbeitung im Google Tag Manager.
- Fügt die einzelnen Cookies mit den Präfixen acrisCookie bzw. acrisCookieUniqueId zum DataLayer hinzu zur besseren Weiterverarbeitung im Google Tag Manager.  
- Erweitert die Liste der bereits vorab bekannten Cookies.

# 2.2.1
- Fügt zusätzliche Informationen in den DataLayer zur weiteren Nutzung im Google Tag Manager ein.

# 2.2.0
- Fügt die akzeptierten Cookies in den DataLayer ein, damit im Google Tag Manager darauf reagiert werden kann.
- Ermöglicht es beim Akzeptieren der Cookies einen sofortigen Seitenreload durchzuführen.

# 2.1.2
- Behebt ein Problem beim Laden der Cookies auf der Bestellbestätigungsseite.
- Beugt Probleme in der Storefront beim Laden des Cookie-Scripts und in Verbindung mit anderen Plugins vor.
- Fügt ein fehlendes Snippet im Admin Bereich ein.

# 2.1.1
- Erweitert die Liste der bereits vorab bekannten Cookies.

# 2.1.0
- Behebt ein Problem bei dem Google Analytics mehrfach getrackt wird über die Standard Shopware Einbindung.
- Behebt ein Problem, bei dem das Cookie, das gesetzt wird beim Akzeptieren nicht über Javascript verfügbar ist.
- Behebt ein Problem bei unterschiedlichen Tracking Verhalten beim Bestätigen über einen unterschiedlichen Button.
- Optimierung der Regex Cookie Prüfung in der Storefront. 
- Optimierung der Ansicht der Cookies in der Administration.
- Fügt eine zusätzliche Option hinzu den Hinweis erneut zu öffnen nach dem neuen Shopware Standard.

# 2.0.7
- Behebt ein Problem beim Setzen von Cookies für unterschiedliche Verkaufskanäle.

# 2.0.6
- Behebt ein Problem wenn andere Plugins einzelne Cookies in den Cookie Hinweis einfügen.

# 2.0.5
- Behebt ein mögliches Problem beim Hinzufügen von vorab bekannten Cookies.
- Erweitert die Liste der bereits vorab bekannten Cookies.

# 2.0.4
- Kompatibilität mit Shopware >= 6.2.0.
- Umpositionierung des Admin Menü Eintrages.

# 2.0.3
- Behebt Probleme bei der Änderung der Hintergrundfarbe des Cookie Hinweises.
- Optimierung der Vererbung von anderen Themes. 

# 2.0.2
- Behebt ein Problem bei der Erkennung von Cookies von anderen Plugins bei unterschiedlichen Sprachkonfigurationen.

# 2.0.1
- Behebt ein mögliches Problem bei der Aktualisierung des Plugins wenn das Plugin inaktiv oder nicht installiert ist.

# 2.0.0
- Korrekte Funktionsweise in Vebindung mit dem Http-Cache.
- Behebt ein Problem beim Hinzufügen des Standardwerts von Cookies, die von anderen Shopware-Plugins gesetzt werden.
- Behebt ein Problem beim Hinzufügen neuer gefundener Cookies.

# 1.3.2
- Behebt mögliche Probleme beim Update und bei der Deinstallation des Plugins in Verbindung mit niedrigen Datenbank Versionen.

# 1.3.1
- Behebt ein mögliches Problem bei dem SASS Storefront Variablen nicht gefunden werden von Shopware beim Theme kompilieren während der Aktivierung des Plugins.

# 1.3.0
- Berücksichtigt registrierte Cookies von anderen Plugins. Behebt ein Problem in Verbindung mit der Wartungsseite. Verbessert die Anzeige der Cookies in der Administration. Erweitert die Liste der vorab bekannten Cookies.  

# 1.2.1
- Behebt einen Fehler beim Laden einer Cookie Gruppe eines nicht zugeordneten Cookies bei einem HTTP-Request.

# 1.2.0
- Fügt die Möglichkeit hinzu die automatische Cookie Erkennung zu deaktivieren.
- Behebt einen Fehler beim Laden des Cookie Plugins auf der Seite.

# 1.1.2
- Behebt ein Problem beim Laden von Cookies ohne zugewiesener Cookie Gruppe. Erweitert die Liste der bereits vorab bekannten Cookies.

# 1.1.1
- Behebt ein JavaScript Problem beim Einsatz des Internet Explorers.

# 1.1.0
- Fügt die Möglichkeit für die Anzeige eines Modalfensters ein. Fügt ausgenommene Cookies zu der Liste der akzeptierten Cookies hinzu. Behebt Probleme in der Administration bei der erkannte Cookies nicht zuerst für die Standard-Sprache angelegt werden.

# 1.0.1
- Behebt mögliche Java Script Probleme wenn keine nicht funktionalen Cookies vorhanden sind.

# 1.0.0
- Veröffentlichung
