# 3.0.3
- Fixes a possible problem in connection with various third-party plug-ins.

# 3.0.2
- Optimize module of cookie group in administration.

# 3.0.1
- Performance optimisations

# 3.0.0
- Compatibility with Shopware >= 6.4.0.0.

# 2.8.10
- Improved compatibility with other plugins when opening the cookie notice.

# 2.8.9
- Fixes problems where the cookie notice keeps appearing due to a JavaScript problem when accepting cookies.
- Prevents problems that can be caused by special characters of various kinds.

# 2.8.8
- Fixes an issue where cookies from other third-party plugins are not automatically detected.

# 2.8.7
- Fix problem with language missing data.

# 2.8.6
- Removes the acrisCookieConsent.footerCmsPageLinkPrefixFirst text module and inserts 3 text modules instead acrisCookieConsent.footerCmsPageLinkPrefixFirstFirst, acrisCookieConsent.footerCmsPageLinkPrefixFirstSecond and acrisCookieConsent.footerCmsPageLinkPrefixFirstThird for better customisability.
- Removes deprecated snippet services.

# 2.8.5
- The Google Analytics cookie inserted by Shopware in the standard will no longer be added from now on unless Google Analytics has been marked as active in the sales channel or no tracking ID has been specified.

# 2.8.4
- Fixes a possible problem with the specific modification of cookies or cookie groups that can delete functional cookies.

# 2.8.3
- Fixes a problem where the maximum character length of the cookie ID is limited to 255 characters.

# 2.8.2
- Fixes a problem when reopening the browser and displaying the cookie hint if it has already been accepted.
- The description of the cookie groups is now also displayed as HTML in the storefront.
- Optimisation of cache handling in interaction with other ACRIS plugins.

# 2.8.1
- Fixes a problem where functional cookies are assigned to a sales channel and this can cause problems.
- If the automatic cookie recognition is deactivated, no extra request is made to the server to recognise the cookie.
- The setting "Expand cookie settings on page view" now has the desired effect.
- Cookies from Shopware plugins are also recognised if automatic cookie recognition is disabled.

# 2.8.0
- Adds a new cookie "acris_cookie_first_activated". This will save which cookies have already been accepted by the user for the first time. The update thus enables the referrer and landing page to be sent correctly to Google Analytics. Attention: An update of the Tag Manager configuration is required, as soon as this has already been configured for landing page and referrer.

# 2.7.0
- Addition of the Google Analytics Conversion Tracking Cookie _gac. Important: If the Google Analytics cookie was configured in the tag manager for an additional transfer of referrer and landing page, this ID must now be updated in the tag manager.

# 2.6.1
- Solves problems saving HTML text in the admin area of Shopware 6.3.x

# 2.6.0
- Adds the option for additional CMS page links such as an legal notice link.
- Adds the option to show a heading in the cookie hint.
- Adds the option to not transfer the cookie status to the DataLayer.

# 2.5.1
- Compatibility with Shopware 6.3.x.

# 2.5.0
- Saves the referrer and the first visited page of the user in separate cookies and adds them to the DataLayer.

# 2.4.0
- Allows the "Accept Cookies" button to be specified at the end of the information text instead of having it listed as a separate button.
- Fix loading correct privacy link from plugin settings.

# 2.3.0
- Adds a new event acrisCookieStateChanged to the DataLayer for better processing in the Google Tag Manager.
- Adds the individual cookies with the prefixes acrisCookie or acrisCookieUniqueId to the DataLayer for better processing in the Google Tag Manager.
- Extends the list of previously known cookies.

# 2.2.1
- Adds additional Information to the DataLayer for further usage in Google Tag Manager.

# 2.2.0
- Inserts the accepted cookies into the DataLayer so that the Google Tag Manager can react to them.
- Allows an immediate page reload when accepting the cookies.

# 2.1.2
- Solves a problem loading the cookies on the order confirmation page.
- Prevents problems in the storefront when loading the cookie script and in connection with other plugins.
- Inserts a missing snippet in the admin area.

# 2.1.1
- Extends the list of previously known cookies.

# 2.1.0
- Fixes a problem where Google Analytics is tracked multiple times over the default Shopware integration.
- Solves a problem where the cookie that is set when accepting is not available via Javascript.
- Solves a problem with different tracking behavior when confirming via a different button.
- Optimization of the regex cookie check in the storefront. 
- Optimization of the view of the cookies in the administration.
- Adds an additional option to reopen the note according to the new Shopware behaviour.

# 2.0.7
- Solves a problem on set cookies for different sales channels.

# 2.0.6
- Fixes a problem when other plugins insert single cookies into the cookie hint.

# 2.0.5
- Fixes a possible problem when adding previously known cookies.
- Extends the list of previously known cookies.

# 2.0.4
- Compatibility with Shopware >= 6.2.0.
- Repositioning of the Admin Menu entry.

# 2.0.3
- Fixes problems with changing the background color of the cookie hint.
- Optimizes the inheritance from other themes.

# 2.0.2
- Fixes a problem with the recognition of cookies from other plugins with different language configurations.

# 2.0.1
- Fixes a possible problem when updating the plugin if the plugin is inactive or not installed.

# 2.0.0
- Correct functionality with activated Http-Cache.
- Fix a problem on adding the default value of cookies set by other Shopware plugins.
- Solves a problem on automatically adding new cookies.

# 1.3.2
- Fixes possible problems when updating or uninstalling the plugin in connection with low database versions.

# 1.3.1
- Solves a potential problem on SASS variables are not found by Shopware on compiling the storefront theme on plugin activation.

# 1.3.0
- Includes registered cookies from other plugins. Fixes a problem in connection with the maintenance page. Improves the cookie listing view in the administration. Extends the list of known cookies.

# 1.2.1
- Fixes an error on calling a group from a not assigned cookie on request.

# 1.2.0
- Adds the possibility to disable automatic cookie recognition.
- Fixes an error when loading the cookie plugin on the page.

# 1.1.2
- Fixes a problem when loading cookies without assigned cookie group. Extends the list of pre known cookies.

# 1.1.1
- Solves a JavaScript problem when using Internet Explorer.

# 1.1.0
- Inserts the possibility for the display of a modal window. Adds excluded cookies to the list of accepted cookies. Fixes problems in the administration where detected cookies are not created first for the default language.

# 1.0.1
- Fixes possible Java Script problems if no non-functional cookies are present.

# 1.0.0
- Release
